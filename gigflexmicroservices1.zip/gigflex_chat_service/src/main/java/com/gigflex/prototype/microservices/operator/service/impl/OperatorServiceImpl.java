package com.gigflex.prototype.microservices.operator.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.dtob.OperatorAndOrganizationResponse;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import com.gigflex.prototype.microservices.operator.service.OperatorService;
import com.gigflex.prototype.microservices.utility.GigflexResponse;

@Service
public class OperatorServiceImpl implements OperatorService {

	@Autowired
	OperatorRepository operatorRepository;

	@Override
	public String getOperatorAndOrganizationByOperatorCode(String operatorCode) {
		String res = "";
		OperatorAndOrganizationResponse wo = null;
		try {
			JSONObject jsonobj = new JSONObject();
			if (operatorCode != null && operatorCode.trim().length() > 0) {
				List<Object> objlst = operatorRepository
						.getOperatorAndOrganizationByOperatorCode(operatorCode);
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 4) {
							wo = new OperatorAndOrganizationResponse();
							Operator data = (Operator) arr[0];
							wo.setId(data.getId());
							wo.setOperatorCode(data.getOperatorCode());
							wo.setOperatorName(data.getOperatorName());
							wo.setEmailId(data.getEmailId());
							wo.setOrganizationCode(data.getOrganizationCode());
							wo.setOrganizationName((String) arr[1]);
							wo.setTimezone((String) arr[2]);
							wo.setTimeZoneName((String) arr[3]);
						}

					}

					if (wo != null) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wo);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getOperatorAndOrganizationByOperatorCodeByPage(
			String operatorCode, int page, int limit) {
		String res = "";
		OperatorAndOrganizationResponse wo = null;
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (operatorCode != null && operatorCode.trim().length() > 0) {
				List<Object> objlst = operatorRepository
						.getOperatorAndOrganizationByOperatorCode(operatorCode,
								pageableRequest);
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 4) {
							wo = new OperatorAndOrganizationResponse();
							Operator data = (Operator) arr[0];
							wo.setId(data.getId());
							wo.setOperatorCode(data.getOperatorCode());
							wo.setOperatorName(data.getOperatorName());
							wo.setEmailId(data.getEmailId());
							wo.setOrganizationCode(data.getOrganizationCode());
							wo.setOrganizationName((String) arr[1]);
							wo.setTimezone((String) arr[2]);
							wo.setTimeZoneName((String) arr[3]);
						}

					}

					if (wo != null) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wo);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
