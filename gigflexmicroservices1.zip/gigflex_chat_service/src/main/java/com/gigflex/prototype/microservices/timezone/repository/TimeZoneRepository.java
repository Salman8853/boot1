package com.gigflex.prototype.microservices.timezone.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;

public interface TimeZoneRepository extends JpaRepository<TimeZoneDetail, Long> ,JpaSpecificationExecutor<TimeZoneDetail> {
	
	@Query("SELECT t FROM TimeZoneDetail t WHERE t.isDeleted != TRUE")
	public List<TimeZoneDetail> getAllTimeZoneDetail();
	
	
	@Query("SELECT t FROM TimeZoneDetail t WHERE t.isDeleted != TRUE AND t.timeZoneCode = :timeZoneCode")
    public TimeZoneDetail getTimeZoneDetailByTimeZoneCode(@Param("timeZoneCode") String timeZoneCode);
	
	@Query("SELECT t FROM TimeZoneDetail t WHERE t.isDeleted != TRUE")
	public List<TimeZoneDetail> getAllTimeZoneDetail(Pageable pageableRequest);

	@Query("SELECT t FROM TimeZoneDetail t WHERE t.isDeleted != TRUE AND t.id = :id")
	public TimeZoneDetail getTimeZoneDetailById(@Param("id") Long id);

}
