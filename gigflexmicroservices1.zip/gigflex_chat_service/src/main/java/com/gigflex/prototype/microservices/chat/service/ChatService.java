/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.chat.service;

import com.gigflex.prototype.microservices.chat.dtob.ChatDetail;
import com.gigflex.prototype.microservices.chat.dtob.ChatMessage;

/**
 *
 * @author Abhishek
 */
public interface ChatService {
    
    public String sendChatInvitationLink(String userCode,String driveCode); 
    public ChatDetail saveChatMessage(ChatMessage chatMessage);
    public String getChatDetailByConversationFrom(String conversationFrom);
    public String getChatDetailByConversationFromByPage(String conversationFrom,int page, int limit);
    public String getChatDetailByConversationTo(String conversationTo);
    public String getChatDetailByConversationToByPage(String conversationTo,int page, int limit);
    public String getChatDetailBySessionId(String sessionId);
    public String getChatDetailBySessionIdByPage(String sessionId,int page, int limit);

}
