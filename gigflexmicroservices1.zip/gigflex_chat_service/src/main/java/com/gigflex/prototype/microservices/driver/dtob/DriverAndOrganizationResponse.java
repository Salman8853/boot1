package com.gigflex.prototype.microservices.driver.dtob;

public class DriverAndOrganizationResponse {
	
	    private Long id;  

	    private String driverCode;

	    private String name;

	    private String contactNumber;
	    
	    private String emailId;
	
	    private Integer fleetSize;
	
	    private String operatorCode;
	    
	    private String operatorName;

	    private Boolean approveStatus;
	 
	    private String organizationCode;
	    
	    private String organizationName;
	    
	    private String timezone;
	    
	    private String timeZoneName;

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getDriverCode() {
			return driverCode;
		}

		public void setDriverCode(String driverCode) {
			this.driverCode = driverCode;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getContactNumber() {
			return contactNumber;
		}

		public void setContactNumber(String contactNumber) {
			this.contactNumber = contactNumber;
		}

		public String getEmailId() {
			return emailId;
		}

		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}

		public Integer getFleetSize() {
			return fleetSize;
		}

		public void setFleetSize(Integer fleetSize) {
			this.fleetSize = fleetSize;
		}

		public String getOperatorCode() {
			return operatorCode;
		}

		public void setOperatorCode(String operatorCode) {
			this.operatorCode = operatorCode;
		}

		public String getOperatorName() {
			return operatorName;
		}

		public void setOperatorName(String operatorName) {
			this.operatorName = operatorName;
		}

		public Boolean getApproveStatus() {
			return approveStatus;
		}

		public void setApproveStatus(Boolean approveStatus) {
			this.approveStatus = approveStatus;
		}

		public String getOrganizationCode() {
			return organizationCode;
		}

		public void setOrganizationCode(String organizationCode) {
			this.organizationCode = organizationCode;
		}

		public String getOrganizationName() {
			return organizationName;
		}

		public void setOrganizationName(String organizationName) {
			this.organizationName = organizationName;
		}

		public String getTimezone() {
			return timezone;
		}

		public void setTimezone(String timezone) {
			this.timezone = timezone;
		}

		public String getTimeZoneName() {
			return timeZoneName;
		}

		public void setTimeZoneName(String timeZoneName) {
			this.timeZoneName = timeZoneName;
		}
	    
	    
	    
	    
	    
	    

}
