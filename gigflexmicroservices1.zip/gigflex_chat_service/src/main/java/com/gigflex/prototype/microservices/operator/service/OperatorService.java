package com.gigflex.prototype.microservices.operator.service;

public interface OperatorService {
	
	public String getOperatorAndOrganizationByOperatorCode(String operatorCode);
	
	public String getOperatorAndOrganizationByOperatorCodeByPage(String operatorCode,int page, int limit);
	
  

}
