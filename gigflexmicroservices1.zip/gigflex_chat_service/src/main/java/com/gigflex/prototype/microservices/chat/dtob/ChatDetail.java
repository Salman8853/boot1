/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.chat.dtob;

import com.gigflex.prototype.microservices.utility.CommonAttribute;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author Abhishek
 */
@Entity
@Table(name = "chat")
public class ChatDetail extends CommonAttribute implements Serializable {
    
     @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;
     
    @Column(name = "session_id", nullable = false)
    private String sessionId;
     
    @Column(name = "conversation_from", nullable = false)
    private String conversationFrom;
    
    @Column(name = "conversation_to", nullable = false)
    private String conversationTo;
    
    @Column(name = "message_body", nullable = false)
    private String messageBody;
    
    @Column(name = "msg_time", nullable = false)
    private Date msgTime;
    

    public ChatDetail() {
    }

    public ChatDetail(Long id, String sessionId, String conversationFrom, String conversationTo, String messageBody, Date msgTime, Boolean isActive) {
        this.id = id;
        this.sessionId = sessionId;
        this.conversationFrom = conversationFrom;
        this.conversationTo = conversationTo;
        this.messageBody = messageBody;
        this.msgTime = msgTime;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getConversationFrom() {
        return conversationFrom;
    }

    public void setConversationFrom(String conversationFrom) {
        this.conversationFrom = conversationFrom;
    }

    public String getConversationTo() {
        return conversationTo;
    }

    public void setConversationTo(String conversationTo) {
        this.conversationTo = conversationTo;
    }

    public String getMessageBody() {
        return messageBody;
    }

    public void setMessageBody(String messageBody) {
        this.messageBody = messageBody;
    }

    public Date getMsgTime() {
        return msgTime;
    }

    public void setMsgTime(Date msgTime) {
        this.msgTime = msgTime;
    }


  
    @Override
	public String toString() {
		return "Worker [id=" + id + ", sessionId=" + sessionId + ", conversationFrom=" + conversationFrom + ", conversationTo=" + conversationTo
				+ ", messageBody=" + messageBody + ", msgTime=" + msgTime +  "]";
	} 
    
    
    
}
