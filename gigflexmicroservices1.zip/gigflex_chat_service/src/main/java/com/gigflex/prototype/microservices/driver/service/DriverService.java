package com.gigflex.prototype.microservices.driver.service;

public interface DriverService {
	
    public String getDriverAndOrganizationByDriverCode(String driverCode);
	
	public String getDriverAndOrganizationByDriverCodeByPage(String driverCode,int page, int limit);

}
