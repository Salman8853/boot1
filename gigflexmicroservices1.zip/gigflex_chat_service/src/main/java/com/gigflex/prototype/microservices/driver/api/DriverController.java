package com.gigflex.prototype.microservices.driver.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.driver.service.DriverService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/chatservice/")
public class DriverController {

	@Autowired
	private DriverService driverService;

	@GetMapping("/getDriverAndOrganizationByDriverCode/{driverCode}")
	public String getDriverAndOrganizationByDriverCode(
			@PathVariable String driverCode) {
		return driverService.getDriverAndOrganizationByDriverCode(driverCode);
	}

	@GetMapping("/getDriverAndOrganizationByDriverCodeByPage/{driverCode}")
	public String getDriverAndOrganizationByDriverCodeByPage(
			@PathVariable String driverCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String cm = driverService.getDriverAndOrganizationByDriverCodeByPage(
				driverCode, page, limit);

		return cm;
	}

}