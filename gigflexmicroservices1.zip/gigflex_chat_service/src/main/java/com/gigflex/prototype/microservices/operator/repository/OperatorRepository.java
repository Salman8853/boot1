/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.operator.repository;

import java.util.List;

import com.gigflex.prototype.microservices.operator.dtob.Operator;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Abhishek
 */
@Repository
public interface OperatorRepository extends JpaRepository<Operator,Long>,JpaSpecificationExecutor<Operator> {

	@Query("SELECT a,b.organizationName,b.timezone,t.timeZoneName FROM Operator a , Organization b, TimeZoneDetail t WHERE a.isDeleted != TRUE AND a.organizationCode = b.organizationCode AND t.timeZoneCode = b.timezone AND a.operatorCode=:operatorCode")
	public List<Object> getOperatorAndOrganizationByOperatorCode(
			@Param("operatorCode") String operatorCode);

	@Query("SELECT a,b.organizationName,b.timezone,t.timeZoneName FROM Operator a , Organization b, TimeZoneDetail t WHERE a.isDeleted != TRUE AND a.organizationCode = b.organizationCode AND t.timeZoneCode = b.timezone AND a.operatorCode=:operatorCode")
	public List<Object> getOperatorAndOrganizationByOperatorCode(
			@Param("operatorCode") String operatorCode, Pageable pageableRequest);
	
	
	//    @Query("SELECT a FROM Operator a WHERE a.isDeleted != TRUE AND a.operatorCode = :operatorCode")
//    public Operator getOperatorByOperatorCode(@Param("operatorCode") String operatorCode);
//    
//    @Query("SELECT a FROM Operator a WHERE a.isDeleted != TRUE AND a.operatorCode = :operatorCode AND a.organizationCode=:organizationCode")
//    public Operator getOperatorByOperatorCodeAndorganizationCode(@Param("operatorCode") String operatorCode,@Param("organizationCode") String organizationCode);
//    
//    
////    @Query("SELECT a,b.organizationName FROM Operator a,Organization b WHERE a.isDeleted != TRUE AND a.organizationCode = b.organizationCode AND a.operatorCode = :operatorCode")
////    public List<Object> getOperatorByOperatorCodeWithName(@Param("operatorCode") String operatorCode);
//    @Query("SELECT a,b.organizationName FROM Operator a,Organization b WHERE a.isDeleted != TRUE AND a.organizationCode = b.organizationCode AND a.operatorCode = :operatorCode")
//    public Object getOperatorByOperatorCodeWithName(@Param("operatorCode") String operatorCode);
//    
//    @Query("SELECT a,b.organizationName FROM Operator a,Organization b WHERE a.isDeleted != TRUE AND a.organizationCode = b.organizationCode")
//  	public List<Object> getAllOperator();
//	
//    @Query("SELECT a,b.organizationName FROM Operator a,Organization b WHERE a.isDeleted != TRUE AND a.organizationCode = b.organizationCode")
//	public List<Object> getAllOperator(Pageable pageableRequest);
//	
//	@Query("SELECT d FROM Operator d WHERE d.isDeleted != TRUE AND d.id = :id")
//	public Operator getOperatorById(@Param("id") Long id);
//	
//	@Query("SELECT driver FROM Operator driver WHERE driver.isDeleted != TRUE AND driver.emailId = :emailId")
//	public Operator findByEmail(@Param("emailId") String emailId);
//	
//	 @Query("SELECT a,b.organizationName FROM Operator a,Organization b WHERE a.isDeleted != TRUE AND a.organizationCode = b.organizationCode")
//	public List<Object> getOperatorByOrgCode(@Param("organizationCode") String organizationCode);
//	
//	 @Query("SELECT a,b.organizationName FROM Operator a,Organization b WHERE a.isDeleted != TRUE AND a.organizationCode = b.organizationCode")
//	 public List<Object> getOperatorByOrgCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);

}
