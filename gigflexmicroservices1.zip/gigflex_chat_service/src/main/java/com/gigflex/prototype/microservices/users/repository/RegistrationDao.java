/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.users.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.users.dtob.Users;

/**
 *
 * @author abhishek
 */

@Repository
public interface RegistrationDao extends JpaRepository<Users, Long>,JpaSpecificationExecutor<Users> {

//	@Query("SELECT users.userName FROM Users users WHERE users.isDeleted != TRUE AND users.userName = :userName")
//	public String getUserName(@Param("userName") String userName);
//
//	@Query("SELECT ur FROM Users ur  WHERE ur.isDeleted != TRUE AND  ur.userName=:username AND ur.userCode=:usercode AND ur.email=:email")
//	public Users findUserByUsercodeUsernaneEmail(
//			@Param("username") String username,
//			@Param("usercode") String usercode, @Param("email") String email);
//
//
//	@Query("SELECT users FROM Users users WHERE users.isDeleted != TRUE AND users.email = :email")
//	public Users findByEmail(@Param("email") String email);
//
//        @Query("SELECT u  FROM Users u WHERE u.userName = :userName AND u.isVerified= TRUE AND (u.isDeleted = FALSE OR u.isDeleted IS NULL)")
//	public Users getUsersByUserNameAtLogin(@Param("userName") String userName);
//        
//	@Query("SELECT users FROM Users users WHERE users.isDeleted != TRUE AND users.userName = :userName")
//	public Optional<Users> findByUserName(@Param("userName") String userName);
//        
//        @Query("SELECT users FROM Users users WHERE users.isDeleted != TRUE AND users.userCode = :userCode")
//	public Users findByUserCode(@Param("userCode") String userCode);
//
//	@Transactional
//	public Integer deleteByUserCode(String userCode);
//
//	// public Users updateByUserCode(String userCode);
//
//	@Query("SELECT role.roleCode FROM UserRolesMapping role, Users users  WHERE users.isDeleted != TRUE AND role.userCode=users.userCode AND  users.userCode = :userCode")
//	public String getRoleCodeByUserCode(@Param("userCode") String userCode);
//
//	@Query("SELECT role.permissionsCode FROM RolePermissions role, RoleMaster r  WHERE r.isDeleted != TRUE AND r.roleCode=role.roleCode AND  r.roleCode = :roleCode")
//	public String getPermissionsCodeByRoleCode(
//			@Param("roleCode") String roleCode);
//
//
//	@Query("SELECT a FROM Activities a, PermissionsActivities pa, UserRolesMapping urm, RolePermissions rp, Users ur WHERE ur.isDeleted != TRUE AND pa.activitiesCode = a.activitiesCode AND pa.permissionsCode = rp.permissionsCode AND urm.userCode = ur.userCode AND urm.roleCode = rp.roleCode AND  ur.userCode = :userCode")
//	public List<Activities> getActivitiesByUserCode(
//			@Param("userCode") String userCode);
//
//	@Query("SELECT a FROM Activities a, PermissionsActivities pa WHERE pa.isDeleted != TRUE AND pa.activitiesCode=a.activitiesCode AND  pa.permissionsCode = :permissionsCode")
//	public List<Activities> getActivitiesByPermissionsCode(
//			@Param("permissionsCode") String permissionsCode);
//	
//	@Query("SELECT a FROM Activities a, PermissionsActivities pa, UserRolesMapping urm, RolePermissions rp, Users ur WHERE ur.isDeleted != TRUE AND pa.activitiesCode = a.activitiesCode AND pa.permissionsCode = rp.permissionsCode AND urm.userCode = ur.userCode AND urm.roleCode = rp.roleCode AND  ur.userCode = :userCode")
//	public List<Activities> getActivitiesByUserCode(
//			@Param("userCode") String userCode,Pageable pageableRequest);
//
//	@Query("SELECT a FROM Activities a, PermissionsActivities pa WHERE pa.isDeleted != TRUE AND pa.activitiesCode=a.activitiesCode AND  pa.permissionsCode = :permissionsCode")
//	public List<Activities> getActivitiesByPermissionsCode(
//			@Param("permissionsCode") String permissionsCode,Pageable pageableRequest);
//
//
//	@Query("SELECT u FROM Users u WHERE u.isDeleted != TRUE")
//	public List<Users> getAllUsers();
//
//	@Query("SELECT u FROM Users u WHERE u.isDeleted != TRUE")
//	public List<Users> getAllUsers(Pageable pageableRequest);
//
//	@Query("SELECT u FROM Users u WHERE u.isDeleted != TRUE AND u.id = :id")
//	public Users getUserById(@Param("id") Long id);
//
//	@Query("SELECT u FROM Users u WHERE u.isDeleted != TRUE AND u.userCode = :userCode")
//	public Users getUserByUserCode(@Param("userCode") String userCode);
//
//	@Query("SELECT o FROM Organization o, Worker w, WorkerApprovalStatus was WHERE was.organization_Code=o.organizationCode AND  was.workerCode=w.workerCode AND (was.isDeleted=FALSE OR was.isDeleted IS NULL)  AND  was.workerCode= :workerCode")
//	public List<Organization> getAllOrganizationByWorkerCode(
//			@Param("workerCode") String workerCode);
//	
//	@Query("SELECT u FROM Users u, WorkerApprovalStatus was WHERE u.userCode=was.workerCode AND u.isAdmin=TRUE AND was.isDeleted!=TRUE AND was.organization_Code=:organization_Code")
//        public Users getUserEmailByOrgCode(@Param("organization_Code") String organization_Code);

//	@Query("SELECT u FROM Users u WHERE u.isDeleted != TRUE")
//    public List<Users> search(String search);

}
