/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.chat.service.impl;

import com.gigflex.prototype.microservices.chat.dtob.ChatMessage;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.chat.dtob.ChatDetail;
import com.gigflex.prototype.microservices.chat.repository.ChatDetailRepository;
import com.gigflex.prototype.microservices.chat.service.ChatService;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.users.repository.UserRepository;
import com.gigflex.prototype.microservices.utility.GigflexResponse;

/**
 *
 * @author Abhishek
 */
@Service
public class ChatServiceImpl implements ChatService{
    @Autowired
    UserRepository userRepository;
    
    @Autowired
    ChatDetailRepository chatDetailRepository;
    
  //  @Value("${email.chatservice.subject}")
    private String subject="Chat Invitation";

  //  @Value("${email.chatservice.link}")
    private String mailUrl;

  //  @Value("${email.chatservice.body}")
    private String mailBody="Please click on following link to join conversation";

 //   @Value("${email.service.url}")
    private String mailServiceURL="http://18.223.158.6:8091/superadminservice/sendEmail/to/{to}/subject/{subject}/body/{body}";

    @Override
    public String sendChatInvitationLink(String userCode, String sessionId) {
         String res = "";
         String mailRes = "false";
         try{
        if (userCode != null && sessionId != null) {
            Users users=userRepository.findByUserCode(userCode);
            if(users!=null && users.getId()>0 && users.getEmail()!=null){
                 byte[] encoded1 = Base64.getEncoder().encode(sessionId.getBytes());
                String tok = new String(encoded1);
                String url = mailUrl + "?tok=" + tok;
                String bodyContent = "Dear "+users.getName() + ",<br><br> ";
                bodyContent += mailBody;
                bodyContent += "<br><br><a href='" + url + "' target='_blank'>" + url + "</a>";
                String encodeURL = URLEncoder.encode(bodyContent, "UTF-8");
                Map<String, String> map = new HashMap<>();
                map.put("to", users.getEmail());
                map.put("subject", subject);
                map.put("body", encodeURL);
                   try {
                    RestTemplate restTemplate = new RestTemplate();
                    ResponseEntity<String> response = restTemplate.getForEntity(mailServiceURL, String.class, map);
                    mailRes = response.getBody();
                    GigflexResponse derr = new GigflexResponse(200, new Date(), "Mail sending status is " + mailRes);
                    res = derr.toString();
                } catch (Exception ex) {
                    ex.printStackTrace();
                    GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred at sending email");
                    res = derr.toString();
                }
             
            }
            else{
           GigflexResponse derr = new GigflexResponse(404, new Date(), "User not found");
            return derr.toString();
            }
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "UserCode Code or rideCode can not be null");
            return derr.toString();
        }
            return res;
    }
    catch(Exception e){
     GigflexResponse derr = new GigflexResponse(400, new Date(), "UserCode Code or rideCode can not be null");
            return derr.toString();
    
}}

    @Override
    public ChatDetail saveChatMessage(ChatMessage chatMessage) {
        ChatDetail chatDetailAfterSaved = null;
        try {
            if (chatMessage != null && chatMessage.getSessionId() != null && chatMessage.getSessionId().trim().length() > 0) {
                ChatDetail chatDetail = new ChatDetail();
                chatDetail.setSessionId(chatMessage.getSessionId());
                chatDetail.setConversationFrom(chatMessage.getConversationFrom());
                chatDetail.setConversationTo(chatMessage.getConversationTo());
                chatDetail.setMessageBody(chatMessage.getContent());
                chatDetail.setMsgTime(new Date());
                chatDetailAfterSaved = chatDetailRepository.save(chatDetail);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return chatDetailAfterSaved;
    }

	@Override
	public String getChatDetailByConversationFrom(String conversationFrom) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (conversationFrom != null && conversationFrom.length() > 0) {
				List<ChatDetail> chatDetLst = new ArrayList<ChatDetail>();
				chatDetLst = chatDetailRepository
						.getChatDetailByConversationFrom(conversationFrom);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (chatDetLst != null && chatDetLst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(chatDetLst);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getChatDetailByConversationFromByPage(
			String conversationFrom, int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (conversationFrom != null && conversationFrom.length() > 0) {
				List<ChatDetail> chatDetLst = new ArrayList<ChatDetail>();
				chatDetLst = chatDetailRepository
						.getChatDetailByConversationFrom(conversationFrom,
								pageableRequest);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (chatDetLst != null && chatDetLst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(chatDetLst);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getChatDetailByConversationTo(String conversationTo) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (conversationTo != null && conversationTo.length() > 0) {
				List<ChatDetail> chatDetLst = new ArrayList<ChatDetail>();
				chatDetLst = chatDetailRepository
						.getChatDetailByConversationTo(conversationTo);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (chatDetLst != null && chatDetLst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(chatDetLst);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getChatDetailByConversationToByPage(String conversationTo,
			int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (conversationTo != null && conversationTo.length() > 0) {
				List<ChatDetail> chatDetLst = new ArrayList<ChatDetail>();
				chatDetLst = chatDetailRepository
						.getChatDetailByConversationTo(conversationTo,
								pageableRequest);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (chatDetLst != null && chatDetLst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(chatDetLst);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getChatDetailBySessionId(String sessionId) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (sessionId != null && sessionId.length() > 0) {
				List<ChatDetail> chatDetLst = new ArrayList<ChatDetail>();
				chatDetLst = chatDetailRepository
						.getChatDetailBySessionId(sessionId);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (chatDetLst != null && chatDetLst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(chatDetLst);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getChatDetailBySessionIdByPage(String sessionId, int page,
			int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (sessionId != null && sessionId.length() > 0) {
				List<ChatDetail> chatDetLst = new ArrayList<ChatDetail>();
				chatDetLst = chatDetailRepository.getChatDetailBySessionId(
						sessionId, pageableRequest);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (chatDetLst != null && chatDetLst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(chatDetLst);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}
    
}
