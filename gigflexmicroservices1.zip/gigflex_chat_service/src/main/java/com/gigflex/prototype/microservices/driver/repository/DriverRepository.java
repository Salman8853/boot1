/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.repository;

import java.util.List;

import com.gigflex.prototype.microservices.driver.dtob.Driver;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Abhishek
 */
@Repository
public interface DriverRepository extends JpaRepository<Driver,Long>,JpaSpecificationExecutor<Driver> {
	
	@Query("SELECT a,o.operatorName,b.organizationName,b.timezone,t.timeZoneName FROM Driver a , Operator o, Organization b, TimeZoneDetail t WHERE a.isDeleted != TRUE AND a.organizationCode = b.organizationCode AND t.timeZoneCode = b.timezone AND a.driverCode=:driverCode")
	public List<Object> getDriverAndOrganizationByDriverCode(
			@Param("driverCode") String driverCode);

	@Query("SELECT a,o.operatorName,b.organizationName,b.timezone,t.timeZoneName FROM Driver a , Operator o, Organization b, TimeZoneDetail t WHERE a.isDeleted != TRUE AND a.organizationCode = b.organizationCode AND t.timeZoneCode = b.timezone AND o.operatorCode = a.operatorCode AND a.driverCode=:driverCode")
	public List<Object> getDriverAndOrganizationByDriverCode(
			@Param("driverCode") String driverCode, Pageable pageableRequest);
	
//    @Query("SELECT d FROM Driver d WHERE d.isDeleted != TRUE AND d.driverCode = :driverCode")
//	public Driver getDriverByDriverCode(@Param("driverCode") String driverCode);
//	
//	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.driverCode = :driverCode")
//    public List<Object> findDriverByDriverCode(@Param("driverCode") String driverCode);
//	
////	@Query("SELECT d,o.operatorName FROM Driver d,Operator o WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.driverCode = :driverCode")
////    public List<Object> findDriverByDriverCode(@Param("driverCode") String driverCode,Pageable pageableRequest);
//    
//	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode")
//	public List<Object> getAllDriver();
//	
////	@Query("SELECT d,dd,o.operatorName,org.organizationName,dtd.documentType FROM Driver d,Operator o,Organization org,DriverDocument dd,DocumentTypeDetail dtd WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND dd.documentCode = dtd.documentCode AND d.driverCode = dd.driverCode")
////	public List<Object> getAllDriverWithDocument();
//	
//	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode")
//	public List<Object> getAllDriver(Pageable pageableRequest);
//	
//	@Query("SELECT d FROM Driver d WHERE d.isDeleted != TRUE AND d.id = :id")
//	public Driver getDriverById(@Param("id") Long id);
//	
//	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.organizationCode = :organizationCode")
//    public List<Object> findDriverByOrganizationCode(@Param("organizationCode") String organizationCode);
//	
//	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.organizationCode = :organizationCode")
//    public List<Object> findDriverByOrganizationByPage(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
//	
//	
//	@Query("SELECT driver FROM Driver driver WHERE driver.isDeleted != TRUE AND driver.emailId = :emailId")
//	public Driver findByEmail(@Param("emailId") String emailId);
//        
//	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.operatorCode = :operatorCode")
//    public List<Object> findDriverByOperatorCode(@Param("operatorCode") String operatorCode);
//	
//	@Query("SELECT d,o.operatorName,org.organizationName FROM Driver d, Operator o, Organization org WHERE d.isDeleted != TRUE AND d.operatorCode = o.operatorCode AND d.organizationCode = org.organizationCode AND d.operatorCode = :operatorCode")
//    public List<Object> findDriverByOperatorCode(@Param("operatorCode") String operatorCode,Pageable pageableRequest);

}
