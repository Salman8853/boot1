package com.gigflex.prototype.microservices.operator.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.operator.service.OperatorService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/chatservice/")
public class OperatorController {
	
	 @Autowired
	private OperatorService operatorService;
	 
	@GetMapping("/getOperatorAndOrganizationByOperatorCode/{operatorCode}")
	public String getOperatorAndOrganizationByOperatorCode(
			@PathVariable String operatorCode) {
		return operatorService
				.getOperatorAndOrganizationByOperatorCode(operatorCode);
	}

	@GetMapping("/getOperatorAndOrganizationByOperatorCodeByPage/{operatorCode}")
	public String getOperatorAndOrganizationByOperatorCodeByPage(
			@PathVariable String operatorCode,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String cm = operatorService
				.getOperatorAndOrganizationByOperatorCodeByPage(operatorCode,
						page, limit);

		return cm;
	}

}
