/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.users.repository;

import com.gigflex.prototype.microservices.users.dtob.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author Abhishek
 */
public interface UserRepository extends JpaRepository<Users, Long>,JpaSpecificationExecutor<Users>  {
     @Query("SELECT users FROM Users users WHERE users.isDeleted != TRUE AND users.userCode = :userCode")
	public Users findByUserCode(@Param("userCode") String userCode);
    
}
