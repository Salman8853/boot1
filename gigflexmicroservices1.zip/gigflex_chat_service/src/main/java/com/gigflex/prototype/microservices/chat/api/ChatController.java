/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.chat.api;

import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.chat.dtob.ChatDetail;
import com.gigflex.prototype.microservices.chat.dtob.ChatMessage;
import com.gigflex.prototype.microservices.chat.dtob.ChatMessage.MessageType;
import com.gigflex.prototype.microservices.chat.service.ChatService;
import com.gigflex.prototype.microservices.utility.GigflexResponse;

import static java.lang.String.format;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Abhishek
 */
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/chatservice/")
public class ChatController {
     private static final Logger logger = LoggerFactory.getLogger(WebSocketEventListener.class);

     @Autowired
    private ChatService chatService;
    private SimpMessageSendingOperations messagingTemplate;

    @Autowired
    public ChatController(SimpMessageSendingOperations messagingTemplate) {
        this.messagingTemplate = messagingTemplate;
    }


    @PostMapping("/chat")
    public String sendMessage(@RequestBody ChatMessage chatMessage) {
      String res = "";
        
        try {
            JSONObject jsonobj=new JSONObject();
            if (chatMessage != null && chatMessage.getSessionId() != null && chatMessage.getSessionId().trim().length() > 0) {
                ChatDetail chatDetailAfterSave = chatService.saveChatMessage(chatMessage);
                if (chatDetailAfterSave != null && chatDetailAfterSave.getId() > 0) {
                    this.messagingTemplate.convertAndSend(format("/channel/%s", chatMessage.getSessionId()), chatMessage);
                    jsonobj.put("responsecode", 200);
                    jsonobj.put("message", "Success");
                    jsonobj.put("timestamp", new Date());
                }
                else{
                    jsonobj.put("responsecode", 500);
                    jsonobj.put("message", "some issue found.");
                    jsonobj.put("timestamp", new Date());
  
                }
            }
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception Occured");
            return derr.toString();
        }
        return null;
    }

    @PostMapping("/enterInChatRoom")
  //public void addUser(@RequestBody ChatMessage chatMessage,SimpMessageHeaderAccessor headerAccessor) {
  public void addUser(@RequestBody ChatMessage chatMessage) {
//  //  String currentRoomId = (String) headerAccessor.getSessionAttributes().put("room_id", chatMessage.getSessionId());
//    if (currentRoomId != null) {
//      ChatMessage leaveMessage = new ChatMessage();
//      leaveMessage.setType(MessageType.LEAVE);
//      leaveMessage.setConversationFrom(chatMessage.getConversationFrom());
//      messagingTemplate.convertAndSend(format("/channel/%s", currentRoomId), leaveMessage);
//    }
  //  headerAccessor.getSessionAttributes().put("username", chatMessage.getConversationFrom());
    messagingTemplate.convertAndSend(format("/channel/%s", chatMessage.getSessionId()), chatMessage);
  }
  
  @PostMapping("/sendChatInvitation/{userCode}/{sessionId}")
    public String sendChatInvitationLink(@PathVariable("userCode") String userCode,@PathVariable("sessionId") String sessionId){
           return chatService.sendChatInvitationLink(userCode, sessionId);
        }
  
	@GetMapping("/getChatDetailByConversationFrom/{conversationFrom}")
	public String getChatDetailByConversationFrom(
			@PathVariable String conversationFrom) {
		return chatService.getChatDetailByConversationFrom(conversationFrom);
	}

	@GetMapping("/getChatDetailByConversationFromByPage/{conversationFrom}")
	public String getChatDetailByConversationFromByPage(
			@PathVariable String conversationFrom,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String cm = chatService.getChatDetailByConversationFromByPage(
				conversationFrom, page, limit);

		return cm;
	}
	
	@GetMapping("/getChatDetailByConversationTo/{conversationTo}")
	public String getChatDetailByConversationTo(
			@PathVariable String conversationTo) {
		return chatService.getChatDetailByConversationTo(conversationTo);
	}

	@GetMapping("/getChatDetailByConversationToByPage/{conversationTo}")
	public String getChatDetailByConversationToByPage(
			@PathVariable String conversationTo,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String cm = chatService.getChatDetailByConversationToByPage(
				conversationTo, page, limit);

		return cm;
	}
	
	@GetMapping("/getChatDetailBySessionId/{sessionId}")
	public String getChatDetailBySessionId(@PathVariable String sessionId) {
		return chatService.getChatDetailBySessionId(sessionId);
	}

	@GetMapping("/getChatDetailBySessionIdByPage/{sessionId}")
	public String getChatDetailBySessionIdByPage(
			@PathVariable String sessionId,
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String cm = chatService.getChatDetailBySessionIdByPage(sessionId, page,
				limit);

		return cm;
	}
  
    
}
