package com.gigflex.prototype.microservices.driver.service.impl;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.dtob.DriverAndOrganizationResponse;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import com.gigflex.prototype.microservices.driver.service.DriverService;
import com.gigflex.prototype.microservices.utility.GigflexResponse;

@Service
public class DriverServiceImpl implements DriverService{
	
	@Autowired
	DriverRepository driverDao;

	@Override
	public String getDriverAndOrganizationByDriverCode(String driverCode) {
		String res = "";
		DriverAndOrganizationResponse wo = null;
		try {
			JSONObject jsonobj = new JSONObject();
			if (driverCode != null && driverCode.trim().length() > 0) {
				List<Object> objlst = driverDao
						.getDriverAndOrganizationByDriverCode(driverCode);
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 5) {
							wo = new DriverAndOrganizationResponse();
							Driver data = (Driver) arr[0];
							wo.setId(data.getId());
							wo.setDriverCode(data.getDriverCode());
							wo.setName(data.getName());
							wo.setContactNumber(data.getContactNumber());
							wo.setEmailId(data.getEmailId());
							wo.setFleetSize(data.getFleetSize());
							wo.setOperatorCode(data.getOperatorCode());
							wo.setOperatorName((String) arr[1]);
							wo.setApproveStatus(data.getApproveStatus());
							wo.setOrganizationCode(data.getOrganizationCode());
							wo.setOrganizationName((String) arr[2]);
							wo.setTimezone((String) arr[3]);
							wo.setTimeZoneName((String) arr[4]);
						}

					}

					if (wo != null) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wo);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDriverAndOrganizationByDriverCodeByPage(String driverCode,
			int page, int limit) {
		String res = "";
		DriverAndOrganizationResponse wo = null;
		try {
			JSONObject jsonobj = new JSONObject();
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (driverCode != null && driverCode.trim().length() > 0) {
				List<Object> objlst = driverDao
						.getDriverAndOrganizationByDriverCode(driverCode, pageableRequest);
				if (objlst != null && objlst.size() > 0) {
					for (int i = 0; i < objlst.size(); i++) {
						Object[] arr = (Object[]) objlst.get(i);
						if (arr.length >= 5) {
							wo = new DriverAndOrganizationResponse();
							Driver data = (Driver) arr[0];
							wo.setId(data.getId());
							wo.setDriverCode(data.getDriverCode());
							wo.setName(data.getName());
							wo.setContactNumber(data.getContactNumber());
							wo.setEmailId(data.getEmailId());
							wo.setFleetSize(data.getFleetSize());
							wo.setOperatorCode(data.getOperatorCode());
							wo.setOperatorName((String) arr[1]);
							wo.setApproveStatus(data.getApproveStatus());
							wo.setOrganizationCode(data.getOrganizationCode());
							wo.setOrganizationName((String) arr[2]);
							wo.setTimezone((String) arr[3]);
							wo.setTimeZoneName((String) arr[4]);
						}

					}

					if (wo != null) {
						ObjectMapper mapperObj = new ObjectMapper();
						String Detail = mapperObj.writeValueAsString(wo);
						jsonobj.put("responsecode", 200);
						jsonobj.put("message", "Success");
						jsonobj.put("timestamp", new Date());
						jsonobj.put("data", new JSONObject(Detail));
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("message", "Record Not Found");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

}
