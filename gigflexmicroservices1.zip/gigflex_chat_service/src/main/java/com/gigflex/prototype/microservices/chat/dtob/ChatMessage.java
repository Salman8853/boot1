/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.chat.dtob;

/**
 *
 * @author Abhishek
 */
public class ChatMessage {
    public enum MessageType {
    CHAT, JOIN, LEAVE
  }

  private MessageType messageType;
  private String content;
  private String conversationFrom;
  private String conversationTo;
   private String sessionId;

  public MessageType getType() {
    return messageType;
  }

  public void setType(MessageType messageType) {
    this.messageType = messageType;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

 

    public String getConversationFrom() {
        return conversationFrom;
    }

    public void setConversationFrom(String conversationFrom) {
        this.conversationFrom = conversationFrom;
    }

    public String getConversationTo() {
        return conversationTo;
    }

    public void setConversationTo(String conversationTo) {
        this.conversationTo = conversationTo;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }
    
}
