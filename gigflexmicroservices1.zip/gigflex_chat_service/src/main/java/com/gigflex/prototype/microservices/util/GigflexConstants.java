/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.util;

/**
 *
 * @author abhishek
 */
public class GigflexConstants {
    public static final String assignedBookingStatus = "pending";
    public static final String assignedBookingAcceptedStatus = "accepted";
    public static final String assignedBookingRejectedStatus = "rejected";
    public static final String assignedBookingChangedStatus = "changed";
    public static final String assignedBookingCompletedStatus = "completed";
    public static final String bookingStatus = "assigned";
    public static final String dateFormatterForView = "dd-MM-yyyy HH:mm:ss";
    public static final String dateFormatterForSave ="yyyy-MM-dd HH:mm:ss";

}
