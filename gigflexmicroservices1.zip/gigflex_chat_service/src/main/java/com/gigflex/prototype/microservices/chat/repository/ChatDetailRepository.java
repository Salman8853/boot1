/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.chat.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.chat.dtob.ChatDetail;

/**
 *
 * @author Abhishek
 */
public interface ChatDetailRepository extends JpaRepository<ChatDetail, Long>,JpaSpecificationExecutor<ChatDetail>  {
    
	@Query("SELECT cm FROM ChatDetail cm WHERE cm.isDeleted != TRUE AND cm.conversationFrom = :conversationFrom")
	public List<ChatDetail> getChatDetailByConversationFrom(@Param("conversationFrom") String conversationFrom);
	
	@Query("SELECT cm FROM ChatDetail cm WHERE cm.isDeleted != TRUE AND cm.conversationFrom = :conversationFrom")
	public List<ChatDetail> getChatDetailByConversationFrom(@Param("conversationFrom") String conversationFrom,Pageable pageableRequest);
	
	@Query("SELECT cm FROM ChatDetail cm WHERE cm.isDeleted != TRUE AND cm.conversationTo = :conversationTo")
	public List<ChatDetail> getChatDetailByConversationTo(@Param("conversationTo") String conversationTo);
	
	@Query("SELECT cm FROM ChatDetail cm WHERE cm.isDeleted != TRUE AND cm.conversationTo = :conversationTo")
	public List<ChatDetail> getChatDetailByConversationTo(@Param("conversationTo") String conversationTo,Pageable pageableRequest);
	
	@Query("SELECT cm FROM ChatDetail cm WHERE cm.isDeleted != TRUE AND cm.sessionId = :sessionId")
	public List<ChatDetail> getChatDetailBySessionId(@Param("sessionId") String sessionId);
	
	@Query("SELECT cm FROM ChatDetail cm WHERE cm.isDeleted != TRUE AND cm.sessionId = :sessionId")
	public List<ChatDetail> getChatDetailBySessionId(@Param("sessionId") String sessionId,Pageable pageableRequest);
}
