/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.driver.dtob.Driver;
import com.gigflex.prototype.microservices.driver.repository.DriverRepository;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 *
 * @author Abhishek
 */
@Service
public class KafkaDriverUpdateConsumeService {
    
    @Autowired
    DriverRepository driverRepository;
    private static final Logger LOG = LoggerFactory.getLogger(KafkaDriverUpdateConsumeService.class);
    
     @KafkaListener(topics = "UpdateDriverFromDriverOrg")
      public void listen(@Payload String message) {
           ObjectMapper objectMapper = new ObjectMapper();
        LOG.info("received message='{}'", message);
        try{
             Driver driverDetail = objectMapper.readValue(message, Driver.class);
            LOG.info("received message for UpdateDriverFromDriverOrg='{}'", driverDetail.getName());
            LOG.info("received message for UpdateDriverFromDriverOrg='{}'", driverDetail.getDriverCode());
            LOG.info("received message for UpdateDriverFromDriverOrg='{}'", driverDetail.getEmailId());
            LOG.info("received message for UpdateDriverFromDriverOrg='{}'", driverDetail.getOperatorCode()); 
            Driver driver=driverRepository.getDriverByDriverCode(driverDetail.getDriverCode());
            if(driver!=null && driver.getId()>0){
                driver.setName(driverDetail.getName());
                driver.setEmailId(driverDetail.getEmailId());
                driver.setContactNumber(driverDetail.getContactNumber());
                driver.setFleetSize(driverDetail.getFleetSize());
                driver.setOperatorCode(driverDetail.getOperatorCode());
                driver.setIpAddress(driverDetail.getIpAddress());
                driver.setIsDeleted(driverDetail.getIsDeleted());
                driver.setOrganizationCode(driverDetail.getOrganizationCode());
                driver.setDriverImage(driverDetail.getDriverImage());
//                driver.setVehicleCode(driverDetail.getVehicleCode());
                driverRepository.save(driver);
            }
            
        }
         catch (JsonParseException e) {
			LOG.error("In  KafkaDriverService for UpdateDriverFromDriverOrg >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaDriverService for UpdateDriverFromDriverOrg >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaDriverService for UpdateDriverFromDriverOrg >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaDriverService for UpdateDriverFromDriverOrg >>>>", e);
		}
      }
      
    
}
