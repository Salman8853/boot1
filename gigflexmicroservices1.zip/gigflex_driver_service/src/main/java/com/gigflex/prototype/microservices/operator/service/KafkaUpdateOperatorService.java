/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.operator.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.operator.dtob.Operator;
import com.gigflex.prototype.microservices.operator.repository.OperatorRepository;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 *
 * @author Abhishek
 */
@Service
public class KafkaUpdateOperatorService {
    private Operator operator;
    
    @Autowired
    OperatorRepository operatorRepository;
     private static final Logger LOG = LoggerFactory.getLogger(KafkaUpdateOperatorService.class);
    
     @KafkaListener(topics = "UpdateOperatorFromDriverOrg")
     public void listen(@Payload String message) {
          ObjectMapper objectMapper = new ObjectMapper();
        LOG.info("received message='{}'", message);
        try{
            Operator operatorDetail=objectMapper.readValue(message, Operator.class);
            LOG.info("received message='{}'", operatorDetail.getOperatorName());
            LOG.info("received message='{}'", operatorDetail.getOperatorCode());
            LOG.info("received message='{}'", operatorDetail.getEmailId());
            LOG.info("received message='{}'", operatorDetail.getOrganizationCode());
            if(operatorDetail!=null && operatorDetail.getId()>0 && operatorDetail.getOperatorCode()!=null && operatorDetail.getOperatorCode().length()>0)
            {
            operator=operatorRepository.getOperatorByOperatorCode(operatorDetail.getOperatorCode());
            if(operator!=null && operator.getId()>0)
            {
            operator.setOperatorCode(operatorDetail.getOperatorCode());
            operator.setOperatorName(operatorDetail.getOperatorName());
            operator.setEmailId(operatorDetail.getEmailId());
            operator.setOrganizationCode(operatorDetail.getOrganizationCode());
            operator.setIsDeleted(operatorDetail.getIsDeleted());
            operator.setOperatorImage(operatorDetail.getOperatorImage());
            operator.setContactNumber(operatorDetail.getContactNumber());
            operator.setTradingAddress(operatorDetail.getTradingAddress());
            operator.setIpAddress(operatorDetail.getIpAddress());
            operatorRepository.save(operator);
            }
            }
        }
       catch (JsonParseException e) {
			LOG.error("In KafkaDriverService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaDriverService >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaDriverService >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaDriverService >>>>", e);
		}
     }
    
}
