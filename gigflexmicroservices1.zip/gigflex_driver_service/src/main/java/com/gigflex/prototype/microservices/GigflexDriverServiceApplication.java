package com.gigflex.prototype.microservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GigflexDriverServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GigflexDriverServiceApplication.class, args);
	}
}
