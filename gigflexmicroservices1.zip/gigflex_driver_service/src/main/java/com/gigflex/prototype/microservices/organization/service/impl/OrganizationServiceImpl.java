/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.organization.service.impl;

import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.organization.service.OrganizationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Abhishek
 */
@Service
public class OrganizationServiceImpl implements OrganizationService{
    private static final Logger LOG = LoggerFactory
			.getLogger(OrganizationServiceImpl.class);
    @Autowired
    OrganizationRepository organizationRepository;

    @Override
    public Organization registerFromOrganization(Organization organization) {
        return organizationRepository.save(organization);

    }
    
}
