/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.repository;

import com.gigflex.prototype.microservices.driver.dtob.Driver;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Abhishek
 */
@Repository
public interface DriverRepository extends JpaRepository<Driver,Long>,JpaSpecificationExecutor<Driver> {
    @Query("SELECT d FROM Driver d WHERE d.isDeleted != TRUE AND d.driverCode = :driverCode")
	public Driver getDriverByDriverCode(@Param("driverCode") String driverCode);
    
}
