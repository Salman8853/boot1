/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.operator.dtob;

import com.gigflex.prototype.microservices.utility.CommonAttribute;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

/**
 *
 * @author Abhishek
 */
@Entity
@Table(name = "operator")
public class Operator extends CommonAttribute implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @Column(name = "operator_code", unique = true)
    private String operatorCode;
    
    @Column(name = "operator_name")
    private String operatorName;
    
    @Column(name = "trading_address")
    private String tradingAddress;
    
    @Column(name = "contact_number")
    private String contactNumber;
    
    @Column(name = "emailid")
    private String emailId;
    
    @Column(name = "organization_code")
    private String organizationCode;
    
    @Column(name = "operator_image")
    private String operatorImage;
    
     @PrePersist
    private void assignUUID() {
        if(this.getOperatorCode()==null || this.getOperatorCode().length()==0)
        {
            this.setOperatorCode(UUID.randomUUID().toString());
        }
    }

    public Operator() {
    }

    public Operator(Long id, String operatorCode, String operatorName, String tradingAddress, String contactNumber, String emailId, String organizationCode,String operatorImage) {
        this.id = id;
        this.operatorCode = operatorCode;
        this.operatorName = operatorName;
        this.tradingAddress = tradingAddress;
        this.contactNumber = contactNumber;
        this.emailId = emailId;
        this.organizationCode = organizationCode;
        this.operatorImage= operatorImage;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOperatorCode() {
        return operatorCode;
    }

    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
    }

    public String getOperatorName() {
        return operatorName;
    }

    public void setOperatorName(String operatorName) {
        this.operatorName = operatorName;
    }

    public String getTradingAddress() {
        return tradingAddress;
    }

    public void setTradingAddress(String tradingAddress) {
        this.tradingAddress = tradingAddress;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getOperatorImage() {
        return operatorImage;
    }

    public void setOperatorImage(String operatorImage) {
        this.operatorImage = operatorImage;
    }
    
}
