/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documenttypedetail.service;

import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.documenttypedetail.repository.DocumentTypeDetailRepository;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 *
 * @author Abhishek
 */
@Service
public class KafkaUpdateDocumemtTypeDetailService {
    private DocumentTypeDetail ddres;
    
    @Autowired
    DocumentTypeDetailRepository documentTypeDetailRepository;
    private static final Logger LOG = LoggerFactory.getLogger(KafkaUpdateDocumemtTypeDetailService.class);
    
    @KafkaListener(topics = "UpdateDocumentTypeDetail")
    public void listen(@Payload String message) {
        ObjectMapper objectMapper = new ObjectMapper();
        LOG.info("received message='{}'", message);
        try{
            DocumentTypeDetail dd = objectMapper.readValue(message, DocumentTypeDetail.class);
            if(dd!=null && dd.getId()>0&& dd.getDocumentCode()!=null)
            {
                
            ddres=documentTypeDetailRepository.getDocumentTypeDetailByDocumentCode(dd.getDocumentCode());
            if(ddres!=null && ddres.getId()>0)
            {
            ddres.setDocumentType(dd.getDocumentType());
            ddres.setDocumentName(dd.getDocumentName());
            ddres.setUserTypeCode(dd.getUserTypeCode());
            ddres.setIpAddress(dd.getIpAddress());
            ddres.setIsDeleted(dd.getIsDeleted());
            documentTypeDetailRepository.save(ddres);
            }
            }
            
        }
       catch (JsonParseException e) {
			LOG.error("In KafkaUpdateDocumemtTypeDetailService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaUpdateDocumemtTypeDetailService >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaUpdateDocumemtTypeDetailService >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaUpdateDocumemtTypeDetailService >>>>", e);
		}
    }
    
}
