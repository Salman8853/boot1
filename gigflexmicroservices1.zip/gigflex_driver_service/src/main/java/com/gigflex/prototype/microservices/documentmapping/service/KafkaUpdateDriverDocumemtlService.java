/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service;

import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocument;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.documentmapping.repository.DriverDocumentRepository;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 *
 * @author Abhishek
 */
@Service
public class KafkaUpdateDriverDocumemtlService {
    private DriverDocument ddres;
    
    @Autowired
    DriverDocumentRepository driverDocumentRepository;
    private static final Logger LOG = LoggerFactory.getLogger(KafkaUpdateDriverDocumemtlService.class);
    
    @KafkaListener(topics = "UpdateDriverDocument")
    public void listen(@Payload String message) {
        ObjectMapper objectMapper = new ObjectMapper();
        LOG.info("received message='{}'", message);
        try{
            DriverDocument dd = objectMapper.readValue(message, DriverDocument.class);
            if(dd!=null && dd.getId()>0 && dd.getDriverCode()!=null)
            {
            ddres=driverDocumentRepository.getDriverDocumentByDriverDocumentCode(dd.getDriverCode());
            if(ddres!=null && ddres.getId()>0)
            {
            ddres.setDocExpiration(dd.getDocExpiration());
            ddres.setDocValue(dd.getDocValue());
            ddres.setDocumentCode(dd.getDocumentCode());
            ddres.setDriverCode(dd.getDriverCode());
            ddres.setIpAddress(dd.getIpAddress());
            ddres.setIsDeleted(dd.getIsDeleted());
            driverDocumentRepository.save(ddres);
            }
            }
            
        }
       catch (JsonParseException e) {
			LOG.error("In KafkaUpdateDriverDocumemtlService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaUpdateDriverDocumemtlService >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaUpdateDriverDocumemtlService >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaUpdateDriverDocumemtlService >>>>", e);
		}
    }
    
}
