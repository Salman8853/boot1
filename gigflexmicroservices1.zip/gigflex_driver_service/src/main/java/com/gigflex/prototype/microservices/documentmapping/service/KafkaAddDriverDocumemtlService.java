/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service;

import com.gigflex.prototype.microservices.documentmapping.dtob.DriverDocument;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.documentmapping.repository.DriverDocumentRepository;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 *
 * @author Abhishek
 */
@Service
public class KafkaAddDriverDocumemtlService {
    private DriverDocument ddres;
    
    @Autowired
    DriverDocumentRepository driverDocumentRepository;
    private static final Logger LOG = LoggerFactory.getLogger(KafkaAddDriverDocumemtlService.class);
    
    @KafkaListener(topics = "AddDriverDocument")
    public void listen(@Payload String message) {
        ObjectMapper objectMapper = new ObjectMapper();
        LOG.info("received message='{}'", message);
        try{
            DriverDocument dd = objectMapper.readValue(message, DriverDocument.class);
            
            ddres=new DriverDocument();
            ddres.setDocExpiration(dd.getDocExpiration());
            ddres.setDocValue(dd.getDocValue());
            ddres.setDocumentCode(dd.getDocumentCode());
            ddres.setDriverCode(dd.getDriverCode());
            ddres.setDriverDocumentCode(dd.getDriverDocumentCode());
            ddres.setIpAddress(dd.getIpAddress());
            ddres.setIsDeleted(Boolean.FALSE);
            driverDocumentRepository.save(ddres);
            
        }
       catch (JsonParseException e) {
			LOG.error("In KafkaAddDriverDocumemtlService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaAddDriverDocumemtlService >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaAddDriverDocumemtlService >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaAddDriverDocumemtlService >>>>", e);
		}
    }
    
}
