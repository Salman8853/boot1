/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.operator.repository;

import com.gigflex.prototype.microservices.operator.dtob.Operator;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Abhishek
 */
@Repository
public interface OperatorRepository extends JpaRepository<Operator,Long>,JpaSpecificationExecutor<Operator> {
    @Query("SELECT a FROM Operator a WHERE a.isDeleted != TRUE AND a.operatorCode = :operatorCode")
    public Operator getOperatorByOperatorCode(@Param("operatorCode") String operatorCode);
}
