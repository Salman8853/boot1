package com.gigflex.prototype.microservices.documenttypedetail.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.utility.CommonAttribute;

@Entity
@Table(name = "documenttypedetail")
public class DocumentTypeDetail extends CommonAttribute implements Serializable{
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "doc_code", unique = true)
    private String documentCode;
    
    @Column(name = "doc_type", nullable = false)
    private String documentType;
    
    @Column(name = "user_type_code")
    private String userTypeCode;
    
    @Column(name = "doc_name", nullable = false)
    private String documentName;
    
    @PrePersist
    private void assignUUID() {
        if(this.getDocumentCode()==null || this.getDocumentCode().length()==0)
        {
            this.setDocumentCode((UUID.randomUUID().toString()));
        }
    }
    
    

    public String getDocumentName() {
		return documentName;
	}



	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

    
    public String getUserTypeCode() {
		return userTypeCode;
	}



	public void setUserTypeCode(String userTypeCode) {
		this.userTypeCode = userTypeCode;
	}



	public DocumentTypeDetail() {
		// TODO Auto-generated constructor stub
	}

	public DocumentTypeDetail(Long id, String documentCode, String documentType) {
		super();
		this.id = id;
		this.documentCode = documentCode;
		this.documentType = documentType;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDocumentCode() {
		return documentCode;
	}

	public void setDocumentCode(String documentCode) {
		this.documentCode = documentCode;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}
    
    

}
