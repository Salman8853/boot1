/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.operator.repository;

import com.gigflex.prototype.microservices.operator.dtob.Users;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface UserRepository extends JpaRepository<Users, Long>{
    
	@Query("SELECT u FROM Users u WHERE u.isDeleted != TRUE AND u.userCode = :userCode")

	public Users findByUserCode(@Param("userCode") String userCode);
}
