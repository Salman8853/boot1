/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.dtob;


import com.gigflex.prototype.microservices.utility.CommonAttribute;

import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author nirbhay.p
 */
@Entity
@Table(name = "driverdocumentmapping")
public class DriverDocument extends CommonAttribute implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "driver_document_code", unique = true)
    private String driverDocumentCode;
    
    @Column(name = "driver_code", unique = true)
    private String driverCode;
    
    @Column(name = "doc_code", unique = true)
    private String documentCode;
    
    
    @Column(name = "docvalue")
    private String docValue;
    
    @Column(name = "docexpiration", columnDefinition="DATETIME")
    private Date docExpiration;
    
    @Column(name = "doc_name", unique = true)
    private String documentName;
    
    
    @PrePersist
    private void assignUUID() {
        if(this.getDriverDocumentCode()==null || this.getDriverDocumentCode().length()==0)
        {
            this.setDriverDocumentCode(UUID.randomUUID().toString());
        }
    }
    
    

    public String getDocumentName() {
		return documentName;
	}



	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}



	public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDriverDocumentCode() {
        return driverDocumentCode;
    }

    public void setDriverDocumentCode(String driverDocumentCode) {
        this.driverDocumentCode = driverDocumentCode;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

   

    public String getDocValue() {
        return docValue;
    }

    public void setDocValue(String docValue) {
        this.docValue = docValue;
    }

    public Date getDocExpiration() {
        return docExpiration;
    }

    public void setDocExpiration(Date docExpiration) {
        this.docExpiration = docExpiration;
    }

    
    
    
}
