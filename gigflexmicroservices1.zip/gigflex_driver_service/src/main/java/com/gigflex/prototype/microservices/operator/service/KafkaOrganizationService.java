package com.gigflex.prototype.microservices.operator.service;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.dtob.OrganizationConsume;
import com.gigflex.prototype.microservices.organization.service.OrganizationService;



@Service
public class KafkaOrganizationService {
	
	@Autowired
	OrganizationService organizationService;
        
       
    private static final Logger LOG = LoggerFactory.getLogger(KafkaOrganizationService.class);
private Organization neworg;

 
    @KafkaListener(topics = "NewOrganization")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			OrganizationConsume org = objectMapper.readValue(message, OrganizationConsume.class);
//                        workingLocationService.saveWorkingLocations(wlocation, ip);
//                        workingLocationService.saveWorkingLocations(wlocation);
                        neworg=new Organization();
                        neworg.setOrganizationName(org.getOrganizationName());
                        neworg.setOrganizationCode(org.getOrganizationCode());
                        neworg.setIsActive(org.getIsActive());
                        neworg.setLang(org.getLang());
                        neworg.setLat(org.getLat());
                        neworg.setIndustryCode(org.getIndustryCode());
                        neworg.setIsVerified(org.getIsVerified());
                        neworg.setTimezone(org.getTimezone());
                        neworg.setIsDeleted(org.getIsDeleted());
			organizationService.registerFromOrganization(neworg);
			
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
     
    
	
	
}