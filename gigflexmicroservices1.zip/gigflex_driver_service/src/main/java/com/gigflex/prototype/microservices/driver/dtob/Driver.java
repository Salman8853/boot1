/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.dtob;

import com.gigflex.prototype.microservices.utility.CommonAttribute;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

/**
 *
 * @author Abhishek
 */
@Entity
@Table(name = "driver")
public class Driver extends CommonAttribute implements Serializable  {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @Column(name = "driver_code", unique = true)
    private String driverCode;
    
    @Column(name = "name")
    private String name;
    
    @Column(name = "contactnumber")
    private String contactNumber;
    
    @Column(name = "emailid")
    private String emailId;
    
    @Column(name = "fleetsize")
    private Integer fleetSize;
    
    @Column(name = "operator_code")
    private String operatorCode;
    
     @Column(name="organization_code")
    private String organizationCode;
     
     @Column(name = "driver_image")
    private String driverImage;
    
//    @Column(name = "vehicle_code")
//    private String vehicleCode;
    
    @PrePersist
    private void assignUUID() {
        if(this.getDriverCode()==null || this.getDriverCode().length()==0)
        {
            this.setDriverCode(UUID.randomUUID().toString());
        }
    }

    public Driver() {
    }



    public Driver(Long id, String driverCode, String name,
			String contactNumber, String emailId, Integer fleetSize,
			String operatorCode, String organizationCode, String driverImage) {
		super();
		this.id = id;
		this.driverCode = driverCode;
		this.name = name;
		this.contactNumber = contactNumber;
		this.emailId = emailId;
		this.fleetSize = fleetSize;
		this.operatorCode = operatorCode;
		this.organizationCode = organizationCode;
		this.driverImage = driverImage;
	}

	public String getDriverImage() {
        return driverImage;
    }

    public void setDriverImage(String driverImage) {
        this.driverImage = driverImage;
    }

//    public String getVehicleCode() {
//        return vehicleCode;
//    }
//
//    public void setVehicleCode(String vehicleCode) {
//        this.vehicleCode = vehicleCode;
//    }
    

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDriverCode() {
        return driverCode;
    }

    public void setDriverCode(String driverCode) {
        this.driverCode = driverCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public Integer getFleetSize() {
        return fleetSize;
    }

    public void setFleetSize(Integer fleetSize) {
        this.fleetSize = fleetSize;
    }

    public String getOperatorCode() {
        return operatorCode;
    }

    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }
    
}
