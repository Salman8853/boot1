/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.driver.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.operator.dtob.Users;
import com.gigflex.prototype.microservices.operator.repository.UserRepository;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 *
 * @author Abhishek
 */
@Service
public class KafkaDriverConsumerForUser {
     private Users users;
     
     @Autowired
     UserRepository userRepository;
     
      private static final Logger LOG = LoggerFactory.getLogger(KafkaDriverConsumerForUser.class);
      
        @KafkaListener(topics = "AddDriverInUserRegistration")
           public void listen(@Payload String message) {
           ObjectMapper objectMapper = new ObjectMapper();
        LOG.info("received message='{}'", message);
        try{
             Users userDetail = objectMapper.readValue(message, Users.class);
            LOG.info("received message for AddDriverInUserRegistration='{}'", userDetail.getName());
            LOG.info("received message for AddDriverInUserRegistration='{}'", userDetail.getUserName());
            LOG.info("received message for AddDriverInUserRegistration='{}'", userDetail.getEmail());
            LOG.info("received message for AddDriverInUserRegistration='{}'", userDetail.getPassword()); 
            users=new Users();
            users.setName(userDetail.getName());
            users.setUserName(userDetail.getUserName());
            users.setEmail(userDetail.getEmail());
            users.setPassword(userDetail.getPassword());
            users.setIsOwner(Boolean.FALSE);
            users.setIsAdmin(Boolean.FALSE);
            users.setIsActive(Boolean.TRUE);
            users.setIsVerified(Boolean.FALSE);
            users.setIpAddress(userDetail.getIpAddress());//
            users.setPassword(userDetail.getPassword());
            users.setIsDeleted(userDetail.getIsDeleted());
            userRepository.save(users);
        }
         catch (JsonParseException e) {
			LOG.error("In  KafkaDriverService for AddDriverInUserRegistration >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaDriverService for AddDriverInUserRegistration >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaDriverService for AddDriverInUserRegistration >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaDriverService for AddDriverInUserRegistration >>>>", e);
		}
           
           
           }
     
    
}
