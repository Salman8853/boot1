/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.dtob;


import com.gigflex.prototype.microservices.utility.CommonAttribute;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author nirbhay.p
 */
@Entity
@Table(name = "operatordocumentmapping")
public class OperatorDocument extends CommonAttribute implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "operator_document_code", unique = true)
    private String operatorDocumentCode;
    
    @Column(name = "operator_code", unique = true)
    private String operatorCode;
    
    @Column(name = "doc_code", unique = true)
    private String documentCode;
    
    
    @Column(name = "docvalue")
    private String docValue;
    
    @Column(name = "docexpiration",columnDefinition="DATETIME")
    private Date docExpiration;
    
    
    @PrePersist
    private void assignUUID() {
        if(this.getOperatorDocumentCode()==null || this.getOperatorDocumentCode().length()==0)
        {
            this.setOperatorDocumentCode(UUID.randomUUID().toString());
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOperatorDocumentCode() {
        return operatorDocumentCode;
    }

    public void setOperatorDocumentCode(String operatorDocumentCode) {
        this.operatorDocumentCode = operatorDocumentCode;
    }

    public String getOperatorCode() {
        return operatorCode;
    }

    public void setOperatorCode(String operatorCode) {
        this.operatorCode = operatorCode;
    }

        

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    
    public String getDocValue() {
        return docValue;
    }

    public void setDocValue(String docValue) {
        this.docValue = docValue;
    }

    public Date getDocExpiration() {
        return docExpiration;
    }

    public void setDocExpiration(Date docExpiration) {
        this.docExpiration = docExpiration;
    }

      
}
