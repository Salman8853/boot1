/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.operator.service;

import com.gigflex.prototype.microservices.operator.dtob.Operator;

/**
 *
 * @author Abhishek
 */
public interface OperatorService {
    public Operator saveOperatorsDetatil(Operator Operator);
    
}
