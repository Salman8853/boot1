package com.gigflex.prototype.microservices.organizationworkinglocationhours.service;

import java.util.List;

import com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob.OrganizationWorkingLocationHoursRequest;

public interface OrganizationWorkingLocationHoursService {
	public String search(String search);
	
	public String saveOrganizationWorkingLocationHours(List<OrganizationWorkingLocationHoursRequest> orgWrLocHrsReq , String ip);
	public String getOrganizationWorkingLocationHoursByWorkingLocationCode(String workingLocationCode);
	public String getOrganizationWorkingLocationHoursByOrganizationCode(String organizationCode);
	public String getOrganizationWorkingLocationHoursByOrganizationCode(String organizationCode,int page, int limit);
	public String getAllOrganizationWorkingLocationHoursWithNames();
	public String getOrganizationWorkingLocationHoursWithNamesByPage(int page, int limit);
	

}
