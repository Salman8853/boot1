package com.gigflex.prototype.microservices.documenttypedetail.dtob;

public class DocumentTypeDetailRequest {

	
	private String documentName;
	

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	
	

}
