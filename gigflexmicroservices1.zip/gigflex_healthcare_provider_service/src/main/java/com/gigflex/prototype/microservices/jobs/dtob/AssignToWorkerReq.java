package com.gigflex.prototype.microservices.jobs.dtob;

/**
 * 
 * @author nirbhay.p
 *
 */

public class AssignToWorkerReq  {

    
    
    private String workerCode; 
    
   
    private Double distance;

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }
   
    
}