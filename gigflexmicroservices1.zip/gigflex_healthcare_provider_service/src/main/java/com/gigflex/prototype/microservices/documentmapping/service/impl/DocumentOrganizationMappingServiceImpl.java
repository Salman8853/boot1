/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationMapping;
import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationMappingRequest;
import com.gigflex.prototype.microservices.documentmapping.repository.DocumentOrganizationMappingRepository;
import com.gigflex.prototype.microservices.documentmapping.service.DocumentOrganizationMappingService;
import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationMappingResponse;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/**
 *
 * @author nirbhay.p
 */
@Service
public class DocumentOrganizationMappingServiceImpl implements DocumentOrganizationMappingService{

    @Autowired
    DocumentOrganizationMappingRepository documentOrganizationMappingRepository;
    @Override
    public String getAllDocumentOrganizationMapping() {
        
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 List<DocumentOrganizationMappingResponse> rsplst= new ArrayList<DocumentOrganizationMappingResponse>();
		 List<Object> objlst = documentOrganizationMappingRepository.getAllDocumentOrganizationMapping();
		        if (objlst != null && objlst.size() > 0) {
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 3) {
                                 DocumentOrganizationMappingResponse resp=new DocumentOrganizationMappingResponse();
                                 DocumentOrganizationMapping dom=(DocumentOrganizationMapping) arr[0];
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentName((String) arr[1]);
                                 resp.setId(dom.getId());
                                 resp.setOrganizationCode(dom.getOrganizationCode());
                                 resp.setOrganizationDocumentCode(dom.getOrganizationDocumentCode());
                                 resp.setOrganizationName((String) arr[2]);
                                 rsplst.add(resp);
                             }
                         }
                     }
		 if (rsplst != null && rsplst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(rsplst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

		
	
    }

    @Override
    public String getAllDocumentOrganizationMappingByPage(int page, int limit) {
        
        
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 if(limit>0)
                        {
                 int count =0;
                 Pageable pageableRequest = PageRequest.of(page, limit);
                 
                 List<DocumentOrganizationMappingResponse> rsplst= new ArrayList<DocumentOrganizationMappingResponse>();
		 List<Object> objlst = documentOrganizationMappingRepository.getAllDocumentOrganizationMapping(pageableRequest);
                 if (objlst != null && objlst.size() > 0) {
                     
                 List<Object> objlstcnt = documentOrganizationMappingRepository.getAllDocumentOrganizationMapping();
		        if(objlstcnt!=null && objlstcnt.size()>0)
                        {
                            count= objlstcnt.size();
                        }
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 3) {
                                 DocumentOrganizationMappingResponse resp=new DocumentOrganizationMappingResponse();
                                 DocumentOrganizationMapping dom=(DocumentOrganizationMapping) arr[0];
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentName((String) arr[1]);
                                 resp.setId(dom.getId());
                                 resp.setOrganizationCode(dom.getOrganizationCode());
                                 resp.setOrganizationDocumentCode(dom.getOrganizationDocumentCode());
                                 resp.setOrganizationName((String) arr[2]);
                                 rsplst.add(resp);
                             }
                         }
                     }
		 if (rsplst != null && rsplst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
                 jsonobj.put("count", count);
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(rsplst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
                 } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

		
	
    
    }

    @Override
    public String getDocumentOrganizationMappingById(Long id) {
        
        
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 if(id!=null)
                 {
                 DocumentOrganizationMapping rsplst = documentOrganizationMappingRepository.getDocumentOrganizationMappingById(id);
		 
		 if (rsplst != null && rsplst.getId() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(rsplst);
		 jsonobj.put("data", new JSONObject(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
                 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "ID should not be blank.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

		
	
    
    }

    @Override
    public String getDocumentOrganizationMappingByCode(String documentOrganizationMappingCode) {
        
		 String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 if(documentOrganizationMappingCode!=null && documentOrganizationMappingCode.trim().length()>0)
                 {
                 DocumentOrganizationMapping rsplst = documentOrganizationMappingRepository.getDocumentOrganizationMappingByCode(documentOrganizationMappingCode.trim());
		 
		 if (rsplst != null && rsplst.getId() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(rsplst);
		 jsonobj.put("data", new JSONObject(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
                 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Document Organization Mapping Code should not be blank.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

    }

    @Override
    public String getDocumentOrganizationMappingWithNameByCode(String documentOrganizationMappingCode) {
       String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 if(documentOrganizationMappingCode!=null && documentOrganizationMappingCode.trim().length()>0)
                 {
                 DocumentOrganizationMappingResponse resp=null;
                 Object rsplst = documentOrganizationMappingRepository.getDocumentOrganizationMappingWithNameByCode(documentOrganizationMappingCode.trim());
		 if (rsplst != null ) {
                             Object[] arr = (Object[]) rsplst;
                             if (arr.length >= 3) {
                                 resp=new DocumentOrganizationMappingResponse();
                                 DocumentOrganizationMapping dom=(DocumentOrganizationMapping) arr[0];
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentName((String) arr[1]);
                                 resp.setId(dom.getId());
                                 resp.setOrganizationCode(dom.getOrganizationCode());
                                 resp.setOrganizationDocumentCode(dom.getOrganizationDocumentCode());
                                 resp.setOrganizationName((String) arr[2]);
                            }
                         
                     }
		 if (resp != null) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(resp);
		 jsonobj.put("data", new JSONObject(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
                 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Document Organization Mapping Code should not be blank.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;

    }
    
    @Override
    public String getgetDocumentOrganizationMappingByOrganizationCode(String organizationCode) {
        String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 if(organizationCode!=null && organizationCode.trim().length()>0)
                 {
                 
                 List<DocumentOrganizationMappingResponse> rsplst= new ArrayList<DocumentOrganizationMappingResponse>();
		 List<Object> objlst = documentOrganizationMappingRepository.getAllDocumentOrganizationMappingByOrgCode(organizationCode.trim());
		        if (objlst != null && objlst.size() > 0) {
                         for (int i = 0; i < objlst.size(); i++) {
                             Object[] arr = (Object[]) objlst.get(i);
                             if (arr.length >= 3) {
                                 DocumentOrganizationMappingResponse resp=new DocumentOrganizationMappingResponse();
                                 DocumentOrganizationMapping dom=(DocumentOrganizationMapping) arr[0];
                                 resp.setDocumentCode(dom.getDocumentCode());
                                 resp.setDocumentName((String) arr[1]);
                                 resp.setId(dom.getId());
                                 resp.setOrganizationCode(dom.getOrganizationCode());
                                 resp.setOrganizationDocumentCode(dom.getOrganizationDocumentCode());
                                 resp.setOrganizationName((String) arr[2]);
                                 rsplst.add(resp);
                             }
                         }
                     }
		 if (rsplst != null && rsplst.size() > 0) {
		 jsonobj.put("responsecode", 200);
		 jsonobj.put("message", "Success");
		 jsonobj.put("timestamp", new Date());
		 ObjectMapper mapperObj = new ObjectMapper();
		 String Detail = mapperObj.writeValueAsString(rsplst);
		 jsonobj.put("data", new JSONArray(Detail));
		 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Record Not Found.");
		 jsonobj.put("timestamp", new Date());
		 }
                 
                 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Organization Code should not be blank.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;
    }

    @Override
    public String saveDocumentOrganizationMapping(DocumentOrganizationMappingRequest docReq, String ip) {
        String res = "";
		 try {
		 JSONObject jsonobj = new JSONObject();
                 if(docReq!=null && docReq.getDocumentCode()!=null && docReq.getDocumentCode().trim().length()>0
                         && docReq.getOrganizationCode()!=null && docReq.getOrganizationCode().trim().length()>0)
                 {
                   DocumentOrganizationMapping dom=  documentOrganizationMappingRepository.getDocumentOrganizationMappingByDocCodeAndOrgCode(docReq.getDocumentCode().trim(), docReq.getOrganizationCode().trim());
                   if(dom!=null && dom.getId()>0)
                   {
                       jsonobj.put("responsecode", 409);
                       jsonobj.put("message", "Record is already exist.");
                       jsonobj.put("timestamp", new Date());
                   }
                   else
                     {
                         DocumentOrganizationMapping dm = new DocumentOrganizationMapping();
                         dm.setDocumentCode(docReq.getDocumentCode().trim());
                         dm.setOrganizationCode(docReq.getOrganizationCode().trim());
                         dm.setIpAddress(ip);
                         DocumentOrganizationMapping dmres = documentOrganizationMappingRepository.save(dm);
                         if (dmres != null && dmres.getId() > 0) {
                             jsonobj.put("responsecode", 200);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message",
                                     "Document Organization Mapping has been added successfully.");
                             ObjectMapper mapperObj = new ObjectMapper();
                             String Detail = mapperObj.writeValueAsString(dmres);
                             jsonobj.put("data", new JSONObject(Detail));
                         } else {
                             jsonobj.put("responsecode", 400);
                             jsonobj.put("timestamp", new Date());
                             jsonobj.put("message", "Failed");
                         }
                     }
                 } else {
		 jsonobj.put("responsecode", 404);
		 jsonobj.put("message", "Document Code, Organization Code should not be blank.");
		 jsonobj.put("timestamp", new Date());
		 }
		 res = jsonobj.toString();
		 } catch (JSONException | JsonProcessingException ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "JSON parsing exception occurred.");
		 res = derr.toString();
		 } catch (Exception ex) {
		 GigflexResponse derr = new GigflexResponse(500, new Date(),
		 "Exception occurred.");
		 res = derr.toString();
		 }
		 return res;
    }

//    @Override
//    public String updateDocumentOrganizationMapping(Long id, DocumentOrganizationMappingRequest docReq, String ip) {
//       
//        String res = "";
//		 try {
//		 JSONObject jsonobj = new JSONObject();
//                 if(docReq!=null && id!=null && docReq.getDocumentCode()!=null && docReq.getDocumentCode().trim().length()>0
//                         && docReq.getOrganizationCode()!=null && docReq.getOrganizationCode().trim().length()>0)
//                 {
//                   DocumentOrganizationMapping dom= documentOrganizationMappingRepository.getDocumentOrganizationMappingByNotIDDocCodeAndOrgCode(id,docReq.getDocumentCode().trim(), docReq.getOrganizationCode().trim());
//                   if(dom!=null && dom.getId()>0)
//                   {
//                       jsonobj.put("responsecode", 409);
//                       jsonobj.put("message", "Record is already exist.");
//                       jsonobj.put("timestamp", new Date());
//                   }
//                   else
//                     {
//                         DocumentOrganizationMapping dm = 
//                         dm.setDocumentCode(docReq.getDocumentCode().trim());
//                         dm.setOrganizationCode(docReq.getOrganizationCode().trim());
//                         dm.setIpAddress(ip);
//                         DocumentOrganizationMapping dmres = documentOrganizationMappingRepository.save(dm);
//                         if (dmres != null && dmres.getId() > 0) {
//                             jsonobj.put("responsecode", 200);
//                             jsonobj.put("timestamp", new Date());
//                             jsonobj.put("message",
//                                     "Document Organization Mapping has been added successfully.");
//                             ObjectMapper mapperObj = new ObjectMapper();
//                             String Detail = mapperObj.writeValueAsString(dmres);
//                             jsonobj.put("data", new JSONObject(Detail));
//                         } else {
//                             jsonobj.put("responsecode", 400);
//                             jsonobj.put("timestamp", new Date());
//                             jsonobj.put("message", "Failed");
//                         }
//                     }
//                 } else {
//		 jsonobj.put("responsecode", 404);
//		 jsonobj.put("message", "ID, Document Code, Organization Code should not be blank.");
//		 jsonobj.put("timestamp", new Date());
//		 }
//		 res = jsonobj.toString();
//		 } catch (JSONException | JsonProcessingException ex) {
//		 GigflexResponse derr = new GigflexResponse(500, new Date(),
//		 "JSON parsing exception occurred.");
//		 res = derr.toString();
//		 } catch (Exception ex) {
//		 GigflexResponse derr = new GigflexResponse(500, new Date(),
//		 "Exception occurred.");
//		 res = derr.toString();
//		 }
//		 return res;
//    
//    }

    
    
}
