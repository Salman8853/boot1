package com.gigflex.prototype.microservices.certificationsmaster.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.gigflex.prototype.microservices.certificationsmaster.dtob.CertificationsMaster;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignment;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertifications;

public interface CertificationsMasterRepository extends JpaRepository<CertificationsMaster,Long>,JpaSpecificationExecutor<CertificationsMaster>{
	
	@Query("SELECT cm FROM CertificationsMaster cm WHERE cm.isDeleted != TRUE AND cm.certificationCode = :certificationCode")
	public CertificationsMaster getCertificationsMasterByCertificationCode(@Param("certificationCode") String certificationCode);
	
	@Query("SELECT wc FROM WorkerCertifications wc WHERE wc.isDeleted != TRUE AND wc.certificationCode = :certificationCode")
	public List<WorkerCertifications> getWorkerCertificationsByCertificationCode(@Param("certificationCode") String certificationCode);
	
	@Query("SELECT wc FROM WorkerScheduleRequestAssignment wc WHERE wc.isDeleted != TRUE AND wc.certificationCode = :certificationCode")
	public List<WorkerScheduleRequestAssignment> getWorkerScheduleReqAssgnByCertificationCode(@Param("certificationCode") String certificationCode);
	
	@Transactional
	public Integer deleteCertificationsMasterByCertificationCode(String certificationCode);
	
//	@Query("SELECT c FROM CertificationsMaster c , WorkerCertifications w, Worker wo WHERE wo.isDeleted != TRUE AND w.workerCode = wo.workerCode AND w.certificationCode = c.certificationCode AND wo.workerCode = :workerCode")
//	public List<CertificationsMaster> getCertificationsMasterByWorkerCode(@Param("workerCode") String workerCode);
//	
//	@Query("SELECT c FROM CertificationsMaster c , WorkerCertifications w, Worker wo WHERE wo.isDeleted != TRUE AND c.isAssigned = TRUE AND w.workerCode = wo.workerCode AND w.certificationCode = c.certificationCode AND wo.workerCode = :workerCode")
//	public List<CertificationsMaster> getCertificationsMasterByWorkerCodeAssigned(@Param("workerCode") String workerCode);
//	
	@Query("SELECT cm,o.organizationName FROM CertificationsMaster cm, Organization o WHERE cm.isDeleted != TRUE AND cm.organizationCode = o.organizationCode  AND cm.organizationCode = :organizationCode")
	public List<Object> getCertificationsMasterByOrganizationCode(@Param("organizationCode") String organizationCode);

//	@Query("SELECT c FROM CertificationsMaster c , WorkerCertifications w, Worker wo WHERE wo.isDeleted != TRUE AND w.workerCode = wo.workerCode AND w.certificationCode = c.certificationCode AND wo.workerCode = :workerCode")
//	public List<CertificationsMaster> getCertificationsMasterByWorkerCode(@Param("workerCode") String workerCode,Pageable pageableRequest);
	
	@Query("SELECT cm,o.organizationName FROM CertificationsMaster cm, Organization o WHERE cm.isDeleted != TRUE AND cm.organizationCode = o.organizationCode  AND cm.organizationCode = :organizationCode")
	public List<Object> getCertificationsMasterByOrganizationCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);

	
	@Query("SELECT cm,o.organizationName FROM CertificationsMaster cm, Organization o WHERE cm.isDeleted != TRUE AND cm.organizationCode = o.organizationCode ")
    public List<Object> getAllCertificationsMaster();
	
	@Query("SELECT cm,o.organizationName FROM CertificationsMaster cm, Organization o WHERE cm.isDeleted != TRUE AND cm.organizationCode = o.organizationCode ")
    public List<Object> getAllCertificationsMaster(Pageable pageableRequest);

	@Query("SELECT cm FROM CertificationsMaster cm WHERE cm.isDeleted != TRUE AND cm.id = :id")
	public CertificationsMaster getCertificationsMastersById(@Param("id") Long id);
	
	@Query("SELECT cm FROM CertificationsMaster cm WHERE cm.isDeleted != TRUE AND cm.certificationName = :certificationName")
	public List<CertificationsMaster> getCertificationsMasterByCertificationsName(@Param("certificationName") String certificationName);
        
        @Query("SELECT cm FROM CertificationsMaster cm WHERE cm.isDeleted != TRUE AND cm.certificationName = :certificationName AND cm.organizationCode = :organizationCode")
	public CertificationsMaster getCertificationsMasterByCertificationsNameOrgCode(@Param("certificationName") String certificationName,@Param("organizationCode") String organizationCode);
        
        @Query("SELECT cm FROM CertificationsMaster cm WHERE cm.isDeleted != TRUE AND cm.certificationName = :certificationName AND cm.organizationCode = :organizationCode AND cm.id != :id")
	public CertificationsMaster getCertificationsMasterByCertificationsNameOrgCodeNotID(@Param("certificationName") String certificationName,@Param("organizationCode") String organizationCode,@Param("id") Long id);
        @Query("Select certimaster from CertificationsMaster  certimaster, WorkerCertifications wrkrcertfkt where wrkrcertfkt.workerCode=:workerCode AND certimaster.certificationCode=wrkrcertfkt.certificationCode")
        public List<CertificationsMaster>getCertificationmasterByWorkerCode(@Param("workerCode") String workerCode);
}