package com.gigflex.prototype.microservices.shift.dtob;



/**
 * 
 * @author ajit.p
 *
 */
public class ShiftRequest {
	
	private String organizationCode;
	
	private String daysCode;
	
	private String workingLocationCode;

	private String shiftName;
	
	private String startTime;
	
	private String endTime;
	
    private Boolean isActive;

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getDaysCode() {
		return daysCode;
	}

	public void setDaysCode(String daysCode) {
		this.daysCode = daysCode;
	}

	public String getWorkingLocationCode() {
		return workingLocationCode;
	}

	public void setWorkingLocationCode(String workingLocationCode) {
		this.workingLocationCode = workingLocationCode;
	}

	public String getShiftName() {
		return shiftName;
	}

	public void setShiftName(String shiftName) {
		this.shiftName = shiftName;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}
	
	

	
}
