/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.healthcarenotification.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotificationRequest;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotificationUpdate;
import com.gigflex.prototype.microservices.healthcarenotification.repository.HealthcareNotificationDao;
import com.gigflex.prototype.microservices.healthcarenotification.service.HealthcareNotificationService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class HealthcareNotificationServiceImpl implements HealthcareNotificationService{

    @Autowired
    private HealthcareNotificationDao notificationDao;

    @Autowired
    private WorkerRepository workerDao;

    @Autowired
    KafkaService kafkaService;
    
    @Override
    public String saveHealthcareNotification(HealthcareNotificationRequest notificationReq, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (notificationReq != null) {

				if (notificationReq.getUserCode() != null && notificationReq.getUserCode().trim().length() > 0
						&& notificationReq.getMessage() != null && notificationReq.getMessage().trim().length() > 0) {

					Worker worker = workerDao.getWorkerdetailByworkerCode(notificationReq.getUserCode());

					if ( worker != null && worker.getId() > 0)  {

						HealthcareNotification notification = new HealthcareNotification();

						notification.setUserCode(notificationReq.getUserCode());
						notification.setMessage(notificationReq.getMessage());
						notification.setIsRead(Boolean.FALSE);
						notification.setIpAddress(ip);

						HealthcareNotification notificationRes = notificationDao.save(notification);

						if (notificationRes != null && notificationRes.getId() > 0) {

							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message", "Notification has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj.writeValueAsString(notificationRes);
							jsonobj.put("data", new JSONObject(Detail));

						} else {
							jsonobj.put("message", "Failed");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "User Code not found.");
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Data should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public void saveHealthcareNotification(HealthcareNotification notification) {
       
        try {
	
                if (notification != null) {
				

                    HealthcareNotification notificationRes = notificationDao.save(notification);

                    if (notificationRes != null && notificationRes.getId() > 0) {

                            kafkaService.sendNotifications(notificationRes);
                    }
						
                }

            }catch (Exception ex) {
//			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            ex.printStackTrace();
    }
    }

    @Override
    public String updateHealthcareNotificationByNotificationCode(HealthcareNotificationUpdate notificationReq, String notificationCode, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			HealthcareNotification notification = notificationDao.getHealthcareNotificationByNotificationCode(notificationCode);

			if (notification != null && notification.getId() > 0) {

				notification.setIsRead(notificationReq.getIsRead());
				notification.setIpAddress(ip);

				HealthcareNotification notificationRes = notificationDao.save(notification);

				if (notificationRes != null && notificationRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Notification has been updated");
					jsonobj.put("timestamp", new Date());
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(notificationRes);
					jsonobj.put("data", new JSONObject(Detail));
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Notification updation has been failed.");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Notification Code is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String getAllHealthcareNotificationByUserCodeWithRead(String userCode, int page, int limit) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				Pageable pageableRequest = PageRequest.of(page, limit);

				List<HealthcareNotification> listCheck = notificationDao.getAllHealthcareNotificationByUserCodeAndIsRead(userCode);

				Integer count = listCheck.size();

				List<HealthcareNotification> list = notificationDao.getAllHealthcareNotificationByUserCodeAndIsRead(userCode,
						pageableRequest);

				if (list != null && list.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(list);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String getAllHealthcareNotificationByUserCodeWithRead(String userCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<HealthcareNotification> list = notificationDao.getAllHealthcareNotificationByUserCodeAndIsRead(userCode);

			if (list != null && list.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(list);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String getAllHealthcareNotificationByUserCodeWithUnRead(String userCode, int page, int limit) {
       String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (limit > 0) {
				Pageable pageableRequest = PageRequest.of(page, limit);

				List<HealthcareNotification> listCheck = notificationDao.getAllHealthcareNotificationByUserCode(userCode);

				Integer count = listCheck.size();

				List<HealthcareNotification> list = notificationDao.getAllHealthcareNotificationByUserCode(userCode, pageableRequest);

				if (list != null && list.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(list);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("count", count);
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}

			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

    @Override
    public String getAllHealthcareNotificationByUserCodeWithUnRead(String userCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<HealthcareNotification> list = notificationDao.getAllHealthcareNotificationByUserCode(userCode);

			if (list != null && list.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(list);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }
    
}
