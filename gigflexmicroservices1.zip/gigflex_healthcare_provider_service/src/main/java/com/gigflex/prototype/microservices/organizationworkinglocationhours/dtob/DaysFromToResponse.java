package com.gigflex.prototype.microservices.organizationworkinglocationhours.dtob;

import java.util.Date;

import javax.persistence.Column;

public class DaysFromToResponse {
	
	private Date fromDate;

	private Date toDate;
	
	private String daysName;

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public String getDaysName() {
		return daysName;
	}

	public void setDaysName(String daysName) {
		this.daysName = daysName;
	}
	
	

}
