package com.gigflex.prototype.microservices.organizationworkerskill.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrgWorkerSkillRequest;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrgWorkerSkillResponse;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkill;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkillRequest;
import com.gigflex.prototype.microservices.organizationworkerskill.repository.OrgWorkerSkillDao;
import com.gigflex.prototype.microservices.organizationworkerskill.search.OrganizationWorkerSkillSpecificationsBuilder;
import com.gigflex.prototype.microservices.organizationworkerskill.service.OrgWorkerSkillService;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.skillmaster.repository.SkillMasterDao;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.organizationskill.repository.OrganizationSkillDao;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationSkillColorDataModel;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationSkillColorDataResponse;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationSkillsModel;
import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkillsModel;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;

/**
 *
 * @author amit.kumar
 */

@Service
public class OrgWorkerSkillServiceImpl implements OrgWorkerSkillService {

	@Autowired
	private OrgWorkerSkillDao orgWorkerSkillDao;
	
        @Autowired
        OrganizationRepository orgRep;
         
   	    
        @Autowired
        SkillMasterDao skillRep;

        @Autowired
        WorkerRepository workRep;
        
        @Autowired
        OrganizationSkillDao orgSkillDao;

	@Override
	public String updateOrgWorkerSkillById(Long id,
			OrganizationWorkerSkillRequest orgWorkerSkillReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && orgWorkerSkillReq != null) {
				if (orgWorkerSkillReq.getSkillCode() != null
						&& orgWorkerSkillReq.getSkillCode().trim().length() > 0
						&& orgWorkerSkillReq.getOrganizationCode() != null
						&& orgWorkerSkillReq.getOrganizationCode().trim()
								.length() > 0
						&& orgWorkerSkillReq.getWorkerCode() != null
						&& orgWorkerSkillReq.getWorkerCode().trim().length() > 0) {

					OrganizationWorkerSkill orgWorSkInDb = orgWorkerSkillDao
							.getOrganizationWorkerSkillById(id);
					
					
					OrganizationWorkerSkill orgSkills = orgWorkerSkillDao.getOrgWorkSkillCheckForUpdate(id, orgWorkerSkillReq.getSkillCode(), orgWorkerSkillReq.getOrganizationCode(), orgWorkerSkillReq.getWorkerCode());

					if (orgSkills != null && orgSkills.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "Record already exist.");
					} else {
					
					Organization org = orgRep
							.findByOrganizationCode(orgWorkerSkillReq
									.getOrganizationCode());
					if (org != null && org.getId() > 0) {
					Worker worker = workRep.findByWorkerCode(orgWorkerSkillReq.getWorkerCode());
					if(worker != null && worker.getId() > 0){
					SkillMaster skill = skillRep.getSkillCode(orgWorkerSkillReq.getSkillCode());
					if (skill != null && skill.getId() > 0) {
					
					if (orgWorSkInDb != null && orgWorSkInDb.getId() > 0) {

						OrganizationWorkerSkill map = orgWorSkInDb;

						map.setSkillCode(orgWorkerSkillReq.getSkillCode());
						map.setOrganizationCode(orgWorkerSkillReq
								.getOrganizationCode());
						map.setWorkerCode(orgWorkerSkillReq.getWorkerCode());
//						map.setExperienceInYear(orgWorkerSkillReq
//								.getExperienceInYear());
						map.setExperienceInDays(orgWorkerSkillReq.getExperienceInDays());
						map.setExperienceInDays(orgWorkerSkillReq.getExperienceInDays());
						if (orgWorkerSkillReq.getIsAssigned() != null) {
							map.setIsAssigned(orgWorkerSkillReq.getIsAssigned());
						} else {
							map.setIsAssigned(false);
						}

						map.setIpAddress(ip);

						OrganizationWorkerSkill mapRes = orgWorkerSkillDao
								.save(map);
						if (mapRes != null && mapRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"OrganizationWorkerSkill updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(mapRes);
							jsonobj.put("data", new JSONObject(Detail));
//							kafkaService
//									.sendUpdateOrganizationWorkerSkill(mapRes);

						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"OrganizationWorkerSkill updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"OrganizationWorkerSkill ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
					
					} else {
						jsonobj.put("message", "Skill Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
					}
					
				} else {
					jsonobj.put("message", "Worker Code Not Found.");
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					}
					
					} else {
					jsonobj.put("message", "Organization Code Not Found.");
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					}
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message",
							"Organization code and Worker Code and Skill Code should not be blank");

					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getAllOrgWorkerSkill() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			List<Object> objlst = orgWorkerSkillDao
					.getAllOrgWorkerSkillWithNames();
			List<OrgWorkerSkillResponse> maplst = new ArrayList<OrgWorkerSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						OrgWorkerSkillResponse ows = new OrgWorkerSkillResponse();

						OrganizationWorkerSkill data = (OrganizationWorkerSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
						ows.setWorkerCode(data.getWorkerCode());
//						ows.setExperienceInYear(data.getExperienceInYear());
						
						ows.setExperienceInDays(data.getExperienceInDays());


						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
						ows.setWorkerName((String) arr[3]);

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String findAllOrgWorkerSkill() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<OrganizationWorkerSkill> maplst = orgWorkerSkillDao
					.getAllOrganizationWorkerSkill();
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			if (maplst != null && maplst.size() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("message", "No data found.");
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String findOrgWorkerSkillById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			OrganizationWorkerSkill orgWorSklst = orgWorkerSkillDao
					.getOrganizationWorkerSkillById(id);
			if (orgWorSklst != null && orgWorSklst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(orgWorSklst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String saveOrgWorkerSkill(OrganizationWorkerSkillRequest orgWorkerSkillReq,
			String ip) {
		String res = "";
		try {
//			JSONArray jarr = new JSONArray();

			if (orgWorkerSkillReq != null) {
				if (orgWorkerSkillReq.getSkillCode() != null
						&& orgWorkerSkillReq.getSkillCode().trim().length() > 0
						&& orgWorkerSkillReq.getOrganizationCode() != null
						&& orgWorkerSkillReq.getOrganizationCode().trim()
								.length() > 0
						&& orgWorkerSkillReq.getWorkerCode() != null
						&& orgWorkerSkillReq.getWorkerCode().trim().length() > 0) {
			
//					for (String skillcode : orgWorkerSkillReq.getSkillCode()) {
//						if (skillcode != null && skillcode.trim().length() > 0) {
							JSONObject jsonobj = new JSONObject();
							OrganizationWorkerSkill orgSkill = orgWorkerSkillDao.getOrgWorkSkillCheckForSave(orgWorkerSkillReq.getSkillCode(), orgWorkerSkillReq.getOrganizationCode(), orgWorkerSkillReq.getWorkerCode());
							if (orgSkill != null && orgSkill.getId() > 0) {
								jsonobj.put("responsecode", 409);
								jsonobj.put("timestamp", new Date());
								jsonobj.put("message", "Record already exist.");
							} else {
							
							Organization org = orgRep
									.findByOrganizationCode(orgWorkerSkillReq
											.getOrganizationCode());
							if (org != null && org.getId() > 0) {
							Worker worker = workRep.findByWorkerCode(orgWorkerSkillReq.getWorkerCode());
							if(worker != null && worker.getId() > 0){
							SkillMaster skill = skillRep.getSkillCode(orgWorkerSkillReq.getSkillCode());
							if (skill != null && skill.getId() > 0) {

							OrganizationWorkerSkill map = new OrganizationWorkerSkill();

							map.setSkillCode(orgWorkerSkillReq.getSkillCode());
							map.setOrganizationCode(orgWorkerSkillReq
									.getOrganizationCode());
							map.setWorkerCode(orgWorkerSkillReq.getWorkerCode());
//							map.setExperienceInYear(orgWorkerSkillReq
//									.getExperienceInYear());
							map.setExperienceInDays(orgWorkerSkillReq.getExperienceInDays());

							if (orgWorkerSkillReq.getIsAssigned() != null) {
								map.setIsAssigned(orgWorkerSkillReq.getIsAssigned());
							} else {
								map.setIsAssigned(false);
							}
							map.setIpAddress(ip);

							OrganizationWorkerSkill mapRes = orgWorkerSkillDao
									.save(map);
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());

							if (mapRes != null && mapRes.getId() > 0) {
//								kafkaService.sendOrganizationWorkerSkill(mapRes);
								jsonobj.put("message",
										"Organization Code and Skill Code And Worker Code has been added successfully.");
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(mapRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("message", "Failed");
							}
							
						} else {
							jsonobj.put("message", "Skill Code Not Found.");
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
						}
						
					} else {
						jsonobj.put("message", "Worker Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						}
						
						} else {
						jsonobj.put("message", "Organization Code Not Found.");
						jsonobj.put("responsecode", 400);
						jsonobj.put("timestamp", new Date());
						}
							}
//							jarr.add(jsonobj);

//						}
//					}
//					if (jarr.size() > 0) {
//						res = jarr.toString();
//					} else {
//						GigflexResponse derr = new GigflexResponse(400,
//								new Date(), "Multiple add failed.");
//						res = derr.toString();
//					}
//				}
							res = jsonobj.toString();
				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(),
							"Organization Code and Skill Code And Worker Code should not be blank");
					res = derr.toString();

				}
			}

		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;

	}
	
	@Override
	public String deleteOrgWorkerSkillById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<OrganizationWorkerSkill> mapData = orgWorkerSkillDao
					.findById(id);
			if (mapData.isPresent() && mapData.get() != null) {

				orgWorkerSkillDao.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message",
						" OrganizationWorkerSkill has been deleted.");
				jsonobj.put("timestamp", new Date());
//				kafkaService.sendDeleteOrganizationWorkerSkill(mapData.get());
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softDeleteOrgWorkerSkillById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			OrganizationWorkerSkill orgWorSklst = orgWorkerSkillDao
					.getOrganizationWorkerSkillById(id);

			if (orgWorSklst != null && orgWorSklst.getId() > 0) {
				orgWorSklst.setIsDeleted(true);
				OrganizationWorkerSkill orgwkSkillRes = orgWorkerSkillDao
						.save(orgWorSklst);
				if (orgwkSkillRes != null && orgwkSkillRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());

					jsonobj.put("message",
							"OrganizationWorkerSkill deleted successfully.");

//					kafkaService
//							.sendUpdateOrganizationWorkerSkill(orgwkSkillRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getSkillsByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (organizationCode != null && organizationCode.length() > 0) {
                            
                           List<Object> objlst=  orgWorkerSkillDao.getOrgWorkerSkillsByOrganizationCode(organizationCode);
                            
                            List<OrgWorkerSkillResponse> maplst = new ArrayList<OrgWorkerSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						OrgWorkerSkillResponse ows = new OrgWorkerSkillResponse();

						OrganizationWorkerSkill data = (OrganizationWorkerSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
						ows.setWorkerCode(data.getWorkerCode());
//						ows.setExperienceInYear(data.getExperienceInYear());
						
						ows.setExperienceInDays(data.getExperienceInDays());


						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
						ows.setWorkerName((String) arr[3]);

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Organization Code should not be blank.");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getSkillsByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (workerCode != null && workerCode.length() > 0) {
                         List<Object> objlst=  orgWorkerSkillDao.getOrgWorkerSkillsByWorkerCode(workerCode);
                         
                         List<OrgWorkerSkillResponse> maplst = new ArrayList<OrgWorkerSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						OrgWorkerSkillResponse ows = new OrgWorkerSkillResponse();

						OrganizationWorkerSkill data = (OrganizationWorkerSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
						ows.setWorkerCode(data.getWorkerCode());
//						ows.setExperienceInYear(data.getExperienceInYear());
						
						ows.setExperienceInDays(data.getExperienceInDays());


						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
						ows.setWorkerName((String) arr[3]);

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			
                        
                        
                        
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker code should not be blank.");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteById(List<Long> idList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (Long id : idList) {
				if (id != null && id > 0) {
					JSONObject jsonobj = new JSONObject();

					OrganizationWorkerSkill orgWorSklst = orgWorkerSkillDao
							.getOrganizationWorkerSkillById(id);

					if (orgWorSklst != null && orgWorSklst.getId() > 0) {

						orgWorSklst.setIsDeleted(true);
						OrganizationWorkerSkill orgwkSkillRes = orgWorkerSkillDao
								.save(orgWorSklst);
						if (orgwkSkillRes != null && orgwkSkillRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message",
									"Organization Worker Skill deleted successfully.");
//							kafkaService
//									.sendUpdateOrganizationWorkerSkill(orgwkSkillRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("Id", id);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("Id", id);
						jsonobj.put("message", "Record Not Found");
					}

					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getSkillsByOrgCodeByPage(String organizationCode, int page,
			int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (organizationCode != null && organizationCode.length() > 0) {
                        
                            int count=0;
                           List<Object> objlst=  orgWorkerSkillDao.getOrgWorkerSkillsByOrganizationCode(organizationCode,pageableRequest);
                           List<Object> objlstCnt=  orgWorkerSkillDao.getOrgWorkerSkillsByOrganizationCode(organizationCode);
                            if(objlstCnt!=null && objlstCnt.size()>0)
                            {
                                count=objlstCnt.size();
                            }
                            List<OrgWorkerSkillResponse> maplst = new ArrayList<OrgWorkerSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						OrgWorkerSkillResponse ows = new OrgWorkerSkillResponse();

						OrganizationWorkerSkill data = (OrganizationWorkerSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
						ows.setWorkerCode(data.getWorkerCode());
//						ows.setExperienceInYear(data.getExperienceInYear());
						
						ows.setExperienceInDays(data.getExperienceInDays());


						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
						ows.setWorkerName((String) arr[3]);

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("count",count);
                                        jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			
                        
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Organization code should not be blank.");
			}
} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getSkillsByWorkerCodeByPage(String workerCode, int page,
			int limit) {
		String res = "";
		try {
			
			JSONObject jsonobj = new JSONObject();
                        if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);
			if (workerCode != null && workerCode.length() > 0) {
                        
                            int count=0;
                           List<Object> objlst=  orgWorkerSkillDao.getOrgWorkerSkillsByWorkerCode(workerCode,pageableRequest);
                           List<Object> objlstCnt=  orgWorkerSkillDao.getOrgWorkerSkillsByWorkerCode(workerCode);
                            if(objlstCnt!=null && objlstCnt.size()>0)
                            {
                                count=objlstCnt.size();
                            }
                            List<OrgWorkerSkillResponse> maplst = new ArrayList<OrgWorkerSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						OrgWorkerSkillResponse ows = new OrgWorkerSkillResponse();

						OrganizationWorkerSkill data = (OrganizationWorkerSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
						ows.setWorkerCode(data.getWorkerCode());
//						ows.setExperienceInYear(data.getExperienceInYear());
						
						ows.setExperienceInDays(data.getExperienceInDays());


						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
						ows.setWorkerName((String) arr[3]);

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("count",count);
                                        jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			
                        
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker code should not be blank.");
			}
} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getOrgWorkerSkill(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<OrganizationWorkerSkill> org = orgWorkerSkillDao
					.getAllOrganizationWorkerSkill(pageableRequest);
                        int count=0;
                        List<OrganizationWorkerSkill> orgcnt = orgWorkerSkillDao.getAllOrganizationWorkerSkill();
			if(orgcnt!=null && orgcnt.size()>0)
                        {
                            count=orgcnt.size();
                        }
			if (org != null && org.size() > 0) {
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("message", "Success");
                            jsonobj.put("count", count);
                            jsonobj.put("timestamp", new Date());
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(org);
                            jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getOrgWorkerSkillWithNamesByPage(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<Object> objlst = orgWorkerSkillDao.getAllOrgWorkerSkillWithNames(pageableRequest);
			List<OrgWorkerSkillResponse> maplst = new ArrayList<OrgWorkerSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
                            int count=0;
                            List<Object> objlstcnt = orgWorkerSkillDao.getAllOrgWorkerSkillWithNames();
                            if(objlstcnt!=null && objlstcnt.size()>0)
                            {
                               count=objlstcnt.size();
                            }
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						OrgWorkerSkillResponse ows = new OrgWorkerSkillResponse();

						OrganizationWorkerSkill data = (OrganizationWorkerSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
						ows.setWorkerCode(data.getWorkerCode());
//						ows.setExperienceInYear(data.getExperienceInYear());
						
						ows.setExperienceInDays(data.getExperienceInDays());


						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
						ows.setWorkerName((String) arr[3]);

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
                                        jsonobj.put("count", count);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getSkillsByWorkerCodeAssigned(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			
			if (workerCode != null && workerCode.length() > 0) {
                         List<Object> objlst=  orgWorkerSkillDao.getOrgWorkerSkillsByWorkerCodeAssigned(workerCode);
                         
                         List<OrgWorkerSkillResponse> maplst = new ArrayList<OrgWorkerSkillResponse>();
			if (objlst != null && objlst.size() > 0) {
				for (int i = 0; i < objlst.size(); i++) {
					Object[] arr = (Object[]) objlst.get(i);
					if (arr.length >= 4) {
						OrgWorkerSkillResponse ows = new OrgWorkerSkillResponse();

						OrganizationWorkerSkill data = (OrganizationWorkerSkill) arr[0];

						ows.setId(data.getId());
						ows.setSkillCode(data.getSkillCode());
						ows.setOrganizationCode(data.getOrganizationCode());
						ows.setWorkerCode(data.getWorkerCode());
//						ows.setExperienceInYear(data.getExperienceInYear());
						
						ows.setExperienceInDays(data.getExperienceInDays());


						ows.setSkillName((String) arr[1]);
						ows.setOrganizationName((String) arr[2]);
						ows.setWorkerName((String) arr[3]);

						maplst.add(ows);

					}
				}
				if (maplst.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(maplst);
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONArray(Detail));
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}
			
                        
                        
                        
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Worker code should not be blank.");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
            if(search != null && search.trim().length() > 0){
			JSONObject jsonobj = new JSONObject();
			
			OrganizationWorkerSkillSpecificationsBuilder builder = new OrganizationWorkerSkillSpecificationsBuilder();
		        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
		        java.util.regex.Matcher matcher = pattern.matcher(search + ",");
		        while (matcher.find()) {
		            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
		        }
		         
		        Specification<OrganizationWorkerSkill> spec = builder.build();
                        if(spec!=null){
		        List<OrganizationWorkerSkill> orglst = orgWorkerSkillDao.findAll(spec);
			if(orglst != null && orglst.size() > 0){
			for(OrganizationWorkerSkill org : orglst){
				if(org.getIsDeleted() != null && org.getIsDeleted() != true){

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(org);
					JSONObject jsonobjNew = new JSONObject();
					jsonobjNew.put("OrganizationWorkerSkill", new JSONObject(Detail));
					jarr.add(jsonobjNew);

			} 
				
			} 
			if (jarr.size() > 0) {
				
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			jsonobj.put("data", jarr);
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}
			
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}}
                        else{
                           jsonobj.put("responsecode", 400);
			   jsonobj.put("message", "Record Not Found!");
			   jsonobj.put("timestamp", new Date()); 
                        }
			res = jsonobj.toString();
		
            }else{
            	GigflexResponse derr = new GigflexResponse(400, new Date(),
    					"Input data is not valid.");
    			res = derr.toString();

            }
			
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

    @Override
    public String getSkillsWorkerByOrganizationCode(String organizationCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        String organizationName = "";
                        if(organizationCode != null && organizationCode.trim().length() > 0)
                        {
                            Organization oroganization = orgRep.findByOrganizationCode(organizationCode.trim());
                            if(oroganization != null)
                            {
                                organizationName = oroganization.getOrganizationName();
                            }
                            
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
			    jsonobj.put("message", "Organization code should not be blank");
			    jsonobj.put("timestamp", new Date());
                            
                            res = jsonobj.toString();
                            return res;
                        }
                        
                        
			List<OrganizationSkill> objlist = orgWorkerSkillDao
					.getOrgSkillsByOrganizationCode(organizationCode);
                        
                        
			List<OrganizationSkillsModel> orgSkillList = new ArrayList<OrganizationSkillsModel>();
			if (objlist != null && objlist.size() > 0) {
                            
                                
				for (int i = 0; i < objlist.size(); i++) {
					
                                    OrganizationSkill orgSkill = objlist.get(i);
                                    OrganizationSkillsModel orgSkillsRes = new OrganizationSkillsModel();
                                    orgSkillsRes.setOrganizationSkillId(orgSkill.getId()); 
                                    orgSkillsRes.setColor(orgSkill.getColor());
                                    String skillCode = orgSkill.getSkillCode();                                    
                                    SkillMaster skillMaster   = skillRep.getSkillCode(skillCode);
                                    if(skillMaster != null)
                                    {
                                        orgSkillsRes.setSkillName(skillMaster.getSkillName()); 
                                    }                                    
                                    orgSkillsRes.setSkillCode(skillCode);
                                    orgSkillsRes.setOrganizationCode(organizationCode); 
                                    orgSkillsRes.setOrganizationName(organizationName); 
                                    
                                    if(skillCode != null && skillCode.trim().length() > 0)
                                    {
                                        List<OrganizationWorkerSkill> objWorkerSkillList = orgWorkerSkillDao
					.getOrgWorkerSkillsByOrgCodeAndSkillCode(organizationCode,skillCode);
                                        
                                        List<OrganizationWorkerSkillsModel> organizationWorkerSkillsModelList = new ArrayList<OrganizationWorkerSkillsModel>();
                                        if (objWorkerSkillList != null && objWorkerSkillList.size() > 0)
                                        {
                                            for (int j = 0; j < objWorkerSkillList.size(); j++) {
                                                
                                                OrganizationWorkerSkill orgWorkerSkill = objWorkerSkillList.get(j);
                                                
                                                OrganizationWorkerSkillsModel orgWorkerSkillsModel = new OrganizationWorkerSkillsModel();
                                                orgWorkerSkillsModel.setOrganizationWorkerSkillId(orgWorkerSkill.getId()); 
                                                orgWorkerSkillsModel.setExperienceInDays(orgWorkerSkill.getExperienceInDays());
                                                orgWorkerSkillsModel.setIsAssigned(orgWorkerSkill.getIsAssigned());
                                                orgWorkerSkillsModel.setOrganizationCode(orgWorkerSkill.getOrganizationCode());
                                                orgWorkerSkillsModel.setSkillCode(orgWorkerSkill.getSkillCode());
                                                orgWorkerSkillsModel.setWorkerCode(orgWorkerSkill.getWorkerCode()); 
                                                Worker worker = workRep.findByWorkerCode(orgWorkerSkill.getWorkerCode());
                                                if(worker != null)
                                                {
                                                    orgWorkerSkillsModel.setWorkerName(worker.getName());
                                                }
                                                 
                                                organizationWorkerSkillsModelList.add(orgWorkerSkillsModel);
                                            }
                                            
                                            
                                        }
                                        orgSkillsRes.setWorkerList(organizationWorkerSkillsModelList);
                                        
                                    }

                                    orgSkillList.add(orgSkillsRes);

					
				}
				if (orgSkillList.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
                                        
                                        OrganizationSkillColorDataModel model = new OrganizationSkillColorDataModel();
                                        model.setOrganizationCode(organizationCode);
                                        model.setOrganizationName(organizationName);
                                        model.setSkillColorList(orgSkillList); 
                                        
					String Detail = mapperObj.writeValueAsString(model);
                                        
                                        
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
//                                        jsonobj.put("organizationCode", organizationCode);
//                                        jsonobj.put("organizationName", organizationName);
					jsonobj.put("data", new JSONObject(Detail)); 
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
        
        
        
    }

    @Override
    public String saveAndUpdateOrganizationWorkerSkill(OrganizationSkillsModel orgSkillsModelReq, String ip) {
       
        String res = "";
        OrganizationSkill organizationSkillRes = null;
        OrganizationWorkerSkill organizationWorkerSkillRes = null;
                
        List<OrganizationWorkerSkill> organizationWorkerSkillResSuccessList = new ArrayList<OrganizationWorkerSkill>();
        List<OrganizationWorkerSkill> organizationWorkerSkillResFailerList = new ArrayList<OrganizationWorkerSkill>();
        
		try {
			JSONObject jsonobj = new JSONObject();
                        
			if (orgSkillsModelReq != null) {
				if (orgSkillsModelReq.getSkillCode() != null
						&& orgSkillsModelReq.getSkillCode().trim().length() > 0
						&& orgSkillsModelReq.getOrganizationCode() != null
						&& orgSkillsModelReq.getOrganizationCode().trim()
								.length() > 0
				) {

                                    OrganizationSkill orgSkillForUpdate = null;
                                    if(orgSkillsModelReq.getOrganizationSkillId() != null
						&& orgSkillsModelReq.getOrganizationSkillId().toString().trim().length() > 0)
                                    {  
                                        orgSkillForUpdate = orgSkillDao.getOrganizationSkillById(orgSkillsModelReq.getOrganizationSkillId());
                                    }
                                    
                                    if(orgSkillForUpdate == null)
                                    {
                                        // add case 
                                        // check if skill already exist
                                        
                                       OrganizationSkill organizationSkill = orgSkillDao.getSkillMasterBySkillCodeAndOrganizationCode(orgSkillsModelReq.getSkillCode(),orgSkillsModelReq.getOrganizationCode());
                                       
                                       if(organizationSkill != null )
                                       {
                                           
                                           jsonobj.put("responsecode", 400);
                                           jsonobj.put("message","Skill already exist");
                                           jsonobj.put("timestamp", new Date());
                                           
                                           res = jsonobj.toString();
                                           return res;
                                       }                                       
                                        
                                    }
                                    
                                    
                                        
                                        if(orgSkillForUpdate != null)
                                        { //Update OrganizationSkill
                                            orgSkillForUpdate.setColor(orgSkillsModelReq.getColor());
                                            orgSkillForUpdate.setIpAddress(ip);
//                                            orgSkillForUpdate.setOrganizationCode(orgSkillsModelReq.getOrganizationCode()); 
                                            orgSkillForUpdate.setSkillCode(orgSkillsModelReq.getSkillCode()); 
                                            
                                            organizationSkillRes = orgSkillDao.save(orgSkillForUpdate) ;                                            
                                        }
                                        else
                                        {   //Add OrganizationSkill
                                            
                                            OrganizationSkill orgSkillForSave = new OrganizationSkill();
                                            
                                            orgSkillForSave.setColor(orgSkillsModelReq.getColor());
                                            orgSkillForSave.setIpAddress(ip);
                                            orgSkillForSave.setOrganizationCode(orgSkillsModelReq.getOrganizationCode()); 
                                            orgSkillForSave.setSkillCode(orgSkillsModelReq.getSkillCode()); 
                                            
                                            organizationSkillRes = orgSkillDao.save(orgSkillForSave) ;                                            
  
                                        }
                                        
                                        
                                        
                                        List<OrganizationWorkerSkillsModel> workerList = orgSkillsModelReq.getWorkerList();
                                        
                                        if(workerList != null && workerList.size() > 0)
                                        {  
                                            
                                            for(int i =0 ; i < workerList.size() ; i++)
                                            {
                                                
                                            
                                            
                                                OrganizationWorkerSkillsModel model = workerList.get(i);
                                                OrganizationWorkerSkill orgWorkerSkillForUpdate = null;
                                                if(model.getOrganizationWorkerSkillId() != null && model.getOrganizationWorkerSkillId().toString().trim().length() > 0)
                                                { 
                                                    orgWorkerSkillForUpdate = orgWorkerSkillDao.getOrganizationWorkerSkillById(model.getOrganizationWorkerSkillId()) ;
                                                }
                                 
                                                    if(orgWorkerSkillForUpdate != null)
                                                    {  //update OrganizationWorkerSkill
                                                        
                                                        OrganizationWorkerSkill orgWrkSkillAlreadyExist = orgWorkerSkillDao.getCheckForOrganizationCodeWorkerCodeSkillCodeAndID(model.getOrganizationCode().trim(),model.getWorkerCode().trim(),model.getSkillCode().trim(),model.getOrganizationWorkerSkillId());
                                                        
                                                        if(orgWrkSkillAlreadyExist == null)
                                                        {
                                                            orgWorkerSkillForUpdate.setIpAddress(ip); 
                                                            orgWorkerSkillForUpdate.setExperienceInDays(model.getExperienceInDays()); 
                                                            orgWorkerSkillForUpdate.setIsAssigned(model.isIsAssigned());
                                                            orgWorkerSkillForUpdate.setOrganizationCode(model.getOrganizationCode());
                                                            orgWorkerSkillForUpdate.setWorkerCode(model.getWorkerCode());
                                                            orgWorkerSkillForUpdate.setSkillCode(model.getSkillCode());

                                                            organizationWorkerSkillRes = orgWorkerSkillDao.save(orgWorkerSkillForUpdate);

                                                            if(organizationWorkerSkillRes != null)
                                                            {
                                                                organizationWorkerSkillResSuccessList.add(organizationWorkerSkillRes);
                                                            }
                                                            else
                                                            {
                                                                organizationWorkerSkillResFailerList.add(organizationWorkerSkillRes);
                                                            }
                                                        }
                                                        else
                                                        {
                                                           organizationWorkerSkillResSuccessList.add(orgWrkSkillAlreadyExist);
                                                        }
                                                        
                                                        
                                                    }
                                                    else
                                                    {   //Add OrganizationWorkerSkill   
                                                        if(model.getWorkerCode() != null && model.getWorkerCode().trim().length() > 0                                                                
                                                                && model.getSkillCode() != null && model.getSkillCode().trim().length() > 0
                                                                && model.getOrganizationCode() !=null && model.getOrganizationCode().trim().length() > 0 )
                                                        {
                                                                                                                                  
                                                            OrganizationWorkerSkill orgWrkSkillAlreadyExist = orgWorkerSkillDao.getCheckForOrganizationCodeWorkerCodeAndSkillCode(model.getOrganizationCode().trim(),model.getWorkerCode().trim(),model.getSkillCode().trim());
                                                            
                                                            if(orgWrkSkillAlreadyExist == null)
                                                            {
                                                                OrganizationWorkerSkill orgWorkerSkillForSave = new OrganizationWorkerSkill();

                                                                orgWorkerSkillForSave.setIpAddress(ip); 
                                                                if(model.getExperienceInDays() != null && model.getExperienceInDays().toString().trim().length() > 0)
                                                                {
                                                                    orgWorkerSkillForSave.setExperienceInDays(model.getExperienceInDays());
                                                                }
                                                                else
                                                                {
                                                                    orgWorkerSkillForSave.setExperienceInDays(0L);
                                                                }

                                                                if(model.isIsAssigned() != null && model.isIsAssigned().toString().trim().length() > 0)
                                                                {
                                                                    orgWorkerSkillForSave.setIsAssigned(model.isIsAssigned());
                                                                }
                                                                else
                                                                {
                                                                    orgWorkerSkillForSave.setIsAssigned(false);
                                                                }

                                                                orgWorkerSkillForSave.setOrganizationCode(model.getOrganizationCode());
                                                                orgWorkerSkillForSave.setWorkerCode(model.getWorkerCode());
                                                                orgWorkerSkillForSave.setSkillCode(model.getSkillCode());


                                                                organizationWorkerSkillRes = orgWorkerSkillDao.save(orgWorkerSkillForSave);

                                                                if(organizationWorkerSkillRes != null)
                                                                {
                                                                    organizationWorkerSkillResSuccessList.add(organizationWorkerSkillRes);
                                                                }
                                                                else
                                                                {
                                                                    organizationWorkerSkillResFailerList.add(organizationWorkerSkillRes);
                                                                }
                                                            }
                                                            else
                                                            {
                                                                organizationWorkerSkillResSuccessList.add(orgWrkSkillAlreadyExist);
                                                                //for add any message for already exiist data
                                                            }
                                                            
                                                           
                                                        }

                                                    }
                                                    
                                                    
                                             }

                                        }
					
                                        if(organizationSkillRes != null && organizationSkillRes.getId() >0 
                                                && organizationWorkerSkillResFailerList.size() == 0)
                                        {
                                            
                                            jsonobj.put("responsecode", 200);
                                            jsonobj.put("message","Success");
                                            jsonobj.put("timestamp", new Date());
                                            
                                        }
                                        else
                                        {
                                            jsonobj.put("responsecode", 400);
                                            jsonobj.put("message","Failed");
                                            jsonobj.put("timestamp", new Date());
                                            
                                            
                                            for( int i =0 ; i < organizationWorkerSkillResSuccessList.size() ; i++ )
                                            {
                                                OrganizationWorkerSkill organizationWorkerSkill = organizationWorkerSkillResSuccessList.get(i);
                                                orgWorkerSkillDao.deleteById(organizationWorkerSkill.getId());                                                 
                                            }
//                                            if(organizationWorkerSkillRes != null && organizationWorkerSkillRes.getId() > 0  )
//                                            {
//                                                orgWorkerSkillDao.deleteById(organizationWorkerSkillRes.getId()); 
//                                            }
                                            
                                            if(organizationSkillRes != null && organizationSkillRes.getId() >0)
                                            {
                                                orgSkillDao.deleteById(organizationSkillRes.getId()); 
                                            }
                                        }
				} else {
                                    
					jsonobj.put("responsecode", 400);
					jsonobj.put("message",
							"Organization code and Skill Code should not be blank");

					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
        
    }

    @Override
    public String getSkillsWorkerByID(Long organizationSkillId) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        String organizationName = "";
                        String organizationCode = "";
                        if(organizationSkillId != null && organizationSkillId.toString().trim().length() > 0)
                        {
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
			    jsonobj.put("message", "Organization ID should not be blank");
			    jsonobj.put("timestamp", new Date());
                            
                            res = jsonobj.toString();
                            return res;
                        }
                        
                        
			OrganizationSkill orgSkill = orgWorkerSkillDao
					.getOrgSkillsByOrganizationSkillID(organizationSkillId);
			
			if (orgSkill != null && orgSkill.getId() > 0) {                            				
                                    
                                    OrganizationSkillsModel orgSkillsRes = new OrganizationSkillsModel();
                                    orgSkillsRes.setOrganizationSkillId(orgSkill.getId()); 
                                    orgSkillsRes.setColor(orgSkill.getColor());
                                    String skillCode = orgSkill.getSkillCode();                                    
                                    SkillMaster skillMaster   = skillRep.getSkillCode(skillCode);
                                    if(skillMaster != null)
                                    {
                                        orgSkillsRes.setSkillName(skillMaster.getSkillName()); 
                                    }                                    
                                    orgSkillsRes.setSkillCode(skillCode);
                                    organizationCode = orgSkill.getOrganizationCode();
                                    orgSkillsRes.setOrganizationCode(organizationCode); 
                                    
                                    Organization oroganization = orgRep.findByOrganizationCode(orgSkill.getOrganizationCode());
                                    if(oroganization != null)
                                    {                                        
                                        organizationName = oroganization.getOrganizationName();
                                        orgSkillsRes.setOrganizationName(organizationName);
                                    }
                                    
                                     
                                    
                                    if(skillCode != null && skillCode.trim().length() > 0)
                                    {
                                        List<OrganizationWorkerSkill> objWorkerSkillList = orgWorkerSkillDao
					.getOrgWorkerSkillsByOrgCodeAndSkillCode(organizationCode,skillCode);
                                        
                                        List<OrganizationWorkerSkillsModel> organizationWorkerSkillsModelList = new ArrayList<OrganizationWorkerSkillsModel>();
                                        if (objWorkerSkillList != null && objWorkerSkillList.size() > 0)
                                        {
                                            for (int j = 0; j < objWorkerSkillList.size(); j++) {
                                                
                                                OrganizationWorkerSkill orgWorkerSkill = objWorkerSkillList.get(j);
                                                
                                                OrganizationWorkerSkillsModel orgWorkerSkillsModel = new OrganizationWorkerSkillsModel();
                                                orgWorkerSkillsModel.setOrganizationWorkerSkillId(orgWorkerSkill.getId()); 
                                                orgWorkerSkillsModel.setExperienceInDays(orgWorkerSkill.getExperienceInDays());
                                                orgWorkerSkillsModel.setIsAssigned(orgWorkerSkill.getIsAssigned());
                                                orgWorkerSkillsModel.setOrganizationCode(orgWorkerSkill.getOrganizationCode());
                                                orgWorkerSkillsModel.setSkillCode(orgWorkerSkill.getSkillCode());
                                                orgWorkerSkillsModel.setWorkerCode(orgWorkerSkill.getWorkerCode()); 
                                                Worker worker = workRep.findByWorkerCode(orgWorkerSkill.getWorkerCode());
                                                if(worker != null)
                                                {
                                                    orgWorkerSkillsModel.setWorkerName(worker.getName());
                                                }
                                                 
                                                organizationWorkerSkillsModelList.add(orgWorkerSkillsModel);
                                            }
                                            
                                            
                                        }
                                        orgSkillsRes.setWorkerList(organizationWorkerSkillsModelList);
                                        
                                    }

				if (orgSkillsRes != null) {
					ObjectMapper mapperObj = new ObjectMapper();
                                        
                                        OrganizationSkillColorDataResponse model = new OrganizationSkillColorDataResponse();
                                        model.setOrganizationCode(organizationCode);
                                        model.setOrganizationName(organizationName);
                                        model.setSkillColor(orgSkillsRes); 
                                        model.setOrganizationWorkerSkillId(organizationSkillId);                                         
					String Detail = mapperObj.writeValueAsString(model);                                        
					jsonobj.put("responsecode", 200);
					jsonobj.put("message", "Success");
					jsonobj.put("timestamp", new Date());
					jsonobj.put("data", new JSONObject(Detail)); 
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("message", "Record Not Found");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }

}
