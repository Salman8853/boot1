package com.gigflex.prototype.microservices.departmentworker.dtob;

import javax.persistence.Column;

/**
 * 
 * @author ajit.p
 *
 */
public class DepartmentWorkerRequest {
	

	private String departmentCode;

	private String workerCode;

	private String departmentName;
	
	private String workerName;
	
	private Boolean isAssigned = false;
	
	public Boolean getIsAssigned() {
		return isAssigned;
	}

	public void setIsAssigned(Boolean isAssigned) {
		this.isAssigned = isAssigned;
	}
	
	
	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getWorkerName() {
		return workerName;
	}

	public void setWorkerName(String workerName) {
		this.workerName = workerName;
	}

	public DepartmentWorkerRequest(String departmentCode, String workerCode) {
		super();
		this.departmentCode = departmentCode;
		this.workerCode = workerCode;
	}

	public DepartmentWorkerRequest() {
		super();
	}

	public String getDepartmentCode() {
		return departmentCode;
	}

	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	public String getWorkerCode() {
		return workerCode;
	}

	public void setWorkerCode(String workerCode) {
		this.workerCode = workerCode;
	}

	
	
}
