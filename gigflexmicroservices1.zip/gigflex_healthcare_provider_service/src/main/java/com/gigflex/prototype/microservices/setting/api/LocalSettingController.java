/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.api;

import com.gigflex.prototype.microservices.setting.dtob.LocalSettingReq;
import com.gigflex.prototype.microservices.setting.dtob.LocalSettingResponse;
import com.gigflex.prototype.microservices.setting.service.LocalSettingService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nirbhay.p
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class LocalSettingController {
    @Autowired
	private LocalSettingService localSettingService;
	
	@GetMapping(path="/getAllLocalSettingByPage")
    public String getAllLocalSettingByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String grt = localSettingService.getAllLocalSettingByPage(page, limit);
      
        return grt;
       
    }
	
	@GetMapping(path="/getLocalSettingByUserCodeByPage/{userCode}")
    public String getLocalSettingByUserCodeByPage(@PathVariable String userCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {
if(userCode!=null && userCode.trim().length()>0)
{
        return localSettingService.getLocalSettingByUserCodeByPage(userCode.trim(),page, limit);
}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"UserCode should not be blank.");
			return derr.toString();
		}
        
       
    }
    
    
    @GetMapping(path="/getLocalSettingByUserTypeSettingType/{userTypeCode}/{settingType}")
    public String getLocalSettingByUserTypeSettingType(@PathVariable String userTypeCode,@PathVariable String settingType) {
if(userTypeCode!=null && userTypeCode.trim().length()>0 && settingType!=null && settingType.trim().length()>0)
{
        return localSettingService.getLocalSettingByUserTypeSettingType(userTypeCode.trim(),settingType.trim());
}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"UserTypeCode and settingType should not be blank.");
			return derr.toString();
		}
        
       
    }
    
    
    
    
    @GetMapping(path="/getAllLocalSettingWithDefaultGlobalSettingByUserCode/{userCode}")
    public String getAllLocalSettingWithDefaultGlobalSettingByUserCode(@PathVariable String userCode) {
if(userCode!=null && userCode.trim().length()>0 )
{
        return localSettingService.getAllLocalSettingWithDefaultGlobalSettingByUserCode(userCode.trim());
}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"UserCode should not be blank.");
			return derr.toString();
		}
        
       
    }

    
    
    @GetMapping(path="/checkOrganizationSetting/{organizationCode}")
    public String checkOrganizationSetting(@PathVariable String organizationCode) {
if(organizationCode!=null && organizationCode.trim().length()>0 )
{
        return localSettingService.checkOrganizationSetting(organizationCode.trim());
}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Organization Code should not be blank.");
			return derr.toString();
		}
        
       
    }
    
    @GetMapping(path="/checkWorkerSetting/{workerCode}")
    public String checkWorkerSetting(@PathVariable String workerCode) {
if(workerCode!=null && workerCode.trim().length()>0 )
{
        return localSettingService.checkWorkerSetting(workerCode.trim());
}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Worker Code should not be blank.");
			return derr.toString();
		}
        
       
    }
    
    
    @GetMapping(path="/getLocalSettingByUserCodeSettingName/{userCode}/{settingName}")
    public String getLocalSettingByUserCodeSettingName(@PathVariable String userCode,@PathVariable String settingName) {
if(userCode!=null && userCode.trim().length()>0 && settingName!=null && settingName.trim().length()>0)
{
        return localSettingService.getLocalSettingByUserCodeSettingName(userCode.trim(),settingName.trim());
}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"UserCode and SettingName should not be blank.");
			return derr.toString();
		}
        
       
    }
    
    @GetMapping(path="/getLocalSettingByUserCodeGlobalSettingCode/{userCode}/{globalSettingCode}")
    public String getLocalSettingByUserCodeGlobalSettingCode(@PathVariable String userCode,@PathVariable String globalSettingCode) {
if(userCode!=null && userCode.trim().length()>0 && globalSettingCode!=null && globalSettingCode.trim().length()>0)
{
        return localSettingService.getLocalSettingByUserCodeGlobalSettingCode(userCode.trim(),globalSettingCode.trim());
}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"UserCode and GlobalSettingCode should not be blank.");
			return derr.toString();
		}
        
       
    }
    
    
    @PutMapping("/updateSettingByUserCode/{userCode}")
	public String updateSettingByUserCode(@PathVariable String userCode,@RequestBody List<LocalSettingResponse> localSettingReq,
			HttpServletRequest request) {
            if(localSettingReq!=null && localSettingReq.size()>0  && userCode!=null && userCode.length()>0)
            {
                
		String ip = request.getRemoteAddr();
		return localSettingService.updateSettingByUserCode(userCode,localSettingReq, ip);
            }
            else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}
    
	
	@PostMapping("/saveLocalSetting")
	public String saveLocalSetting(@RequestBody LocalSettingReq localSettingReq,
			HttpServletRequest request) {
            if(localSettingReq!=null && localSettingReq.getGlobalSettingCode()!=null && localSettingReq.getGlobalSettingCode().trim().length()>0
                 &&   localSettingReq.getLocalSettingValue()!=null && localSettingReq.getLocalSettingValue().trim().length()>0 &&
                    localSettingReq.getUserCode()!=null && localSettingReq.getUserCode().trim().length()>0 )
            {
                localSettingReq.setGlobalSettingCode(localSettingReq.getGlobalSettingCode().trim());
                localSettingReq.setLocalSettingValue(localSettingReq.getLocalSettingValue().trim());
                localSettingReq.setUserCode(localSettingReq.getUserCode().trim());
		String ip = request.getRemoteAddr();
		return localSettingService.saveLocalSetting(localSettingReq, ip);
            }
            else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

	
    @GetMapping("/getLocalSettingByLocalSettingCode/{localSettingCode}")
	public String getLocalSettingByLocalSettingCode(@PathVariable String localSettingCode) {
	if(localSettingCode!=null && localSettingCode.trim().length()>0)
            {	
            return localSettingService.getLocalSettingByLocalSettingCode(localSettingCode.trim());
            }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Local Setting Code should not be blank.");
			return derr.toString();
		}
	}
        
        
        @PutMapping("/updateLocalSettingById/{id}")
	public String updateGlobalSettingById(@PathVariable Long id,
			@RequestBody LocalSettingReq localSettingReq, HttpServletRequest request) {

            if(localSettingReq!=null && localSettingReq.getGlobalSettingCode()!=null && localSettingReq.getGlobalSettingCode().trim().length()>0
                 &&   localSettingReq.getLocalSettingValue()!=null && localSettingReq.getLocalSettingValue().trim().length()>0 &&
                    localSettingReq.getUserCode()!=null && localSettingReq.getUserCode().trim().length()>0 )
            {
                localSettingReq.setGlobalSettingCode(localSettingReq.getGlobalSettingCode().trim());
                localSettingReq.setLocalSettingValue(localSettingReq.getLocalSettingValue().trim());
                localSettingReq.setUserCode(localSettingReq.getUserCode().trim());
		String ip = request.getRemoteAddr();
		return localSettingService.updateLocalSettingById(localSettingReq, id,ip);
            }
            else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	

	}

	@DeleteMapping("/softDeleteLocalSettingByLocalSettingCode/{localSettingCode}")
	public String softDeleteLocalSettingByLocalSettingCode(@PathVariable String localSettingCode) {
	if(localSettingCode!=null && localSettingCode.trim().length()>0)
            {	
            return localSettingService.softDeleteLocalSettingByLocalSettingCode(localSettingCode.trim());
            }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),"Local Setting Code should not be blank.");
			return derr.toString();
		}
	}

	@DeleteMapping("/softMultipleDeleteLocalSettingByLocalSettingCode/{localSettingCodeList}")
	public String softMultipleDeleteLocalSettingByLocalSettingCode(
			@PathVariable List<String> localSettingCodeList) {
		if (localSettingCodeList != null && localSettingCodeList.size() > 0) {
			return localSettingService.softMultipleDeleteLocalSettingByLocalSettingCode(localSettingCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),"Input data is not valid");
			return derr.toString();
		}

	}
        @GetMapping("/getTimeSlotByOrganisationCode/{orgCode}")
       public String getTimeSlotByOrganisationCode(@PathVariable String orgCode)
       {  
          return localSettingService. getTimeslotByorganisationCode(orgCode);
       }
}
