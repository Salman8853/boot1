package com.gigflex.prototype.microservices.organization.dtob;

public class OrganizationLogoRequest {
	
	 private String organizationLogo;

	public String getOrganizationLogo() {
		return organizationLogo;
	}

	public void setOrganizationLogo(String organizationLogo) {
		this.organizationLogo = organizationLogo;
	}
	 
	 

}
