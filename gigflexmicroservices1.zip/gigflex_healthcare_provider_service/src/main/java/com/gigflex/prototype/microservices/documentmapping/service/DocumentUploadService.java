/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service;

import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author nirbhay.p
 */
@Service
public class DocumentUploadService {
   @Value("${upload.doc.worker}")
   String uploadDoc;//="D:\\gigflexfiles\\driver";
   
//   @Value("${upload.doc.operator}")
//   String uploadDocOperator;//="D:\\gigflexfiles\\operator";
   
    private Path fileStorageLocation;



    public String storeFile(MultipartFile file) {
        // Normalize file name
        String res = "";
      
            this.fileStorageLocation = Paths.get(uploadDoc).toAbsolutePath().normalize();
        
        String fileName = StringUtils.cleanPath(file.getOriginalFilename());
        try {
            String filenameStart = "";
            String filenameEnd = "";
            Date date = new Date();
            long time = date.getTime();
            int inx = fileName.lastIndexOf(".");
            filenameStart = fileName.substring(0, inx);
            filenameEnd = fileName.substring(inx);
            fileName = filenameStart + "-" + time + filenameEnd;

            JSONObject jsonobj = new JSONObject();
// Check if the file's name contains invalid characters
            if (fileName.contains("..") || fileName.contains("/") || fileName.contains("\\") || fileName.contains("<") || fileName.contains(">") || fileName.contains("'")) {
                //  throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
                jsonobj.put("responsecode", 500);
                jsonobj.put("message", "Sorry! Filename contains invalid path sequence or characters like(.. ' / \\ < >)");
                res = jsonobj.toString();
            } else {
                // Copy file to the target location (Replacing existing file with the same name)
                Path targetLocation = this.fileStorageLocation.resolve(fileName);
                Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
                jsonobj.put("responsecode", 200);
                jsonobj.put("message", "success");
                jsonobj.put("filename", fileName);
                res = jsonobj.toString();
            }
        } catch (IOException ex) {
            //throw new FileStorageException("Could not store file " + fileName + ". Please try again!", ex);
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Could not store file " + fileName + ". Please try again!");
            res = derr.toString();
            ex.printStackTrace();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(),
                    "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
    } 
    
    public Resource loadUploadedDocAsResource(String fileName) {
        Resource resource = null;
        try {
            
                this.fileStorageLocation = Paths.get(uploadDoc).toAbsolutePath().normalize();
            
            Path filePath = this.fileStorageLocation.resolve(fileName).normalize();
            resource = new UrlResource(filePath.toUri());

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return resource;
    }
}
