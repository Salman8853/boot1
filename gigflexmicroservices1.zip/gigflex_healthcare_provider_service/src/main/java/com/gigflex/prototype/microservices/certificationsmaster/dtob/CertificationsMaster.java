package com.gigflex.prototype.microservices.certificationsmaster.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "certifications_master")
public class CertificationsMaster extends CommonAttributes implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "Id")
	private Long id;
	
	@Column(name = "certificationname")
	private String certificationName;
	
        @Column(name = "organization_code")
	private String organizationCode;
        
	@GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "certification_code", unique = true)
	private String certificationCode;
	
        @Column(name = "skill_code")
	private String skillCode;
        
        @Column(name = "certification_url")
	private String certificationUrl;
        
	@Column(name = "isassigned", columnDefinition = "boolean default false", nullable = false)
	private Boolean isAssigned = false;
	
	@PrePersist
	private void assignUUID() {
		if (this.getCertificationCode() == null || this.getCertificationCode().length() == 0) {
			this.setCertificationCode(UUID.randomUUID().toString());
		}
	}
	
	public CertificationsMaster(){}

	public CertificationsMaster(Long id, String certificationName,
			String certificationCode,String organizationCode) {
		super();
		this.id = id;
		this.certificationName = certificationName;
		this.certificationCode = certificationCode;
                this.organizationCode=organizationCode;
	}

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }
	
	public Boolean getIsAssigned() {
		return isAssigned;
	}

	public void setIsAssigned(Boolean isAssigned) {
		this.isAssigned = isAssigned;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCertificationName() {
		return certificationName;
	}

	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}

	public String getCertificationCode() {
		return certificationCode;
	}

	public void setCertificationCode(String certificationCode) {
		this.certificationCode = certificationCode;
	}

        public String getSkillCode() {
            return skillCode;
        }

        public void setSkillCode(String skillCode) {
            this.skillCode = skillCode;
        }

        public String getCertificationUrl() {
            return certificationUrl;
        }

        public void setCertificationUrl(String certificationUrl) {
            this.certificationUrl = certificationUrl;
        }
	

        
}
