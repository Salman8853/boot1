/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationworkerskill.dtob;

import java.util.List;

/**
 *
 * @author amit.kumar
 */
public class OrganizationSkillsModel {
    
    private Long organizationSkillId;
    private String organizationCode;
    private String skillCode;
    private String skillName;
    private String color;
    private String organizationName;
    
    List<OrganizationWorkerSkillsModel> workerList;

    public String getSkillName() {
        return skillName;
    }

    public void setSkillName(String skillName) {
        this.skillName = skillName;
    }
     
    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public Long getOrganizationSkillId() {
        return organizationSkillId;
    }

    public void setOrganizationSkillId(Long organizationSkillId) {
        this.organizationSkillId = organizationSkillId;
    }    
    
    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getSkillCode() {
        return skillCode;
    }

    public void setSkillCode(String skillCode) {
        this.skillCode = skillCode;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public List<OrganizationWorkerSkillsModel> getWorkerList() {
        return workerList;
    }

    public void setWorkerList(List<OrganizationWorkerSkillsModel> workerList) {
        this.workerList = workerList;
    }
    
}
