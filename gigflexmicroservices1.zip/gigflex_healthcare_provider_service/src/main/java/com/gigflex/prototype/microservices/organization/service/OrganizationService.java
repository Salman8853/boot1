package com.gigflex.prototype.microservices.organization.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.gigflex.prototype.microservices.organization.dtob.MassActiveInactiveOrganization;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.dtob.OrganizationLogoRequest;

public interface OrganizationService {

	// public Page<Organization> listAllByPage(Pageable pageable);
	public String search(String search);

	public String getOrganization(int page, int limit);

	public Organization registerFromOrganization(Organization organization);

	public String findAllOrganizations();

	public Optional<Organization> getOrganizationById(Long id);

	public String fetchOrganizationById(Long id);

	public Organization getOrgById(Long id);

	public String findOrganizationByOrgCode(String organizationCode);

	public void deleteOrganization(Long id);

	public String deleteByOrgCode(String organizationCode);

	public String softDeleteByOrgCode(String organizationCode);

	public String softMultipleDeleteByOrgCode(List<String> organizationCodeList);

	public String deleteOrganizationById(Long id);

	public String updateOrganization(Organization organization, Long id);

	public String updateOrganizationLogoByOrgCode(
			OrganizationLogoRequest orgLogoReq, String organizationCode,
			String ip);

	public String massActiveInactiveOrganizationByOrgCode(
			MassActiveInactiveOrganization maassAcInOrgReq, String ip);
	// public String getOrgByWASOrgCode(String organization_Code);

	// public String approveOrganization(OrganizationApprovalRequest orgreq);
}
