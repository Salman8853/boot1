/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.patient.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.k
 */
@Entity
@Table(name = "patient_details")
public class PatientDetails extends CommonAttributes implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
        
        @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "patient_code", unique = true)
	private String patientCode;
        
               
        @Column(name = "patient_name", nullable = false)
	private String patientName;

        @Column(name = "organization_code", nullable = false)
	private String organizationCode;
        
        @Column(name = "patient_address", nullable = false)
	private String patientAddress;
        
        
        @Column(name = "patient_country", nullable = true)
	private String patientCountry;
        
        
        @Column(name = "patient_state", nullable = true)
	private String patientState;
        
        @Column(name = "patient_city")
	private String patientCity;
        
	@Column(name = "phone_number", nullable = false)
	private String phoneNumber;

	@Column(name = "mobile_number")
	private String mobileNumber;
	
	@Column(name = "pcountry_code",nullable = false)
        private String pCountryCode;
	
	@Column(name = "mcountry_code")
        private String mCountryCode;
        
        @Column(name = "patient_email", nullable = true)
	private String patientEmail;
        
        @Column(name = "patient_latitude", nullable = false)
	private String patientLatitude;

	@Column(name = "patient_longitude", nullable = false)
	private String patientLongitude;

       
        @Column(name = "zip_code", nullable = true)
	private String zipCode;
        
        @Column(name = "patient_history_description",columnDefinition = "TEXT", nullable = true)
	private String patientHistoryDescription;
        
        @Column(name = "isactive",columnDefinition = "boolean default false", nullable = false)
	private Boolean isActive;

        public Boolean isIsActive() {
            return isActive;
        }

        public void setIsActive(Boolean isActive) {
            this.isActive = isActive;
        }
        
                     
        @PrePersist
	private void assignUUID() {
		if (this.getPatientCode() == null || this.getPatientCode().length() == 0) {
			this.setPatientCode(UUID.randomUUID().toString());
		}
	}

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getPatientAddress() {
        return patientAddress;
    }

    public void setPatientAddress(String patientAddress) {
        this.patientAddress = patientAddress;
    }

    public String getPatientCountry() {
        return patientCountry;
    }

    public void setPatientCountry(String patientCountry) {
        this.patientCountry = patientCountry;
    }

    public String getPatientState() {
        return patientState;
    }

    public void setPatientState(String patientState) {
        this.patientState = patientState;
    }

    public String getPatientCity() {
        return patientCity;
    }

    public void setPatientCity(String patientCity) {
        this.patientCity = patientCity;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getpCountryCode() {
        return pCountryCode;
    }

    public void setpCountryCode(String pCountryCode) {
        this.pCountryCode = pCountryCode;
    }

    public String getmCountryCode() {
        return mCountryCode;
    }

    public void setmCountryCode(String mCountryCode) {
        this.mCountryCode = mCountryCode;
    }

    public String getPatientEmail() {
        return patientEmail;
    }

    public void setPatientEmail(String patientEmail) {
        this.patientEmail = patientEmail;
    }

    public String getPatientLatitude() {
        return patientLatitude;
    }

    public void setPatientLatitude(String patientLatitude) {
        this.patientLatitude = patientLatitude;
    }

    public String getPatientLongitude() {
        return patientLongitude;
    }

    public void setPatientLongitude(String patientLongitude) {
        this.patientLongitude = patientLongitude;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public String getPatientHistoryDescription() {
        return patientHistoryDescription;
    }

    public void setPatientHistoryDescription(String patientHistoryDescription) {
        this.patientHistoryDescription = patientHistoryDescription;
    }    
    
}
