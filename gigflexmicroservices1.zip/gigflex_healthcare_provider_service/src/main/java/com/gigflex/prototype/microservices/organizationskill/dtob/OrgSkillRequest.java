package com.gigflex.prototype.microservices.organizationskill.dtob;

public class OrgSkillRequest {

	private String organizationCode;
	private String skillCode;
        private String color;
        private String skillImage;

	public String getOrganizationCode() {
		return organizationCode;
	}

	public void setOrganizationCode(String organizationCode) {
		this.organizationCode = organizationCode;
	}

	public String getSkillCode() {
		return skillCode;
	}

	public void setSkillCode(String skillCode) {
		this.skillCode = skillCode;
	}

        public String getColor() {
            return color;
        }

        public void setColor(String color) {
            this.color = color;
        }

        public String getSkillImage() {
            return skillImage;
        }

        public void setSkillImage(String skillImage) {
            this.skillImage = skillImage;
        }

}
