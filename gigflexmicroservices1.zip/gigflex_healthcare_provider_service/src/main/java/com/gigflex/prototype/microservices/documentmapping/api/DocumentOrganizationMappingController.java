/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.api;

import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationMappingRequest;
import com.gigflex.prototype.microservices.documentmapping.service.DocumentOrganizationMappingService;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nirbhay.p
 */

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class DocumentOrganizationMappingController {
    
    
    
	
	@Autowired
	public DocumentOrganizationMappingService documentOrganizationMappingService;
	
	
	@GetMapping("/getAllDocumentOrganizationMapping")
	public String getAllDocumentOrganizationMapping() {
		return documentOrganizationMappingService.getAllDocumentOrganizationMapping();
	}

	@GetMapping(path = "/getAllDocumentOrganizationMappingByPage")
	public String getAllDocumentOrganizationMappingByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String docType = documentOrganizationMappingService.getAllDocumentOrganizationMappingByPage(page, limit);

		return docType;

	}
        
      

	@GetMapping("/getDocumentOrganizationMappingById/{id}")
	public String getDocumentOrganizationMappingById(@PathVariable Long id) {
		return documentOrganizationMappingService.getDocumentOrganizationMappingById(id);
	}

	@GetMapping("/getDocumentOrganizationMappingByCode/{documentOrganizationMappingCode}")
	public String getDocumentOrganizationMappingByCode(@PathVariable String documentOrganizationMappingCode) {
		return documentOrganizationMappingService.getDocumentOrganizationMappingByCode(documentOrganizationMappingCode);
	}
        
        @GetMapping("/getDocumentOrganizationMappingWithNameByCode/{documentOrganizationMappingCode}")
	public String getDocumentOrganizationMappingWithNameByCode(@PathVariable String documentOrganizationMappingCode) {
		return documentOrganizationMappingService.getDocumentOrganizationMappingWithNameByCode(documentOrganizationMappingCode);
	}
        
        
        @GetMapping("/getgetDocumentOrganizationMappingByOrganizationCode/{organizationCode}")
	public String getgetDocumentOrganizationMappingByOrganizationCode(@PathVariable String organizationCode) {
		return documentOrganizationMappingService.getgetDocumentOrganizationMappingByOrganizationCode(organizationCode);
	}

	@PostMapping("/saveDocumentOrganizationMapping")
	public String saveDocumentOrganizationMapping(@RequestBody DocumentOrganizationMappingRequest docTypeDetReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return documentOrganizationMappingService.saveDocumentOrganizationMapping(docTypeDetReq, ip);

	}

//	@PutMapping("/updateDocumentOrganizationMapping/{id}")
//	public String updateDocumentOrganizationMapping(@PathVariable Long id,
//			@RequestBody DocumentOrganizationMappingRequest docTypeDetReq, HttpServletRequest request) {
//
//		if (id == null) {
//			return "ID should not be blank.";
//		} else {
//			String ip = request.getRemoteAddr();
//
//			return documentOrganizationMappingService.updateDocumentOrganizationMapping(id, docTypeDetReq, ip);
//
//		}
//
//	}

	


}
