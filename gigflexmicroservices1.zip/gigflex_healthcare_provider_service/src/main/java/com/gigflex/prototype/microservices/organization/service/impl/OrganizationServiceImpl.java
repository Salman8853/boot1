package com.gigflex.prototype.microservices.organization.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organization.dtob.MassActiveInactiveOrganization;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.dtob.OrganizationLogoRequest;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.organization.search.OrgSpecificationsBuilder;
import com.gigflex.prototype.microservices.organization.service.OrganizationService;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.users.repository.UserRepository;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.verifyemployee.repository.WorkerApprovalStatusRepository;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;

/**
 *
 * @author abhishek
 */
@Service
public class OrganizationServiceImpl implements OrganizationService {
	private static final Logger LOG = LoggerFactory
			.getLogger(OrganizationServiceImpl.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	WorkerRepository workerRepository;


	@Autowired
	UserRepository userRepository;

	@Autowired
	WorkerApprovalStatusRepository wasRepository;

	/*
	 * @Override public Organization registerFromOrganization(Organization
	 * organization) { Organization newOrg =
	 * organizationRepository.save(organization); Optional<Organization>
	 * newOrganization = organizationRepository.findById(newOrg.getId());
	 * kafkaService.sendOrganization(newOrganization.get()); return newOrg; }
	 */
	@Override
	public Organization registerFromOrganization(Organization organization) {
		return organizationRepository.save(organization);
	}

	@Override
	public Optional<Organization> getOrganizationById(Long id) {

		return organizationRepository.findById(id);
	}

	@Override
	public void deleteOrganization(Long id) {

		organizationRepository.deleteById(id);
	}

	@Override
	public String findAllOrganizations() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<Organization> organization = organizationRepository
					.getAllOrganization();
			jsonobj.put("responsecode", 200);
			jsonobj.put("timestamp", new Date());
			if (organization != null && organization.size() > 0) {
				jsonobj.put("message", "Success");
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(organization);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}

			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public Organization getOrgById(Long id) {
		return organizationRepository.getOne(id);

	}

	// @Override
	// public String approveOrganization(OrganizationApprovalRequest orgreq) {
	// String res = "";
	// try {
	// if (orgreq != null) {
	// Organization org = organizationRepository
	// .findByOrganizationCode(orgreq.getOrganizationCode());
	// if (org != null && org.getId() > 0) {
	// org.setApprovedBy(orgreq.getApprovedByCode());
	// org.setApprovedDate(new Date());
	// org.setIsApproved(orgreq.getIsApproved());
	// Organization orgRes = organizationRepository.save(org);
	// if (orgRes != null && orgRes.getId() > 0) {
	// GigflexResponse derr = new GigflexResponse(200,
	// new Date(),
	// "Approval of organization has been done.");
	// return derr.toString();
	// } else {
	// GigflexResponse derr = new GigflexResponse(400,
	// new Date(),
	// "Approval of organization has been failed.");
	// return derr.toString();
	// }
	// } else {
	// GigflexResponse derr = new GigflexResponse(400, new Date(),
	// "OrganizationCode is not matched.");
	// return derr.toString();
	// }
	//
	// } else {
	// GigflexResponse derr = new GigflexResponse(400, new Date(),
	// "Input is invalid.");
	// return derr.toString();
	// }
	//
	// } catch (Exception ex) {
	// GigflexResponse derr = new GigflexResponse(500, new Date(),
	// "Exception is occurred.");
	// return derr.toString();
	// }
	// }

	@Override
	public String fetchOrganizationById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization orglst = organizationRepository
					.getOrganizationById(id);
			if (orglst != null && orglst.getId() > 0) {
				Organization org = orglst;
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				if (org != null) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(org);
					jsonobj.put("data", new JSONObject(Detail));
					jsonobj.put("message", "Success");
				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");
				}
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteOrganizationById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Optional<Organization> orglst = organizationRepository.findById(id);
			if (orglst.isPresent()) {
				organizationRepository.deleteById(id);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Organization has been deleted.");
				Organization org = orglst.get();
//				kafkaService.sendDeleteOrganization(org);
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
			}
			jsonobj.put("timestamp", new Date());
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateOrganization(Organization organization, Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && organization != null) {
				if (organization.getOrganizationName() != null
						&& organization.getOrganizationName().length() > 0) {
					Organization orglst = organizationRepository
							.getOrganizationById(id);
					if (orglst != null && orglst.getId() > 0) {

						Organization org = orglst;
						org.setOrganizationName(organization
								.getOrganizationName());
						org.setPhoneNumber(organization.getPhoneNumber());
						org.setAddress(organization.getAddress());
						org.setAddress1(organization.getAddress1());
						org.setCity(organization.getCity());
						org.setStateProvince(organization.getStateProvince());
						org.setCountry(organization.getCountry());
						org.setZipCode(organization.getZipCode());
						org.setTaxId(organization.getTaxId());
						org.setRegNo(organization.getRegNo());
						org.setWorkFrom(organization.getWorkFrom());
						org.setWorkTo(organization.getWorkTo());
						org.setIndustryCode(organization.getIndustryCode());
						org.setLat(organization.getLat());
						org.setLang(organization.getLang());
						org.setIsActive(organization.getIsActive());
						org.setIpAddress(organization.getIpAddress());
						org.setIsVerified(organization.getIsVerified());
						org.setOrganizationLogo(organization.getOrganizationLogo());
						org.setUpdatedAt(organization.getUpdatedAt());
						org.setCreatedAt(organization.getCreatedAt());
                                                org.setTimezone(organization.getTimezone());
						Organization orgRes = organizationRepository.save(org);
						if (orgRes != null && orgRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"Organization updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(orgRes);
							jsonobj.put("data", new JSONObject(Detail));
//							kafkaService.sendUpdateOrganization(orgRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Organization updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "Organization ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message", "Organization Name can not be blank");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String findOrganizationByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization orglst = organizationRepository
					.findByOrganizationCode(organizationCode);
			if (orglst != null) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(orglst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String deleteByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization org = organizationRepository
					.findByOrganizationCode(organizationCode);
			Integer deleteByOrgCode = organizationRepository
					.deleteOrganizationrByOrganizationCode(organizationCode);
			if (deleteByOrgCode != 0 && org != null && org.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Organization has been deleted.");
				jsonobj.put("timestamp", new Date());
//				kafkaService.sendDeleteOrganization(org);
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();

		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String updateOrganizationLogoByOrgCode(
			OrganizationLogoRequest orgLogoReq, String organizationCode,
			String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (orgLogoReq != null) {
				if (orgLogoReq.getOrganizationLogo() != null
						&& orgLogoReq.getOrganizationLogo().length() > 0) {
					Organization org = organizationRepository
							.findByOrganizationCode(organizationCode);
					if (org != null) {

						org.setOrganizationLogo(orgLogoReq
								.getOrganizationLogo());
						org.setIpAddress(ip);

						Organization orgRes = organizationRepository.save(org);
						if (orgRes != null && orgRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("message",
									"Organization Logo updation has been done");
							jsonobj.put("timestamp", new Date());
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(orgRes);
							jsonobj.put("data", new JSONObject(Detail));
//							kafkaService.sendUpdateOrganization(orgRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Organization Logo updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message",
								"Organization Code is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("message",
							"Organization Logo should not be blank");
					jsonobj.put("timestamp", new Date());
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByOrgCode(String organizationCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			Organization org = organizationRepository
					.findByOrganizationCode(organizationCode);

			if (org != null && org.getId() > 0) {
				
				org.setIsDeleted(true);
				Organization orgRes = organizationRepository.save(org);

				if (orgRes != null && orgRes.getId() > 0) {
					

					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Organization deleted successfully.");
//					kafkaService.sendUpdateOrganization(orgRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
			LOG.error("Error in softDeleteByOrganizationCode>>>>>>", ex);
		} catch (org.springframework.orm.jpa.JpaSystemException ex) {
			GigflexResponse derr = new GigflexResponse(401, new Date(),
					GigUtil.getRootException(ex));
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			ex.printStackTrace();
			LOG.error("Error in softDeleteByOrganizationCode>>>>>>", ex);
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByOrgCode(List<String> organizationCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String organizationCode : organizationCodeList) {
				if (organizationCode != null
						&& organizationCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					organizationCode = organizationCode.trim();

					Organization org = organizationRepository
							.findByOrganizationCode(organizationCode);

					if (org != null && org.getId() > 0) {
						try {
						org.setIsDeleted(true);
						Organization orgRes = organizationRepository.save(org);

						if (orgRes != null && orgRes.getId() > 0) {


							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", organizationCode);
							jsonobj.put("message",
									"Organization deleted successfully.");
//							kafkaService.sendUpdateOrganization(orgRes);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", organizationCode);
							jsonobj.put("message", "Failed");
						}
						} catch (org.springframework.orm.jpa.JpaSystemException ex) {
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", organizationCode);
							jsonobj.put("message", GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", organizationCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String massActiveInactiveOrganizationByOrgCode(
			MassActiveInactiveOrganization maassAcInOrgReq, String ip) {
		String res = "";
		try {
			if (maassAcInOrgReq != null
					&& maassAcInOrgReq.getIsActive() != null
					&& maassAcInOrgReq.getOrganizationCode() != null
					&& maassAcInOrgReq.getOrganizationCode().size() > 0) {
				JSONArray jarr = new JSONArray();
				for (String organizationCode : maassAcInOrgReq
						.getOrganizationCode()) {

					JSONObject jsonobj = new JSONObject();

					Organization org = organizationRepository
							.findByOrganizationCode(organizationCode);

					if (org != null && org.getId() > 0) {
						
						org.setIsActive(maassAcInOrgReq.getIsActive());
						org.setIpAddress(ip);
						
						Organization orgRes = organizationRepository.save(org);

						if (orgRes != null && orgRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", organizationCode);
							jsonobj.put("message",
									"Active/Inactive set successfully");
//							kafkaService.sendUpdateOrganization(org);
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", organizationCode);
							jsonobj.put("message", "Failed");
						}
					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", organizationCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);

				}
				if (jarr.size() > 0) {
					res = jarr.toString();
				} else {
					GigflexResponse derr = new GigflexResponse(400, new Date(),
							"Mass active/inactive failed.");
					res = derr.toString();
				}

			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Input data is not valid.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;

	}
	@Override
	public String getOrganization(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
	        Pageable pageableRequest = PageRequest.of(page, limit);
	        List<Organization> org = organizationRepository.getAllOrganization(pageableRequest);
	       int count=0;
               List<Organization> orgcnt = organizationRepository.getAllOrganization();
               if(orgcnt!=null && orgcnt.size()>0)
               {
                   count=orgcnt.size();
               }
			if (org != null && org.size() > 0) {
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("message", "Success");
                            jsonobj.put("count", count);
                            jsonobj.put("timestamp", new Date());
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(org);
                            jsonobj.put("data", new JSONArray(Detail));
			}
			 else
	            {
	                jsonobj.put("responsecode", 400);
	            jsonobj.put("message", "Record Not Found");
	            jsonobj.put("timestamp", new Date());
	            }
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
	    return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
            if(search != null && search.trim().length() > 0){
			JSONObject jsonobj = new JSONObject();
			
			OrgSpecificationsBuilder builder = new OrgSpecificationsBuilder();
		        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
		        java.util.regex.Matcher matcher = pattern.matcher(search + ",");
		        while (matcher.find()) {
		            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
		        }
		         
		        Specification<Organization> spec = builder.build();
                        if(spec!=null){
		        List<Organization> orglst = organizationRepository.findAll(spec);
			if(orglst != null && orglst.size() > 0){
			for(Organization org : orglst){
				if(org.getIsDeleted() != null && org.getIsDeleted() != true){

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(org);
					JSONObject jsonobjNew = new JSONObject();
					jsonobjNew.put("organization", new JSONObject(Detail));
					jarr.add(jsonobjNew);

			} 
				
			} 
			if (jarr.size() > 0) {
				
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			jsonobj.put("data", jarr);
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}
			
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}}
                        else{
                           jsonobj.put("responsecode", 400);
			   jsonobj.put("message", "Record Not Found!");
			   jsonobj.put("timestamp", new Date()); 
                        }
			res = jsonobj.toString();
		
            }else{
            	GigflexResponse derr = new GigflexResponse(400, new Date(),
    					"Input data is not valid.");
    			res = derr.toString();

            }
			
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}
}