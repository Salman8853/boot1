/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationworkerskill.dtob;

/**
 *
 * @author amit.kumar
 */
public class OrganizationSkillColorDataResponse {
    
    private Long organizationWorkerSkillId;
    
    private String organizationCode;
    
    private String organizationName;
    
    private OrganizationSkillsModel skillColor;

    public Long getOrganizationWorkerSkillId() {
        return organizationWorkerSkillId;
    }

    public void setOrganizationWorkerSkillId(Long organizationWorkerSkillId) {
        this.organizationWorkerSkillId = organizationWorkerSkillId;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public OrganizationSkillsModel getSkillColor() {
        return skillColor;
    }

    public void setSkillColor(OrganizationSkillsModel skillColor) {
        this.skillColor = skillColor;
    }    
    
}
