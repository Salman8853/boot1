/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.service;


import com.gigflex.prototype.microservices.schedule.dtob.ScheduleCalendarRequest;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignmentInputList;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestInput;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestUpdate;
import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public interface WorkerScheduleRequestService {
   
    public String getWorkerScheduleRequestByScheduleRequestCode(String scheduleRequestCode);
    public String getAvailableWorkerBasedOnScheduleFilterByScheduleRequestCode(String scheduleRequestCode);
    public String getWorkerScheduleRequestByScheduleRequestCode(String scheduleRequestCode,int page, int limit);
    
    public String getWorkerScheduleRequestById(Long id);
    public String getWorkerScheduleRequestById(Long id,int page, int limit);
    
    public String getWorkerScheduleRequestByOrganizationCode(String organizationCode);
    public String getWorkerScheduleRequestByOrganizationCode(String organizationCode,int page, int limit);
    
    public String publishedWorkerScheduleRequest(Boolean pub,String scheduleCode, String ip);
    public String saveWorkerScheduleRequest(WorkerScheduleRequestInput schReq, String ip);
    public String addWorkerScheduleRequestAssignment(String scheduleCode,WorkerScheduleRequestAssignmentInputList wsr,String ip);
    public String  getScheduleCalendar(ScheduleCalendarRequest calreq);

	public String getTargetAchieved(String scheduleRequestCode);

    public String getPercentageOfScheduleFulfilment(String scheduleRequestCode);
	public String getWeeklyReportByDates(String scheduleRequestCode, String status,String startDate, String endDate);
//	public String getWorkerScheduleRequestByScheduleRequestCode(String scheduleRequestCode);
//    public String getWorkerScheduleRequestById(Long id);
//    public String getWorkerScheduleRequestByOrganizationCode(String organizationCode);

    public String publishedWorkerScheduleRequestByOrganizationCode(Boolean pub, String orgCode, String ip);
    
    public String getScheduleCalendarForWorker(String workerCode,List <String> status,String stratDT, String endDT);
    public String updateWorkerScheduleRequestByScheduleRequestCode(WorkerScheduleRequestUpdate wsr,String scheduleRequestCode, String ip);
}
