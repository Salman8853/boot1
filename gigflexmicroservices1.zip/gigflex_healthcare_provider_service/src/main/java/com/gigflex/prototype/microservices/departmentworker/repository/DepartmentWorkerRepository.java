/**
 * 
 */
package com.gigflex.prototype.microservices.departmentworker.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.gigflex.prototype.microservices.departmentworker.dtob.DepartmentWorker;

/**
 * @author ajit.p
 *
 */
@Repository
public interface DepartmentWorkerRepository extends JpaRepository<DepartmentWorker, Long>,JpaSpecificationExecutor<DepartmentWorker> {

    @Query("SELECT dep.workerCode FROM DepartmentWorker dep WHERE dep.departmentCode=:departmentCode")
    public List<String> getWorkerCodesByDepCode(@Param("departmentCode") String departmentCode);
 
    @Query("SELECT dep FROM DepartmentWorker dep WHERE dep.departmentCode=:departmentCode AND dep.workerCode = :workerCode")
    public DepartmentWorker getDepartmentWorker(@Param("departmentCode") String departmentCode,@Param("workerCode") String workerCode);
    
    @Query("SELECT dw FROM DepartmentWorker dw WHERE dw.isDeleted != TRUE AND dw.workerCode=:workerCode")
    public List<DepartmentWorker> getDepartmentWorkerByWorkerCode(@Param("workerCode") String workerCode);
    
    @Query("SELECT dw FROM DepartmentWorker dw WHERE dw.isDeleted != TRUE AND dw.workerCode=:workerCode")
    public List<DepartmentWorker> getDepartmentWorkerByWorkerCode(@Param("workerCode") String workerCode,Pageable pageableRequest);
    
    @Query("SELECT dw FROM DepartmentWorker dw WHERE dw.isDeleted != TRUE AND dw.isAssigned = TRUE AND dw.workerCode = :workerCode")
    public List<DepartmentWorker> getDepartmentWorkerByWorkerCodeAssigned(@Param("workerCode") String workerCode);
    
}
