/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.documentmapping.service;

import com.gigflex.prototype.microservices.documentmapping.dtob.DocumentOrganizationMappingRequest;

/**
 *
 * @author nirbhay.p
 */
public interface DocumentOrganizationMappingService {
    public String getAllDocumentOrganizationMapping();
    public String getAllDocumentOrganizationMappingByPage(int page,int limit);
    public String getDocumentOrganizationMappingById(Long id) ;
    public String getDocumentOrganizationMappingByCode(String documentOrganizationMappingCode);
    public String getDocumentOrganizationMappingWithNameByCode(String documentOrganizationMappingCode);
    public String getgetDocumentOrganizationMappingByOrganizationCode(String organizationCode);
    public String saveDocumentOrganizationMapping(DocumentOrganizationMappingRequest docTypeDetReq,String ip);
    //public String updateDocumentOrganizationMapping(Long id,DocumentOrganizationMappingRequest docTypeDetReq,String ip);
}
