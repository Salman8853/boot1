/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.dtob;

import com.gigflex.prototype.microservices.patient.dtob.PatientResponse;
import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public class JobsRequest {
    
   
    private String procedureCode;
    
    private String jobName;
    
    private String organizationCode;
    
    private String startDate ;
   
    private String endDate ;
    
    private String startTime ;
    
    private Integer repeatValue;
    
    private String repeatType;
    
    private Boolean isDateOfMonth;
    
    private List<Integer> daysList;
     
    //private String endTime ;
    
    private Integer durationHours;
    
    private Integer durationMinute;
    
    private String patientCode; 
    
    private String notes; 
    
    private PatientResponse patientDetail;

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

//    public String getEndTime() {
//        return endTime;
//    }
//
//    public void setEndTime(String endTime) {
//        this.endTime = endTime;
//    }

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public PatientResponse getPatientDetail() {
        return patientDetail;
    }

    public void setPatientDetail(PatientResponse patientDetail) {
        this.patientDetail = patientDetail;
    }

    public Integer getDurationHours() {
        return durationHours;
    }

    public void setDurationHours(Integer durationHours) {
        this.durationHours = durationHours;
    }

    public Integer getDurationMinute() {
        return durationMinute;
    }

    public void setDurationMinute(Integer durationMinute) {
        this.durationMinute = durationMinute;
    }

    public List<Integer> getDaysList() {
        return daysList;
    }

    public void setDaysList(List<Integer> daysList) {
        this.daysList = daysList;
    }

    public Integer getRepeatValue() {
        return repeatValue;
    }

    public void setRepeatValue(Integer repeatValue) {
        this.repeatValue = repeatValue;
    }

    public String getRepeatType() {
        return repeatType;
    }

    public void setRepeatType(String repeatType) {
        this.repeatType = repeatType;
    }

    public Boolean getIsDateOfMonth() {
        return isDateOfMonth;
    }

    public void setIsDateOfMonth(Boolean isDateOfMonth) {
        this.isDateOfMonth = isDateOfMonth;
    }

           
}
