package com.gigflex.prototype.microservices.schedule.dtob;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.util.Date;

import java.util.UUID;

import javax.persistence.PrePersist;
import org.hibernate.annotations.GenericGenerator;

/**
 * 
 * @author nirbhay.p
 *
 */
@Entity
@Table(name = "worker_schedule_request")
public class WorkerScheduleRequest extends CommonAttributes implements Serializable {


    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;  
    
    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "schedule_request_code", unique = true)
    private String scheduleRequestCode;
    
    @Column(name = "patient_code", nullable=false)
    private String patientCode;    
    
    @Column(name = "jobname",nullable=false)
    private String jobName;
    
    @Column(name = "organization_code" ,  nullable=false)
    private String organizationCode;
    
    @Column(name = "start", columnDefinition="DATETIME")
    private Date startDT ;
     
    @Column(name = "end", columnDefinition="DATETIME")
    private Date endDT ;
       
    @Column(name = "isprocessed")
    private Boolean isProcessed; 
    
    @Column(name = "ispublished")
    private Boolean isPublished; 
    
    @Column(name = "working_location_code" )
    private String workingLocationCode;
   
   @PrePersist
    private void assignUUID() {
        if(this.getScheduleRequestCode()==null || this.getScheduleRequestCode().length()==0)
        {
            this.setScheduleRequestCode(UUID.randomUUID().toString());
        }
    }

	public String getWorkingLocationCode() {
		return workingLocationCode;
	}

	public void setWorkingLocationCode(String workingLocationCode) {
		this.workingLocationCode = workingLocationCode;
	}

	public Boolean getIsPublished() {
        return isPublished;
    }

    public void setIsPublished(Boolean isPublished) {
        this.isPublished = isPublished;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getScheduleRequestCode() {
        return scheduleRequestCode;
    }

    public void setScheduleRequestCode(String scheduleRequestCode) {
        this.scheduleRequestCode = scheduleRequestCode;
    }
    
    public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }
    public Date getStartDT() {
        return startDT;
    }

    public void setStartDT(Date startDT) {
        this.startDT = startDT;
    }

    public Date getEndDT() {
        return endDT;
    }

    public void setEndDT(Date endDT) {
        this.endDT = endDT;
    }

    public Boolean getIsProcessed() {
        return isProcessed;
    }

    public void setIsProcessed(Boolean isProcessed) {
        this.isProcessed = isProcessed;
    }

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }
    
    
}