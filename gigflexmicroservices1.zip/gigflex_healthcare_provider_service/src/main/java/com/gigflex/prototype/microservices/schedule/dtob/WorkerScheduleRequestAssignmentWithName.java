package com.gigflex.prototype.microservices.schedule.dtob;

import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;

public class WorkerScheduleRequestAssignmentWithName {

	private WorkerScheduleRequestAssignment workerScheduleRequestAssignment;
               

	private String skillName;

	private String location;

	private String certificationName;
	
	private String jobName;

	public WorkerScheduleRequestAssignment getWorkerScheduleRequestAssignment() {
		return workerScheduleRequestAssignment;
	}

	public void setWorkerScheduleRequestAssignment(
			WorkerScheduleRequestAssignment workerScheduleRequestAssignment) {
		this.workerScheduleRequestAssignment = workerScheduleRequestAssignment;
	}       
        
	public String getSkillName() {
		return skillName;
	}

	public void setSkillName(String skillName) {
		this.skillName = skillName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getCertificationName() {
		return certificationName;
	}

	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}
	 
	

}
