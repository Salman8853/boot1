/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.proceduremaster.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "procedure_skill_mapping")
public class ProcedureSkillMapping extends CommonAttributes implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "procedure_skilmapping_code", unique = true)
    private String procedureSkillMappingCode;

    @PrePersist
    private void assignUUID() {
        if (this.getProcedureSkillMappingCode() == null || this.getProcedureSkillMappingCode().length() == 0) {
           this.setProcedureSkillMappingCode(UUID.randomUUID().toString());
        }
    }
    
    @Column(name = "procedure_code", nullable = false)
    private String procedureCode;
    
    @Column(name = "skill_Code", nullable = false)
    private String skillCode;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProcedureSkillMappingCode() {
        return procedureSkillMappingCode;
    }

    public void setProcedureSkillMappingCode(String procedureSkillMappingCode) {
        this.procedureSkillMappingCode = procedureSkillMappingCode;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getSkillCode() {
        return skillCode;
    }

    public void setSkillCode(String skillCode) {
        this.skillCode = skillCode;
    }
    
    
    
}
