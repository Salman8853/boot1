package com.gigflex.prototype.microservices.documentmapping.dtob;

public class DocumentOrganizationWorkerMappingResponse {
	
     private Long id;

    private String documentOrganizationWorkerCode;
    
   private String workerDocumentCode;
   
    private String documentCode;
    
    private String documentName;
   private String workerCode;
   private String workerName;
   
   private String organizationDocumentCode;
     private String organizationCode;
   private String organizationName;

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDocumentOrganizationWorkerCode() {
        return documentOrganizationWorkerCode;
    }

    public void setDocumentOrganizationWorkerCode(String documentOrganizationWorkerCode) {
        this.documentOrganizationWorkerCode = documentOrganizationWorkerCode;
    }

    public String getDocumentCode() {
        return documentCode;
    }

    public void setDocumentCode(String documentCode) {
        this.documentCode = documentCode;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getWorkerName() {
        return workerName;
    }

    public void setWorkerName(String workerName) {
        this.workerName = workerName;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

   
   
    public String getWorkerDocumentCode() {
        return workerDocumentCode;
    }

    public void setWorkerDocumentCode(String workerDocumentCode) {
        this.workerDocumentCode = workerDocumentCode;
    }

    public String getOrganizationDocumentCode() {
        return organizationDocumentCode;
    }

    public void setOrganizationDocumentCode(String organizationDocumentCode) {
        this.organizationDocumentCode = organizationDocumentCode;
    }

    
}
