/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.repository;


import com.gigflex.prototype.microservices.jobs.dtob.Jobs;
import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorker;
import com.gigflex.prototype.microservices.jobs.dtob.JobsDuration;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import java.util.Date;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface JobsRepository  extends JpaRepository<Jobs, Long>,JpaSpecificationExecutor<Jobs> {
    
    @Query("SELECT j FROM Jobs j WHERE j.isDeleted != TRUE AND j.id = :id")
    public Jobs getJobsById(@Param("id") Long id);
    
    @Query("SELECT j FROM Jobs j WHERE j.isDeleted != TRUE AND j.jobsCode = :jobsCode")
    public Jobs getJobsByJobsCode(@Param("jobsCode") String jobsCode);

    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ORDER BY FIELD(jaw.status,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(jd.startTime))")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPage(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT,@Param("orderLst") List<String> orderLst, Pageable pageableRequest);

    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ORDER BY FIELD(jaw.status,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(jd.startTime))")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPage(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT,@Param("orderLst") List<String> orderLst);
    
    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ORDER BY jd.startTime")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPageForDist(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT);
        
    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.patientCode= :patientCode AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ORDER BY FIELD(jaw.status,  :orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(jd.startTime))")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPage(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT,@Param("patientCode") String patientCode,@Param("orderLst") List<String> orderLst);
        
    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) ORDER BY FIELD(jaw.status,:orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(jd.startTime))")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPage(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("orderLst") List<String> orderLst,Pageable pageableRequest);
    
    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) ORDER BY FIELD(jaw.status,:orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(jd.startTime))")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPage(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("orderLst") List<String> orderLst);

    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) ORDER BY jd.startTime")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPageForDist(@Param("organizationCode") String organizationCode,@Param("status") List<String> status);

    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.patientCode= :patientCode AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) ORDER BY FIELD(jaw.status,:orderLst ), ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(jd.startTime))")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPage(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("patientCode") String patientCode,@Param("orderLst") List<String> orderLst);
    
    @Query("SELECT jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode ORDER BY jaw.status DESC") 
    public List<JobsAssignToWorker> getAllDashboardJobByOrganizationCode(@Param("organizationCode") String organizationCode);

    @Query("SELECT jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status = :jobStatus")
    public List<JobsAssignToWorker> getAllDashboardJobByOrganizationCodeByStatus(@Param("organizationCode") String organizationCode,@Param("jobStatus") String jobStatus);

    @Query("SELECT jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT )) ") 
    public List<JobsAssignToWorker> getAllDashboardJobByOrganizationCode(@Param("organizationCode") String organizationCode,@Param("sDT") Date sDT,@Param("eDT") Date eDT);

    @Query("SELECT jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status = :jobStatus AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ))")
    public List<JobsAssignToWorker> getAllDashboardJobByOrganizationCodeByStatus(@Param("organizationCode") String organizationCode,@Param("jobStatus")  String jobStatus,@Param("sDT") Date sDT,@Param("eDT") Date eDT);

    @Query("SELECT job,jd,jaw FROM Jobs job,JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode AND jd.jobsDurationCode = jaw.jobsDurationCode AND  jd.jobsCode = jaw.jobsCode  AND jaw.status = :jobsStatus AND jd.startTime >:curDT ORDER BY job.id DESC")
    public List<Object> getAllUpcomingAcceptedJobs(@Param("curDT") Date curDT,@Param("jobsStatus") String jobsStatus);

    @Query("SELECT job,jd,jaw FROM Jobs job,JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode AND jd.jobsDurationCode = jaw.jobsDurationCode AND  jd.jobsCode = jaw.jobsCode  AND  jd.startTime <:curDT AND jaw.status NOT IN ( :assignedJobStatusList)  ORDER BY job.organizationCode ASC ")
    public List<Object> getAllJobsNearToExpire(@Param("curDT") Date curDT,@Param("assignedJobStatusList") List<String> assignedJobStatusList);

    @Query("SELECT w FROM Worker w WHERE w.isDeleted != TRUE AND w.workerCode = :workerCode")
    public Worker getWorkerByWorkerCodeForNoti(@Param("workerCode") String workerCode);
    
    @Query("SELECT org FROM Organization org WHERE org.isDeleted != TRUE AND org.organizationCode = :organizationCode")
    public Organization getOrganizationByOrganizationCodeForNoti(@Param("organizationCode") String organizationCode);
    
    @Query("SELECT j FROM JobsDuration j WHERE j.isDeleted != TRUE AND j.jobsDurationCode = :jobsDurationCode")
    public JobsDuration getJobsDurationByJobsDurationCodeForNoti(@Param("jobsDurationCode") String jobsDurationCode);

    @Query("SELECT pd FROM PatientDetails pd  WHERE pd.isDeleted != TRUE AND pd.isActive = TRUE  AND pd.patientCode = :patientCode")
    public PatientDetails getPatientDetailsBypatientCodeForNoti(@Param("patientCode") String patientCode);

    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ORDER BY ABS(UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(jd.startTime))")
    public List<Object> getAllJobsByOrganizationCode(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT);
    
    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.workerCode = :workerCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ORDER BY jd.startTime")
    public List<Object> getAppointmentDetailOfTechnicianByOrgCodeAndWorkerCode(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT,@Param("workerCode") String workerCode);
    
    @Query("SELECT job,jd,jaw FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ")
    public List<Object> getAllJobStatusDetailByOrgCode(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT);
    
    @Query("SELECT job,jd,jaw,pd,pm FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw,PatientDetails pd,ProcedureMaster pm WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND pd.isActive = TRUE AND pd.isDeleted != TRUE AND pm.isDeleted != TRUE  AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND pd.patientCode =job.patientCode AND pm.procedureCode=job.procedureCode  AND job.organizationCode = :organizationCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ORDER BY  jd.startTime")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPageForTest(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT);
    
    @Query("SELECT job,jd,jaw,pd,pm FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw,PatientDetails pd,ProcedureMaster pm WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND pd.isActive = TRUE AND pd.isDeleted != TRUE AND pm.isDeleted != TRUE  AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND pd.patientCode =job.patientCode AND pm.procedureCode=job.procedureCode  AND job.organizationCode = :organizationCode AND jaw.status IN (:status) ORDER BY jd.startTime")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPageForTest(@Param("organizationCode") String organizationCode,@Param("status") List<String> status);
    
    @Query("SELECT job,jd,jaw, pd,worker FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw ,PatientDetails pd ,Worker worker WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND pd.isDeleted != TRUE AND worker.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode  AND pd.patientCode =job.patientCode AND worker.workerCode =jaw.workerCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ORDER BY jd.startTime")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPageForDistForTest(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT);
    
    @Query("SELECT job,jd,jaw, pd,worker FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw,PatientDetails pd ,Worker worker WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND pd.isDeleted != TRUE AND worker.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND pd.patientCode =job.patientCode AND worker.workerCode =jaw.workerCode AND job.organizationCode = :organizationCode AND jaw.status IN (:status) ORDER BY jd.startTime")
    public List<Object> getAllJobsByOrganizationCodeWithFilterByPageForDistForTest(@Param("organizationCode") String organizationCode,@Param("status") List<String> status);
    
    @Query("SELECT job,jd,jaw, pd,pm FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw,PatientDetails pd,ProcedureMaster pm WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND pd.isDeleted != TRUE AND pm.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND pd.patientCode =job.patientCode AND pm.procedureCode=job.procedureCode AND job.organizationCode = :organizationCode AND jaw.workerCode = :workerCode AND jaw.status IN (:status) AND ( (jd.startTime >= :sDT AND jd.endTime <=:eDT ) OR (jd.startTime <:sDT AND jd.endTime > :eDT  ) OR (jd.startTime <:sDT AND jd.endTime > :sDT  ) OR (jd.startTime < :eDT AND jd.endTime > :eDT ) ) ORDER BY jd.startTime")
    public List<Object> getAppointmentDetailOfTechnicianByOrgCodeAndWorkerCodeForTest(@Param("organizationCode") String organizationCode,@Param("status") List<String> status,@Param("sDT") Date sDT,@Param("eDT") Date eDT,@Param("workerCode") String workerCode);
    
    @Query("SELECT job,jd,jaw, pd,pm FROM Jobs job, JobsDuration jd, JobsAssignToWorker jaw,PatientDetails pd,ProcedureMaster pm WHERE job.isDeleted != TRUE AND jd.isDeleted != TRUE AND jaw.isDeleted != TRUE AND pd.isDeleted != TRUE AND pm.isDeleted != TRUE AND job.jobsCode =jd.jobsCode  AND jd.jobsDurationCode = jaw.jobsDurationCode AND jd.jobsCode = jaw.jobsCode AND pd.patientCode =job.patientCode AND pm.procedureCode=job.procedureCode AND jd.jobsDurationCode = :jobsDurationCode")
    public Object getFullJobDetailsByJobDurationCode(@Param("jobsDurationCode") String jobsDurationCode);
}
