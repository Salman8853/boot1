/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.dtob;

/**
 *
 * @author m.salman
 */
public class TodaysAssignedPatientListResForMobile {
    private String name;
    private String address;
    private Double distance;
   private String startTime;
   private String endTime;
   private String time;
    private String date;
  private String procedureIcon;
  private String jobDurationCode;
  private String patientLatitude;
  private String patientLongitude;
  private String status;

    public String getJobDurationCode() {
        return jobDurationCode;
    }

    public void setJobDurationCode(String jobDurationCode) {
        this.jobDurationCode = jobDurationCode;
    }

    public String getPatientLatitude() {
        return patientLatitude;
    }

    public void setPatientLatitude(String patientLatitude) {
        this.patientLatitude = patientLatitude;
    }

    public String getPatientLongitude() {
        return patientLongitude;
    }

    public void setPatientLongitude(String patientLongitude) {
        this.patientLongitude = patientLongitude;
    }

   
    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

   

   
  
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

   

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getProcedureIcon() {
        return procedureIcon;
    }

    public void setProcedureIcon(String procedureIcon) {
        this.procedureIcon = procedureIcon;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    
}
