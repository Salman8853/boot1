package com.gigflex.prototype.microservices.organizationskill.service;

import java.util.List;

import com.gigflex.prototype.microservices.organizationskill.dtob.OrgSkillRequest;
import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkillRequest;

public interface OrganizationSkillService {
	
	public String search(String search);
	public String getAllOrganizationSkill();
	public String getAllOrganizationSkillWithNames();
	public String getOrganizationSkillById(Long id);
	public String saveOrganizationSkill(OrganizationSkillRequest orgskillrqst, String ip);
	public String deleteOrganizationSkillById(Long id);
	public String softDeleteOrganizationSkillById(Long id);
	public String softMultipleDeleteById(List<Long> idList);

	public String updateOrganizationSkillById(Long id, OrgSkillRequest orgskillrqst, String ip);
	public String getOrganizationSkill(int page, int limit);
	public String getOrganizationSkillWithNamesByPage(int page, int limit);
	
	public String getSkillsByOrgCode(String organizationCode);
	public String getSkillsByOrgCode(int page, int limit,String organizationCode);


}
