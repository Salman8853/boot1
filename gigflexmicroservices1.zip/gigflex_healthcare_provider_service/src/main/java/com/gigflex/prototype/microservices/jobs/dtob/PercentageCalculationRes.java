/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.jobs.dtob;

import java.util.List;

/**
 *
 * @author amit.kumar
 */
public class PercentageCalculationRes {
    
    private List<JobsAllResponse> jobResponseList ; 
    private List<PercentageCalculation> percentageCalculationList;
    private double fullfillmentAverage ;

    public List<JobsAllResponse> getJobResponseList() {
        return jobResponseList;
    }

    public void setJobResponseList(List<JobsAllResponse> jobResponseList) {
        this.jobResponseList = jobResponseList;
    }

    public List<PercentageCalculation> getPercentageCalculationList() {
        return percentageCalculationList;
    }

    public void setPercentageCalculationList(List<PercentageCalculation> percentageCalculationList) {
        this.percentageCalculationList = percentageCalculationList;
    }

    public double getFullfillmentAverage() {
        return fullfillmentAverage;
    }

    public void setFullfillmentAverage(double fullfillmentAverage) {
        this.fullfillmentAverage = fullfillmentAverage;
    }
    
    
    
    
}
