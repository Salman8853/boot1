/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.proceduremaster.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureMaster;
import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureMasterRequest;
import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureMasterResponse;
import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureSkillMapping;
import com.gigflex.prototype.microservices.proceduremaster.repository.ProcedureMasterDao;
import com.gigflex.prototype.microservices.proceduremaster.repository.ProcedureSkillMappingDao;
import com.gigflex.prototype.microservices.proceduremaster.service.ProcedureMasterService;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;
import com.gigflex.prototype.microservices.util.GigUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class ProcedureMasterServiceImpl implements ProcedureMasterService{
    
    private static final Logger LOG = LoggerFactory.getLogger(ProcedureMasterServiceImpl.class);

    @Autowired
    private ProcedureMasterDao procedureMasterRep;
    
    @Autowired
    ProcedureSkillMappingDao procedureSkillMappingRep;
    
    
    @Override
    public String findAllProcedureMaster() {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<ProcedureMaster> procedureMasterlist = procedureMasterRep.getAllProcedureMaster();

                        List<ProcedureMasterResponse> maplist = new ArrayList<ProcedureMasterResponse>();
                        if(procedureMasterlist != null && procedureMasterlist.size() > 0)
                        {
                            
                            for (int i = 0; i < procedureMasterlist.size(); i++) {
                                ProcedureMaster pm = procedureMasterlist.get(i);
                                
                                    ProcedureMasterResponse pmr = new ProcedureMasterResponse();

                                    List<SkillMaster> skillMasterList = procedureSkillMappingRep.getSkillByProcedureCode(pm.getProcedureCode());
                                    pmr.setId(pm.getId());
                                    pmr.setProcedureCode(pm.getProcedureCode());
                                    pmr.setProcedureDescription(pm.getProcedureDescription());
                                    pmr.setProcedureId(pm.getProcedureId());
                                    pmr.setProcedureName(pm.getProcedureName());
                                    pmr.setProcedureIcon(pm.getProcedureIcon()); 
                                    if(skillMasterList != null && skillMasterList.size()>0)
                                    {
                                        pmr.setSkillMasterList(skillMasterList);
                                    }
                                     
                                    maplist.add(pmr);
                               
                            }
                            
                            if (maplist != null && maplist.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(maplist);
				jsonobj.put("data", new JSONArray(Detail));
                            } else {
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Record Not Found.");
                                    jsonobj.put("timestamp", new Date());
                            }
                        }
                        else
                        {
                            jsonobj.put("responsecode",404);
                            jsonobj.put("message", "Record Not Found");
                            jsonobj.put("timestamp", new Date());
			
                        }                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }

    @Override
    public String getAllProcedureMasterByPage(int page, int limit) {
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0)
                        {
                            Pageable pageableRequest = PageRequest.of(page, limit);
                            List<ProcedureMaster> procedureMasterlist = procedureMasterRep.getAllProcedureMaster(pageableRequest);

                            List<ProcedureMasterResponse> maplist = new ArrayList<ProcedureMasterResponse>();
                            if(procedureMasterlist != null && procedureMasterlist.size() > 0)
                            {
                            
                            for (int i = 0; i < procedureMasterlist.size(); i++) {
                                    ProcedureMaster pm = procedureMasterlist.get(i);
                                
                                    ProcedureMasterResponse pmr = new ProcedureMasterResponse();

                                    List<SkillMaster> skillMasterList = procedureSkillMappingRep.getSkillByProcedureCode(pm.getProcedureCode());
                                    pmr.setId(pm.getId());
                                    pmr.setProcedureCode(pm.getProcedureCode());
                                    pmr.setProcedureDescription(pm.getProcedureDescription());
                                    pmr.setProcedureId(pm.getProcedureId());
                                    pmr.setProcedureName(pm.getProcedureName());
                                    pmr.setProcedureIcon(pm.getProcedureIcon());
                                    if(skillMasterList != null && skillMasterList.size()>0)
                                    {
                                        pmr.setSkillMasterList(skillMasterList);
                                    }
                                     
                                    maplist.add(pmr);
                               
                            }
                            
                                if (maplist != null && maplist.size() > 0) {
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Success");
                                    jsonobj.put("timestamp", new Date());
                                    ObjectMapper mapperObj = new ObjectMapper();
                                    String Detail = mapperObj.writeValueAsString(maplist);
                                    jsonobj.put("data", new JSONArray(Detail));
                                } else {
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("message", "Record Not Found.");
                                        jsonobj.put("timestamp", new Date());
                                }
                            }
                            else
                            {
                                jsonobj.put("responsecode",404);
                                jsonobj.put("message", "Record Not Found");
                                jsonobj.put("timestamp", new Date());

                            }         
                        
                         } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }

    @Override
    public String findProcedureMasterById(Integer id) {
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			ProcedureMaster pm = procedureMasterRep.getProcedureMasterById(id);
                        ProcedureMasterResponse pmr = new ProcedureMasterResponse();
                        if(pm != null && pm.getId()> 0)
                        {  
                            List<SkillMaster> skillMasterList = procedureSkillMappingRep.getSkillByProcedureCode(pm.getProcedureCode());
                            pmr.setId(pm.getId());
                            pmr.setProcedureCode(pm.getProcedureCode());
                            pmr.setProcedureDescription(pm.getProcedureDescription());
                            pmr.setProcedureId(pm.getProcedureId());
                            pmr.setProcedureName(pm.getProcedureName());
                            pmr.setProcedureIcon(pm.getProcedureIcon());
                            if(skillMasterList != null && skillMasterList.size()>0)
                            {
                                pmr.setSkillMasterList(skillMasterList);
                            }
                            
                            if (pmr != null ) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(pmr);
				jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Record Not Found.");
                                    jsonobj.put("timestamp", new Date());
                            }
                        }
                        else
                        {
                            jsonobj.put("responsecode",404);
                            jsonobj.put("message", "Record Not Found");
                            jsonobj.put("timestamp", new Date());
			
                        }                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }

    @Override
    public String findByProcedureCode(String procedureCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			ProcedureMaster pm = procedureMasterRep.getProcedureMasterByProcedureCode(procedureCode);
                        ProcedureMasterResponse pmr = new ProcedureMasterResponse();
                        if(pm != null && pm.getId()> 0)
                        {  
                            List<SkillMaster> skillMasterList = procedureSkillMappingRep.getSkillByProcedureCode(pm.getProcedureCode());
                            pmr.setId(pm.getId());
                            pmr.setProcedureCode(pm.getProcedureCode());
                            pmr.setProcedureDescription(pm.getProcedureDescription());
                            pmr.setProcedureId(pm.getProcedureId());
                            pmr.setProcedureName(pm.getProcedureName());
                            pmr.setProcedureIcon(pm.getProcedureIcon());
                            if(skillMasterList != null && skillMasterList.size()>0)
                            {
                                pmr.setSkillMasterList(skillMasterList);
                            }
                            
                            if (pmr != null ) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(pmr);
				jsonobj.put("data", new JSONObject(Detail));
                            } else {
                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Record Not Found.");
                                    jsonobj.put("timestamp", new Date());
                            }
                        }
                        else
                        {
                            jsonobj.put("responsecode",404);
                            jsonobj.put("message", "Record Not Found");
                            jsonobj.put("timestamp", new Date());
			
                        }                        
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
                        LOG.error("Exception is occurred.",ex);
		}
		return res;
    }

    @Override
    public String saveProcedureMaster(ProcedureMasterRequest procedureMasterReq, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (procedureMasterReq != null ) {
				if (procedureMasterReq.getProcedureDescription() != null
						&& procedureMasterReq.getProcedureDescription().trim().length() > 0
                                        && procedureMasterReq.getProcedureId() != null && procedureMasterReq.getProcedureId().trim().length() > 0
                                        && procedureMasterReq.getProcedureName() != null && procedureMasterReq.getProcedureName().trim().length() > 0 
                                        && procedureMasterReq.getSkillCodeList() != null && procedureMasterReq.getSkillCodeList().size() > 0 ) {

                                        ProcedureMaster pmExist = procedureMasterRep.getProcedureMasterByProcedureId(procedureMasterReq.getProcedureId());
                                        
                                        if(pmExist != null && pmExist.getId() > 0)
                                        {
                                            jsonobj.put("responsecode", 409);
                                            jsonobj.put("timestamp", new Date());
                                            jsonobj.put("message", "Record already exist.");
                                        }
                                        else
                                        {
                                            ProcedureMaster procedures = new ProcedureMaster();
                                            procedures.setIpAddress(ip);
                                            procedures.setProcedureDescription(procedureMasterReq.getProcedureDescription());
                                            procedures.setProcedureId(procedureMasterReq.getProcedureId());
                                            procedures.setProcedureName(procedureMasterReq.getProcedureName()); 
                                            procedures.setProcedureIcon(procedureMasterReq.getProcedureIcon()); 

                                            ProcedureMaster proceduresRes = procedureMasterRep.save(procedures);
                                            
                                        
                                            if(proceduresRes != null && proceduresRes.getId() >0 )
                                            {   
                                                List<String> skillCodeList = procedureMasterReq.getSkillCodeList(); 
                                                boolean isPresent = false;
                                                for(String skillCode :skillCodeList )
                                                {
                                                    try{
                                                        ProcedureSkillMapping  procedureSkillMapping =  new ProcedureSkillMapping();
                                                        procedureSkillMapping.setIpAddress(ip);
                                                        procedureSkillMapping.setProcedureCode(proceduresRes.getProcedureCode()); 
                                                        procedureSkillMapping.setSkillCode(skillCode); 
                                                        ProcedureSkillMapping psMappingRes = procedureSkillMappingRep.save(procedureSkillMapping);
                                                        if( psMappingRes != null && psMappingRes.getId() > 0  )
                                                        {
                                                             isPresent = true;
                                                        }
                                                    }
                                                    catch(Exception ex)
                                                    {
                                                        ex.printStackTrace();
                                                    }
                                                     
                                                     
                                                }
                                                

                                                if (isPresent) {
                                                        jsonobj.put("responsecode", 200);
                                                        jsonobj.put("timestamp", new Date());
                                                        jsonobj.put("message",
                                                                        "Procedure Master has been added successfully.");
                                                        ObjectMapper mapperObj = new ObjectMapper();
                                                        String Detail = mapperObj.writeValueAsString(proceduresRes);
                                                        jsonobj.put("data", new JSONObject(Detail));
                                                } else {
                                                       procedureMasterRep.deleteById(proceduresRes.getId()); 
                                                       jsonobj.put("responsecode", 400);
                                                       jsonobj.put("timestamp", new Date());
                                                       jsonobj.put("message", "Failed");
                                                }
                                            }
                                            else
                                            {
                                                jsonobj.put("responsecode", 400);
                                                jsonobj.put("timestamp", new Date());
                                                jsonobj.put("message", "Failed");
                                            }

                                           
                                        }
                                            
					
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Procedure Description,ProcedureId,Procedure Name & Skill Code should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
    }

    @Override
    public String updateProcedureMasterByProcedureCode(String procedureCode, ProcedureMasterRequest procedureMasterReq, String ip) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (procedureCode != null && procedureMasterReq != null) {
				if (procedureMasterReq.getProcedureDescription() != null
						&& procedureMasterReq.getProcedureDescription().trim().length() > 0
                                        && procedureMasterReq.getProcedureId() != null && procedureMasterReq.getProcedureId().trim().length() > 0
                                        && procedureMasterReq.getProcedureName() != null && procedureMasterReq.getProcedureName().trim().length() > 0 
                                        && procedureMasterReq.getSkillCodeList() != null && procedureMasterReq.getSkillCodeList().size() > 0 ) {
                                    

                                       ProcedureMaster  alreadyExist = procedureMasterRep.getProcedureMasterByProcedureCodeAndProcedureId(procedureCode,procedureMasterReq.getProcedureId());
                                    					
					if (alreadyExist == null ) {
                                            
                                                ProcedureMaster procedureMasterInDb = procedureMasterRep
                                                            .getProcedureMasterByProcedureCode(procedureCode);
                                               
                                                
                                                procedureMasterInDb.setIpAddress(ip);
                                                procedureMasterInDb.setProcedureDescription(procedureMasterReq.getProcedureDescription());
                                                procedureMasterInDb.setProcedureId(procedureMasterReq.getProcedureId());
                                                procedureMasterInDb.setProcedureName(procedureMasterReq.getProcedureName());
                                                procedureMasterInDb.setProcedureIcon(procedureMasterReq.getProcedureIcon()); 


                                                ProcedureMaster proceduresRes = procedureMasterRep.save(procedureMasterInDb);
                                                
                                              
						if (proceduresRes != null && proceduresRes.getId() > 0) {
                                                    
                                                        List<ProcedureSkillMapping> procedureSkillMappingList = procedureSkillMappingRep.getProcedureSkillByProcedureCode(procedureCode);
                                                        
                                                        if(procedureSkillMappingList != null && procedureSkillMappingList.size() > 0)
                                                        {
                                                            List<String> skillCodeList = procedureMasterReq.getSkillCodeList(); 
                                                            List<ProcedureSkillMapping> removeProcedureSkillMappingList = new  ArrayList<>();
                                                            boolean isPresent = false;
                                                            boolean isRemoved = false;
                                                            boolean isAdd = false;
                                                            for(ProcedureSkillMapping procedureMapping :procedureSkillMappingList )
                                                            {                                                                
                                                                String skillCode = procedureMapping.getSkillCode();
                                                                if(skillCodeList.contains(skillCode)) 
                                                                {
                                                                    skillCodeList.remove(skillCode);
                                                                }
                                                                else
                                                                {
                                                                    removeProcedureSkillMappingList.add(procedureMapping);
                                                                }
                                                                                                                                
                                                            }
                                                           
                                                            if(removeProcedureSkillMappingList.size() > 0)
                                                            { 
                                                                isRemoved = true;
                                                                for(ProcedureSkillMapping mapping :removeProcedureSkillMappingList )
                                                                {
                                                                    try
                                                                    {
                                                                        procedureSkillMappingRep.deleteById(mapping.getId()); 
                                                                    }
                                                                    catch(Exception ex)
                                                                    {
                                                                        ex.printStackTrace();
                                                                    }
                                                                    
                                                                }
                                                            }
                                      
                                                            if(skillCodeList.size() > 0)
                                                            {
                                                                isAdd =true;
                                                                for(String skillCode:skillCodeList)
                                                                {
                                                                    ProcedureSkillMapping  procedureSkillMapping =  new ProcedureSkillMapping();
                                                                    procedureSkillMapping.setIpAddress(ip);
                                                                    procedureSkillMapping.setProcedureCode(proceduresRes.getProcedureCode()); 
                                                                    procedureSkillMapping.setSkillCode(skillCode); 
                                                                    ProcedureSkillMapping psMappingRes = procedureSkillMappingRep.save(procedureSkillMapping);
                                                                    
                                                                    if(psMappingRes!= null && psMappingRes.getId() > 0)
                                                                    {
                                                                        isPresent = true;
                                                                    }
                                                                }
                                                            }
                                                           
//                                                            if (isRemoved || (isAdd && isPresent)) {
                                                            jsonobj.put("responsecode", 200);
                                                            jsonobj.put("message",
                                                                            "Procedure Master updation has been done");
                                                            jsonobj.put("timestamp", new Date());
                                                            ObjectMapper mapperObj = new ObjectMapper();
                                                            String Detail = mapperObj.writeValueAsString(proceduresRes);
                                                            jsonobj.put("data", new JSONObject(Detail));
//                                                            } else {
//                                                                   procedureMasterRep.deleteById(proceduresRes.getId()); 
//                                                                   jsonobj.put("responsecode", 400);
//                                                                   jsonobj.put("timestamp", new Date());
//                                                                   jsonobj.put("message", "Failed");
//                                                            } 
                                                        }
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("message",
									"Procedure Master updation has been failed.");
							jsonobj.put("timestamp", new Date());
						}
					} else {
						jsonobj.put("responsecode", 409);
						jsonobj.put("message", "Procedure Master already exist for procedure ID "+procedureMasterReq.getProcedureId() +" .");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Procedure Description,ProcedureId,Procedure Name & Skill Code should not be blank");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }
    
    
    @Override
    public String softDeleteProcedureMasterByProcedureCode(String procedureCode) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(procedureCode == null)
                        {
                            ProcedureMaster procedureMaster = procedureMasterRep.getProcedureMasterByProcedureCode(procedureCode);
                            if (procedureMaster != null && procedureMaster.getId() > 0) {

                                procedureMaster.setIsDeleted(true);
                                ProcedureMaster procedureMasterRes = procedureMasterRep.save(procedureMaster);
                                if (procedureMasterRes != null && procedureMasterRes.getId() > 0) {
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message","Procedure Master deleted successfully.");

                                } else {
                                        jsonobj.put("responsecode", 400);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Failed");
                                }
                            }
                            else {
                                    jsonobj.put("responsecode", 404);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message", "Record Not Found");
                            }
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Record Not Found");
                        }
			
			res = jsonobj.toString();
		} catch (JSONException ex) {
                        GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
                        res = derr.toString();
                        ex.printStackTrace();
                        LOG.error("Error in softDeleteByProcedureCode>>>>>>", ex);
                }catch(org.springframework.orm.jpa.JpaSystemException ex)
                {
                    GigflexResponse derr = new GigflexResponse(401, new Date(), GigUtil.getRootException(ex));
                    res = derr.toString();
                    ex.printStackTrace();
                    LOG.error("Error in softDeleteByProcedureCode>>>>>>", ex);
		} catch (Exception ex) {
                    ex.printStackTrace();
                    LOG.error("Error in softDeleteByProcedureCode>>>>>>", ex);	
                    GigflexResponse derr = new GigflexResponse(500, new Date(),	"Exception is occurred.");
                    res = derr.toString();
                    LOG.error("Error in softDeleteByProcedureCode>>>>>>", ex);
		}
		return res;
    }

    @Override
    public String softMultipleDeleteByProcedureCode(List<String> procedureCodeList) {
       
        String res = "";
		try {
			JSONArray jarr = new JSONArray();
                        
                        if(procedureCodeList != null && procedureCodeList.size() > 0)
                        {
                            	for (String procedureCode : procedureCodeList) {
				if (procedureCode != null && procedureCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					procedureCode = procedureCode.trim();

					ProcedureMaster procedureMaster = procedureMasterRep.getProcedureMasterByProcedureCode(procedureCode);

					if (procedureMaster != null && procedureMaster.getId() > 0) {
						
						try{
                                                    procedureMaster.setIsDeleted(true);
                                                    ProcedureMaster procedureRes = procedureMasterRep.save(procedureMaster);
                                                    if (procedureRes != null && procedureRes.getId() > 0) {
                                                            jsonobj.put("responsecode", 200);
                                                            jsonobj.put("timestamp", new Date());
                                                            jsonobj.put("code", procedureRes);
                                                            jsonobj.put("message","Procedure Master deleted successfully.");		
                                                    } else {
                                                            jsonobj.put("responsecode", 400);
                                                            jsonobj.put("timestamp", new Date());
                                                            jsonobj.put("code", procedureCode);
                                                            jsonobj.put("message", "Failed");
                                                    }
						}catch(org.springframework.orm.jpa.JpaSystemException ex){
							jsonobj.put("responsecode", 401);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", procedureCode);
							jsonobj.put("message",  GigUtil.getRootException(ex));
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", procedureCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			   }
                        }
                        else
                        {
                            JSONObject jsonobj = new JSONObject();                            
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("code", procedureCodeList);
                            jsonobj.put("message", "Record Not Found");
                            jarr.add(jsonobj);
                        }
                        
		
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
                        ex.printStackTrace();
                        LOG.error("Error in softDeleteByProcedureCode>>>>>>", ex);
                        
		}
		return res;
    }

    
        
}
