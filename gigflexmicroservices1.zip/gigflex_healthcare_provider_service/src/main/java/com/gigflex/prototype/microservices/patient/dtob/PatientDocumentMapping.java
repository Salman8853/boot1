/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.patient.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "patient_document_mapping")
public class PatientDocumentMapping extends CommonAttributes implements Serializable {
    
        @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
        
        @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "patient_document_mapping_code", unique = true)
	private String patientDocumentMappingCode;
        
        @Column(name = "patient_code")
	private String patientCode;
        
        @Column(name = "document_name")
	private String documentName;
        
        @Column(name = "document_description")
	private String documentDescription;
        
        @Column(name = "document_file_path")
	private String documentFilePath;
        
        @PrePersist
	private void assignUUID() {
            if (this.getPatientDocumentMappingCode() == null || this.getPatientDocumentMappingCode().length() == 0) {
                    this.setPatientDocumentMappingCode(UUID.randomUUID().toString());
            }
	}

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getPatientDocumentMappingCode() {
            return patientDocumentMappingCode;
        }

        public void setPatientDocumentMappingCode(String patientDocumentMappingCode) {
            this.patientDocumentMappingCode = patientDocumentMappingCode;
        }

        public String getPatientCode() {
            return patientCode;
        }

        public void setPatientCode(String patientCode) {
            this.patientCode = patientCode;
        }

        public String getDocumentName() {
            return documentName;
        }

        public void setDocumentName(String documentName) {
            this.documentName = documentName;
        }

        public String getDocumentDescription() {
            return documentDescription;
        }

        public void setDocumentDescription(String documentDescription) {
            this.documentDescription = documentDescription;
        }

        public String getDocumentFilePath() {
            return documentFilePath;
        }

        public void setDocumentFilePath(String documentFilePath) {
            this.documentFilePath = documentFilePath;
        }
        
        
}
