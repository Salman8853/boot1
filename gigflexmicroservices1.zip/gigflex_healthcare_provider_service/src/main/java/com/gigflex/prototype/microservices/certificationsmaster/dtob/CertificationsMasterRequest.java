package com.gigflex.prototype.microservices.certificationsmaster.dtob;

public class CertificationsMasterRequest {

        private String organizationCode;
	private String certificationName;
	private Boolean isAssigned = false;
        private String skillCode;
        private String certificationUrl;

	public Boolean getIsAssigned() {
		return isAssigned;
	}

	public void setIsAssigned(Boolean isAssigned) {
		this.isAssigned = isAssigned;
	}

	public String getCertificationName() {
		return certificationName;
	}

	public void setCertificationName(String certificationName) {
		this.certificationName = certificationName;
	}

        public String getOrganizationCode() {
            return organizationCode;
        }

        public void setOrganizationCode(String organizationCode) {
            this.organizationCode = organizationCode;
        }

        public String getSkillCode() {
            return skillCode;
        }

        public void setSkillCode(String skillCode) {
            this.skillCode = skillCode;
        }

        public String getCertificationUrl() {
            return certificationUrl;
        }

        public void setCertificationUrl(String certificationUrl) {
            this.certificationUrl = certificationUrl;
        }
	
	
}
