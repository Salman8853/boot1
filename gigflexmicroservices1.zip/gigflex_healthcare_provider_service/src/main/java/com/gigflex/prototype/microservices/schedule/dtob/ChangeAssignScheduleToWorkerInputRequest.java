/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

/**
 *
 * @author abhishek
 */

public class ChangeAssignScheduleToWorkerInputRequest  {
    
   
    private String assignScheduletoWorkerCode;
    
   
    private String changedByWorkerCode;
    
    
    private String changeToWorkerCode;
    
    
    private Boolean isApproved;

    public String getAssignScheduletoWorkerCode() {
        return assignScheduletoWorkerCode;
    }

    public void setAssignScheduletoWorkerCode(String assignScheduletoWorkerCode) {
        this.assignScheduletoWorkerCode = assignScheduletoWorkerCode;
    }

    public String getChangedByWorkerCode() {
        return changedByWorkerCode;
    }

    public void setChangedByWorkerCode(String changedByWorkerCode) {
        this.changedByWorkerCode = changedByWorkerCode;
    }

    public String getChangeToWorkerCode() {
        return changeToWorkerCode;
    }

    public void setChangeToWorkerCode(String changeToWorkerCode) {
        this.changeToWorkerCode = changeToWorkerCode;
    }

    public Boolean getIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }
    
  

}
