package com.gigflex.prototype.microservices.employmenttype.api;


import com.gigflex.prototype.microservices.employmenttype.dtob.EmploymentTypeRequest;
import com.gigflex.prototype.microservices.employmenttype.service.EmploymentTypeService;
import com.gigflex.prototype.microservices.timezone.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.timezone.service.TimeZoneDetailService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")
public class EmploymentTypeController { 

	@Autowired
	private EmploymentTypeService employmentTypeService;

	@GetMapping("/getAllEmploymentType")
	public String getAllEmploymentType() {
		return employmentTypeService.getAllEmploymentType();
	}

	@PostMapping("/saveEmploymentType")
	public String saveEmploymentType(
			@RequestBody EmploymentTypeRequest empreq,
			HttpServletRequest request) {
            if(empreq!=null && empreq.getEmploymentTypeName()!=null && empreq.getEmploymentTypeName().length()>0)
            {
		String ip = request.getRemoteAddr();
		return employmentTypeService.saveEmploymentType(empreq, ip);
            }else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Employment Type should not be blank.");
			return derr.toString();
            }

	}


	@GetMapping("/getEmploymentTypeByCode/{employmentTypeCode}")
	public String getEmploymentTypeByCode(
			@PathVariable String employmentTypeCode) {
	if( employmentTypeCode!=null && employmentTypeCode.trim().length()>0)
            {	
            return employmentTypeService.getEmploymentTypeByCode(employmentTypeCode.trim());
                }else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Employment Type Code should not be blank.");
			return derr.toString();
            }
	}

        @DeleteMapping("/softDeleteEmploymentTypeByCode/{employmentTypeCode}")
	public String softDeleteEmploymentTypeByCode(
			@PathVariable String employmentTypeCode) {
		if( employmentTypeCode!=null && employmentTypeCode.trim().length()>0)
            {	
            return employmentTypeService.softDeleteEmploymentTypeByCode(employmentTypeCode.trim());
                }else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Employment Type Code should not be blank.");
			return derr.toString();
            }
	}
        
     
	@PutMapping("/updateEmploymentTypeByCode/{employmentTypeCode}")
	public String updateEmploymentTypeByCode(
			@PathVariable String employmentTypeCode,@RequestBody EmploymentTypeRequest empreq,
			HttpServletRequest request) {
            if(empreq!=null && empreq.getEmploymentTypeName()!=null && empreq.getEmploymentTypeName().length()>0
                    && employmentTypeCode!=null && employmentTypeCode.trim().length()>0)
            {
		String ip = request.getRemoteAddr();
		return employmentTypeService.updateEmploymentTypeByCode(empreq,employmentTypeCode.trim(), ip);
            }else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Employment Type Code and Employment Type Name should not be blank.");
			return derr.toString();
            }

	}
        


}
