/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.dtob;

import java.util.List;

/**
 *
 * @author nirbhay.p
 */
public class ScheduleRequestresponse {
    private WorkerScheduleRequestRes workerScheduleRequest;
    private WorkerScheduleRequestAssignment workerScheduleRequestAssignment;
     private List<AssignScheduleToWorker> assignScheduleToWorker;
    private String skillName;
        
    private String skillColor;

    private String certificationName;

    public List<AssignScheduleToWorker> getAssignScheduleToWorker() {
        return assignScheduleToWorker;
    }

    public void setAssignScheduleToWorker(List<AssignScheduleToWorker> assignScheduleToWorker) {
        this.assignScheduleToWorker = assignScheduleToWorker;
    }

      public String getSkillName() {
        return skillName;
    }

    public void setSkillName(String skillName) {
        this.skillName = skillName;
    }

    public String getSkillColor() {
        return skillColor;
    }

    public void setSkillColor(String skillColor) {
        this.skillColor = skillColor;
    }

    public String getCertificationName() {
        return certificationName;
    }

    public void setCertificationName(String certificationName) {
        this.certificationName = certificationName;
    }
        
        

    public WorkerScheduleRequestRes getWorkerScheduleRequest() {
        return workerScheduleRequest;
    }

    public void setWorkerScheduleRequest(WorkerScheduleRequestRes workerScheduleRequest) {
        this.workerScheduleRequest = workerScheduleRequest;
    }
    

    public WorkerScheduleRequestAssignment getWorkerScheduleRequestAssignment() {
        return workerScheduleRequestAssignment;
    }

    public void setWorkerScheduleRequestAssignment(WorkerScheduleRequestAssignment workerScheduleRequestAssignment) {
        this.workerScheduleRequestAssignment = workerScheduleRequestAssignment;
    }
    
    
}
