/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.jobs.service.impl;

import com.gigflex.prototype.microservices.device.dtob.DeviceDetail;
import com.gigflex.prototype.microservices.device.repository.DeviceDetailRepository;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.healthcarenotification.service.HealthcareNotificationService;
import com.gigflex.prototype.microservices.jobs.dtob.Jobs;
import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorker;
import com.gigflex.prototype.microservices.jobs.dtob.JobsDuration;
import com.gigflex.prototype.microservices.jobs.repository.JobsAssignToWorkerRepository;
import com.gigflex.prototype.microservices.jobs.repository.JobsDurationRepository;
import com.gigflex.prototype.microservices.jobs.repository.JobsRepository;
import com.gigflex.prototype.microservices.jobs.service.JobsNotification;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.patient.repository.PatientDao;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.usertype.dtob.UserType;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.util.PushNotification;
import com.gigflex.prototype.microservices.util.SendMessageAPI;
import com.gigflex.prototype.microservices.util.SendNotification;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.workertimeoff.repository.WorkerTimeOffDao;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;


/**
 *
 * @author amit.kumar
 */
@Service
public class JobsNotificationImpl implements JobsNotification{

    private static final Logger logger = LoggerFactory.getLogger(JobsNotificationImpl.class);
    
    @Autowired
    GlobalSettingRepository globalSettingRepository;

    @Autowired
    LocalSettingRepository localSettingRepository;
        
    @Autowired
    UserTypeRepository userTypeDao;
    
    @Autowired
    JobsRepository jobsDao;
    
    @Autowired
    PatientDao patientDao;
    
    @Autowired
    WorkerRepository workerDao;
    
    @Autowired
    WorkerTimeOffDao workerTimeOffDao;
    
    @Autowired
    OrganizationRepository organizationRepository;
    
    @Autowired
    TimeZoneRepository timeZoneDao;
    
    @Autowired
    private HealthcareNotificationService notificationService;
    
    @Autowired
    JobsDurationRepository jobsDurationRepository;

    @Autowired
    JobsAssignToWorkerRepository jobsAssignToWorkerRepository;

    
    @Autowired
    DeviceDetailRepository deviceDetailDao;
    
    @Value("${email.upcomingacceptedjob.subject}")
    private String subject; //= "Upcoming accepted booking notification";
    
    @Value("${email.service.url}")
    private String mailServiceURL;//="http://18.223.158.6:8091/superadminservice/sendEmail/to/{to}/subject/{subject}/body/{body}";
  
    @Value("${message.appKey}")
    private String appKey; //="5f660e09-e0b7-474e-889c-fd3c077f195c";

    @Value("${message.appSecret}")
    private String appSecret;//="qegMoUCBT0OGXuASFMPB+Q==";

    @Value("${message.url}")
    private String url;//="https://messagingapi.sinch.com/v1/sms/";
    
    @Value("${notification.fcm.url}")
    private String FMCurl; 

    @Value("${notification.fcm.authkey}")
    private String authKey;    

    
    private String subjectExpired= "Job expiry notification";
    
    @Override
    public void sendNotification() {
        
        Date dt = new Date();
        List<Object> objList = jobsDao.getAllUpcomingAcceptedJobs(dt, GigflexConstants.JOBSTATUS_ACCEPTED);
        if(objList!=null && objList.size()>0)
        {
            logger.info("In Scheduler all upcoming jobs size="+objList.size());
        UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.HealthcareProvider);    
        for (int i = 0; i < objList.size(); i++) {
        	try {
                Object[] arr = (Object[]) objList.get(i);   
                Jobs job = (Jobs) arr[0];
                JobsDuration jd= (JobsDuration) arr[1];
                JobsAssignToWorker jaw = (JobsAssignToWorker) arr[2];  
                    
                if (job != null && job.getId() > 0) {
                    
                Date curdt = new Date();
                int configMinut =1440;
                int alertMinute=30;
                Boolean isRecursive=false;
                String organizationCode = job.getOrganizationCode();
                
                String patientName="";
                PatientDetails patientDetail=  patientDao.getPatientDetailBypatientCode(job.getPatientCode());
                if(patientDetail!=null && patientDetail.getId()>0)
                 {
                   patientName=patientDetail.getPatientName();
                 }
                
                if (ut!=null && ut.getUserTypeCode()!=null && ut.getUserTypeCode().length()>0 && job.getOrganizationCode() != null && job.getOrganizationCode().length() > 0) {
                    
                   String configureminutesValue= GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), job.getOrganizationCode(),GigflexConstants.CONFIGURE_MINUTES_NAME);
                   if(configureminutesValue!=null && configureminutesValue.length()>0)
                   {
                       try
                       {
                           configMinut=Integer.parseInt(configureminutesValue);
                       }
                       catch(Exception ex)
                       {
                           ex.printStackTrace();;
                       }
                   }
                   
                   String alertminutesValue= GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), job.getOrganizationCode(),GigflexConstants.ALERT_MINUTES);
                   if(alertminutesValue!=null && alertminutesValue.length()>0)
                   {
                       try
                       {
                           alertMinute=Integer.parseInt(alertminutesValue);
                       }
                       catch(Exception ex)
                       {
                           ex.printStackTrace();;
                       }
                   }
                   
                   String isrecursiveValue= GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), job.getOrganizationCode(), GigflexConstants.IS_RECURSIVE);
                   if(isrecursiveValue!=null && isrecursiveValue.length()>0)
                   {
                       try
                       {
                           if(isrecursiveValue.equalsIgnoreCase("true"))
                           {
                           isRecursive=true;
                           }
                           
                       }
                       catch(Exception ex)
                       {
                           ex.printStackTrace();
                       }
                   }
                }
                if(!isRecursive){
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(curdt);
                    cal.add(Calendar.MINUTE, alertMinute);
                    Date sdt = cal.getTime();
                    cal.add(Calendar.MINUTE, 5);
                    Date edt = cal.getTime();
                    Date startDt = jd.getStartTime();
                    if (startDt != null && (startDt.after(sdt) || startDt.equals(sdt)) && startDt.before(edt)) {
                        logger.info("In Scheduler picup time is matched. appointment id="+jaw.getAppointmentId());

                    if (jaw != null && jaw.getId() > 0 && jaw.getWorkerCode()!= null && jaw.getWorkerCode().length() > 0) {
                        Worker worker = workerDao.getWorkerdetailByworkerCode(jaw.getWorkerCode());                      
                        if (worker != null && worker.getId() > 0 && worker.getEmail() != null && worker.getEmail().length() > 0) {
                            String toid = "";
                            boolean SMSSt=true;                           
                            boolean MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), jaw.getWorkerCode(),GigflexConstants.MAIL_NOTIFICATIONS);
                            if(MailST)
                            {
                               toid = worker.getEmail(); 
                            }
                            
                            Organization org = organizationRepository.findByOrganizationCode(organizationCode);
                            SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), organizationCode, GigflexConstants.SMS_NOTIFICATIONS);

                            String organizationName = "";
                            if (org != null) {
                                organizationName = org.getOrganizationName();
                            }
                            
                            Users adminUser = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);
                            
                            String ccMail = "";
                            String adminUserCode ="";
                            if (adminUser != null) {
                                ccMail = adminUser.getEmail();
                                adminUserCode = adminUser.getUserCode();
                            }
                            String workerUserCode =worker.getWorkerCode();                            
                                                                             
                            String conStartDt="";
                            String conEndDt="";
                            String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.HealthcareProvider, job.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.HealthcareProvider, job.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.HealthcareProvider, job.getOrganizationCode(), GigflexConstants.TimeZone);

                           TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                           if (tzd != null && tzd.getId() > 0) {

                               String timezone = tzd.getTimeZoneName();
                               if(timezone!=null && timezone.length()>0 )
                               {
                                    Date startDate = jd.getStartTime();
                                    Date endDate = jd.getEndTime();
                                    startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                    endDate = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                    conStartDt=GigflexDateUtil.convertDateToString(startDate, dtFormat);
                                    conEndDt=GigflexDateUtil.convertDateToString(endDate, dtFormat);
                               }

                            }         

                            String bodyContent = "Your upcoming accepted job details are given below-<br><br>"
                                    + "Worker Name : " + worker.getName() + "<br>"
                                    +"Patient Name : "+patientName+"<br>"+ "Start Time : "
                                    + conStartDt + "<br>" + "End Time : " + conEndDt;
                            
                             String messageBody = "\n"+"Your upcoming accepted job details are given below-"+"\n"
                                            + "Worker Name : " + worker.getName() + "\n"
                                            +"Patient Name : "+patientName+"\n"+ "Start Time : "
                                            + conStartDt + "\n" + "End Time : " + conEndDt;
                             String notificationBody = "Your upcoming accepted job details are given below-"
                                            + "Worker Name : " + worker.getName() + ","
                                            +" Patient Name : "+patientName+","+ " Start Time : "
                                            + conStartDt + "," + "End Time : " + conEndDt;
                             
                            SendNotification sn = new SendNotification();
                            SendMessageAPI sendmessageapi = new SendMessageAPI();
                              logger.info("====messageBody=====" + messageBody);

                            if (ccMail != null && ccMail.length() > 0) {
                               String res= sn.sendMail(ccMail, subject, bodyContent, mailServiceURL);
                                
                               logger.info("Cron scheduler mail respose in JobNotificationImpl >>>>>>", res);
                            } 
                            if (toid != null && toid.length() > 0) {
                                String res= sn.sendMail(toid, subject, bodyContent, mailServiceURL);
                                logger.info("Cron scheduler mail respose in JobNotificationImpl >>>>>>", res);
                                
                            }                          

                            try {
//                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), organizationCode, GigflexConstants.SMS_NOTIFICATIONS);
                                    if(SMSSt && worker.getWork_phone()!=null && worker.getWork_phone().trim().length()>0 && worker.getWorkcountryCode()!=null && worker.getWorkcountryCode().trim().length()>0){
                                   String conno="+"+worker.getWorkcountryCode().trim()+worker.getWork_phone().trim();
                                   String msg="Dear Worker,"+messageBody;
                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, conno, msg);
                                    System.out.println("====messageToken=====" + messageToken);
                                    logger.info("====messageToken=====" + messageToken);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            
                            
                            try {
                                
                                Worker adminWorker = workerDao.getWorkerdetailByworkerCode(adminUser.getUserCode());
                                
                                if (adminWorker != null && adminWorker.getId() > 0) {   
                                  
                                    
                                   
                                    
                                    String adminPhone ="+"+adminWorker.getWork_phone().trim()+adminWorker.getWork_phone().trim();
                                    if (SMSSt && adminPhone != null && adminPhone.length() > 0) {
                                    String msg="Dear Admin,"+messageBody;
                                    String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, adminPhone, msg);
                                    System.out.println("====messageToken=====" + messageToken);
                                    logger.info("====messageToken=====" + messageToken);
                                    }
                                    
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                            try {

                                if (workerUserCode != null && workerUserCode.length() > 0) {
                                    HealthcareNotification notification = new HealthcareNotification();
                                    String shortMessage = "Upcoming accepted job notification.";
                                    notification.setUserCode(workerUserCode);
                                    notification.setMessage(notificationBody);
                                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                                    notification.setShortMessage(shortMessage);
                                    notification.setAppointmentCode(jaw.getAppointmentId());
                                    notification.setIsRead(Boolean.FALSE);
                                    notification.setIpAddress("via scheduler");
                                    notificationService.saveHealthcareNotification(notification);
                                    
                                }
                                
                                 if (workerUserCode != null && workerUserCode.length() > 0) {
                                    HealthcareNotification notification = new HealthcareNotification();
                                    String shortMessage = "Upcoming accepted job notification.";
                                    notification.setUserCode(workerUserCode);
                                    notification.setMessage(notificationBody);
                                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                                    notification.setShortMessage(shortMessage);
                                    notification.setAppointmentCode(jaw.getAppointmentId());
                                    notification.setIsRead(Boolean.FALSE);
                                    notification.setIpAddress("via scheduler");
                                    notificationService.saveHealthcareNotification(notification);
                                }
//           

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            
                            
                                List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(worker.getWorkerCode().trim());
                                if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                                {
                                  //for push notification 
                                    for(DeviceDetail deviceDetail : deviceDetailResList)
                                    {
                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Job is about to start", "The job is about to start shortly");
                                    }
                                  
                                }
                           
                            }
                        }
                    }
                    else
                    {
                         logger.info("In Scheduler start time is not matched. Appointment id="+jaw.getAppointmentId());
                    }
                }
                else{
                        
                    Date curDt = new Date();
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(curDt);
                    cal.add(Calendar.MINUTE, configMinut);
                    Date sdt = cal.getTime();
                    Date startDt = jd.getStartTime();                   
                    if (startDt != null && startDt.after(curDt) && (startDt.before(sdt) || startDt.equals(sdt))) {

                        long pdtInMinute = ((startDt.getTime()) / (60000));
                        long curInMinute = ((curDt.getTime()) / (60000));
                        long difInMinute = pdtInMinute - curInMinute;
                        long modAlert = difInMinute % alertMinute;
                        logger.info("In Scheduler start time is matched for isRecursive. Appointment id=" + jaw.getAppointmentId());
                        if (modAlert >= 0 && modAlert < 5) {
                             if (jaw != null && jaw.getId() > 0 && jaw.getWorkerCode()!= null && jaw.getWorkerCode().length() > 0) {
                              Worker worker = workerDao.getWorkerdetailByworkerCode(jaw.getWorkerCode());                      
                            if (worker != null && worker.getId() > 0 && worker.getEmail() != null && worker.getEmail().length() > 0) {
                                    
                            String toid = "";
                            boolean SMSSt=false;
                            boolean MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), worker.getWorkerCode(),GigflexConstants.MAIL_NOTIFICATIONS);
                            if(MailST)
                            {
                               toid = worker.getEmail(); 
                            }
                            
                                  Organization org = organizationRepository.findByOrganizationCode(organizationCode);
                                  SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(),organizationCode, GigflexConstants.SMS_NOTIFICATIONS);

                            String organizationName = "";
                            if (org != null) {
                                organizationName = org.getOrganizationName();
                            }
                            
                            Users adminUser = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);
                            
                            String ccMail = "";
                            String adminUserCode ="";
                            if (adminUser != null) {
                                ccMail = adminUser.getEmail();
                                adminUserCode = adminUser.getUserCode();
                            }
                            String workerUserCode =worker.getWorkerCode();  
                           
                                    String conStartDt="";
                            String conEndDt="";
                            String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                            String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.HealthcareProvider, job.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                            String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.HealthcareProvider, job.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                            if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            }                

                            String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.HealthcareProvider, job.getOrganizationCode(), GigflexConstants.TimeZone);

                           TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                           if (tzd != null && tzd.getId() > 0) {

                               String timezone = tzd.getTimeZoneName();
                               if(timezone!=null && timezone.length()>0 )
                               {
                                    Date startDate = jd.getStartTime();
                                    Date endDate = jd.getEndTime();
                                    startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                    endDate = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                    conStartDt=GigflexDateUtil.convertDateToString(startDate, dtFormat);
                                    conEndDt=GigflexDateUtil.convertDateToString(endDate, dtFormat);
                               }

                            }         
                                    String bodyContent = "Your upcoming accepted job details are given below-<br><br>"
                                    + "Worker Name : " + worker.getName() + "<br>"
                                    +"Patient Name : "+patientName+"<br>"+ "Start Time : "
                                    + conStartDt + "<br>" + "End Time : " + conEndDt;
                            
                             String messageBody = "\n"+"Your upcoming accepted job details are given below-"+"\n"
                                            + "Worker Name : " + worker.getName() + "\n"
                                            +"Patient Name : "+patientName+"\n"+ "Start Time : "
                                            + conStartDt + "\n" + "End Time : " + conEndDt;
                             String notificationBody = "Your upcoming accepted job details are given below-"
                                            + "Worker Name : " + worker.getName() + ","
                                            +" Patient Name : "+patientName+","+ " Start Time : "
                                            + conStartDt + "," + "End Time : " + conEndDt;
                             
                            SendNotification sn = new SendNotification();
                            SendMessageAPI sendmessageapi = new SendMessageAPI();
                              logger.info("====messageBody=====" + messageBody);
                                  
                              if (ccMail != null && ccMail.length() > 0) {
                               String res= sn.sendMail(ccMail, subject, bodyContent, mailServiceURL);
                                
                               logger.info("Cron scheduler mail respose in JobNotificationImpl >>>>>>", res);
                            } 
                            if (toid != null && toid.length() > 0) {
                                String res= sn.sendMail(toid, subject, bodyContent, mailServiceURL);
                                logger.info("Cron scheduler mail respose in JobNotificationImpl >>>>>>", res);
                                
                            }                                              

                            try {
//                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(),organizationCode, GigflexConstants.SMS_NOTIFICATIONS);
                                    if(SMSSt && worker.getWork_phone()!=null && worker.getWork_phone().trim().length()>0 && worker.getWorkcountryCode()!=null && worker.getWorkcountryCode().trim().length()>0){
                                   String conno="+"+worker.getWorkcountryCode().trim()+worker.getWork_phone().trim();
                                   String msg="Dear Worker,"+messageBody;
                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, conno, msg);
                                    System.out.println("====messageToken=====" + messageToken);
                                    logger.info("====messageToken=====" + messageToken);
                                    }
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            
                            
                            try {
                                
                                Worker adminWorker = workerDao.getWorkerdetailByworkerCode(adminUser.getUserCode());
                                
                                if (adminWorker != null && adminWorker.getId() > 0) {   
                                  
                                    String adminPhone ="+"+adminWorker.getWork_phone().trim()+adminWorker.getWork_phone().trim();
                                    if (SMSSt && adminPhone != null && adminPhone.length() > 0) {
                                    String msg="Dear Admin,"+messageBody;
                                    String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, adminPhone, msg);
                                    System.out.println("====messageToken=====" + messageToken);
                                    logger.info("====messageToken=====" + messageToken);
                                    }
                                    
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                                    
                                  try {

                                if (workerUserCode != null && workerUserCode.length() > 0) {
                                    HealthcareNotification notification = new HealthcareNotification();
                                    String shortMessage = "Upcoming accepted job notification.";
                                    notification.setUserCode(workerUserCode);
                                    notification.setMessage(notificationBody);
                                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                                    notification.setShortMessage(shortMessage);
                                    notification.setAppointmentCode(jaw.getAppointmentId());
                                    notification.setIsRead(Boolean.FALSE);
                                    notification.setIpAddress("via scheduler");
                                    notificationService.saveHealthcareNotification(notification);
                                    
                                }
                                
                                 if (workerUserCode != null && workerUserCode.length() > 0) {
                                    HealthcareNotification notification = new HealthcareNotification();
                                    String shortMessage = "Upcoming accepted job notification.";
                                    notification.setUserCode(workerUserCode);
                                    notification.setMessage(notificationBody);
                                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                                    notification.setShortMessage(shortMessage);
                                    notification.setAppointmentCode(jaw.getAppointmentId());
                                    notification.setIsRead(Boolean.FALSE);
                                    notification.setIpAddress("via scheduler");
                                    notificationService.saveHealthcareNotification(notification);
                                }
//           

                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            

                                List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(worker.getWorkerCode().trim());
                                if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                                {
                                  //for push notification 
                                    for(DeviceDetail deviceDetail : deviceDetailResList)
                                    {
                                        PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Job is about to start", "The job is about to start shortly");
                                    }                              
                                  
                                }
                                                                  
                                }
                            }
                        }
                    }

                }
            }

        }catch (Exception ex) {
			ex.printStackTrace();
		}
	 }
    }
        else
        {
            logger.info("In Scheduler all upcoming job size=0");
        }
    }

    @Override
    public void setExpired() {
        
        Date dt = new Date();
        List<String> stlst = new ArrayList<String>();
        //stlst.add(GigflexConstants.assignedBookingInProgressStatus);
        stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
        stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
        List<Object> objList = jobsDao.getAllJobsNearToExpire(dt, stlst);
        if (objList != null && objList.size() > 0) {
            
            UserType ut=userTypeDao.getUserTypeByUserTypeName(GigflexConstants.HealthcareProvider);
            int min = 15;
            String orgcode = "";
            for (int i = 0; i < objList.size(); i++) {
                try
                {
                    Object[] arr = (Object[]) objList.get(i);   
                    Jobs job = (Jobs) arr[0];
                    JobsDuration jd= (JobsDuration) arr[1];
                    JobsAssignToWorker jaw = (JobsAssignToWorker) arr[2];  
                    String organizationCode = job.getOrganizationCode();
                    if (job.getOrganizationCode() == null) {
                        min = 15;
                        orgcode = "";
                    } else {
                        if (orgcode.length() == 0 || !(orgcode.equalsIgnoreCase(job.getOrganizationCode()))) {
                            orgcode = job.getOrganizationCode();
                            if (ut != null && ut.getUserTypeCode() != null && ut.getUserTypeCode().length() > 0 && job.getOrganizationCode() != null && job.getOrganizationCode().length() > 0) {

                                String expiredminutesValue = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), job.getOrganizationCode(), GigflexConstants.EXPIRED_MINUTES);
                                if (expiredminutesValue != null && expiredminutesValue.length() > 0) {
                                    try {
                                        min = Integer.parseInt(expiredminutesValue);
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                        min = 15;
                                    }
                                } else {
                                    min = 15;
                                }
                            } else {
                                min = 15;
                            }
                    }
                }

            try{       
                min=min*-1;
                Calendar cal = Calendar.getInstance();
                cal.setTime(dt);
                cal.add(Calendar.MINUTE, min);
                Date curdt = cal.getTime();
                Date startDt=jd.getStartTime();
                if(jaw.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_INPROGRESS))
                {
                    curdt = dt;
                    curdt=new SimpleDateFormat("yyyy-MM-dd").parse( new SimpleDateFormat("yyyy-MM-dd").format(curdt));
                    startDt=new SimpleDateFormat("yyyy-MM-dd").parse( new SimpleDateFormat("yyyy-MM-dd").format(startDt));
                        
                }
                
                if (curdt.after(startDt)) {
                    String oldst = jaw.getStatus();
//                    jd.setEndTime(new Date());                    
//                    JobsDuration jdRes = jobsDurationRepository.save(jd); 
//
//                    if (jdRes != null && jdRes.getId() > 0 ) {
                           
                        try {
                            if (jaw != null && jaw.getId() > 0) {
                                jaw.setStatus(GigflexConstants.JOBSTATUS_EXPIRED);
                                JobsAssignToWorker jawRes = jobsAssignToWorkerRepository.save(jaw);
                                if (jawRes != null && jawRes.getId() > 0) {
                                    
                                    try{
                                 Worker workerUser = null;
                                 if(oldst!=null && !(oldst.equalsIgnoreCase(GigflexConstants.JOBSTATUS_REJECTED))   && !(oldst.equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED)))
                                {
                                    workerUser=workerDao.getWorkerdetailByworkerCode(jaw.getWorkerCode());   
                                }                                    
                                 
                                Users adminUser = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);
                                String adminUserCode = "";
                                Worker workerAdmin = null;
                               
                                if(adminUser != null && adminUser.getId() > 0)
                                {
                                    adminUserCode = adminUser.getUserCode();
                                    workerAdmin=workerDao.getWorkerdetailByworkerCode(adminUserCode);  
                                }
                                 
                                 
                                String workerUserCode = "";
                                if(workerUser != null)
                                {
                                    workerUserCode = workerUser.getWorkerCode();
                                }
                                
                                boolean SMSSt=true;
                                boolean MailST=true;                               
                                String adminEmail = "";
                                String adminMob="";
                                String workerEmail ="";
                                String workerMob = "";
                                
                                MailST=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), organizationCode,GigflexConstants.MAIL_NOTIFICATIONS);
                                SMSSt=GigflexUtility.findSettingValueByNameForNotification(globalSettingRepository, localSettingRepository, ut.getUserTypeCode(), organizationCode,GigflexConstants.SMS_NOTIFICATIONS);
                                if(workerAdmin != null )
                                {
                                    if (MailST && workerAdmin.getEmail() != null && workerAdmin.getEmail().length() > 0) {

                                        adminEmail = adminUser.getEmail();                                       
                                    }
                                    if (SMSSt && workerAdmin!=null && workerAdmin.getWork_phone()!=   null && workerAdmin.getWork_phone().length() > 0 && workerAdmin.getWorkcountryCode()!= null && workerAdmin.getWorkcountryCode().length() > 0) {

                                        adminMob ="+"+workerAdmin.getWorkcountryCode()+ workerAdmin.getWork_phone();
                                    }
                                }
                                
                                if(workerUser != null )
                                {
                                    if (MailST && workerUser.getEmail() != null && workerUser.getEmail().length() > 0) {

                                       workerEmail = workerUser.getEmail();
                                    }
                                    
                                    if (SMSSt && workerUser.getWork_phone()!=   null && workerUser.getWork_phone().length() > 0 && workerUser.getWorkcountryCode()!= null && workerUser.getWorkcountryCode().length() > 0) {

                                        workerMob ="+"+workerUser.getWorkcountryCode()+ workerUser.getWork_phone();
                                    }
                                }                                
                                                                        
                                    String conStartDt = "";
                                    String conEndDt = "";
                                    String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.HealthcareProvider, job.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.HealthcareProvider, job.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                                    {
                                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                                    }                

                                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, userTypeDao, GigflexConstants.HealthcareProvider, job.getOrganizationCode(), GigflexConstants.TimeZone);

                                   TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);	
                                   if (tzd != null && tzd.getId() > 0) {

                                       String timezone = tzd.getTimeZoneName();
                                       if(timezone!=null && timezone.length()>0 )
                                       {
                                            Date startDate = jd.getStartTime();
                                            Date endDate = jd.getEndTime();
                                            startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                            endDate = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                            conStartDt=GigflexDateUtil.convertDateToString(startDate, dtFormat);
                                            conEndDt=GigflexDateUtil.convertDateToString(endDate, dtFormat);
                                       }

                                    }     
                                    String patientName="";
                                    PatientDetails patientDetails=  patientDao.getPatientDetailBypatientCode(job.getPatientCode());
                                    if(patientDetails!=null && patientDetails.getId()>0)
                                    {
                                        patientName=patientDetails.getPatientName();
                                    }

                                    if (adminEmail != null && adminEmail.length() > 0) {
                                        String bodyContent = "Your job has been expired.Jobs details are given below-<br><br>";
                                        if(workerUser!=null && workerUser.getName()!=null && workerUser.getName().length()>0)
                                        {
                                             bodyContent+="Worker Name : "+workerUser.getName()+"<br>";
                                        }
                                        bodyContent+="Patient Name : "+patientName+"<br>"+ "Start Time : "
                                            + conStartDt + "<br>" + "End Time : " + conEndDt;
                                        SendNotification sn = new SendNotification();
                                        String res = sn.sendMail(adminEmail, subjectExpired, bodyContent, mailServiceURL);
                                        logger.info("Cron scheduler mail respose in JobsNotificationImpl >>>>>>", res);
                                    }
                                   
                                    if(adminMob!=null && adminMob.length()>0)
                                    {
                                        
                                        try {
                                             String messageBody = "Your job has been expired. Job details are given below-"+"\n";
                                             if(workerUser!=null && workerUser.getName()!=null && workerUser.getName().length()>0)
                                            {
                                             messageBody+="Worker Name : "+workerUser.getName()+"\n";
                                            }
                                            messageBody+="Patient Name : "+patientName+"\n"+ "Start Time : "
                                            + conStartDt + "\n" + "End Time : " + conEndDt;
                                            SendMessageAPI sendmessageapi = new SendMessageAPI();
                                          
                                            String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, adminMob, messageBody);
                                            System.out.println("====messageToken=====" + messageToken);
                                            logger.info("====messageToken=====" + messageToken);
                                            
                                            
                                        } catch (Exception e) {
                                            e.printStackTrace();
                                        }
                                    }

                                    try {
                                if (adminUserCode != null && adminUserCode.length() > 0) {
                                     String notificationBody = "Your job has been expired. Job details are given below-";
                                     if(workerUser!=null && workerUser.getName()!=null && workerUser.getName().length()>0)
                                            {
                                             notificationBody+=" Worker Name : "+workerUser.getName()+",";
                                            }
                                            notificationBody+=" Patient Name : "+patientName+","+ " Start Time : "
                                            + conStartDt + "," + " End Time : " + conEndDt;
                                   
                                                                     
                                        if (adminUserCode != null && adminUserCode.length() > 0) {
                                            HealthcareNotification notification = new HealthcareNotification();
                                            String shortMessage = "Job expiry notification.";
                                            notification.setUserCode(adminUserCode);
                                            notification.setMessage(notificationBody);
                                            notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                                            notification.setShortMessage(shortMessage);
                                            notification.setAppointmentCode(jaw.getAppointmentId());
                                            notification.setIpAddress("via scheduler");
                                            notification.setIsRead(Boolean.FALSE);
                                            notificationService.saveHealthcareNotification(notification);
                                            
                                            //for push notification 
//                                            PushNotification.pushFCMNotification(FMCurl,authKey,deviceId, shortMessage, notificationBody);
                                        }
  
                                }

                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                                 
                                    if(jawRes.getWorkerCode()!=null && jawRes.getWorkerCode().length()>0 )
                                    {
                                        if(oldst!=null && !(oldst.equalsIgnoreCase(GigflexConstants.JOBSTATUS_REJECTED)) && !(oldst.equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED)))
                                        {
                                            
                                            if(workerUser!=null && workerUser.getId()>0)
                                            {
                                                 if (MailST && workerEmail != null && workerEmail.length() > 0) {
                                                    String bodyContent = "Your job has been expired. Job details are given below-<br><br>";
                                                    if(!(oldst.equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED)))
                                                    {
                                                    bodyContent +="Patient Name : "+patientName+"<br>";
                                                    }
                                                    bodyContent +="Start Time : "+ conStartDt + "<br>" + "End Time : " + conEndDt;
                                                    SendNotification sn = new SendNotification();
                                                    String res = sn.sendMail(workerEmail, subjectExpired, bodyContent, mailServiceURL);
                                                    logger.info("Cron scheduler mail respose in JobsNotificationImpl >>>>>>", res);
                                                 }
//          
                                            
                                                if(SMSSt && workerMob!=null && workerMob.length()>0)
                                                {
                                                    try {
                                                         String messageBody = "Your job has been expired. Job details are given below-"+"\n";
                                                         if(!(oldst.equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED)))
                                                        {
                                                            messageBody +="Patient Name : "+patientName+"\n";
                                                        }
                                                        messageBody += "Start Time : "+ conStartDt + "\n" + "End Time : " + conEndDt;
                                                        SendMessageAPI sendmessageapi = new SendMessageAPI();

                                                        String messageToken = sendmessageapi.sendMessageForUsers(appKey, appSecret, url, workerMob, messageBody);
                                                        System.out.println("====messageToken=====" + messageToken);
                                                        logger.info("====messageToken=====" + messageToken);

                                                    } catch (Exception e) {
                                                        e.printStackTrace();
                                                    }
                                               }   

                                            try 
                                            {
                                                if (workerUser.getWorkerCode() != null && workerUser.getWorkerCode().length() > 0) {
                                                    String notificationBody = "Your job has been expired. Job details are given below-";
                                                    if(!(oldst.equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED)))
                                                    {      
                                                        notificationBody +=" Patient Name : "+patientName+",";
                                                    }
                                                    notificationBody += " Start Time : "+ conStartDt + "," + " End Time : " + conEndDt;
                                   
                                    
                                                    HealthcareNotification notification = new HealthcareNotification();
                                                    String shortMessage = "Job expiry notification.";
                                                    notification.setUserCode(workerUserCode);
                                                    notification.setMessage(notificationBody);
                                                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                                                    notification.setShortMessage(shortMessage);  
                                                     notification.setAppointmentCode(jaw.getAppointmentId());
                                                    notification.setIpAddress("via scheduler");
                                                    notification.setIsRead(Boolean.FALSE);
                                                    notificationService.saveHealthcareNotification(notification);
                                                                                                
                                                    //for push notification  
                                            
                                                    List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(workerUser.getWorkerCode().trim());
                                                   if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                                                    {
                                                      //for push notification 
                                                        for(DeviceDetail deviceDetail : deviceDetailResList)
                                                        {
                                                            PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Job Alert", "Job expiry notification.");
                                                        }                                                        
                                                    }
                                                 }

                                            } catch (Exception e) {
                                                e.printStackTrace();
                                            }

                                        }
                                    }
                                }
                                  } catch (Exception eee) {
                                      eee.printStackTrace();
                                  }  
                                    
                                }
                                else
                                {
                                   jaw.setStatus(oldst);
                                   jobsAssignToWorkerRepository.save(jaw); 
                                }
                            }

                        } catch (Exception ee) {
                            logger.error("Error in set Expire>>>", ee);
                            jaw.setStatus(oldst);
                            jobsAssignToWorkerRepository.save(jaw); 
                        }
                    //}

                }
                } catch (ParseException exx) {
                        logger.error("ParseException in set Expire from inprogrss>>>", exx);
                    }
                } catch (Exception e) {
                            logger.error("Error in loop set Expire>>>", e);
                            
                        }
            }
        } else {
            logger.info("In Scheduler near to expire job size=0");
        }
    }
    
}
