package com.gigflex.prototype.microservices.shift.dtob;

import java.util.Date;
import java.util.List;



public class MultiOrganizationWorkerShiftResponse {

	
	private String organizationName;

	private List<DaysCodeRes> daysCodeList;
        
	private String location;

	private Shift shift;

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public List<DaysCodeRes> getDaysCodeList() {
        return daysCodeList;
    }

    public void setDaysCodeList(List<DaysCodeRes> daysCodeList) {
        this.daysCodeList = daysCodeList;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Shift getShift() {
        return shift;
    }

    public void setShift(Shift shift) {
        this.shift = shift;
    }

	
	
	

}
