package com.gigflex.prototype.microservices.organizationskill.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.gigflex.prototype.microservices.organizationskill.dtob.OrganizationSkill;
import com.gigflex.prototype.microservices.skillmaster.dtob.SkillMaster;

@Repository
public interface OrganizationSkillDao extends JpaRepository<OrganizationSkill , Long> ,JpaSpecificationExecutor<OrganizationSkill>{
	
//	public OrganizationSkill getByPermissionsCode(String skillCode);

//	public OrganizationSkill deleteByOrgCodeAndSkillCode(String organizationCode, String SkillCode);

//	
	@Query("SELECT os FROM OrganizationSkill os WHERE os.isDeleted != TRUE AND os.organizationCode = :organizationCode AND os.skillCode = :skillCode")
	public OrganizationSkill getByOrgCodeAndSkillCode(@Param("organizationCode") String organizationCode, @Param("skillCode") String skillCode);
	
//	@Query("SELECT a FROM OrganizationSkill a WHERE a.isDeleted != TRUE AND a.organizationCode = :organizationCode AND a.skillCode = :skillCode")
//	public OrganizationSkill getSkillByOrgCodeSkillCode(@Param("organizationCode") String organizationCode,@Param("skillCode") String skillCode);
	
	@Query("SELECT a,b.skillName,c.organizationName FROM OrganizationSkill a , Organization c , SkillMaster b WHERE a.isDeleted != TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode")
	public List<Object> getAllOrganizationSkillWithNames();

	@Query("SELECT os FROM OrganizationSkill os WHERE os.isDeleted != TRUE")
	public List<OrganizationSkill> getAllOrganizationSkill();

	@Query("SELECT os FROM OrganizationSkill os WHERE os.isDeleted != TRUE AND os.id = :id")
	public OrganizationSkill getOrganizationSkillById(@Param("id") Long id);
	
	@Query("SELECT a,b.skillName,c.organizationName FROM OrganizationSkill a , Organization c , SkillMaster b WHERE a.isDeleted != TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode")
	public List<Object> getAllOrganizationSkillWithNames(Pageable pageableRequest);

	@Query("SELECT os FROM OrganizationSkill os WHERE os.isDeleted != TRUE")
	public List<OrganizationSkill> getAllOrganizationSkill(Pageable pageableRequest);
	
        @Query("SELECT a,b.skillName,c.organizationName FROM OrganizationSkill a , Organization c , SkillMaster b WHERE a.isDeleted != TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode AND a.organizationCode = :organizationCode")
	public List<Object> getOrganizationSkillsByOrganizationCode(@Param("organizationCode") String organizationCode);
	
        @Query("SELECT a,b.skillName,c.organizationName FROM OrganizationSkill a , Organization c , SkillMaster b WHERE a.isDeleted != TRUE AND a.skillCode=b.skillCode AND a.organizationCode=c.organizationCode AND a.organizationCode = :organizationCode")
	public List<Object> getOrganizationSkillsByOrganizationCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
	@Query("SELECT a FROM SkillMaster a, Organization org, OrganizationSkill os WHERE org.isDeleted != TRUE AND org.organizationCode = os.organizationCode AND os.skillCode = a.skillCode AND org.organizationCode = :organizationCode")
	public List<SkillMaster> getSkillsByOrganizationCode(@Param("organizationCode") String organizationCode);
	
	@Query("SELECT a FROM SkillMaster a, Organization org, OrganizationSkill os WHERE org.isDeleted != TRUE AND org.organizationCode = os.organizationCode AND os.skillCode = a.skillCode AND org.organizationCode = :organizationCode")
	public List<SkillMaster> getSkillsByOrganizationCode(@Param("organizationCode") String organizationCode,Pageable pageableRequest);
	
	@Query("SELECT a FROM OrganizationSkill a WHERE a.isDeleted != TRUE AND a.skillCode = :skillCode AND a.organizationCode =:organizationCode")
	public OrganizationSkill getSkillMasterCheckForSave(@Param("skillCode") String skillCode,@Param("organizationCode") String organizationCode);
	
	@Query("SELECT a FROM OrganizationSkill a WHERE a.isDeleted != TRUE AND a.id != :id AND a.skillCode = :skillCode AND a.organizationCode =:organizationCode")
	public OrganizationSkill getSkillMasterCheckForUpdate(@Param("id") Long id,@Param("skillCode") String skillCode,@Param("organizationCode") String organizationCode);

        @Query("SELECT a FROM OrganizationSkill a WHERE a.isDeleted != TRUE AND a.skillCode = :skillCode AND a.organizationCode =:organizationCode")
        public OrganizationSkill getSkillMasterBySkillCodeAndOrganizationCode(@Param("skillCode") String skillCode,@Param("organizationCode") String organizationCode);
        
       @Query("SELECT a FROM OrganizationSkill a WHERE a.isDeleted != TRUE AND a.skillCode = :skillCode AND a.organizationCode =:organizationCode")
	public OrganizationSkill getOrgskillCheckForSave(@Param("skillCode") String skillCode);
        
       @Query("SELECT sm FROM SkillMaster sm , OrganizationSkill orgskill WHERE  sm.isDeleted != TRUE AND  orgskill.isDeleted != TRUE AND  orgskill.organizationCode=:orgCode AND orgskill.skillCode=sm.skillCode AND orgskill.skillCode IN (:skillcode)")
       public List<SkillMaster> skillMasterByorgCodeAndskillCodeList(@Param("orgCode") String orgCode,@Param("skillcode") List<String> skillcode);
       
}
