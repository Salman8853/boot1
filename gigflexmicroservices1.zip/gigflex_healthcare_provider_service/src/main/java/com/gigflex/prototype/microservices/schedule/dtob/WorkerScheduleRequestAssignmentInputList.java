package com.gigflex.prototype.microservices.schedule.dtob;

import javax.persistence.Column;

/**
 * 
 * @author nirbhay.p
 *
 */

public class WorkerScheduleRequestAssignmentInputList {


       
    private String skillCode;
    
    
    private Integer requestedStaff;
    
    
    private Integer requiredHours;
    
    
    private String locationCode;
  
    private Long expDays;
    
    private Double costPerHours;
    
    
    private String certificationCode;

    public String getSkillCode() {
        return skillCode;
    }

    public void setSkillCode(String skillCode) {
        this.skillCode = skillCode;
    }

    public Integer getRequestedStaff() {
        return requestedStaff;
    }

    public void setRequestedStaff(Integer requestedStaff) {
        this.requestedStaff = requestedStaff;
    }

    public Integer getRequiredHours() {
        return requiredHours;
    }

    public void setRequiredHours(Integer requiredHours) {
        this.requiredHours = requiredHours;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public Long getExpDays() {
        return expDays;
    }

    public void setExpDays(Long expDays) {
        this.expDays = expDays;
    }

    
  
    
    public Double getCostPerHours() {
        return costPerHours;
    }

    public void setCostPerHours(Double costPerHours) {
        this.costPerHours = costPerHours;
    }

    public String getCertificationCode() {
        return certificationCode;
    }

    public void setCertificationCode(String certificationCode) {
        this.certificationCode = certificationCode;
    }
        	
   
}