package com.gigflex.prototype.microservices.skillmaster.dtob;

public class SkillMasterRequest {
	
	private String skillName;
	
	private String industryCode;

	public String getSkillname() {
		return skillName;
	}

	public void setSkillname(String skillname) {
		this.skillName = skillname;
	}

	public String getIndustryCode() {
		return industryCode;
	}

	public void setIndustryCode(String industryCode) {
		this.industryCode = industryCode;
	}
	
	
	

}
