/**
 * 
 */
package com.gigflex.prototype.microservices.schedule.service;

import com.gigflex.prototype.microservices.schedule.dtob.ChangeAssignScheduleToWorkerByScheduleRequestCodeRequest;
import java.util.List;

import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.worker.dtob.Worker;

/**
 * @author ajit.p
 *
 */
public interface ChangeAssignScheduleRequestToWorkerService {

	
	public String getTradeWorkerListByOrganizationCode(String organizationCode);

	public String getTradeWorkerListByWorkerCode(String workerCode);

        public String changeAssignScheduleRequestToWorker(ChangeAssignScheduleToWorkerByScheduleRequestCodeRequest casWorkerByScheduleRequestCodeRequest, String remoteAddr);

        public String updateAssignScheduleRequestToWorkerByID(Long id, ChangeAssignScheduleToWorkerByScheduleRequestCodeRequest caswRequest, String remoteAddr);

}
