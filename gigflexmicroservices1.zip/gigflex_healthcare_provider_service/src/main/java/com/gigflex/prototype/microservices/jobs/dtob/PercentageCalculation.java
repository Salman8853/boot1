/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.jobs.dtob;

import java.util.Date;

/**
 *
 * @author amit.kumar
 */
public class PercentageCalculation {
    
    private Date dateTimestamp;
    private Double fullfillmentRatio;
    private String date;
    private String dateFormat;

    public Date getDateTimestamp() {
        return dateTimestamp;
    }

    public void setDateTimestamp(Date dateTimestamp) {
        this.dateTimestamp = dateTimestamp;
    }   

    public Double getFullfillmentRatio() {
        return fullfillmentRatio;
    }

    public void setFullfillmentRatio(Double fullfillmentRatio) {
        this.fullfillmentRatio = fullfillmentRatio;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    
}
