package com.gigflex.prototype.microservices.industry.service;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.industry.dtob.IndustryMaster;
import com.gigflex.prototype.microservices.industry.repository.IndustryMasterDao;

@Service
public class IndustryMasterDeleteOfRegistrationKafkaService {
	
	@Autowired
	private IndustryMasterDao industryMasterDao;
	
    private static final Logger LOG = LoggerFactory.getLogger(IndustryMasterDeleteOfRegistrationKafkaService.class);


	@KafkaListener(topics = "DeleteIndustryMaster")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
			
			IndustryMaster industry = objectMapper.readValue(message, IndustryMaster.class);
			
			LOG.info("received message='{}'", industry.getIndustryName());
			LOG.info("received message='{}'", industry.getIndustryCode());
			
			IndustryMaster industryRes=industryMasterDao.getIndustryMasterByIndustryCode(industry.getIndustryCode());
			
                        if(industryRes!=null && industryRes.getId()>0)
                        {
                        	industryMasterDao.deleteById(industryRes.getId());
                        }
			
		} catch (JsonParseException e) {
			LOG.error("In IndustryMasterDeleteOfRegistrationKafkaService >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In IndustryMasterDeleteOfRegistrationKafkaService >>>>", e);
		} catch (IOException e) {
			LOG.error("In IndustryMasterDeleteOfRegistrationKafkaService >>>>", e);
		}catch (Exception e) {
			LOG.error("In IndustryMasterDeleteOfRegistrationKafkaService >>>>", e);
		}
    }

}
