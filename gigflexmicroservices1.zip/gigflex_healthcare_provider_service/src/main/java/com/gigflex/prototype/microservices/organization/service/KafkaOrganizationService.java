package com.gigflex.prototype.microservices.organization.service;
import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.dtob.OrganizationConsume;
import com.gigflex.prototype.microservices.workinglocation.dtob.WorkingLocation;
import com.gigflex.prototype.microservices.workinglocation.service.WorkingLocationService;




@Service
public class KafkaOrganizationService {
	
	@Autowired
	OrganizationService organizationService;
        
//        @Autowired
//	WorkingLocationService workingLocationService;
    private static final Logger LOG = LoggerFactory.getLogger(KafkaOrganizationService.class);
private Organization neworg;
//private WorkingLocation wlocation;
 
    @KafkaListener(topics = "NewOrganizationForHealthcare")
    public void listen(@Payload String message) {
		ObjectMapper objectMapper = new ObjectMapper();
		LOG.info("received message='{}'", message);
		try {
                     //wlocation=new WorkingLocation();
			OrganizationConsume org = objectMapper.readValue(message, OrganizationConsume.class);
//                        wlocation.setIsactive(org.getIsActive());
//                        wlocation.setLang(org.getLang());
//                        wlocation.setLat(org.getLat());
//                        wlocation.setOrganizationCode(org.getOrganizationCode());
//                        workingLocationService.saveWorkingLocations(wlocation, ip);
//                        workingLocationService.saveWorkingLocations(wlocation);
                        neworg=new Organization();
                        neworg.setOrganizationName(org.getOrganizationName());
                        neworg.setOrganizationCode(org.getOrganizationCode());
                        neworg.setIsActive(org.getIsActive());
                        neworg.setLang(org.getLang());
                        neworg.setLat(org.getLat());
                        neworg.setIndustryCode(org.getIndustryCode());
                        neworg.setIsVerified(org.getIsVerified());
                        neworg.setTimezone(org.getTimezone());
			organizationService.registerFromOrganization(neworg);
			
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
     
    
	
	
}