package com.gigflex.prototype.microservices.documenttypedetail.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetail;

public interface DocumentTypeDetailRepository extends JpaRepository<DocumentTypeDetail, Long>,JpaSpecificationExecutor<DocumentTypeDetail>{
	
	@Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE ")
	public List<DocumentTypeDetail> getAllDocumentTypeDetail();
        
        
    	@Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE ")
	public List<DocumentTypeDetail> getAllDocumentTypeDetail(Pageable pageableRequest);
        
       
	@Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.documentCode = :documentCode")
	public DocumentTypeDetail getDocumentTypeDetailByDocumentCode(@Param("documentCode") String documentCode);
	
	@Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.id = :id")
	public DocumentTypeDetail getDocumentTypeDetailById(@Param("id") Long id);
	
//	@Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.documentType = :documentType")
//	public DocumentTypeDetail getDocumentTypeDetailByDocumentType(@Param("documentType") String documentType);
	
        @Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.documentName = :documentName")
	public DocumentTypeDetail getDocumentTypeDetailByDocumentName(@Param("documentName") String documentName);
	
//	@Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.id != :id AND d.documentType = :documentType")
//	public DocumentTypeDetail getDocumentTypeDetailByIdDocumentType(@Param("id") Long id,@Param("documentType") String documentType);
        
        @Query("SELECT d FROM DocumentTypeDetail d WHERE d.isDeleted != TRUE AND d.id != :id AND d.documentName = :documentName ")
	public DocumentTypeDetail getDocumentTypeDetailByNotIdDocumentName(@Param("id") Long id,@Param("documentName") String documentName);

//        
//        @Query("SELECT d,u.userTypeName FROM DocumentTypeDetail d,UserType u WHERE d.isDeleted != TRUE AND d.userTypeCode = u.userTypeCode AND d.documentTypeCode=:documentTypeCode")
//    	public List<Object> getAllDocumentTypeDetailByDocumentTypeCode(@Param("documentTypeCode") String documentTypeCode);
//
//        @Query("SELECT d,u.userTypeName FROM DocumentTypeDetail d,UserType u WHERE d.isDeleted != TRUE AND d.userTypeCode = u.userTypeCode AND d.documentTypeCode=:documentTypeCode")
//    	public List<Object> getAllDocumentTypeDetailByDocumentTypeCode(@Param("documentTypeCode") String documentTypeCode,Pageable pageableRequest);

}
