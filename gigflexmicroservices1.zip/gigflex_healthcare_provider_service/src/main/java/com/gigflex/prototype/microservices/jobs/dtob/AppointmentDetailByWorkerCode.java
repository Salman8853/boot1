/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.jobs.dtob;

import com.gigflex.prototype.microservices.workerhoursofoperation.dtob.WorkerHoursOfOperation;
import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOff;
import java.util.List;

/**
 *
 * @author amit.kumar
 */
public class AppointmentDetailByWorkerCode {
    
   private String workerCode; 
    private String name;
    private String workerLogo;
    private String email;
    private WorkerHoursOfOperationRes workerHoursOfOperation;
     private List<WorkerTimeOff> workerTimeOffList;
    private List<AppointmentDetail> appointmentDetailList;

    public WorkerHoursOfOperationRes getWorkerHoursOfOperation() {
        return workerHoursOfOperation;
    }

    public void setWorkerHoursOfOperation(WorkerHoursOfOperationRes workerHoursOfOperation) {
        this.workerHoursOfOperation = workerHoursOfOperation;
    }

    public List<WorkerTimeOff> getWorkerTimeOffList() {
        return workerTimeOffList;
    }

    public void setWorkerTimeOffList(List<WorkerTimeOff> workerTimeOffList) {
        this.workerTimeOffList = workerTimeOffList;
    }
    
    
    
    public List<AppointmentDetail> getAppointmentDetailList() {
        return appointmentDetailList;
    }

    public void setAppointmentDetailList(List<AppointmentDetail> appointmentDetailList) {
        this.appointmentDetailList = appointmentDetailList;
    }

    public String getWorkerCode() {
        return workerCode;
    }

    public void setWorkerCode(String workerCode) {
        this.workerCode = workerCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getWorkerLogo() {
        return workerLogo;
    }

    public void setWorkerLogo(String workerLogo) {
        this.workerLogo = workerLogo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
    
}
