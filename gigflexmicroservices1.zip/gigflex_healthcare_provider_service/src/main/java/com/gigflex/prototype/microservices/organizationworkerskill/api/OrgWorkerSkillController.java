package com.gigflex.prototype.microservices.organizationworkerskill.api;

import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationSkillsModel;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkillRequest;
import com.gigflex.prototype.microservices.organizationworkerskill.service.OrgWorkerSkillService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.TokenUtility;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.RequestHeader;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/healthcareservice/")
public class OrgWorkerSkillController {
	
	@Autowired
	private OrgWorkerSkillService orgWorSkMapService;
        @Autowired
        TokenUtility tokenutility;
        
	@GetMapping("/OrgWorkerSkill/{search}")
	public String search(@PathVariable("search") String search) {
		return orgWorSkMapService.search(search);
	}
	
	@GetMapping("/getAllOrgWorkerSkill")
	public String getAllOrgWorkerSkill(){
		return orgWorSkMapService.findAllOrgWorkerSkill();
	}
	
	@GetMapping("/getAllOrganizationWorkerSkillWithNames")
	public String getAllOrganizationWorkerSkill(){
		return orgWorSkMapService.getAllOrgWorkerSkill();
	}
	
	@GetMapping(path="/getAllOrgWorkerSkillByPage")
    public String getAllOrgWorkerSkillByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String orgSkill = orgWorSkMapService.getOrgWorkerSkill(page, limit);
      
        return orgSkill;
       
    }
	
	@GetMapping(path="/getAllOrgWorkerSkillWithNamesByPage")
    public String getAllOrgWorkerSkillWithNamesByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String orgSkill = orgWorSkMapService.getOrgWorkerSkillWithNamesByPage(page, limit);
      
        return orgSkill;
       
    }
	
	@GetMapping("/getOrganizationWorkerSkill/{id}")
    public String getOrganizationWorkerSkillById(@PathVariable Long id){
  	    return orgWorSkMapService.findOrgWorkerSkillById(id);
    }
	
	@GetMapping("/getSkillsByOrgCode/{organizationCode}")
	public String getSkillsByOrgCode(@PathVariable String organizationCode) {
		return orgWorSkMapService.getSkillsByOrgCode(organizationCode);
	}
	
	@GetMapping(path="/getSkillsByOrgCodeByPage/{organizationCode}")
    public String getSkillsByOrgCodeByPage(@PathVariable String organizationCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String skills = orgWorSkMapService.getSkillsByOrgCodeByPage(organizationCode, page, limit);
      
        return skills;
       
    }

	@GetMapping("/getSkillsWorkerCodeByPage/{workerCode}")
	public String getSkillsWorkerCodeByPage(@PathVariable String workerCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit,@RequestHeader HttpHeaders headers) {
              String res="";
               res=tokenutility.userValidation(headers, workerCode);
               if(res.equalsIgnoreCase("true"))
               {
                 return orgWorSkMapService.getSkillsByWorkerCodeByPage(workerCode, page, limit);
               }else
               {
                 return res; 
               }
		
	}
	
	
	@GetMapping("/getSkillsWorkerCode/{workerCode}")
	public String getSkillsWorkerCode(@PathVariable String workerCode,@RequestHeader HttpHeaders headers) {
            String res="";
               res=tokenutility.userValidation(headers, workerCode);
               if(res.equalsIgnoreCase("true"))
               {
               return orgWorSkMapService.getSkillsByWorkerCode(workerCode);
               }else
               {
               return res;
               }

		
	}
	
	@GetMapping("/getSkillsByWorkerCodeAssigned/{workerCode}")
	public String getSkillsByWorkerCodeAssigned(@PathVariable String workerCode,@RequestHeader HttpHeaders headers) {
               String res="";
                 res=tokenutility.userValidation(headers, workerCode);
               if(res.equalsIgnoreCase("true"))
               {
                 return orgWorSkMapService.getSkillsByWorkerCodeAssigned(workerCode);
               }else
               {
                 return res;
               }
		
	}
	
	
	@PostMapping("/saveOrganizationWorkerSkill")
      public String saveNewOrganizationWorkerSkill(@RequestBody OrganizationWorkerSkillRequest orgWorkerSkillReq, HttpServletRequest request){
  	    String ip=request.getRemoteAddr();
  	   return orgWorSkMapService.saveOrgWorkerSkill(orgWorkerSkillReq, ip);
  	
    }
	
    @DeleteMapping("/deleteOrganizationWorkerSkill/{id}")
    public String deleteOrganizationWorkerSkillById(@PathVariable Long id){
    	return orgWorSkMapService.deleteOrgWorkerSkillById(id);
    }
    
    @DeleteMapping("/softDeleteOrganizationWorkerSkill/{id}")
    public String softDeleteOrganizationWorkerSkill(@PathVariable Long id){
    	return orgWorSkMapService.softDeleteOrgWorkerSkillById(id);
    }
    
    @DeleteMapping("/softMultipleDeleteOrganizationWorkerSkillById/{idList}")
	public String softMultipleDeleteOrganizationWorkerSkillById(@PathVariable("idList") List<Long> idList) {
		if(idList != null && idList.size()>0){
			return orgWorSkMapService.softMultipleDeleteById(idList);
		}else{
			 GigflexResponse derr = new GigflexResponse(400, new Date(), "Input data is not valid");
	           return derr.toString();
		}
	}

    
    @PutMapping("/updateOrganizationWorkerSkill/{id}")
 		public String updateOrganizationWorkerSkillById(@PathVariable Long id, @RequestBody OrganizationWorkerSkillRequest orgWorkerSkillReq,
 				HttpServletRequest request) {
    	
    	if (id == null) {
 				return "OrganizationWorkerSkill with Id : (" + id + ") Not found.";
 			} else {
                 String ip = request.getRemoteAddr();
 				 return orgWorSkMapService.updateOrgWorkerSkillById(id, orgWorkerSkillReq, ip);
 				
 			}
 			
 		}
                
                
        @GetMapping("/getSkillsWorkerByOrganizationCode/{organizationCode}")
	public String getSkillsWorkerByOrganizationCode(@PathVariable String organizationCode) {
		return orgWorSkMapService.getSkillsWorkerByOrganizationCode(organizationCode);
	}

        
        @GetMapping("/getSkillsWorkerByOrgSkillID/{organizationSkillId}")
	public String getSkillsWorkerByOrgSkillID(@PathVariable Long organizationSkillId) {
		return orgWorSkMapService.getSkillsWorkerByID(organizationSkillId);
	}
        
        
        @PostMapping("/saveAndUpdateOrganizationWorkerSkill")
        public String saveAndUpdateOrganizationWorkerSkill(@RequestBody OrganizationSkillsModel orgSkillsModelReq, HttpServletRequest request){
  	    String ip=request.getRemoteAddr();
  	   return orgWorSkMapService.saveAndUpdateOrganizationWorkerSkill(orgSkillsModelReq, ip);
  	
       }
        
        
}
