package com.gigflex.prototype.microservices.jobs.dtob;

import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.patient.dtob.PatientResponse;
import java.util.Date;

/**
 * 
 * @author nirbhay.p
 *
 */

public class JobsRes {


    private Long id;  
    
   
    private String jobsCode;
    
   
    private String patientCode; 
    
    private String procedureCode;
    
    private String jobName;
    
    private String organizationCode;
    
    private Date startDTStamp ;
    
    private Date endDTStamp ;

    private String startDT ;
    
    private String endDT ;
    
    private String notes;
    
    private String dateFormat;
    
    private String timeFormat;
    
    private PatientDetails patientDetail;
    
    private String startTime ;
   
    private Integer repeatValue;
   
    private String repeatType;
  
    private Boolean isDateOfMonth;
    
    private String daysList;
    
    private String durationHours;
  
    private String  durationMinute;

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public Integer getRepeatValue() {
        return repeatValue;
    }

    public void setRepeatValue(Integer repeatValue) {
        this.repeatValue = repeatValue;
    }

    public String getRepeatType() {
        return repeatType;
    }

    public void setRepeatType(String repeatType) {
        this.repeatType = repeatType;
    }

    public Boolean getIsDateOfMonth() {
        return isDateOfMonth;
    }

    public void setIsDateOfMonth(Boolean isDateOfMonth) {
        this.isDateOfMonth = isDateOfMonth;
    }

    public String getDaysList() {
        return daysList;
    }

    public void setDaysList(String daysList) {
        this.daysList = daysList;
    }

    public String getDurationHours() {
        return durationHours;
    }

    public void setDurationHours(String durationHours) {
        this.durationHours = durationHours;
    }

    public String getDurationMinute() {
        return durationMinute;
    }

    public void setDurationMinute(String durationMinute) {
        this.durationMinute = durationMinute;
    }


    public PatientDetails getPatientDetail() {
        return patientDetail;
    }

    public void setPatientDetail(PatientDetails patientDetail) {
        this.patientDetail = patientDetail;
    }      

    public String getDateFormat() {
        return dateFormat;
    }

    public void setDateFormat(String dateFormat) {
        this.dateFormat = dateFormat;
    }

    public String getTimeFormat() {
        return timeFormat;
    }

    public void setTimeFormat(String timeFormat) {
        this.timeFormat = timeFormat;
    }

    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getJobsCode() {
        return jobsCode;
    }

    public void setJobsCode(String jobsCode) {
        this.jobsCode = jobsCode;
    }

    public String getPatientCode() {
        return patientCode;
    }

    public void setPatientCode(String patientCode) {
        this.patientCode = patientCode;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public Date getStartDTStamp() {
        return startDTStamp;
    }

    public void setStartDTStamp(Date startDTStamp) {
        this.startDTStamp = startDTStamp;
    }

    public Date getEndDTStamp() {
        return endDTStamp;
    }

    public void setEndDTStamp(Date endDTStamp) {
        this.endDTStamp = endDTStamp;
    }

    public String getStartDT() {
        return startDT;
    }

    public void setStartDT(String startDT) {
        this.startDT = startDT;
    }

    public String getEndDT() {
        return endDT;
    }

    public void setEndDT(String endDT) {
        this.endDT = endDT;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
   
    
}