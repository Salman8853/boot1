package com.gigflex.prototype.microservices.daysmaster.service;

import java.util.List;

import com.gigflex.prototype.microservices.daysmaster.dtob.DaysMasterRequest;

public interface DaysMasterService {
	
	public String getAllDaysMasterByPage(int page, int limit);

	public String findAllDaysMaster();

	public String findDaysMasterById(Integer id);

	public String findByDaysCode(String daysCode);

	public String saveDaysMaster(DaysMasterRequest daysMasterReq,String ip);

	public String deleteDaysMasterById(Integer id);

	public String deleteDaysMasterByDaysCode(String daysCode);

	public String updateDaysMasterById(Integer id,
			DaysMasterRequest daysMasterReq,String ip);
	
	public String softDeleteDaysMasterByDaysCode(String daysCode);
	
	public String softMultipleDeleteByDaysCode(List<String> daysCodeList);
	public String search(String search);

}
