/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.api;

import com.gigflex.prototype.microservices.setting.dtob.GlobalSettingReq;
import com.gigflex.prototype.microservices.setting.service.GlobalSettingService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nirbhay.p
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class GlobalSettingController {
    @Autowired
	private GlobalSettingService globalSettingService;
	
	@GetMapping(path="/getAllGlobalSettingByPage")
    public String getAllGlobalSettingByPage(@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {

        String grt = globalSettingService.getAllGlobalSettingByPage(page, limit);
      
        return grt;
       
    }
	
	@GetMapping(path="/getGlobalSettingByUserTypeByPage/{userTypeCode}")
    public String getGlobalSettingByUserTypeByPage(@PathVariable String userTypeCode,@RequestParam(value = "page", defaultValue = "0") int page,
            @RequestParam(value = "limit", defaultValue = "30") int limit) {
if(userTypeCode!=null && userTypeCode.trim().length()>0)
{
        return globalSettingService.getGlobalSettingByUserTypeByPage(userTypeCode.trim(),page, limit);
}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"UserTypeCode should not be blank.");
			return derr.toString();
		}
        
       
    }
    
    @GetMapping(path="/getGlobalSettingByUserTypeSettingType/{userTypeCode}/{settingType}")
    public String getGlobalSettingByUserTypeSettingType(@PathVariable String userTypeCode,@PathVariable String settingType) {
if(userTypeCode!=null && userTypeCode.trim().length()>0 && settingType!=null && settingType.trim().length()>0)
{
        return globalSettingService.getGlobalSettingByUserTypeSettingType(userTypeCode.trim(),settingType.trim());
}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"UserTypeCode and settingType should not be blank.");
			return derr.toString();
		}
        
       
    }
    
    @GetMapping(path="/getGlobalSettingByUserTypeSettingName/{userTypeCode}/{settingName}")
    public String getGlobalSettingByUserTypeSettingName(@PathVariable String userTypeCode,@PathVariable String settingName) {
if(userTypeCode!=null && userTypeCode.trim().length()>0 && settingName!=null && settingName.trim().length()>0)
{
        return globalSettingService.getGlobalSettingByUserTypeSettingName(userTypeCode.trim(),settingName.trim());
}else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"UserTypeCode and settingName should not be blank.");
			return derr.toString();
		}
        
       
    }
	
	@PostMapping("/saveGlobalSetting")
	public String saveGlobalSetting(@RequestBody GlobalSettingReq globalSettingReq,
			HttpServletRequest request) {
            if(globalSettingReq!=null && globalSettingReq.getSettingName()!=null && globalSettingReq.getSettingName().trim().length()>0
                 &&   globalSettingReq.getSettingValue()!=null && globalSettingReq.getSettingValue().trim().length()>0 &&
                    globalSettingReq.getUserTypeCode()!=null && globalSettingReq.getUserTypeCode().trim().length()>0 )
            {
                globalSettingReq.setSettingName(globalSettingReq.getSettingName().trim());
                globalSettingReq.setSettingValue(globalSettingReq.getSettingValue().trim());
                globalSettingReq.setUserTypeCode(globalSettingReq.getUserTypeCode().trim());
		String ip = request.getRemoteAddr();
		return globalSettingService.saveGlobalSetting(globalSettingReq, ip);
            }
            else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

	
    @GetMapping("/getGlobalSettingByGlobalSettingCode/{globalSettingCode}")
	public String getGlobalSettingByGlobalSettingCode(@PathVariable String globalSettingCode) {
	if(globalSettingCode!=null && globalSettingCode.trim().length()>0)
            {	
            return globalSettingService.getGlobalSettingByGlobalSettingCode(globalSettingCode.trim());
            }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Global Setting Code should not be blank.");
			return derr.toString();
		}
	}
        
        
        @PutMapping("/updateGlobalSettingById/{id}")
	public String updateGlobalSettingById(@PathVariable Long id,
			@RequestBody GlobalSettingReq globalSettingReq, HttpServletRequest request) {

            if(globalSettingReq!=null && id!=null && id >0 && globalSettingReq.getSettingName()!=null && globalSettingReq.getSettingName().trim().length()>0
                 &&   globalSettingReq.getSettingValue()!=null && globalSettingReq.getSettingValue().trim().length()>0 &&
                    globalSettingReq.getUserTypeCode()!=null && globalSettingReq.getUserTypeCode().trim().length()>0 )
            {
                globalSettingReq.setSettingName(globalSettingReq.getSettingName().trim());
                globalSettingReq.setSettingValue(globalSettingReq.getSettingValue().trim());
                globalSettingReq.setUserTypeCode(globalSettingReq.getUserTypeCode().trim());
		String ip = request.getRemoteAddr();
		return globalSettingService.updateGlobalSettingById(globalSettingReq, id,ip);
            }
            else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	

	}

	@DeleteMapping("/softDeleteGlobalSettingByGlobalSettingCode/{globalSettingCode}")
	public String softDeleteGlobalSettingByGlobalSettingCode(@PathVariable String globalSettingCode) {
	if(globalSettingCode!=null && globalSettingCode.trim().length()>0)
            {	
            return globalSettingService.softDeleteGlobalSettingByGlobalSettingCode(globalSettingCode.trim());
            }else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),"Global Setting Code should not be blank.");
			return derr.toString();
		}
	}

	@DeleteMapping("/softMultipleDeleteGlobalSettingByGlobalSettingCode/{globalSettingCodeList}")
	public String softMultipleDeleteGlobalSettingByGlobalSettingCode(
			@PathVariable List<String> globalSettingCodeList) {
		if (globalSettingCodeList != null && globalSettingCodeList.size() > 0) {
			return globalSettingService.softMultipleDeleteGlobalSettingByGlobalSettingCode(globalSettingCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}
}
