/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.proceduremaster.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "procedure_master")
public class ProcedureMaster extends CommonAttributes implements Serializable {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
    @GenericGenerator(name = "uuid", strategy = "uuid2")
    @Column(name = "procedure_code", unique = true)
    private String procedureCode;

    @Column(name = "procedure_name", nullable = false)
    private String procedureName;

    @Column(name = "procedure_description", nullable = false)
    private String procedureDescription;
    
    @Column(name = "procedure_id", nullable = false)
    private String procedureId;
    
    @Column(name = "procedure_icon", nullable = true)
    private String procedureIcon;
    
    @PrePersist
    private void assignUUID() {
        if (this.getProcedureCode() == null || this.getProcedureCode().length() == 0) {
           this.setProcedureCode(UUID.randomUUID().toString());
        }
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProcedureCode() {
        return procedureCode;
    }

    public void setProcedureCode(String procedureCode) {
        this.procedureCode = procedureCode;
    }

    public String getProcedureName() {
        return procedureName;
    }

    public void setProcedureName(String procedureName) {
        this.procedureName = procedureName;
    }

    public String getProcedureDescription() {
        return procedureDescription;
    }

    public void setProcedureDescription(String procedureDescription) {
        this.procedureDescription = procedureDescription;
    }

    public String getProcedureId() {
        return procedureId;
    }

    public void setProcedureId(String procedureId) {
        this.procedureId = procedureId;
    }

    public String getProcedureIcon() {
        return procedureIcon;
    }

    public void setProcedureIcon(String procedureIcon) {
        this.procedureIcon = procedureIcon;
    }


    
	    
}
