package com.gigflex.prototype.microservices.industry.dtob;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class IndustryMasterRequest {
	
	private String industryName;

	public String getIndustryName() {
		return industryName;
	}

	public void setIndustryName(String industryName) {
		this.industryName = industryName;
	}
	
	

}
