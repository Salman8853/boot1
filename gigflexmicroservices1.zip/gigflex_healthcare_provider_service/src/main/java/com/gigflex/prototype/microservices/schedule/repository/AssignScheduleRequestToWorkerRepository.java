/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.schedule.repository;

import com.gigflex.prototype.microservices.organizationworkerskill.dtob.OrganizationWorkerSkill;
import org.springframework.data.jpa.repository.JpaRepository;
import com.gigflex.prototype.microservices.schedule.dtob.AssignScheduleToWorker;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequest;
import com.gigflex.prototype.microservices.schedule.dtob.WorkerScheduleRequestAssignment;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.workercertifications.dtob.WorkerCertifications;
import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOff;
import java.util.Date;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author abhishek
 */
public interface AssignScheduleRequestToWorkerRepository extends JpaRepository<AssignScheduleToWorker,Long>{
    
    @Query("SELECT wsr.startDT,wsr.endDT,org.organizationName FROM WorkerScheduleRequest wsr INNER JOIN Organization org WHERE wsr.scheduleRequestCode = :scheduleRequestCode AND org.organizationCode = wsr.organizationCode")

    public List<Object> getScheduleDetailToAssignWorker(@Param("scheduleRequestCode") String scheduleRequestCode);
    
//    @Query("SELECT wsr.organizationCode FROM WorkerScheduleRequest wsr WHERE wsr.scheduleRequestCode = :scheduleRequestCode")
//    public String getWorkerOrganizationCode(@Param("scheduleRequestCode") String scheduleRequestCode);
//    
//    @Query("SELECT org.organizationName FROM Organization org WHERE org.organizationCode = :organizationCode")
//    public String getOrganizationName(@Param("organizationCode") String organizationCode);
    @Query("SELECT wkr FROM Worker wkr WHERE wkr.workerCode = :workerCode")
    public Worker getWorkerEmail(@Param("workerCode") String workerCode);
    
    @Query("SELECT asw FROM AssignScheduleToWorker asw WHERE asw.isDeleted != TRUE AND asw.assignScheduletoWorkerCode = :assignScheduletoWorkerCode")
    public AssignScheduleToWorker getAssignedScheduledToWorker(@Param("assignScheduletoWorkerCode") String assignScheduletoWorkerCode);

    @Query("SELECT asw FROM AssignScheduleToWorker asw WHERE asw.isDeleted != TRUE AND asw.scheduleRequestCode = :scheduleRequestCode AND asw.scheduleRequestAssignmentCode = :scheduleRequestAssignmentCode AND asw.workerCode = :workerCode")
    public AssignScheduleToWorker getAssignedScheduledToWorkerByWorkerScheduleRequestAssignment(@Param("scheduleRequestCode") String scheduleRequestCode,@Param("scheduleRequestAssignmentCode") String scheduleRequestAssignmentCode,@Param("workerCode") String workerCode);

    
    @Query("SELECT wkr FROM Worker wkr, OrganizationWorkerSkill ows, AssignScheduleToWorker asw, WorkerScheduleRequest wsr WHERE wsr.scheduleRequestCode=asw.scheduleRequestCode AND wsr.organizationCode=ows.organizationCode AND ows.workerCode=wkr.workerCode AND wkr.isDeleted != TRUE AND asw.assignScheduletoWorkerCode = :assignScheduletoWorkerCode")
    public List<Worker> getSmaeSkillWorkerList(@Param("assignScheduletoWorkerCode") String assignScheduletoWorkerCode);

    @Query("SELECT wkr FROM Worker wkr, OrganizationWorkerSkill ows, AssignScheduleToWorker asw, WorkerScheduleRequest wsr WHERE  wsr.scheduleRequestCode=asw.scheduleRequestCode AND wsr.organizationCode=ows.organizationCode AND ows.workerCode=wkr.workerCode AND wkr.isDeleted != TRUE AND wkr.workerCode NOT IN(:busyworkerList) AND asw.assignScheduletoWorkerCode = :assignScheduletoWorkerCode AND ows.experienceInDays>=:experienceInDays")
    public List<Worker> getSameSkillAvailableWorkerList(@Param("experienceInDays")Long experienceInDays ,@Param("assignScheduletoWorkerCode")String assignScheduletoWorkerCode , @Param("busyworkerList")List<String> busyworkerList);
 
    @Query("SELECT wkr FROM Worker wkr, OrganizationWorkerSkill ows, AssignScheduleToWorker asw, WorkerScheduleRequest wsr WHERE  wsr.scheduleRequestCode=asw.scheduleRequestCode AND wsr.organizationCode=ows.organizationCode AND ows.workerCode=wkr.workerCode AND wkr.isDeleted != TRUE  AND asw.assignScheduletoWorkerCode = :assignScheduletoWorkerCode AND ows.experienceInDays>=:experienceInDays")
    public List<Worker> getSameSkillAvailableWorkerListWithoutin(@Param("experienceInDays")Long experienceInDays ,@Param("assignScheduletoWorkerCode")String assignScheduletoWorkerCode );
 
    
    @Query("SELECT wkr FROM Worker wkr, WorkerCertifications wcr, WorkerApprovalStatus was  WHERE   was.organization_Code=:organizationCode AND was.workerCode=wkr.workerCode AND wcr.certificationCode=:certificationCode   AND wcr.workerCode=wkr.workerCode AND wkr.isDeleted != TRUE AND wcr.isDeleted != TRUE AND wcr.workerCode NOT IN(:busyworkerList)")
    public List<Worker> getSameCertificateAvailableWorkerListWithNotIN(@Param("certificationCode") String certificationCode ,@Param("organizationCode") String organizationCode , @Param("busyworkerList")List<String> busyworkerList);

    @Query("SELECT wkr FROM Worker wkr, WorkerCertifications wcr, WorkerApprovalStatus was  WHERE   was.organization_Code=:organizationCode AND was.workerCode=wkr.workerCode AND wcr.certificationCode=:certificationCode   AND wcr.workerCode=wkr.workerCode AND wkr.isDeleted != TRUE AND wcr.isDeleted != TRUE AND wcr.workerCode IN(:availworkerList)")
    public List<Worker> getSameCertificateAvailableWorkerListWithIN(@Param("certificationCode") String certificationCode ,@Param("organizationCode") String organizationCode , @Param("availworkerList")List<String> availworkerList);

    
    @Query("SELECT wkr FROM Worker wkr, WorkerApprovalStatus was  WHERE   was.organization_Code=:organizationCode AND was.workerCode=wkr.workerCode AND (wkr.expYear>:expYear OR (wkr.expYear=:expYear AND wkr.expMonth>:expMonth)  OR ((wkr.expYear=:expYear AND wkr.expMonth=:expMonth AND wkr.expDays>=:expDays)))  AND was.workerCode=wkr.workerCode AND wkr.isDeleted != TRUE AND wkr.workerCode NOT IN(:busyworkerList)")
    public List<Worker> getSameExperienceAvailableWorkerListWithNotIN(@Param("expYear") Integer expYear ,@Param("expMonth") Integer expMonth ,@Param("expDays") Integer expDays,@Param("organizationCode") String organizationCode , @Param("busyworkerList")List<String> busyworkerList);

    @Query("SELECT wkr FROM Worker wkr, WorkerApprovalStatus was  WHERE   was.organization_Code=:organizationCode AND was.workerCode=wkr.workerCode AND (wkr.expYear>:expYear OR (wkr.expYear=:expYear AND wkr.expMonth>:expMonth)  OR ((wkr.expYear=:expYear AND wkr.expMonth=:expMonth AND wkr.expDays>=:expDays)))  AND was.workerCode=wkr.workerCode AND wkr.isDeleted != TRUE AND wkr.workerCode IN(:availworkerList)")
    public List<Worker> getSameExperienceAvailableWorkerListWithIN(@Param("expYear") Integer expYear ,@Param("expMonth") Integer expMonth ,@Param("expDays") Integer expDays,@Param("organizationCode") String organizationCode , @Param("availworkerList")List<String> availworkerList);

    
    @Query("SELECT was FROM AssignScheduleToWorker asw, WorkerScheduleRequestAssignment was WHERE was.scheduleRequestAssignmentCode=asw.scheduleRequestAssignmentCode AND asw.isDeleted != TRUE and asw.assignScheduletoWorkerCode = :assignScheduletoWorkerCode")
    public WorkerScheduleRequestAssignment getWorkerScheduleRequestAssignmentByAssignScheduletoWorkerCode(@Param("assignScheduletoWorkerCode") String assignScheduletoWorkerCode);

    
    @Query("SELECT wsr FROM AssignScheduleToWorker asw, WorkerScheduleRequest wsr WHERE wsr.scheduleRequestCode=asw.scheduleRequestCode AND asw.isDeleted != TRUE AND asw.assignScheduletoWorkerCode = :assignScheduletoWorkerCode")
    public WorkerScheduleRequest getWorkerScheduleRequestByAssignScheduletoWorkerCode(@Param("assignScheduletoWorkerCode") String assignScheduletoWorkerCode);
    
    @Query("SELECT wkr.workerCode FROM Worker wkr,  AssignScheduleToWorker asw, WorkerScheduleRequest wsr WHERE wsr.scheduleRequestCode=asw.scheduleRequestCode  AND wkr.workerCode=asw.workerCode AND wkr.isDeleted != TRUE AND ( ( wsr.startDT<=:startDT AND  wsr.endDT>=:endDT  ) OR ( wsr.startDT>=:startDT AND  wsr.endDT<=:endDT ) OR ( wsr.startDT<=:startDT AND  wsr.endDT<=:endDT AND wsr.endDT>:startDT) OR ( wsr.startDT>=:startDT AND  wsr.endDT>=:endDT AND wsr.startDT<:endDT ) )")
    public List<Object> getBusyWorkerListInStartEnd(@Param("startDT") Date startDT,@Param("endDT") Date endDT);
    
    @Query("SELECT wkr.workerCode FROM Worker wkr,  AssignScheduleToWorker asw, WorkerScheduleRequest wsr WHERE asw.scheduleRequestAssignmentCode!=:scheduleRequestAssignmentCode AND wsr.scheduleRequestCode=asw.scheduleRequestCode  AND wkr.workerCode=asw.workerCode AND wkr.isDeleted != TRUE AND ( ( wsr.startDT<=:startDT AND  wsr.endDT>=:endDT  ) OR ( wsr.startDT>=:startDT AND  wsr.endDT<=:endDT ) OR ( wsr.startDT<=:startDT AND  wsr.endDT<=:endDT AND wsr.endDT>:startDT) OR ( wsr.startDT>=:startDT AND  wsr.endDT>=:endDT AND wsr.startDT<:endDT ) )")
    public List<Object> getBusyWorkerLisInOtherScheduletInStartEnd(@Param("startDT") Date startDT,@Param("endDT") Date endDT,@Param("scheduleRequestAssignmentCode") String scheduleRequestAssignmentCode);
     
    @Query("SELECT asw FROM AssignScheduleToWorker asw  WHERE scheduleRequestCode = :scheduleRequestCode AND asw.isDeleted != TRUE")
    public AssignScheduleToWorker getWorkerScheduleRequestCode(@Param("scheduleRequestCode") String scheduleRequestCode);

    @Query("SELECT asw FROM WorkerScheduleRequestAssignment asw  WHERE scheduleRequestAssignmentCode = :scheduleRequestAssignmentCode AND asw.isDeleted != TRUE")
    public WorkerScheduleRequestAssignment getWorkerScheduleRequestAssignmentCode(@Param("scheduleRequestAssignmentCode") String scheduleRequestAssignmentCode);
    
    @Query("SELECT asw, wsr, was FROM AssignScheduleToWorker asw, WorkerScheduleRequest wsr, WorkerScheduleRequestAssignment was  WHERE wsr.scheduleRequestCode = asw.scheduleRequestCode AND was.scheduleRequestAssignmentCode = asw.scheduleRequestAssignmentCode AND asw.workerCode=:workerCode AND asw.isDeleted != TRUE ORDER BY asw.id DESC")
    public List<Object> getAssigntoWorkerScheduleRequestByWorkerCode(@Param("workerCode") String workerCode);
    
    @Query("SELECT asw, wsr, was FROM AssignScheduleToWorker asw, WorkerScheduleRequest wsr, WorkerScheduleRequestAssignment was  WHERE wsr.scheduleRequestCode = asw.scheduleRequestCode AND was.scheduleRequestAssignmentCode = asw.scheduleRequestAssignmentCode AND asw.workerCode=:workerCode AND asw.isDeleted != TRUE ORDER BY asw.id DESC")
    public List<Object> getAssigntoWorkerScheduleRequestByWorkerCode(@Param("workerCode") String workerCode,Pageable pageableRequest);

    @Query("SELECT asw, wsr, was FROM AssignScheduleToWorker asw, WorkerScheduleRequest wsr, WorkerScheduleRequestAssignment was  WHERE wsr.scheduleRequestCode = asw.scheduleRequestCode AND was.scheduleRequestAssignmentCode = asw.scheduleRequestAssignmentCode AND asw.workerCode=:workerCode AND asw.isDeleted != TRUE AND wsr.isDeleted != TRUE AND   asw.status IN (:statusList)    AND   ( ( wsr.startDT<=:startDT AND  wsr.endDT>=:endDT  ) OR ( wsr.startDT>=:startDT AND  wsr.endDT<=:endDT ) OR ( wsr.startDT<=:startDT AND  wsr.endDT<=:endDT AND wsr.endDT>:startDT) OR ( wsr.startDT>=:startDT AND  wsr.endDT>=:endDT AND wsr.startDT<:endDT ) ) ORDER BY asw.id DESC")
    public List<Object> getAllSceduleByWorkerCodeWithFilterByPage(@Param("workerCode") String workerCode,@Param("statusList") List<String> statusList,@Param("startDT") Date startDT,@Param("endDT") Date endDT);

    @Query("SELECT asw, wsr, was FROM AssignScheduleToWorker asw, WorkerScheduleRequest wsr, WorkerScheduleRequestAssignment was  WHERE wsr.scheduleRequestCode = asw.scheduleRequestCode AND was.scheduleRequestAssignmentCode = asw.scheduleRequestAssignmentCode AND asw.workerCode=:workerCode AND asw.isDeleted != TRUE AND wsr.isDeleted != TRUE AND   asw.status IN (:statusList)    AND   ( ( wsr.startDT<=:startDT AND  wsr.endDT>=:endDT  ) OR ( wsr.startDT>=:startDT AND  wsr.endDT<=:endDT ) OR ( wsr.startDT<=:startDT AND  wsr.endDT<=:endDT AND wsr.endDT>:startDT) OR ( wsr.startDT>=:startDT AND  wsr.endDT>=:endDT AND wsr.startDT<:endDT ) ) ORDER BY asw.id DESC")
    public List<Object> getAllSceduleByWorkerCodeWithFilterByPage(@Param("workerCode") String workerCode,@Param("statusList") List<String> statusList,@Param("startDT") Date startDT,@Param("endDT") Date endDT,Pageable pageableRequest);

    @Query("SELECT asw, wsr, was FROM AssignScheduleToWorker asw, WorkerScheduleRequest wsr, WorkerScheduleRequestAssignment was  WHERE wsr.scheduleRequestCode = asw.scheduleRequestCode AND was.scheduleRequestAssignmentCode = asw.scheduleRequestAssignmentCode AND asw.workerCode=:workerCode AND asw.isDeleted != TRUE AND wsr.isDeleted != TRUE AND   asw.status IN (:statusList)     ORDER BY asw.id DESC")
    public List<Object> getAllSceduleByWorkerCodeWithFilterByPage(@Param("workerCode") String workerCode,@Param("statusList") List<String> statusList);

    @Query("SELECT asw, wsr, was FROM AssignScheduleToWorker asw, WorkerScheduleRequest wsr, WorkerScheduleRequestAssignment was  WHERE wsr.scheduleRequestCode = asw.scheduleRequestCode AND was.scheduleRequestAssignmentCode = asw.scheduleRequestAssignmentCode AND asw.workerCode=:workerCode AND asw.isDeleted != TRUE AND wsr.isDeleted != TRUE AND   asw.status IN (:statusList)     ORDER BY asw.id DESC")
    public List<Object> getAllSceduleByWorkerCodeWithFilterByPage(@Param("workerCode") String workerCode,@Param("statusList") List<String> statusList,Pageable pageableRequest);

    @Query("SELECT asw FROM AssignScheduleToWorker asw WHERE asw.isDeleted != TRUE AND asw.scheduleRequestCode = :scheduleRequestCode")
    public AssignScheduleToWorker getAssignedScheduledToWorkerByScheduleRequestCode(@Param("scheduleRequestCode") String scheduleRequestCode);
    
    @Query("SELECT asw FROM AssignScheduleToWorker asw WHERE asw.isDeleted != TRUE AND asw.scheduleRequestCode = :scheduleRequestCode AND asw.scheduleRequestAssignmentCode= :scheduleRequestAssignmentCode")
    public List<AssignScheduleToWorker> getAssignedScheduledToWorkerByReqCodeAndAssignCode(@Param("scheduleRequestCode") String scheduleRequestCode, @Param("scheduleRequestAssignmentCode") String  scheduleRequestAssignmentCode);

    @Query("SELECT asw FROM AssignScheduleToWorker asw WHERE asw.isDeleted != TRUE AND asw.scheduleRequestCode = :scheduleRequestCode AND asw.scheduleRequestAssignmentCode= :scheduleRequestAssignmentCode AND asw.workerCode = :workerCode")
    public AssignScheduleToWorker getAssignedScheduledToWorkerByReqCodeAndAssignCodeWorkerCode(@Param("scheduleRequestCode") String scheduleRequestCode, @Param("scheduleRequestAssignmentCode") String  scheduleRequestAssignmentCode,@Param("workerCode") String workerCode);
  
    @Query("SELECT wt FROM WorkerTimeOff wt WHERE wt.isDeleted != TRUE AND wt.workerCode = :workercode AND wt.organizationCode= :organizationCode")
    public List<WorkerTimeOff> getTimeOffByWorkerCodeOrgCode(@Param("workercode") String workercode, @Param("organizationCode") String organizationCode);
    
    @Query("SELECT w.workerCode FROM Organization org, WorkerApprovalStatus was, Worker w WHERE w.isDeleted != TRUE AND  was.isDeleted != TRUE AND  org.isDeleted != TRUE AND was.workerCode=w.workerCode AND was.organization_Code=org.organizationCode AND  org.organizationCode = :organizationCode")
    public List<String> getAllWorkerCodeListByOrgCode(@Param("organizationCode") String organizationCode);
    
    @Query("SELECT w.workerCode FROM Organization org, WorkerApprovalStatus was, Worker w WHERE w.isDeleted != TRUE AND  was.isDeleted != TRUE AND  org.isDeleted != TRUE AND was.workerCode=w.workerCode AND was.organization_Code=org.organizationCode AND  org.organizationCode = :organizationCode AND was.workerCode NOT IN (:wkrList)")
    public List<String> getAllFreeWorkerCodeListByOrgCode(@Param("organizationCode") String organizationCode, @Param("wkrList") List<String> wkrList);

    @Query("SELECT a.skillCode FROM OrganizationWorkerSkill a WHERE a.isDeleted != TRUE AND  a.workerCode =:workerCode")
    public List<String> getSkillByWorkerCode(@Param("workerCode") String workerCode);
	
    @Query("SELECT a.certificationCode FROM WorkerCertifications a WHERE a.isDeleted != TRUE AND a.workerCode = :workerCode ")
    public List<String> getWorkerCertificationsByWorkerCode(@Param("workerCode") String workerCode);
    
    @Query("SELECT wkr.workerCode FROM Worker wkr,  AssignScheduleToWorker asw, WorkerScheduleRequest wsr WHERE asw.scheduleRequestAssignmentCode!=:scheduleRequestAssignmentCode AND wsr.scheduleRequestCode=asw.scheduleRequestCode  AND wkr.workerCode=asw.workerCode AND wkr.isDeleted != TRUE AND ( ( wsr.startDT<=:startDT AND  wsr.endDT>=:endDT  ) OR ( wsr.startDT>=:startDT AND  wsr.endDT<=:endDT ) OR ( wsr.startDT<=:startDT AND  wsr.endDT<=:endDT AND wsr.endDT>:startDT) OR ( wsr.startDT>=:startDT AND  wsr.endDT>=:endDT AND wsr.startDT<:endDT ) )")
    public List<String> getBusyWorkerCodeListInOtherScheduletInStartEnd(@Param("startDT") Date startDT,@Param("endDT") Date endDT,@Param("scheduleRequestAssignmentCode") String scheduleRequestAssignmentCode);
    
}








