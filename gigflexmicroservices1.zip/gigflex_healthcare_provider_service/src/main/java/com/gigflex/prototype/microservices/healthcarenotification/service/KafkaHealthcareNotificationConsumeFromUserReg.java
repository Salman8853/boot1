/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.healthcarenotification.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.healthcarenotification.repository.HealthcareNotificationDao;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.simp.SimpMessagingTemplate;

/**
 *
 * @author amit.kumar
 */
public class KafkaHealthcareNotificationConsumeFromUserReg {
    
    private HealthcareNotification notification;
	 
	 @Autowired
	    private SimpMessagingTemplate template;
	    
	    @Autowired
	    HealthcareNotificationDao notificationDao;
	    private static final Logger LOG = LoggerFactory.getLogger(KafkaHealthcareNotificationConsumeFromUserReg.class);
	    
	     @KafkaListener(topics = "AddNotificationFromUserReg")
	     public void listen(@Payload String message) {
	           ObjectMapper objectMapper = new ObjectMapper();
	        LOG.info("received message='{}'", message);
	        try{
                    
                    HealthcareNotification notify = objectMapper.readValue(message, HealthcareNotification.class);
                    LOG.info("received message for AddNewNotificationFromUserReg='{}'", notify.getMessage());
                    LOG.info("received message for AddNewNotificationFromUserReg='{}'", notify.getHealthcareNotificationCode());
                    LOG.info("received message for AddNewNotificationFromUserReg='{}'", notify.getUserCode());
                    LOG.info("received message for AddNewNotificationFromUserReg='{}'", notify.getUserType());
	      
	          
	            notification=new HealthcareNotification();
	            
	            notification.setHealthcareNotificationCode(notify.getHealthcareNotificationCode());
	            notification.setMessage(notify.getMessage());
	            notification.setShortMessage(notify.getShortMessage());
	            notification.setUserCode(notify.getUserCode());
	            notification.setIsRead(notify.getIsRead());
	            notification.setIsDeleted(notify.getIsDeleted());
	            notification.setUserType(notify.getUserType());

	            
	            template.convertAndSend("/topic/notification", notify);
//	            notification.setIsRead(true);

	            notificationDao.save(notification);
	            
	        }
	         catch (JsonParseException e) {
				LOG.error("In  KafkaHealthcareNotificationService for AddNewNotificationFromUserReg >>>>", e);
			} catch (JsonMappingException e) {
				LOG.error("In KafkaHealthcareNotificationService for AddNewNotificationFromUserReg >>>>", e);
			} catch (IOException e) {
				LOG.error("In KafkaHealthcareNotificationService for AddNewNotificationFromUserReg >>>>", e);
			}catch (Exception e) {
				LOG.error("In KafkaHealthcareNotificationService for AddNewNotificationFromUserReg >>>>", e);
			}
	         
	     }
}
