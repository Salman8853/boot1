/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.device.api;

import com.gigflex.prototype.microservices.device.dtob.DeviceDetailReq;
import com.gigflex.prototype.microservices.device.service.DeviceDetailService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author amit.kumar
 */
@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class DeviceDetailController {
    
    @Autowired
    DeviceDetailService deviceDetailService;
    
     @PostMapping("/saveDeviceDetail")
	public String saveDeviceDetail(@RequestBody DeviceDetailReq dReq,
			HttpServletRequest request) {
            if(dReq!=null && dReq.getDeviceId()!=null && dReq.getDeviceId().trim().length()>0 
                    &&  dReq.getUserCode() != null && dReq.getUserCode().trim().length() >0
                    &&  dReq.getDeviceType()!= null && dReq.getDeviceType().trim().length() >0
                    )
            {
                dReq.setDeviceId(dReq.getDeviceId().trim());
                dReq.setUserCode(dReq.getUserCode().trim());
		String ip = request.getRemoteAddr();
		return deviceDetailService.saveDeviceDetail(dReq, ip);
            }
            else
            {
                GigflexResponse derr = new GigflexResponse(400, new Date(),
					"User code , Device id & Device Type should not be blank.");
			return derr.toString();
            }

	}
}
