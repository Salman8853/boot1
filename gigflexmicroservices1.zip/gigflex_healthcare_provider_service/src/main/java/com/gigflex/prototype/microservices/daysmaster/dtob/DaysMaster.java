package com.gigflex.prototype.microservices.daysmaster.dtob;

import java.io.Serializable;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.gigflex.prototype.microservices.util.CommonAttributes;

@Entity
@Table(name = "days_master")
public class DaysMaster extends CommonAttributes implements Serializable {
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "id")
	    private Integer id;

	    @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	    @GenericGenerator(name = "uuid", strategy = "uuid2")
	    @Column(name = "day_code", unique = true)
	    private String daysCode;
	    
	    @Column(name = "days_name", nullable = false)
	    private String daysName;
	    
	    @PrePersist
	    private void assignUUID() {
	    	if (this.getDaysCode() == null || this.getDaysCode().length() == 0) {
	           this.setDaysCode(UUID.randomUUID().toString());
	    	}
	    }


		public Integer getId() {
			return id;
		}

		public void setId(Integer id) {
			this.id = id;
		}

		public String getDaysCode() {
			return daysCode;
		}

		public void setDaysCode(String daysCode) {
			this.daysCode = daysCode;
		}

		public String getDaysName() {
			return daysName;
		}

		public void setDaysName(String daysName) {
			this.daysName = daysName;
		}
	    
	    

}
