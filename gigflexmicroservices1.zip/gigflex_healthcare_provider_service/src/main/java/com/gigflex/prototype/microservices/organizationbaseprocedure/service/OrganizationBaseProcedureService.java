/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.organizationbaseprocedure.service;

import com.gigflex.prototype.microservices.organizationbaseprocedure.dtob.OrganizationBaseProcedureRequest;

/**
 *
 * @author amit.kumar
 */
public interface OrganizationBaseProcedureService {

    public String findAllProcedureByOrganizationCode(String organizationCode);

    public String findProcedureByOrganizationCodeAndProcedureCode(String organizationCode, String procedureCode);

    public String updateProcedureByOrganizationBasedProcedureCode(String organizationBaseProcedureCode, OrganizationBaseProcedureRequest orgBaseProcedureReq, String ip);

    public String saveOrganizationBaseProcedure(OrganizationBaseProcedureRequest orgBaseProcedureReq, String ip);
    
}
