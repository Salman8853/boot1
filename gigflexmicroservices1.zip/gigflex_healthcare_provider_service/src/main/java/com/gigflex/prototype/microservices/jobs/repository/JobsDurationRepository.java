/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.repository;


import com.gigflex.prototype.microservices.jobs.dtob.JobsDuration;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

/**
 *
 * @author nirbhay.p
 */
public interface JobsDurationRepository  extends JpaRepository<JobsDuration, Long>,JpaSpecificationExecutor<JobsDuration> {
    
@Query("SELECT j FROM JobsDuration j WHERE j.isDeleted != TRUE AND j.jobsCode = :jobsCode")
public List<JobsDuration> getJobsDurationByJobsCode(@Param("jobsCode") String jobsCode);

@Query("SELECT j FROM JobsDuration j WHERE j.isDeleted != TRUE AND j.jobsDurationCode = :jobsDurationCode")
public JobsDuration getJobsDurationByJobsDurationCode(@Param("jobsDurationCode") String jobsDurationCode);


@Query("SELECT jo,j FROM JobsDuration j, Jobs jo WHERE j.isDeleted != TRUE AND jo.isDeleted != TRUE AND j.jobsCode = jo.jobsCode AND j.jobsDurationCode = :jobsDurationCode")
public Object getJobsDurationAndJobsByJobsDurationCode(@Param("jobsDurationCode") String jobsDurationCode);


}