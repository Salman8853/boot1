package com.gigflex.prototype.microservices.departmentworker.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.departmentworker.dtob.DepartmentWorker;
import com.gigflex.prototype.microservices.departmentworker.dtob.DepartmentWorkerRequest;
import com.gigflex.prototype.microservices.departmentworker.repository.DepartmentWorkerRepository;
import com.gigflex.prototype.microservices.departmentworker.search.DepartmentWorkerSpecificationsBuilder;
import com.gigflex.prototype.microservices.departmentworker.service.DepartmentWorkerService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

/**
 *
 * @author ajit.p
 *
 */
@Service
public class DepartmentWorkerServiceImpl implements DepartmentWorkerService {

    @Autowired
    DepartmentWorkerRepository depWorkRep;

    @Override
    public String saveWorkerInDepartment(DepartmentWorkerRequest depWorkerRequest, String ip) {
        String res = "";
        try {
            JSONArray jarr = new JSONArray();

            if (depWorkerRequest != null) {
                if ((depWorkerRequest.getDepartmentCode()) != null
                        && depWorkerRequest.getDepartmentCode().trim().length() > 0
                        && (depWorkerRequest.getWorkerCode() != null
                        && depWorkerRequest.getWorkerCode().length() > 0)) {
                    JSONObject jsonobj = new JSONObject();
                    DepartmentWorker depWorkerRes = null;
                    DepartmentWorker depWorker = new DepartmentWorker();
                    DepartmentWorker departmentWorker = depWorkRep.getDepartmentWorker(
                            depWorkerRequest.getDepartmentCode(), depWorkerRequest.getWorkerCode());
                    if (departmentWorker == null) {

                        depWorker.setWorkerCode(depWorkerRequest.getDepartmentCode());
                        depWorker.setDepartmentCode(depWorkerRequest.getDepartmentCode());
                        depWorker.setDepartmentName(depWorkerRequest.getDepartmentName());
                        depWorker.setWorkerName(depWorkerRequest.getWorkerName());
                        if(depWorkerRequest.getIsAssigned() != null){
                        depWorker.setIsAssigned(depWorkerRequest.getIsAssigned());
                        }else{
                        	depWorker.setIsAssigned(false);
                        }
                        depWorker.setIpAddress(ip);

                        jsonobj.put("responsecode", 200);
                        jsonobj.put("timestamp", new Date());
                        depWorkerRes = depWorkRep.save(depWorker);
                        if (depWorkerRes != null && depWorkerRes.getId() > 0) {
                            // kafkaService.sendOrganizationSkill(depWorkerRes);
                            jsonobj.put("message", "Worker Code added successfully.");
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(depWorkerRes);
                            jsonobj.put("data", new JSONObject(Detail));
                        } else {
                            jsonobj.put("message", "Failed");
                            jsonobj.put("responsecode", 400);
                        }
                        jarr.add(jsonobj);

                    } else {
                        jsonobj.put("message", " Not allowed as this Worker belongs to same Department.");
                        jsonobj.put("responsecode", 409);
                        jsonobj.put("timestamp", new Date());
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(depWorkerRes);
                        jsonobj.put("data", new JSONObject(Detail));
                    }

                }
                if (jarr.size() > 0) {
                    res = jarr.toString();
                } else {
                    GigflexResponse derr = new GigflexResponse(400, new Date(), "Multiple add failed.");
                    res = derr.toString();
                }
            } else {
                GigflexResponse derr = new GigflexResponse(400, new Date(),
                        "Worker Code and Department Code must not be blank.");
                res = derr.toString();

            }

        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
    }

    @Override
    public String updateWorkerById(Long id, DepartmentWorkerRequest departmentWorkerRequest, String ip) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            if (id > 0 && departmentWorkerRequest != null) {
                if ((departmentWorkerRequest.getWorkerCode() != null
                        && departmentWorkerRequest.getWorkerCode().trim().length() > 0)
                        && (departmentWorkerRequest.getDepartmentCode() != null
                        && departmentWorkerRequest.getDepartmentCode().trim().length() > 0)) {

                    DepartmentWorker departmentWorker = depWorkRep.getDepartmentWorker(
                            departmentWorkerRequest.getDepartmentCode(), departmentWorkerRequest.getWorkerCode());

                    if (departmentWorker == null) {

                        DepartmentWorker depWorker = new DepartmentWorker();
                        depWorker.setWorkerCode(departmentWorkerRequest.getDepartmentCode());
                        depWorker.setDepartmentCode(departmentWorkerRequest.getDepartmentCode());
                        depWorker.setDepartmentName(departmentWorkerRequest.getDepartmentName());
                        depWorker.setWorkerName(departmentWorkerRequest.getWorkerName());
                        if(departmentWorkerRequest.getIsAssigned() != null){
                            depWorker.setIsAssigned(departmentWorkerRequest.getIsAssigned());
                            }else{
                            	depWorker.setIsAssigned(false);
                            }
                        depWorker.setIpAddress(ip);
                        DepartmentWorker depWorkerRes = depWorkRep.save(depWorker);
                        if (depWorkerRes != null && depWorkerRes.getId() > 0) {
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("message", "Worker updated successfully.");
                            jsonobj.put("timestamp", new Date());
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(depWorkerRes);
                            jsonobj.put("data", new JSONObject(Detail));

                            // kafkaService.sendUpdateOrganizationSkill(depWorkerRes);
                        } else {
                            jsonobj.put("responsecode", 400);
                            jsonobj.put("message", "Worker updation has been failed.");
                            jsonobj.put("timestamp", new Date());
                        }
                    } else {
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("message", "Worker ID is not valid.");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("message", "Worker Code and Department Code should not be blank");
                    jsonobj.put("timestamp", new Date());
                }
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Input data is not valid.");
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        }
        return res;
    }

	@Override
	public String getDepartmentWorkerByWorkerCode(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (workerCode != null && workerCode.trim().length() > 0) {
				List<DepartmentWorker> departmentWorker = new ArrayList<DepartmentWorker>();
				departmentWorker =	depWorkRep.getDepartmentWorkerByWorkerCode(workerCode);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (departmentWorker != null && departmentWorker.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(departmentWorker);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String getDepartmentWorkerByWorkerCodeAssigned(String workerCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (workerCode != null && workerCode.trim().length() > 0) {
				List<DepartmentWorker> departmentWorker = new ArrayList<DepartmentWorker>();
				departmentWorker =	depWorkRep.getDepartmentWorkerByWorkerCodeAssigned(workerCode);
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());

				if (departmentWorker != null && departmentWorker.size() > 0) {
					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(departmentWorker);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
		
	}

	@Override
	public String getDepartmentWorkerByWorkerCode(String workerCode, int page,
			int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if(limit>0){
			if (workerCode != null && workerCode.trim().length() > 0) {
				Pageable pageableRequest = PageRequest.of(page, limit);
				List<DepartmentWorker> departmentWorker = new ArrayList<DepartmentWorker>();
				departmentWorker =	depWorkRep.getDepartmentWorkerByWorkerCode(workerCode, pageableRequest);
				int count=0;
                                List<DepartmentWorker> departmentWorkercnt=depWorkRep.getDepartmentWorkerByWorkerCode(workerCode);
                                if(departmentWorkercnt!=null && departmentWorkercnt.size()>0)
                                {
                                    count=departmentWorkercnt.size();
                                }
				if (departmentWorker != null && departmentWorker.size() > 0) {
                                    jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
                                jsonobj.put("count", count);
				jsonobj.put("timestamp", new Date());

                                    ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(departmentWorker);
					jsonobj.put("data", new JSONArray(Detail));

				} else {
					jsonobj.put("responsecode", 404);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Record Not Found");

				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Invalid Input");
			}
                        } else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Limit should not be Zero or Negative.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String search(String search) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
            if(search != null && search.trim().length() > 0){
			JSONObject jsonobj = new JSONObject();
			
			DepartmentWorkerSpecificationsBuilder builder = new DepartmentWorkerSpecificationsBuilder();
		        Pattern pattern = Pattern.compile("(\\w+?)(:|<|>)([\\w\\s\\.\\@\\-]+?),");
		        java.util.regex.Matcher matcher = pattern.matcher(search + ",");
		        while (matcher.find()) {
		            builder.with(matcher.group(1), matcher.group(2), matcher.group(3));
		        }
		         
		        Specification<DepartmentWorker> spec = builder.build();
                        if(spec!=null){
		        List<DepartmentWorker> departmentWorker = depWorkRep.findAll(spec);
			if(departmentWorker != null && departmentWorker.size() > 0){
			for(DepartmentWorker dept : departmentWorker){
				if(dept.getIsDeleted() != null && dept.getIsDeleted() != true){

					ObjectMapper mapperObj = new ObjectMapper();
					String Detail = mapperObj.writeValueAsString(dept);
					JSONObject jsonobjNew = new JSONObject();
					jsonobjNew.put("departmentWorker", new JSONObject(Detail));
					jarr.add(jsonobjNew);

			} 
				
			} 
			if (jarr.size() > 0) {
				
			jsonobj.put("responsecode", 200);
			jsonobj.put("message", "Success");
			jsonobj.put("timestamp", new Date());
			jsonobj.put("data", jarr);
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}
			
			}else{
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Record Not Found!");
				jsonobj.put("timestamp", new Date());
			}}
                        else{
                           jsonobj.put("responsecode", 400);
			   jsonobj.put("message", "Record Not Found!");
			   jsonobj.put("timestamp", new Date()); 
                        }
			res = jsonobj.toString();
		
            }else{
            	GigflexResponse derr = new GigflexResponse(400, new Date(),
    					"Input data is not valid.");
    			res = derr.toString();

            }
			
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

}

/*
 * @Override public String softDeleteOrganizationSkillById(Long id) { String res
 * = ""; try { JSONObject jsonobj = new JSONObject(); OrganizationSkill
 * orgSkillinDb = orgSkillDao.getOrganizationSkillById(id);
 * 
 * if (orgSkillinDb != null && orgSkillinDb.getId() > 0) {
 * orgSkillinDb.setIsDeleted(true); OrganizationSkill orgSkillRes =
 * orgSkillDao.save(orgSkillinDb); if (orgSkillRes != null &&
 * orgSkillRes.getId() > 0) { jsonobj.put("responsecode", 200);
 * jsonobj.put("timestamp", new Date());
 * 
 * jsonobj.put("message", "Organization Skill deleted successfully.");
 * 
 * kafkaService.sendUpdateOrganizationSkill(orgSkillRes); } else {
 * jsonobj.put("responsecode", 400); jsonobj.put("timestamp", new Date());
 * jsonobj.put("message", "Failed"); }
 * 
 * } else { jsonobj.put("responsecode", 404); jsonobj.put("timestamp", new
 * Date()); jsonobj.put("message", "Record Not Found"); } res =
 * jsonobj.toString(); } catch (Exception ex) { GigflexResponse derr = new
 * GigflexResponse(500, new Date(), "JSON parsing exception occurred."); res =
 * derr.toString(); } return res; }
 */
