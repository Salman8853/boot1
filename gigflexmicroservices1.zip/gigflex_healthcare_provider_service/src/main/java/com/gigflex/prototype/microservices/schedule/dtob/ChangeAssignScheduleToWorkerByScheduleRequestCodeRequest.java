/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.schedule.dtob;

/**
 *
 * @author amit.kumar
 */
public class ChangeAssignScheduleToWorkerByScheduleRequestCodeRequest {
    
    
    private String scheduleRequestCode;
    
   
    private String changedByWorkerCode;
    
    
    private String changeToWorkerCode;
    
    
    private Boolean isApproved;

    public String getScheduleRequestCode() {
        return scheduleRequestCode;
    }

    public void setScheduleRequestCode(String scheduleRequestCode) {
        this.scheduleRequestCode = scheduleRequestCode;
    }

    public String getChangedByWorkerCode() {
        return changedByWorkerCode;
    }

    public void setChangedByWorkerCode(String changedByWorkerCode) {
        this.changedByWorkerCode = changedByWorkerCode;
    }

    public String getChangeToWorkerCode() {
        return changeToWorkerCode;
    }

    public void setChangeToWorkerCode(String changeToWorkerCode) {
        this.changeToWorkerCode = changeToWorkerCode;
    }

    public Boolean isIsApproved() {
        return isApproved;
    }

    public void setIsApproved(Boolean isApproved) {
        this.isApproved = isApproved;
    }
    
    
    
}
