/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.jobs.dtob;

import java.util.List;

/**
 *
 * @author amit.kumar
 */
public class AppoaintmentDetailAndStatusCountRes {
    
    private List<StatusCount> statusCountList;
    private List<AppointmentDetailByWorkerCode> appointmentDetailByWorkerCodeList;

    public List<StatusCount> getStatusCountList() {
        return statusCountList;
    }

    public void setStatusCountList(List<StatusCount> statusCountList) {
        this.statusCountList = statusCountList;
    }

    public List<AppointmentDetailByWorkerCode> getAppointmentDetailByWorkerCodeList() {
        return appointmentDetailByWorkerCodeList;
    }

    public void setAppointmentDetailByWorkerCodeList(List<AppointmentDetailByWorkerCode> appointmentDetailByWorkerCodeList) {
        this.appointmentDetailByWorkerCodeList = appointmentDetailByWorkerCodeList;
    }

    

    
    
}
