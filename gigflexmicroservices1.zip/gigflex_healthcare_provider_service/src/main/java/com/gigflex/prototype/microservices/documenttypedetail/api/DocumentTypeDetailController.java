package com.gigflex.prototype.microservices.documenttypedetail.api;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.documenttypedetail.dtob.DocumentTypeDetailRequest;
import com.gigflex.prototype.microservices.documenttypedetail.service.DocumentTypeDetailService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/healthcareservice/")
public class DocumentTypeDetailController {
	
	@Autowired
	public DocumentTypeDetailService docTypeDetService;
	
	@GetMapping("/DocumentTypeDetail/{search}")
	public String search(@PathVariable("search") String search) {
		return docTypeDetService.search(search);
	}

	@GetMapping("/getAllDocumentTypeDetail")
	public String getAllDocumentTypeDetail() {
		return docTypeDetService.getAllDocumentTypeDetail();
	}

	@GetMapping(path = "/getDocumentTypeDetailByPage")
	public String getDocumentTypeDetailByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String docType = docTypeDetService.getAllDocumentTypeDetailByPgae(page, limit);

		return docType;

	}
        
      

	@GetMapping("/getDocumentTypeDetail/{id}")
	public String getDocumentTypeDetailById(@PathVariable Long id) {
		return docTypeDetService.getDocumentTypeDetailById(id);
	}

	@GetMapping("/getDocumentTypeDetailByDocumentCode/{documentCode}")
	public String getDocumentTypeDetailByDocumentCode(@PathVariable String documentCode) {
		return docTypeDetService.getDocumentTypeDetailByDocumentCode(documentCode);
	}
        
        @GetMapping("/getDocumentTypeDetailByDocumentName/{documentName}")
	public String getDocumentTypeDetailByDocumentName(@PathVariable String documentName) {
		return docTypeDetService.getDocumentTypeDetailByDocumentName(documentName);
	}

	@PostMapping("/saveDocumentTypeDetail")
	public String saveDocumentTypeDetail(@RequestBody DocumentTypeDetailRequest docTypeDetReq,
			HttpServletRequest request) {
		String ip = request.getRemoteAddr();
		return docTypeDetService.saveNewDocumentTypeDetail(docTypeDetReq, ip);

	}

	@PutMapping("/updateDocumentTypeDetail/{id}")
	public String updateDocumentTypeDetail(@PathVariable Long id,
			@RequestBody DocumentTypeDetailRequest docTypeDetReq, HttpServletRequest request) {

		if (id == null) {
			return "Document Type Detail with Id : (" + id + ") Not found.";
		} else {
			String ip = request.getRemoteAddr();

			return docTypeDetService.updateDocumentTypeDetailById(id, docTypeDetReq, ip);

		}

	}

	@DeleteMapping("/softDeleteDocumentTypeDetailByDocumentCode/{documentCode}")
	public String softDeleteDocumentTypeDetailByDocumentCode(
			@PathVariable String documentCode) {
		return docTypeDetService.softDeleteByDocumentCode(documentCode);
	}

	@DeleteMapping("/softMultipleDeleteByDocumentCode/{documentCodeList}")
	public String softMultipleDeleteByDocumentCode(
			@PathVariable List<String> documentCodeList) {
		if (documentCodeList != null && documentCodeList.size() > 0) {
			return docTypeDetService
					.softMultipleDeleteByDocumentCode(documentCodeList);
		} else {
			GigflexResponse derr = new GigflexResponse(400, new Date(),
					"Input data is not valid");
			return derr.toString();
		}

	}

}
