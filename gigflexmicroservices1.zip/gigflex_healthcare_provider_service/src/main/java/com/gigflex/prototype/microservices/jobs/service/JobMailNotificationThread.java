/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.service;

import com.gigflex.prototype.microservices.device.dtob.DeviceDetail;
import com.gigflex.prototype.microservices.device.repository.DeviceDetailRepository;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.healthcarenotification.service.HealthcareNotificationService;
import com.gigflex.prototype.microservices.jobs.dtob.Jobs;
import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorker;
import com.gigflex.prototype.microservices.jobs.dtob.JobsDuration;
import com.gigflex.prototype.microservices.jobs.repository.JobsRepository;
import com.gigflex.prototype.microservices.jobs.service.impl.JobsServiceImpl;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.util.PushNotification;
import com.gigflex.prototype.microservices.util.SendNotification;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class JobMailNotificationThread implements Runnable {
    
private static final Logger LOG = LoggerFactory.getLogger(JobMailNotificationThread.class);
private Boolean isShort;    
private JobsAssignToWorker jaw;
    private TimeZoneRepository timeZoneDao;
    private JobsRepository jobsRepository;
    private GlobalSettingRepository globalSettingRepository;
    private LocalSettingRepository localSettingRepository;
    private UserTypeRepository utr;
    private HealthcareNotificationService notificationService;
    private String mailServiceURL;
    private String subject;
    private String sortbody;
    private DeviceDetailRepository deviceDetailDao;
    private String FMCurl;
    private String authKey;

    public JobMailNotificationThread(Boolean isShort,JobsAssignToWorker jaw, TimeZoneRepository timeZoneDao,
            JobsRepository jobsRepository, GlobalSettingRepository globalSettingRepository,
            LocalSettingRepository localSettingRepository, UserTypeRepository utr,
            HealthcareNotificationService notificationService,String mailServiceURL,String subject,String sortbody,DeviceDetailRepository deviceDetailDao,String FMCurl,String authKey) {
        super();
        this.isShort=isShort;
        this.jaw = jaw;
        this.timeZoneDao = timeZoneDao;
        this.jobsRepository = jobsRepository;
        this.globalSettingRepository = globalSettingRepository;
        this.localSettingRepository = localSettingRepository;
        this.utr = utr;
        this.notificationService = notificationService;
        this.mailServiceURL=mailServiceURL;
        this.subject=subject;
        this.sortbody=sortbody;
        this.deviceDetailDao = deviceDetailDao;
        this.FMCurl = FMCurl;
        this.authKey = authKey;
    }

    @Override
    public void run() {
         LOG.info("================Start JobMailNotificationThread===============");
        try
        {
        if(isShort)
        {
             if(jaw!=null && jaw.getId()>0 && jaw.getWorkerCode()!=null && jaw.getWorkerCode().trim().length()>0)
        {
            Worker worker = jobsRepository.getWorkerByWorkerCodeForNoti(jaw.getWorkerCode().trim());
            if(worker!=null && worker.getId()>0)
            {
                HealthcareNotification notification = new HealthcareNotification();
                String appointmentId = jaw.getAppointmentId();
                String notisortbody=sortbody.replaceAll("<br>", "");
                         
                            String shortMessage = subject;

                            notification.setUserCode(worker.getWorkerCode());
                            notification.setMessage(notisortbody);
                            notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                            notification.setShortMessage(shortMessage);
                            notification.setAppointmentCode(appointmentId);
                            notification.setIsRead(Boolean.FALSE);

                            notificationService.saveHealthcareNotification(notification);

                                    
                            SendNotification sn = new SendNotification();

                            if (worker.getEmail() != null && worker.getEmail().length() > 0) {
                                String response = sn.sendMail(worker.getEmail(), subject, sortbody, mailServiceURL);

                                LOG.info("mail response in JobMailNotificationThread >>>>>>", response);
                            }
                                                        
                             List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(worker.getWorkerCode().trim());
                            if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                             {
                               //for push notification 
                                 for(DeviceDetail deviceDetail : deviceDetailResList)
                                 {
                                     PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Job Alert", notisortbody);
                                 }                                                        
                             }
            }
        }
        }
        else
        {
        if(jaw!=null && jaw.getId()>0 && jaw.getWorkerCode()!=null && jaw.getWorkerCode().trim().length()>0)
        {
            Worker worker = jobsRepository.getWorkerByWorkerCodeForNoti(jaw.getWorkerCode().trim());
            if(worker!=null && worker.getId()>0)
            {
                Jobs job = jobsRepository.getJobsByJobsCode(jaw.getJobsCode());
                if (job != null && job.getId()>0) {
                HealthcareNotification notification = new HealthcareNotification();
                            String appointmentId = jaw.getAppointmentId();

                            
                            String organizationName = "";
                            Organization org = jobsRepository.getOrganizationByOrganizationCodeForNoti(job.getOrganizationCode());
                            if (org != null && org.getId()>0) {
                                organizationName = org.getOrganizationName();
                            }
                            String patientName="";
                            PatientDetails pDetail = jobsRepository.getPatientDetailsBypatientCodeForNoti(job.getPatientCode());
                            if(pDetail!=null && pDetail.getId()>0)
                            {
                                patientName=pDetail.getPatientName();
                            }
                            

                            JobsDuration jd = jobsRepository.getJobsDurationByJobsDurationCodeForNoti(jaw.getJobsDurationCode());
                            Date startTime = null;
                            Date endTime = null;
                            if (jd != null) {
                                startTime = jd.getStartTime();
                                endTime = jd.getEndTime();
                            }

                            String stDate = "";
                            String endDate = "";
                            if (startTime != null && endTime != null) {
                                String timezone = null;
                                String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                String dtFormatView = dtFormat;
                                String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, jaw.getWorkerCode(), GigflexConstants.TimeZone);
                                String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, jaw.getWorkerCode(), GigflexConstants.DATEFORMAT);
                                String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, jaw.getWorkerCode(), GigflexConstants.TIMEFORMAT);
                                if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                                    dtFormatView = dateformat.trim() + " " + timeformat.trim();
                                }

                                if (timezoneCode != null && timezoneCode.length() > 0) {
                                    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                    if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                        timezone = tzd.getTimeZoneName();
                                    }
                                }

                                if (timezone != null) {
                                    try{
                                    startTime = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                                    stDate=GigflexDateUtil.convertDateToString(startTime, dtFormatView);
                                    endTime = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                                    endDate=GigflexDateUtil.convertDateToString(endTime, dtFormatView);
                                            }
                                    catch(Exception e)
                                    {
                                        e.printStackTrace();
                                    }
                                }
                            }
                            String notisortbody=sortbody.replaceAll("<br>", "");
                            String bodyContentShortMessage = notisortbody 
                                    + " Appointment ID : " + appointmentId
                                    + "Patient Name : " + patientName
                                    + "Organization Name : " + organizationName
                                    + " Start Time : " + stDate
                                    + " End Time : " + endDate;
                                    

                            String shortMessage = subject;

                            notification.setUserCode(worker.getWorkerCode());
                            notification.setMessage(bodyContentShortMessage);
                            notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                            notification.setShortMessage(shortMessage);
                            notification.setAppointmentCode(appointmentId);
                            notification.setIsRead(Boolean.FALSE);

                            notificationService.saveHealthcareNotification(notification);

                            
                            String bodyContent = sortbody 
                                    + "<br>Appointment ID : " + appointmentId
                                     + "<br>Patient Name : " + patientName
                                    + "<br>Organization Name : " + organizationName
                                    + "<br>Start Time : " + stDate
                                    + "<br>End Time : " + endDate;
                                    
                            SendNotification sn = new SendNotification();

                            if (worker.getEmail() != null && worker.getEmail().length() > 0) {
                                String response = sn.sendMail(worker.getEmail(), subject, bodyContent, mailServiceURL);

                                LOG.info("mail response in JobMailNotificationThread >>>>>>", response);
                            }
                            
                            List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(worker.getWorkerCode().trim());
                            if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                             {
                               //for push notification 
                                 for(DeviceDetail deviceDetail : deviceDetailResList)
                                 {
                                     PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Job Alert", bodyContentShortMessage);
                                 }                                                        
                             }
                }        
            }
        }
        }
        }
        catch(Exception e)
        {
            LOG.error("Error in JobMailNotificationThread >>>>>>", e);
        }
         LOG.info("================End JobMailNotificationThread===============");
    }

}
