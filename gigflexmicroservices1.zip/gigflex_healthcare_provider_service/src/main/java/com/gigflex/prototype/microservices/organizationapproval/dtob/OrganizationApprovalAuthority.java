/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.organizationapproval.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

/**
 *
 * @author nirbhay.p
 */
@Entity
@Table(name="organization_approval_authority")
public class OrganizationApprovalAuthority extends CommonAttributes implements Serializable {
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @Column(name = "organization_approval_authority_code", nullable = false)
    private String organizationApprovalAuthorityCode ;
    
    @Column(name = "organization_code", nullable = false)
    private String organizationCode ;
    
    @Column(name = "isprocessed", columnDefinition="BOOLEAN DEFAULT FALSE")
    private Boolean isProcessed=false;
    
    @Column(name ="authority_code" , nullable = false)
    private String authorityCode ;

    @PrePersist
    private void assignUUID() {
        if(this.getOrganizationApprovalAuthorityCode()==null || this.getOrganizationApprovalAuthorityCode().length()==0)
        {
            this.setOrganizationApprovalAuthorityCode(UUID.randomUUID().toString());
        }
    }
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrganizationApprovalAuthorityCode() {
        return organizationApprovalAuthorityCode;
    }

    public void setOrganizationApprovalAuthorityCode(String organizationApprovalAuthorityCode) {
        this.organizationApprovalAuthorityCode = organizationApprovalAuthorityCode;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public Boolean getIsProcessed() {
        return isProcessed;
    }

    public void setIsProcessed(Boolean isProcessed) {
        this.isProcessed = isProcessed;
    }

    public String getAuthorityCode() {
        return authorityCode;
    }

    public void setAuthorityCode(String authorityCode) {
        this.authorityCode = authorityCode;
    }
    
    
}
