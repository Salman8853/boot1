/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.patient.repository;

import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.patient.dtob.PatientDocumentMapping;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface PatientDocumentMappingDao extends JpaRepository<PatientDocumentMapping,Long>,JpaSpecificationExecutor<PatientDocumentMapping>{
    
    @Query("SELECT pdm FROM PatientDocumentMapping pdm  WHERE pdm.isDeleted != TRUE AND pdm.patientCode = :patientCode")
    public List<PatientDocumentMapping> getPatientDocumentMappingByPatientCode(@Param("patientCode") String patientCode);
    
    @Query("SELECT pdm FROM PatientDocumentMapping pdm  WHERE pdm.isDeleted != TRUE AND pdm.patientDocumentMappingCode = :patientDocumentMappingCode")
    public PatientDocumentMapping getPatientDocumentMappingByPatientDocumentMappingCode(@Param("patientDocumentMappingCode") String patientDocumentMappingCode);
}
