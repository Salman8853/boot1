/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.jobs.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.device.dtob.DeviceDetail;
import com.gigflex.prototype.microservices.device.repository.DeviceDetailRepository;
import com.gigflex.prototype.microservices.healthcarenotification.dtob.HealthcareNotification;
import com.gigflex.prototype.microservices.healthcarenotification.service.HealthcareNotificationService;
import com.gigflex.prototype.microservices.jobs.dtob.AppoaintmentDetailAndStatusCountRes;
import com.gigflex.prototype.microservices.jobs.dtob.AppointmentDetail;
import com.gigflex.prototype.microservices.jobs.dtob.AppointmentDetailByWorkerCode;
import com.gigflex.prototype.microservices.jobs.dtob.AssignToWorkerReq;
import com.gigflex.prototype.microservices.jobs.dtob.AssignToWorkerReqNew;
import com.gigflex.prototype.microservices.jobs.dtob.AssignToWorkerStatusReq;
import com.gigflex.prototype.microservices.jobs.dtob.AssignWorkerInProgerssStatusReq;
import com.gigflex.prototype.microservices.jobs.dtob.CancelToworkerReq;
import com.gigflex.prototype.microservices.jobs.dtob.EligibleWorkerRes;
import com.gigflex.prototype.microservices.jobs.dtob.JobAssigntoWorkerWithFilterforWorkerResponse;
import com.gigflex.prototype.microservices.jobs.dtob.JobDurationUpdate;
import com.gigflex.prototype.microservices.jobs.dtob.JobManualResponse;
import com.gigflex.prototype.microservices.jobs.dtob.Jobs;
import com.gigflex.prototype.microservices.jobs.dtob.JobsAllResponse;
import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorker;
import com.gigflex.prototype.microservices.jobs.dtob.JobsDuration;
import com.gigflex.prototype.microservices.jobs.dtob.JobsDurationRes;
import com.gigflex.prototype.microservices.jobs.dtob.JobsRequest;
import com.gigflex.prototype.microservices.jobs.dtob.JobsRes;
import com.gigflex.prototype.microservices.jobs.dtob.JobsWithDurationRes;
import com.gigflex.prototype.microservices.jobs.dtob.WorkerWithDistance;
import com.gigflex.prototype.microservices.jobs.repository.JobsAssignToWorkerRepository;
import com.gigflex.prototype.microservices.jobs.repository.JobsDurationRepository;
import com.gigflex.prototype.microservices.jobs.repository.JobsRepository;
import com.gigflex.prototype.microservices.jobs.service.JobsService;
import com.gigflex.prototype.microservices.organizationworkerskill.repository.OrgWorkerSkillDao;
import com.gigflex.prototype.microservices.patient.dtob.PatientDetails;
import com.gigflex.prototype.microservices.patient.dtob.PatientResponse;
import com.gigflex.prototype.microservices.patient.repository.PatientDao;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.setting.repository.LocalSettingRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import com.gigflex.prototype.microservices.verifyemployee.repository.WorkerApprovalStatusRepository;
import com.gigflex.prototype.microservices.worker.dtob.Worker;
import com.gigflex.prototype.microservices.worker.repository.WorkerRepository;
import com.gigflex.prototype.microservices.workertimeoff.dtob.WorkerTimeOff;
import com.gigflex.prototype.microservices.jobs.dtob.JobsAssignToWorkerResponse;
import com.gigflex.prototype.microservices.jobs.dtob.JobsUpdateRequest;
import com.gigflex.prototype.microservices.jobs.dtob.PercentageCalculation;
import com.gigflex.prototype.microservices.jobs.dtob.PercentageCalculationRes;
import com.gigflex.prototype.microservices.jobs.dtob.RejectToworkerreq;
import com.gigflex.prototype.microservices.jobs.dtob.StatusCount;
import com.gigflex.prototype.microservices.jobs.dtob.TodaysAssignedPatientListResForMobile;
import com.gigflex.prototype.microservices.jobs.optaplanner.ScheduleAssignement;
import com.gigflex.prototype.microservices.jobs.service.JobMailNotificationThread;
import com.gigflex.prototype.microservices.organization.dtob.Organization;
import com.gigflex.prototype.microservices.organization.repository.OrganizationRepository;
import com.gigflex.prototype.microservices.proceduremaster.dtob.ProcedureMaster;
import com.gigflex.prototype.microservices.proceduremaster.repository.ProcedureMasterDao;
import com.gigflex.prototype.microservices.proceduremaster.repository.ProcedureSkillMappingDao;
import com.gigflex.prototype.microservices.users.dtob.Users;
import com.gigflex.prototype.microservices.util.GoogleDistanceDuration;
import com.gigflex.prototype.microservices.util.GoogleDistanceDurationResponse;
import com.gigflex.prototype.microservices.util.PushNotification;
import com.gigflex.prototype.microservices.util.SendNotification;
import com.gigflex.prototype.microservices.verifyemployee.dtob.WorkerApprovalStatus;
import com.gigflex.prototype.microservices.workerhoursofoperation.dtob.WorkerHoursOfOperation;
import com.gigflex.prototype.microservices.jobs.dtob.WorkerHoursOfOperationRes;
import com.gigflex.prototype.microservices.workerhoursofoperation.repository.WorkerHoursofOperationDao;
import com.gigflex.prototype.microservices.workertimeoff.repository.WorkerTimeOffDao;
import java.lang.reflect.Field;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.optaplanner.core.api.solver.Solver;
import org.optaplanner.core.api.solver.SolverFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import com.gigflex.prototype.microservices.jobs.dtob.CoveredDistanceRes;
import com.gigflex.prototype.microservices.jobs.service.AssignJobToWorkerDynamicDistanceThread;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/**
 *
 * @author nirbhay.p
 */
@Service
public class JobsServiceImpl implements JobsService {

    private static final Logger LOG = LoggerFactory.getLogger(JobsServiceImpl.class);
   
    @Autowired
    JobsRepository jobsRepository;

    @Autowired
    PatientDao patientDao;

    @Autowired
    JobsDurationRepository jobsDurationRepository;

    @Autowired
    JobsAssignToWorkerRepository jobsAssignToWorkerRepository;

    @Autowired
    TimeZoneRepository timeZoneDao;

    @Autowired
    GlobalSettingRepository globalSettingRepository;
    @Autowired
    LocalSettingRepository localSettingRepository;
    @Autowired
    UserTypeRepository utr;

    @Autowired
    WorkerApprovalStatusRepository workerApprovalStatusRepository;

    @Autowired
    OrgWorkerSkillDao orgWorkerSkillDao;
    @Autowired
    WorkerHoursofOperationDao workerHoursofOperationDao;
    @Autowired
    WorkerTimeOffDao workerTimeOffDao;
    @Autowired
    WorkerRepository workerRepository;
    @Autowired
    ProcedureSkillMappingDao procedureSkillMappingDao;
    @Autowired
    OrganizationRepository organizationRepository;
    @Autowired
    ProcedureMasterDao procedureMasterDao;

    @Autowired
    private HealthcareNotificationService notificationService;
    
    @Autowired
    private OrganizationRepository orgDao;
    
    @Autowired
    DeviceDetailRepository deviceDetailDao;

    @Value("${email.service.url}")
    private String mailServiceURL;
    //"http://18.223.158.6:8091/superadminservice/sendEmail/to/{to}/subject/{subject}/body/{body}";

    @Value("${email.jobservice.subject}")
    private String subject;
    
    @Value("${notification.fcm.url}")
    private String FMCurl; 

    @Value("${notification.fcm.authkey}")
    private String authKey;   
    
    @Value("${google.api.key}")
    private String googleKey;   

    public String genAppointmentID()
    {
        String rand="0l";
        JobsAssignToWorker b=null;
        do
        {
            rand=""+System.currentTimeMillis();
            b=jobsAssignToWorkerRepository.getJobsAssignToWorkerByAppointmentid(rand);
        }while(b!=null && b.getId()>0);
        return rand;
    }
    
    @Override
    public String createWorkerJob(JobsRequest jobr, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            Jobs job = new Jobs();
            PatientDetails pDetailResponse = null;
            if (jobr.getPatientCode() != null && jobr.getPatientCode().trim().length() > 0) {
                PatientResponse pRequest = jobr.getPatientDetail();
                PatientDetails pDetail = patientDao.getPatientDetailsBypatientCode(jobr.getPatientCode().trim());

                if (pDetail != null && pDetail.getId() > 0) {
                    if ((jobr.getPatientDetail() != null && jobr.getPatientDetail().getPatientName() != null && jobr.getPatientDetail().getPatientName().length() > 0
                            && jobr.getPatientDetail().getPatientLatitude() != null && jobr.getPatientDetail().getPatientLatitude().trim().length() > 0
                            && jobr.getPatientDetail().getPatientLongitude() != null && jobr.getPatientDetail().getPatientLongitude().trim().length() > 0
                            && jobr.getPatientDetail().getPhoneNumber() != null && jobr.getPatientDetail().getPhoneNumber().trim().length() > 0
                            && jobr.getPatientDetail().getPhoneCountryCode() != null && jobr.getPatientDetail().getPhoneCountryCode().trim().length() > 0
                            && jobr.getPatientDetail().getOrganizationCode() != null && jobr.getPatientDetail().getOrganizationCode().trim().length() > 0
                            && jobr.getPatientDetail().getPatientAddress() != null && jobr.getPatientDetail().getPatientAddress().trim().length() > 0)) {
                        pDetail.setPatientName(pRequest.getPatientName());
                        pDetail.setIpAddress(ip);
                        pDetail.setOrganizationCode(pRequest.getOrganizationCode());
                        pDetail.setPatientAddress(pRequest.getPatientAddress());
                        pDetail.setPatientCountry(pRequest.getPatientCountry());
                        pDetail.setPatientState(pRequest.getPatientState());
                        pDetail.setPatientCity(pRequest.getPatientCity());
                        pDetail.setZipCode(pRequest.getZipCode());
                        pDetail.setPatientLatitude(pRequest.getPatientLatitude());
                        pDetail.setPatientLongitude(pRequest.getPatientLongitude());
                        pDetail.setMobileNumber(pRequest.getMobileNumber());
                        pDetail.setPhoneNumber(pRequest.getPhoneNumber());
                        pDetail.setPatientEmail(pRequest.getPatientEmail());
                        pDetail.setmCountryCode(pRequest.getMobileCountryCode());
                        pDetail.setpCountryCode(pRequest.getPhoneCountryCode());
                        if (pRequest.isIsActive() != null) {
                            pDetail.setIsActive(pRequest.isIsActive());
                        } else {
                            pDetail.setIsActive(true);
                        }

                        pDetailResponse = patientDao.save(pDetail);
                    } else {
                        pDetailResponse = pDetail;
                    }

                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Patient Detail does not exist");
                    return jsonobj.toString();
                }

            } else {
                PatientResponse pRequest = jobr.getPatientDetail();

                PatientDetails pDetail = new PatientDetails();

                pDetail.setPatientName(pRequest.getPatientName());
                pDetail.setIpAddress(ip);
                pDetail.setOrganizationCode(pRequest.getOrganizationCode());
                pDetail.setPatientAddress(pRequest.getPatientAddress());
                pDetail.setPatientCountry(pRequest.getPatientCountry());
                pDetail.setPatientState(pRequest.getPatientState());
                pDetail.setPatientCity(pRequest.getPatientCity());
                pDetail.setZipCode(pRequest.getZipCode());
                pDetail.setPatientLatitude(pRequest.getPatientLatitude());
                pDetail.setPatientLongitude(pRequest.getPatientLongitude());
                pDetail.setMobileNumber(pRequest.getMobileNumber());
                pDetail.setPhoneNumber(pRequest.getPhoneNumber());
                pDetail.setPatientEmail(pRequest.getPatientEmail());
                pDetail.setmCountryCode(pRequest.getMobileCountryCode());
                pDetail.setpCountryCode(pRequest.getPhoneCountryCode());
                if (pRequest.isIsActive() != null) {
                    pDetail.setIsActive(pRequest.isIsActive());
                } else {
                    pDetail.setIsActive(true);
                }

                pDetailResponse = patientDao.save(pDetail);

            }

            if (pDetailResponse == null || pDetailResponse.getPatientCode() == null) {
                jsonobj.put("responsecode", 400);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Patient Details addition has been failed.");
                return jsonobj.toString();
            } else {
                job.setPatientCode(pDetailResponse.getPatientCode());
                Date sdt = null;
                Date edt = null;
                try {
                    sdt = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(jobr.getStartDate().trim());
                    edt = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(jobr.getEndDate().trim());
                } catch (Exception ee) {
                    LOG.error("Error in createWorkerJob>>>>>", ee);
                }
                if (sdt == null || edt == null) {
                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                            "Plz send start date and end date in correct format(" + GigflexConstants.YYYY_MM_DD + ")");
                    return derr.toString();
                } else {
                    if (sdt.after(edt)) {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Start date can not be after End date");
                        return derr.toString();
                    }
                }
                 String orgst =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobr.getOrganizationCode().trim(), GigflexConstants.ORG_WORKING_TIME_START);
                            String orgend =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobr.getOrganizationCode().trim(), GigflexConstants.ORG_WORKING_TIME_END);
                            if(orgst==null || orgend==null || orgst.trim().length()==0 ||  orgend.trim().length()==0 )
                            {
                                 GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Please set working time from setting.");
                                return derr.toString();
                            }
                            orgst=orgst.trim().length()==5?orgst.trim()+":00":orgst.trim();
                            orgend=orgend.trim().length()==5?orgend.trim()+":00":orgend.trim();
                            String startDTPeriodStr = jobr.getStartDate().trim() + " "+orgst;
                            Date startDTPeriod=GigflexDateUtil.convertStringToDate(startDTPeriodStr, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            String endDTPeriodStr = jobr.getStartDate().trim() + " "+orgend;
                            Date endDTPeriod=GigflexDateUtil.convertStringToDate(endDTPeriodStr, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            String checkSdtStr=jobr.getStartDate().trim() + " "+jobr.getStartTime().trim();
                            Date checkSdt=GigflexDateUtil.convertStringToDate(checkSdtStr, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            if(startDTPeriod==null || endDTPeriod==null || checkSdt==null)
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Exception is occurred in date parsing at validation.");
                                return derr.toString();
                            }
                            if(checkSdt.before(startDTPeriod))
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Job start time should be in Organization's working time.");
                                return derr.toString();
                            }
                            Calendar callck = Calendar.getInstance();
                callck.setTime(checkSdt);
                if (jobr.getDurationHours() != null && jobr.getDurationHours() > 0) {
                    callck.add(Calendar.HOUR_OF_DAY, jobr.getDurationHours());
                }
                if (jobr.getDurationMinute() != null && jobr.getDurationMinute() > 0) {
                    callck.add(Calendar.MINUTE, jobr.getDurationMinute());
                }
                Date checkEdt = callck.getTime();
                if(checkEdt.after(endDTPeriod))
                    {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Job duration time should be in Organization's working time.");
                                return derr.toString();
                    }
                
HashMap <Integer,String> dayCodeSettingMap=new HashMap<>();
                for(int i=1;i<=7;i++)
                {
                    String lookingForValue = "ORG_WORKING_DAY_";
                    lookingForValue += i;
                    String dayVal = null;
                    try {
                        Object clazz = new GigflexConstants();
                        Field field = clazz.getClass().getField(lookingForValue);
                        dayVal = (String) field.get(clazz);
                        if (dayVal != null) {
                            String dayValSt = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobr.getOrganizationCode().trim(), dayVal);
                            if (dayValSt != null) {
                                dayCodeSettingMap.put(i, dayValSt);
                            }
                        }
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }

                }
                
                if(jobr.getRepeatType().equalsIgnoreCase("Week"))
                {
                    for(Integer dl:jobr.getDaysList())
                    {
                        if(!dayCodeSettingMap.containsKey(dl))
                        {
                            GigflexResponse derr = new GigflexResponse(400, new Date(), GigflexDateUtil.getNameFromDayCode(dl)+" is not working day.");
                            return derr.toString();
                        }
                        else
                        {
                            if(!(dayCodeSettingMap.get(dl)!=null &&  dayCodeSettingMap.get(dl).equalsIgnoreCase("true")))
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),GigflexDateUtil.getNameFromDayCode(dl)+" is off day.");
                                return derr.toString();
                            }
                        }
                    }
                }
                
       HashMap <Date,Boolean> holidayOrgMap=new HashMap<>(); 
       try{
         
       String orgHoliday =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobr.getOrganizationCode().trim(), GigflexConstants.ORG_SPEC_NON_WORKING_DAYS);
       if(orgHoliday!=null && orgHoliday.trim().length()>0)
       {
           String holiarr[]=orgHoliday.split(",");
           for(int j=0;j<holiarr.length;j++)
           {
               String str=holiarr[j];
               if(str!=null)
               {
                   Date hdt=GigflexDateUtil.convertStringToDate(str.trim(), GigflexConstants.DD_MMMM_YYYY);
                   if(hdt!=null)
                   {
                       holidayOrgMap.put(hdt, Boolean.TRUE);
                   }
               }
           }
       }
             
       }
       catch(Exception eee)
       {
           eee.printStackTrace();
       }
            if(holidayOrgMap.containsKey(sdt)) 
            {
                 GigflexResponse derr = new GigflexResponse(400, new Date(),
                                jobr.getStartDate()+" is non working date.");
                                return derr.toString();
            }
            String timezone = null;
                    String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                    String dtFormatDate = GigflexConstants.YYYY_MM_DD;
                    String dtFormatView = dtFormat;
                    String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobr.getOrganizationCode().trim(), GigflexConstants.TimeZone);
                    String datefoemat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobr.getOrganizationCode().trim(), GigflexConstants.DATEFORMAT);
                    String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobr.getOrganizationCode().trim(), GigflexConstants.TIMEFORMAT);
                    if (datefoemat != null && datefoemat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                        dtFormatView = datefoemat.trim() + " " + timeformat.trim();
                    }
                    if (datefoemat != null && datefoemat.trim().length() > 0) {
                        dtFormatDate = datefoemat.trim();
                    }
                    if (timezoneCode != null && timezoneCode.length() > 0) {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                        if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                            timezone = tzd.getTimeZoneName();
                        }
                    }
                job.setEndDT(edt);
                job.setIpAddress(ip);
                job.setJobName(jobr.getJobName());
                job.setNotes(jobr.getNotes());
                job.setOrganizationCode(jobr.getOrganizationCode().trim());
                job.setProcedureCode(jobr.getProcedureCode().trim());
                job.setStartDT(sdt);
                if(jobr.getDaysList()!=null && jobr.getDaysList().size()>0)
                {
                    String dlst="";
                    int i=0;
                    for(Integer dl:jobr.getDaysList())
                    {
                        if(i==0)
                        {
                            dlst=""+dl;
                        }else
                        {
                            dlst+=","+dl;
                        }
                        i++;
                    }
                job.setDaysList(dlst);
                }
                if(jobr.getDurationHours()!=null)
                {
                job.setDurationHours(jobr.getDurationHours());
                }
                else
                {
                  job.setDurationHours(0);  
                }
                if(jobr.getDurationMinute()!=null)
                {
                job.setDurationMinute(jobr.getDurationMinute());
                }
                else
                {
                  job.setDurationMinute(0);
                }
                
                job.setIsDateOfMonth(jobr.getIsDateOfMonth());
                job.setRepeatType(jobr.getRepeatType());
                job.setRepeatValue(jobr.getRepeatValue());
                job.setStartTime(jobr.getStartTime().trim());
                Jobs jobres = jobsRepository.save(job);
                if (jobres != null && jobres.getId() > 0) {

                    List<JobsDuration> jdurLst = new ArrayList<JobsDuration>();
                    List<JobsDurationRes> jdurResLst = new ArrayList<JobsDurationRes>();
                    HashMap<String, String> mapJobDurationTime = new HashMap<>();
                    Boolean st = false;
                    
                    JobsRes jres = new JobsRes();
                    jres.setEndDT(GigflexDateUtil.convertDateToString(jobres.getEndDT(), dtFormatDate));
                    jres.setEndDTStamp(jobres.getEndDT());
                    jres.setId(jobres.getId());
                    jres.setJobName(jobres.getJobName());
                    jres.setJobsCode(jobres.getJobsCode());
                    jres.setNotes(jobres.getNotes());
                    jres.setOrganizationCode(jobres.getOrganizationCode());
                    jres.setPatientCode(jobres.getPatientCode());
                    jres.setProcedureCode(jobres.getProcedureCode());
                    jres.setStartDT(GigflexDateUtil.convertDateToString(jobres.getStartDT(), dtFormatDate));
                    jres.setStartDTStamp(jobres.getStartDT());
                    jres.setDaysList(jobres.getDaysList());
                    String jobDurationHours = "";
                    if(jobres.getDurationHours() < 10)
                    {
                        StringBuilder durationBuilder = new StringBuilder();
                        durationBuilder.append("0");
                        durationBuilder.append(jobres.getDurationHours().toString()) ;
                        jobDurationHours = durationBuilder.toString();
                    }
                    else
                    {
                        jobDurationHours = jobres.getDurationHours().toString();
                    }
                    jres.setDurationHours(jobDurationHours);

                    String jobDurationMinute = "";
                    if(jobres.getDurationMinute() < 10)
                    {
                        StringBuilder minuteBuilder = new StringBuilder();
                        minuteBuilder.append("0");
                        minuteBuilder.append(jobres.getDurationMinute().toString()) ;
                        jobDurationMinute = minuteBuilder.toString();
                    }
                    else
                    {
                        jobDurationMinute = jobres.getDurationMinute().toString();
                    }
                    jres.setDurationMinute(jobDurationMinute);
                    jres.setIsDateOfMonth(jobres.getIsDateOfMonth());
                    jres.setRepeatType(jobres.getRepeatType());
                    jres.setRepeatValue(jobres.getRepeatValue());
                    jres.setStartTime(jobres.getStartTime());

                    if (timezone != null && timezone.length() > 0) {

                        if (jobr.getRepeatType().equalsIgnoreCase("Day")) {
                            do {
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(sdt);
                                System.out.println(">>>" + sdt);

                                try {

                                    String dtStr = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).format(sdt);
                                    String sdtStr = dtStr + " " + jobr.getStartTime().trim();
                                    //String edtStr=dtStr+" "+jobr.getEndTime().trim(); 
                                    boolean boolstm = GigflexDateUtil.validateDateFormat(sdtStr, dtFormat);
                                    //boolean booletm=   GigflexDateUtil.validateDateFormat(edtStr,dtFormat);
                                    if (boolstm == true) //&& booletm==true)
                                    {
                                        if(!(holidayOrgMap.containsKey(sdt)) )
                                        {
                                        Date chkdt=GigflexDateUtil.convertStringToDate(sdtStr, dtFormat);
                                        Calendar calint = Calendar.getInstance();
                                        calint.setTime(chkdt);
                                        Integer day=calint.get(Calendar.DAY_OF_WEEK);
                                        Boolean stck=true;
                                        if(!dayCodeSettingMap.containsKey(day))
                                        {
                                            stck=false;
                                        }
                                        else
                                        {
                                            if(!(dayCodeSettingMap.get(day)!=null && dayCodeSettingMap.get(day).equalsIgnoreCase("true")))
                                            {
                                                stck=false;
                                            }
                                        }
                                        if(stck)
                                        {
                                        Date sdtm = null;// new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getStartTime().trim());
                                        Date edtm = null;//new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getEndTime().trim());

                                        sdtm = GigflexDateUtil.convertStringDateToGMT(sdtStr, timezone, dtFormat);
                                        Calendar call = Calendar.getInstance();
                                        call.setTime(sdtm);
                                        if (jobr.getDurationHours() != null && jobr.getDurationHours() > 0) {
                                            call.add(Calendar.HOUR_OF_DAY, jobr.getDurationHours());
                                        }
                                        if (jobr.getDurationMinute() != null && jobr.getDurationMinute() > 0) {
                                            call.add(Calendar.MINUTE, jobr.getDurationMinute());
                                        }
                                        edtm = call.getTime(); //GigflexDateUtil.convertStringDateToGMT(edtStr, timezone,dtFormat);
                                        Date curDt=new Date();
                                        if (sdtm != null && edtm != null && edtm.after(sdtm) && sdtm.after(curDt)) {
                                            JobsDuration jdur = new JobsDuration();
                                            jdur.setEndTime(edtm);
                                            jdur.setIpAddress(ip);
                                            jdur.setJobsCode(jobres.getJobsCode());
                                            jdur.setStartTime(sdtm);
                                            jdur.setDurationHours(jobr.getDurationHours());
                                            jdur.setDurationMinute(jobr.getDurationMinute());
                                            jdur.setJobName(jobr.getJobName());
                                            jdur.setNotes(jobr.getNotes());
                                            JobsDuration jdurRes = jobsDurationRepository.save(jdur);
                                            if (jdurRes != null && jdurRes.getId() > 0) {
                                                jdurLst.add(jdurRes);
                                                JobsDurationRes jobsdurRes = new JobsDurationRes();
                                                jobsdurRes.setId(jdurRes.getId());
                                                jobsdurRes.setJobsCode(jdurRes.getJobsCode());
                                                jobsdurRes.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                Date stDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getStartTime(), timezone, dtFormatView);
                                                String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                                                Date endDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getEndTime(), timezone, dtFormatView);
                                                String endDatestr = GigflexDateUtil.convertDateToString(endDate, dtFormatView);
                                                jobsdurRes.setEndTime(endDatestr);
                                                jobsdurRes.setStartTime(stDatestr);
                                                mapJobDurationTime.put(jdurRes.getJobsDurationCode(), stDatestr);
                                                jobsdurRes.setJobName(jdurRes.getJobName());
                                                jobsdurRes.setNotes(jdurRes.getNotes());
                                                jdurResLst.add(jobsdurRes);
                                                JobsAssignToWorker jtw = new JobsAssignToWorker();
                                                jtw.setIpAddress(ip);
                                                jtw.setJobsCode(jobres.getJobsCode());
                                                jtw.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                jtw.setStatus(GigflexConstants.JOBSTATUS_PENDING);
                                                jtw.setAppointmentId( genAppointmentID());
                                                JobsAssignToWorker jtwRes = jobsAssignToWorkerRepository.save(jtw);
                                                if (jtwRes != null && jtwRes.getId() > 0) {
                                                    st = Boolean.TRUE;
                                                }

                                            }
                                        }
                                    }
                                    }
                                    }

                                } catch (Exception ee) {
                                    LOG.error("Error in createWorkerJob>>>>>", ee);
                                }

                                cal.add(Calendar.DAY_OF_MONTH, jobr.getRepeatValue());
                                sdt = cal.getTime();

                            } while (!(sdt.after(edt)));
                        } else if (jobr.getRepeatType().equalsIgnoreCase("Week")) {
                            do {
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(sdt);
                                int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
                                try {
                                    
                                    if (jobr.getDaysList().contains(dayOfWeek)) {
                                        String dtStr = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).format(sdt);
                                        String sdtStr = dtStr + " " + jobr.getStartTime().trim();
                                        //String edtStr=dtStr+" "+jobr.getEndTime().trim(); 
                                        boolean boolstm = GigflexDateUtil.validateDateFormat(sdtStr, dtFormat);
                                        //boolean booletm=   GigflexDateUtil.validateDateFormat(edtStr,dtFormat);
                                        if (boolstm == true) //&& booletm==true)
                                        {
                                        if(!(holidayOrgMap.containsKey(sdt)) )
                                        {
                                        Date chkdt=GigflexDateUtil.convertStringToDate(sdtStr, dtFormat);
                                        Calendar calint = Calendar.getInstance();
                                        calint.setTime(chkdt);
                                        Integer day=calint.get(Calendar.DAY_OF_WEEK);
                                        Boolean stck=true;
                                        if(!dayCodeSettingMap.containsKey(day))
                                        {
                                            stck=false;
                                        }
                                        else
                                        {
                                            if(!(dayCodeSettingMap.get(day)!=null && dayCodeSettingMap.get(day).equalsIgnoreCase("true")))
                                            {
                                                stck=false;
                                            }
                                        }
                                        if(stck)
                                        {
                                            Date sdtm = null;// new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getStartTime().trim());
                                            Date edtm = null;//new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getEndTime().trim());

                                            sdtm = GigflexDateUtil.convertStringDateToGMT(sdtStr, timezone, dtFormat);
                                            Calendar call = Calendar.getInstance();
                                            call.setTime(sdtm);
                                            if (jobr.getDurationHours() != null && jobr.getDurationHours() > 0) {
                                                call.add(Calendar.HOUR_OF_DAY, jobr.getDurationHours());
                                            }
                                            if (jobr.getDurationMinute() != null && jobr.getDurationMinute() > 0) {
                                                call.add(Calendar.MINUTE, jobr.getDurationMinute());
                                            }
                                            edtm = call.getTime(); //GigflexDateUtil.convertStringDateToGMT(edtStr, timezone,dtFormat);
                                            Date curDt=new Date();
                                        if (sdtm != null && edtm != null && edtm.after(sdtm) && sdtm.after(curDt)) {
                                                JobsDuration jdur = new JobsDuration();
                                                jdur.setEndTime(edtm);
                                                jdur.setIpAddress(ip);
                                                jdur.setJobsCode(jobres.getJobsCode());
                                                jdur.setStartTime(sdtm);
                                                jdur.setDurationHours(jobr.getDurationHours());
                                                jdur.setDurationMinute(jobr.getDurationMinute());
                                                jdur.setJobName(jobr.getJobName());
                                                jdur.setNotes(jobr.getNotes());
                                                JobsDuration jdurRes = jobsDurationRepository.save(jdur);
                                                if (jdurRes != null && jdurRes.getId() > 0) {
                                                    jdurLst.add(jdurRes);
                                                    JobsDurationRes jobsdurRes = new JobsDurationRes();
                                                    jobsdurRes.setId(jdurRes.getId());
                                                    jobsdurRes.setJobsCode(jdurRes.getJobsCode());
                                                    jobsdurRes.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                    Date stDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getStartTime(), timezone, dtFormatView);
                                                    String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                                                    Date endDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getEndTime(), timezone, dtFormatView);
                                                    String endDatestr = GigflexDateUtil.convertDateToString(endDate, dtFormatView);
                                                    jobsdurRes.setEndTime(endDatestr);
                                                    jobsdurRes.setStartTime(stDatestr);
                                                    mapJobDurationTime.put(jdurRes.getJobsDurationCode(), stDatestr);
                                                    jobsdurRes.setJobName(jdurRes.getJobName());
                                                    jobsdurRes.setNotes(jdurRes.getNotes());
                                                    jdurResLst.add(jobsdurRes);
                                                    JobsAssignToWorker jtw = new JobsAssignToWorker();
                                                    jtw.setIpAddress(ip);
                                                    jtw.setJobsCode(jobres.getJobsCode());
                                                    jtw.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                    jtw.setStatus(GigflexConstants.JOBSTATUS_PENDING);
                                                    jtw.setAppointmentId( genAppointmentID());
                                                    JobsAssignToWorker jtwRes = jobsAssignToWorkerRepository.save(jtw);
                                                    if (jtwRes != null && jtwRes.getId() > 0) {
                                                        st = Boolean.TRUE;
                                                    }

                                                }
                                            }
                                        }
                                        }
                                        }
                                    }
                                } catch (Exception ee) {
                                    LOG.error("Error in createWorkerJob>>>>>", ee);
                                }

                                int incr = 1;
                                if (dayOfWeek == 7) {
                                    incr = ((jobr.getRepeatValue() - 1) * dayOfWeek) + incr;
                                    cal.add(Calendar.DAY_OF_MONTH, incr);
                                } else {
                                    cal.add(Calendar.DAY_OF_MONTH, incr);
                                }
                                sdt = cal.getTime();

                            } while (!(sdt.after(edt)));
                        } else if (jobr.getRepeatType().equalsIgnoreCase("Month")) {
                            do {
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(sdt);
                                int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
                                int weekOfMonth = cal.get(Calendar.WEEK_OF_MONTH);

                                try {
                                    String dtStr = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).format(sdt);
                                    String sdtStr = dtStr + " " + jobr.getStartTime().trim();
                                    //String edtStr=dtStr+" "+jobr.getEndTime().trim(); 
                                    boolean boolstm = GigflexDateUtil.validateDateFormat(sdtStr, dtFormat);
                                    //boolean booletm=   GigflexDateUtil.validateDateFormat(edtStr,dtFormat);
                                    if (boolstm == true) //&& booletm==true)
                                    {
                                        if(!(holidayOrgMap.containsKey(sdt)) )
                                        {
                                        Date chkdt=GigflexDateUtil.convertStringToDate(sdtStr, dtFormat);
                                        Calendar calint = Calendar.getInstance();
                                        calint.setTime(chkdt);
                                        Integer day=calint.get(Calendar.DAY_OF_WEEK);
                                        Boolean stck=true;
                                        if(!dayCodeSettingMap.containsKey(day))
                                        {
                                            stck=false;
                                        }
                                        else
                                        {
                                            if(!(dayCodeSettingMap.get(day)!=null && dayCodeSettingMap.get(day).equalsIgnoreCase("true")))
                                            {
                                                stck=false;
                                            }
                                        }
                                        if(stck)
                                        {
                                        Date sdtm = null;// new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getStartTime().trim());
                                        Date edtm = null;//new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getEndTime().trim());

                                        sdtm = GigflexDateUtil.convertStringDateToGMT(sdtStr, timezone, dtFormat);
                                        Calendar call = Calendar.getInstance();
                                        call.setTime(sdtm);
                                        if (jobr.getDurationHours() != null && jobr.getDurationHours() > 0) {
                                            call.add(Calendar.HOUR_OF_DAY, jobr.getDurationHours());
                                        }
                                        if (jobr.getDurationMinute() != null && jobr.getDurationMinute() > 0) {
                                            call.add(Calendar.MINUTE, jobr.getDurationMinute());
                                        }
                                        edtm = call.getTime(); //GigflexDateUtil.convertStringDateToGMT(edtStr, timezone,dtFormat);
                                        Date curDt=new Date();
                                        if (sdtm != null && edtm != null && edtm.after(sdtm) && sdtm.after(curDt)) {
                                            JobsDuration jdur = new JobsDuration();
                                            jdur.setEndTime(edtm);
                                            jdur.setIpAddress(ip);
                                            jdur.setJobsCode(jobres.getJobsCode());
                                            jdur.setStartTime(sdtm);
                                            jdur.setDurationHours(jobr.getDurationHours());
                                            jdur.setDurationMinute(jobr.getDurationMinute());
                                            jdur.setJobName(jobr.getJobName());
                                            jdur.setNotes(jobr.getNotes());
                                            JobsDuration jdurRes = jobsDurationRepository.save(jdur);
                                            if (jdurRes != null && jdurRes.getId() > 0) {
                                                jdurLst.add(jdurRes);
                                                JobsDurationRes jobsdurRes = new JobsDurationRes();
                                                jobsdurRes.setId(jdurRes.getId());
                                                jobsdurRes.setJobsCode(jdurRes.getJobsCode());
                                                jobsdurRes.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                Date stDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getStartTime(), timezone, dtFormatView);
                                                String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                                                Date endDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getEndTime(), timezone, dtFormatView);
                                                String endDatestr = GigflexDateUtil.convertDateToString(endDate, dtFormatView);
                                                jobsdurRes.setEndTime(endDatestr);
                                                jobsdurRes.setStartTime(stDatestr);
                                                mapJobDurationTime.put(jdurRes.getJobsDurationCode(), stDatestr);
                                                jobsdurRes.setJobName(jdurRes.getJobName());
                                                jobsdurRes.setNotes(jdurRes.getNotes());
                                                jdurResLst.add(jobsdurRes);
                                                JobsAssignToWorker jtw = new JobsAssignToWorker();
                                                jtw.setIpAddress(ip);
                                                jtw.setJobsCode(jobres.getJobsCode());
                                                jtw.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                jtw.setStatus(GigflexConstants.JOBSTATUS_PENDING);
                                                jtw.setAppointmentId( genAppointmentID());
                                                JobsAssignToWorker jtwRes = jobsAssignToWorkerRepository.save(jtw);
                                                if (jtwRes != null && jtwRes.getId() > 0) {
                                                    st = Boolean.TRUE;
                                                }

                                            }
                                        }
                                        }
                                        }
                                    }

                                } catch (Exception ee) {
                                    LOG.error("Error in createWorkerJob>>>>>", ee);
                                }

                                cal.add(Calendar.MONTH, jobr.getRepeatValue());
                                if (!(jobr.getIsDateOfMonth())) {
                                    cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
                                    cal.set(Calendar.WEEK_OF_MONTH, weekOfMonth);
                                    cal.set(Calendar.DAY_OF_WEEK, dayOfWeek);
                                }

                                sdt = cal.getTime();

                            } while (!(sdt.after(edt)));
                        }

                    }
                    if (st && (jdurLst != null && jdurLst.size() > 0)) {
                        boolean manualassign = true;
                        String autoass = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.FULLTIME_STAFF_AUTO_ASSIGN);
                        if (autoass != null && autoass.trim().length() > 0 && autoass.equalsIgnoreCase("true")) {
                            manualassign = false;
                        }
                        //for manual assignment
                        if (manualassign) {
                            List<EligibleWorkerRes> ewresLst = getEligibleWorkerForManualAssignment(jobres, jdurLst, pDetailResponse,mapJobDurationTime);
                            JobManualResponse jmres = new JobManualResponse();
                            jmres.setJobsDurationResList(jdurResLst);
                            jmres.setJobsRes(jres);
                            jmres.setEligibleWorkerResList(ewresLst);
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("manualAssignment", true);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Job creation has been done.");
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(jmres);
                            jsonobj.put("data", new JSONObject(Detail));
                        } else {//for automatic assignment

                            List<EligibleWorkerRes> ewresLst = autoJobAssignmentToWorker(jobres, jdurLst, pDetailResponse,mapJobDurationTime,timezone);
                            JobManualResponse jmres = new JobManualResponse();
                            jmres.setJobsDurationResList(jdurResLst);
                            jmres.setJobsRes(jres);
                            jmres.setEligibleWorkerResList(ewresLst);
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("manualAssignment", false);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Job creation has been done.");
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(jmres);
                            jsonobj.put("data", new JSONObject(Detail));
                        }

                    } else {
                        jobsRepository.deleteById(jobres.getId());
                        jsonobj.put("responsecode", 400);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Job creation has been failed.");
                    }
                } else {
                    jsonobj.put("responsecode", 400);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job creation has been failed.");
                }
            }

            res = jsonobj.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred");
            res = derr.toString();
            LOG.error("Error in createWorkerJob>>>>>", e);
        }
        return res;
    }

    public List<EligibleWorkerRes> autoJobAssignmentToWorker(Jobs jobres, List<JobsDuration> jdurLst, PatientDetails pDetail,HashMap<String, String> mapJobDurationTime,String orgTimeZone) {
        List<EligibleWorkerRes> ewresLst = new ArrayList<EligibleWorkerRes>();
        String patientLat = null;
        String patientLan = null;
        if (pDetail != null && pDetail.getPatientLatitude() != null && pDetail.getPatientLatitude().trim().length() > 0 && pDetail.getPatientLongitude() != null && pDetail.getPatientLongitude().trim().length() > 0) {
            try {
                patientLat = pDetail.getPatientLatitude().trim();
                patientLan = pDetail.getPatientLongitude().trim();
            } catch (Exception ex) {
                LOG.error("Error in getEligibleWorkerForManualAssignment", ex);
            }
        }
        List<String> skills = procedureSkillMappingDao.getProcedureSkillCodesByProcedureCode(jobres.getProcedureCode());

        List<Worker> workerList = workerApprovalStatusRepository.getAllApprovedWorkerOnlyByOrgCode(jobres.getOrganizationCode());
        if (workerList.size() > 0 && skills.size() > 0) {
            try {
                ScheduleAssignement unsolvedSchedule = new ScheduleAssignement();
                List<com.gigflex.prototype.microservices.jobs.optaplanner.Worker> wlst = new ArrayList<com.gigflex.prototype.microservices.jobs.optaplanner.Worker>();
                for (Worker wkr : workerList) {
                    com.gigflex.prototype.microservices.jobs.optaplanner.Worker w = new com.gigflex.prototype.microservices.jobs.optaplanner.Worker();
                    w.setWorkerCode(wkr.getWorkerCode());
                    List<WorkerTimeOff> workerTimeOffList = new ArrayList<WorkerTimeOff>();
                    try {
                        Date jdStartime = null;
                        Date jdEndTime = null;
                        String sdtStr = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).format(jobres.getStartDT());
                        String fullsdtStr = sdtStr + " 00:00:00";
                        jdStartime = new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(fullsdtStr);
                        String edtStr = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).format(jobres.getEndDT());
                        String fulledtStr = edtStr + " 23:59:59";
                        jdEndTime = new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(fulledtStr);
                        workerTimeOffList = workerTimeOffDao.getTimeOffByWorkerCodeAndBetweenDateTimeStamp(wkr.getWorkerCode(), jdStartime, jdEndTime);
                    } catch (Exception ee) {
                        LOG.error("Error in autoJobAssignmentToWorker>>>", ee);
                    }
                    w.setWorkertimeof(workerTimeOffList);
                    List<String> workerskills = orgWorkerSkillDao.getSkillCodeListByworkerCode(wkr.getWorkerCode());
                    w.setSkillList(workerskills);
                    String timezone=null;
                    String timezoneCode = GigflexUtility.findSettingValueByNameFromLocal(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, wkr.getWorkerCode(), GigflexConstants.TimeZone);
                    if (timezoneCode != null && timezoneCode.length() > 0) {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                        if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                            timezone = tzd.getTimeZoneName();
                        }
                    }
                    if(timezone==null || timezone.isEmpty())
                    {
                        timezone=orgTimeZone;
                    }
                    w.setWorkerTimeZone(timezone);
                    List<WorkerHoursOfOperation> whoplst=workerHoursofOperationDao.getHoursByWorkerCode(wkr.getWorkerCode());
                    HashMap <Integer,WorkerHoursOfOperation> workerHOPMap=new HashMap<>();
                    if(whoplst!=null && whoplst.size()>0)
                    {
                        for(WorkerHoursOfOperation hop:whoplst)
                        {
                            if(hop.getDayCode()!=null)
                            {
                                workerHOPMap.put(hop.getDayCode(), hop);
                            }
                        }
                    }
                    w.setWorkerHOPMap(workerHOPMap);
                    if (wkr.getLatitude() != null && wkr.getLatitude().trim().length() > 0 && wkr.getLongitude() != null && wkr.getLongitude().trim().length() > 0) {
                       w.setLang( wkr.getLongitude().trim());
                       w.setLat(wkr.getLatitude().trim());
                    }
                    
                    wlst.add(w);
                }
                unsolvedSchedule.setWorkerList(wlst);
                List<com.gigflex.prototype.microservices.jobs.optaplanner.Schedule> slst = new ArrayList<com.gigflex.prototype.microservices.jobs.optaplanner.Schedule>();

                for (JobsDuration jd : jdurLst) {

                    com.gigflex.prototype.microservices.jobs.optaplanner.Schedule ss = new com.gigflex.prototype.microservices.jobs.optaplanner.Schedule(jd.getId(), jd.getJobsCode(), jd.getJobsDurationCode(), skills, jd.getStartTime(), jd.getEndTime(), patientLat, patientLan, jobsAssignToWorkerRepository,googleKey,orgTimeZone,GigflexConstants.WORKING_DISTANCE_IN_MILES);
                    slst.add(ss);

                }
                if (slst != null && slst.size() > 0) {
                    unsolvedSchedule.setScheduleList(slst);
                    SolverFactory<ScheduleAssignement> solverFactory = SolverFactory.createFromXmlResource("ScheduleSolverConfiguration.xml");
                    Solver<ScheduleAssignement> solver = solverFactory.buildSolver();
                    ScheduleAssignement solvedCourseSchedule = solver.solve(unsolvedSchedule);
                    if (solvedCourseSchedule != null && solvedCourseSchedule.getScheduleList() != null && solvedCourseSchedule.getScheduleList().size() > 0) {
                        List<com.gigflex.prototype.microservices.jobs.optaplanner.Schedule> slstRes = solvedCourseSchedule.getScheduleList();
                        for (com.gigflex.prototype.microservices.jobs.optaplanner.Schedule ss : slstRes) {
                            EligibleWorkerRes ewres = new EligibleWorkerRes();
                            ewres.setJobsCode(ss.getJobCode());
                            ewres.setJobsDurationCode(ss.getJobDurationCode());
                            String stdt="";
                            if(mapJobDurationTime.containsKey(ss.getJobDurationCode()) )
                                {
                                    stdt=mapJobDurationTime.get(ss.getJobDurationCode());
                                }
                            ewres.setJobDurationStartTime(stdt);
                            List<WorkerWithDistance> eligWorkerLst = new ArrayList<WorkerWithDistance>();
                            if (ss.getWorker() != null && ss.getWorker().getWorkerCode() != null) {
                                Worker wkr = workerRepository.getWorkerdetailByworkerCode(ss.getWorker().getWorkerCode());
                                if (wkr != null && wkr.getId() > 0) {
                                    JobsAssignToWorker jwtwRes = null;
                                    JobsAssignToWorker jwtw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsCodeAndJobsDurationCode(ss.getJobCode(), ss.getJobDurationCode());
                                    if (jwtw == null) {
                                        JobsAssignToWorker jtw = new JobsAssignToWorker();
                                        jtw.setJobsCode(ss.getJobCode());
                                        jtw.setJobsDurationCode(ss.getJobDurationCode());
                                        jtw.setStatus(GigflexConstants.JOBSTATUS_ACCEPTED);
                                        jtw.setWorkerCode(wkr.getWorkerCode());
                                        if (ss.getDistance() != null) {
                                            jtw.setDistance(ss.getDistance());
                                        }
                                        jwtwRes = jobsAssignToWorkerRepository.save(jtw);

                                    } else {
                                        jwtw.setStatus(GigflexConstants.JOBSTATUS_ACCEPTED);
                                        jwtw.setWorkerCode(wkr.getWorkerCode());
                                        if (ss.getDistance() != null) {
                                            jwtw.setDistance(ss.getDistance());
                                        }
                                        jwtwRes = jobsAssignToWorkerRepository.save(jwtw);
                                    }
                                    if (jwtwRes != null && jwtwRes.getId() > 0) {
                                        WorkerWithDistance wwd = new WorkerWithDistance();
                                        wwd.setWorker(wkr);
                                        wwd.setDistance(ss.getDistance());
                                        
                                        eligWorkerLst.add(wwd);
                                        if(jwtwRes.getWorkerCode()!=null)
                                        {
                                        //startAssignJobToWorkerDynamicDistanceThread(wkr,jobres.getOrganizationCode(),ss.getFromdate(),orgTimeZone);
                                        }
                                        startJobMailNotificationThread(false,jwtwRes,subject,"Dear technician,<br><br>Job has been assigned and auto accepted to you. Details are given below-<br>");
                                        
                                       
                                        
                                        
                                        
                                    }
                                }
                            }
                            ewres.setWorkerWithDistanceList(eligWorkerLst);
                            ewresLst.add(ewres);
                        }
                    }
                }
            } catch (Exception ex) {
                LOG.error("Error in optaplanner calling>>>>", ex);
            }
        }

        return ewresLst;
    }

    public List<EligibleWorkerRes> getEligibleWorkerForManualAssignment(Jobs jobres, List<JobsDuration> jdurLst, PatientDetails pDetail,HashMap<String, String> mapJobDurationTime) {

        List<EligibleWorkerRes> ewresLst = new ArrayList<EligibleWorkerRes>();
        
        List<String> skills = procedureSkillMappingDao.getProcedureSkillCodesByProcedureCode(jobres.getProcedureCode());
        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode().trim(), GigflexConstants.TimeZone);
        String orgtimezone=null;
                    if (timezoneCode != null && timezoneCode.length() > 0) {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                        if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                            orgtimezone = tzd.getTimeZoneName();
                        }
                    }
        List<String> workerCodeList = workerApprovalStatusRepository.getAllApprovedWorkerCodesByOrgCode(jobres.getOrganizationCode());
        if (workerCodeList.size() > 0 && skills.size() > 0) {
            for (JobsDuration jd : jdurLst) {
                EligibleWorkerRes ewres = new EligibleWorkerRes();
                ewres.setJobsCode(jd.getJobsCode());
                ewres.setJobsDurationCode(jd.getJobsDurationCode());
                String stdt = "";
                if (mapJobDurationTime.containsKey(jd.getJobsDurationCode())) {
                    stdt = mapJobDurationTime.get(jd.getJobsDurationCode());
                }
                ewres.setJobDurationStartTime(stdt);
                List<String> workerList = new ArrayList<String>();
                workerList.addAll(workerCodeList);
                List<WorkerWithDistance> eligWorkerLst = new ArrayList<WorkerWithDistance>();
                Date jdStartime = jd.getStartTime();
                Date jdEndTime = jd.getEndTime();
                Calendar cal = Calendar.getInstance();

                cal.setTime(jdStartime);
                cal.add(Calendar.HOUR_OF_DAY, -1);
                Date decrementedjdStartime = cal.getTime();

                cal.setTime(jdEndTime);
                cal.add(Calendar.HOUR_OF_DAY, 1);
                Date incrementedjdEndTime = cal.getTime();
                List<String> busyWorkerList = jobsAssignToWorkerRepository.getBusyWorkerList(decrementedjdStartime, incrementedjdEndTime, workerList, GigflexConstants.JOBSTATUS_CANCELLED, GigflexConstants.JOBSTATUS_REJECTED);
                workerList.removeAll(busyWorkerList);
                for (String workerCode : workerList) {
                    WorkerWithDistance eligWorker = new WorkerWithDistance();
                    List<String> matchedskills = orgWorkerSkillDao.getSkillCodeListByworkerCodeAndSkills(workerCode, skills);
                    if (matchedskills.size() < skills.size()) {
                        continue;
                    }

                    List<WorkerTimeOff> workerTimeOffList = workerTimeOffDao.getTimeOffByWorkerCodeAndBetweenDateTimeStamp(workerCode, jdStartime, jdEndTime);
                    if (workerTimeOffList != null && workerTimeOffList.size() > 0) {
                        continue;
                    }
                    
                    String timezone=null;
                    String timezoneCodeW = GigflexUtility.findSettingValueByNameFromLocal(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician,workerCode, GigflexConstants.TimeZone);
                    if (timezoneCodeW != null && timezoneCodeW.length() > 0) {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCodeW);
                        if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                            timezone = tzd.getTimeZoneName();
                        }
                    }
                    if(timezone==null || timezone.isEmpty())
                    {
                        timezone=orgtimezone;
                    }
                    
                    
                    
                    Boolean hopNot=false;
                Date timestampStartTime =null;
               try{
               timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(jd.getStartTime(), orgtimezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
               
                   if (timestampStartTime != null) {
                       String stDate=GigflexDateUtil.convertDateToString(timestampStartTime, GigflexConstants.YYYY_MM_DD);
                       if(stDate!=null)
                       {
                       Calendar call = Calendar.getInstance();
                       call.setTime(timestampStartTime);
                       int day = call.get(Calendar.DAY_OF_WEEK);
                     
                          
                             WorkerHoursOfOperation whop= workerHoursofOperationDao.getHoursByWorkerCodeAndDayCode(workerCode, day);
                              if(whop!=null && whop.getFromTime()!=null && whop.getFromTime().length()>0 && whop.getToTime()!=null && whop.getToTime().length()>0)
                              {
                              String startDT = stDate + " "+whop.getFromTime();
                              String endDT = stDate + " "+whop.getToTime();
                            
                              Date  sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                              Date  eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS); 
                              if(sDT!=null && eDT!=null)
                              {
                                  if(sDT.after(jd.getStartTime()))
                                  {
                                      hopNot=true;
                                  }
                                  if(eDT.before(jd.getEndTime()))
                                  {
                                     hopNot=true; 
                                  }
                              }
                              }
                      
                       }
                   }
               }catch(Exception e)
               {
                   e.printStackTrace();
                   LOG.error("Error in geteligible date conversion>>>", e);
               }
               
               if(hopNot)
               {
                   continue;
               }
                   
                    Worker wkr = workerRepository.getWorkerdetailByworkerCode(workerCode);
                    if (wkr != null && wkr.getId() > 0) {
                        eligWorker.setWorker(wkr);
                       
                        Double workerLat = null;
                        Double workerLan = null;

                        if (wkr.getLatitude() != null && wkr.getLatitude().trim().length() > 0 && wkr.getLongitude() != null && wkr.getLongitude().trim().length() > 0) {
                            try {
                                workerLat = Double.parseDouble(wkr.getLatitude().trim());
                                workerLan = Double.parseDouble(wkr.getLongitude().trim());
                            } catch (Exception ex) {
                                LOG.error("Error in getEligibleWorkerForManualAssignment", ex);
                            }
                        }
                        if (pDetail != null && pDetail.getPatientLatitude() != null && pDetail.getPatientLatitude().trim().length() > 0 && pDetail.getPatientLongitude() != null && pDetail.getPatientLongitude().trim().length() > 0&& wkr.getLatitude() != null && wkr.getLatitude().trim().length() > 0 && wkr.getLongitude() != null && wkr.getLongitude().trim().length() > 0) {
                            Double distance = distance(pDetail.getPatientLatitude().trim(), pDetail.getPatientLongitude().trim(), wkr.getLatitude().trim(), wkr.getLongitude().trim());
                            eligWorker.setDistance(distance);
                        }
                        eligWorkerLst.add(eligWorker);
                    }

                }
                ewres.setWorkerWithDistanceList(eligWorkerLst);
                ewresLst.add(ewres);
            }
        }

        return ewresLst;
    }

    @Override
    public String getWorkerJobById(Long id) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            Jobs jobres = jobsRepository.getJobsById(id);
            if (jobres != null && jobres.getId() > 0) {
                String timezone = null;
                String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                String dtFormatDate = GigflexConstants.YYYY_MM_DD;
                String dtFormatView = dtFormat;
                String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.TimeZone);
                String datefoemat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                if (datefoemat != null && datefoemat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                    dtFormatView = datefoemat.trim() + " " + timeformat.trim();
                }
                if (datefoemat != null && datefoemat.trim().length() > 0) {
                    dtFormatDate = datefoemat.trim();
                }
                if (timezoneCode != null && timezoneCode.length() > 0) {
                    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                        timezone = tzd.getTimeZoneName();
                    }
                }
                JobsRes jres = new JobsRes();
                jres.setEndDT(GigflexDateUtil.convertDateToString(jobres.getEndDT(), dtFormatDate));
                jres.setEndDTStamp(jobres.getEndDT());
                jres.setId(jobres.getId());
                jres.setJobName(jobres.getJobName());
                jres.setJobsCode(jobres.getJobsCode());
                jres.setNotes(jobres.getNotes());
                jres.setOrganizationCode(jobres.getOrganizationCode());
                jres.setPatientCode(jobres.getPatientCode());
                jres.setProcedureCode(jobres.getProcedureCode());
                jres.setStartDT(GigflexDateUtil.convertDateToString(jobres.getStartDT(), dtFormatDate));
                jres.setStartDTStamp(jobres.getStartDT());
                List<JobsDuration> jdrlst = jobsDurationRepository.getJobsDurationByJobsCode(jobres.getJobsCode());
                List<JobsDurationRes> jdurResLst = new ArrayList<JobsDurationRes>();
                if (jdrlst != null && jdrlst.size() > 0) {

                    for (JobsDuration jdurRes : jdrlst) {

                        JobsDurationRes jobsdurRes = new JobsDurationRes();
                        jobsdurRes.setId(jdurRes.getId());
                        jobsdurRes.setJobsCode(jdurRes.getJobsCode());
                        jobsdurRes.setJobsDurationCode(jdurRes.getJobsDurationCode());
                        Date stDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getStartTime(), timezone, dtFormatView);
                        String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                        Date endDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getEndTime(), timezone, dtFormatView);
                        String endDatestr = GigflexDateUtil.convertDateToString(endDate, dtFormatView);
                        jobsdurRes.setEndTime(endDatestr);
                        jobsdurRes.setStartTime(stDatestr);
                        jdurResLst.add(jobsdurRes);
                    }

                }
                JobsWithDurationRes jdres = new JobsWithDurationRes();
                jdres.setJobsRes(jres);
                jdres.setJobsDurationResLst(jdurResLst);
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Success.");
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(jdres);
                jsonobj.put("data", new JSONObject(Detail));

            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Jobs not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getWorkerJobById>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getWorkerJobById>>>>>", ex);
        }
        return res;

    }

    @Override
    public String getWorkerJobByJobCode(String jobCode) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            Jobs jobres = jobsRepository.getJobsByJobsCode(jobCode);
            if (jobres != null && jobres.getId() > 0) {
                String timezone = null;
                String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                String dtFormatDate = GigflexConstants.YYYY_MM_DD;
                String dtFormatView = dtFormat;
                String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.TimeZone);
                String datefoemat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                if (datefoemat != null && datefoemat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                    dtFormatView = datefoemat.trim() + " " + timeformat.trim();
                }
                if (datefoemat != null && datefoemat.trim().length() > 0) {
                    dtFormatDate = datefoemat.trim();
                }
                if (timezoneCode != null && timezoneCode.length() > 0) {
                    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                        timezone = tzd.getTimeZoneName();
                    }
                }
                JobsRes jres = new JobsRes();
                jres.setEndDT(GigflexDateUtil.convertDateToString(jobres.getEndDT(), dtFormatDate));
                jres.setEndDTStamp(jobres.getEndDT());
                jres.setId(jobres.getId());
                jres.setJobName(jobres.getJobName());
                jres.setJobsCode(jobres.getJobsCode());
                jres.setNotes(jobres.getNotes());
                jres.setOrganizationCode(jobres.getOrganizationCode());
                jres.setPatientCode(jobres.getPatientCode());
                jres.setProcedureCode(jobres.getProcedureCode());
                jres.setStartDT(GigflexDateUtil.convertDateToString(jobres.getStartDT(), dtFormatDate));
                jres.setStartDTStamp(jobres.getStartDT());
                jres.setDateFormat(datefoemat);
                jres.setTimeFormat(timeformat); 
                
                if(jobres.getPatientCode() != null && jobres.getPatientCode().trim().length() > 0)
                {
                    PatientDetails pDetailRes = patientDao.getPatientDetailBypatientCode(jobres.getPatientCode());
                    
                    if(pDetailRes != null)
                    {
                        jres.setPatientDetail(pDetailRes); 
                    }
                }
                
                
                List<JobsDuration> jdrlst = jobsDurationRepository.getJobsDurationByJobsCode(jobres.getJobsCode());
                List<JobsDurationRes> jobsDurationResLst = new ArrayList<JobsDurationRes>();
                if (jdrlst != null && jdrlst.size() > 0) {

                    for (JobsDuration jdurRes : jdrlst) {

                        JobsDurationRes jobsdurRes = new JobsDurationRes();
                        jobsdurRes.setId(jdurRes.getId());
                        jobsdurRes.setJobsCode(jdurRes.getJobsCode());
                        jobsdurRes.setJobsDurationCode(jdurRes.getJobsDurationCode());
                        Date stDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getStartTime(), timezone, dtFormatView);
                        String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                        Date endDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getEndTime(), timezone, dtFormatView);
                        String endDatestr = GigflexDateUtil.convertDateToString(endDate, dtFormatView);
                        jobsdurRes.setEndTime(endDatestr);
                        jobsdurRes.setStartTime(stDatestr);
                        jobsdurRes.setDurationHours(jdurRes.getDurationHours().toString());
                        jobsdurRes.setDurationMinute(jdurRes.getDurationMinute().toString());
                        jobsdurRes.setJobName(jdurRes.getJobName());
                        jobsdurRes.setNotes(jdurRes.getNotes());
                        String duration ="";
                                
                                Integer hours = jdurRes.getDurationHours();
                                Integer minute = jdurRes.getDurationMinute();
                                
                                String strHours = "";
                                if(hours != null && hours > 0 )
                                {
                                    strHours = hours.toString();
                                }
                                
                                String strMinute = "";
                                if(minute != null && minute > 0 )
                                {
                                    strMinute = minute.toString();
                                }
                                
                                if(strHours.length() > 0 )
                                {
                                    duration = strHours +" Hours ";
                                }
                                
                                if(strMinute.length() > 0 )
                                {
                                    duration =duration+strMinute+" Minutes";
                                }
                                
                                jobsdurRes.setDuration(duration);
                        jobsDurationResLst.add(jobsdurRes);
                    }

                }
                JobsWithDurationRes jdres = new JobsWithDurationRes();
                jdres.setJobsRes(jres);
                jdres.setJobsDurationResLst(jobsDurationResLst);
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Success.");
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(jdres);
                jsonobj.put("data", new JSONObject(Detail));

            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Jobs not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getWorkerJobByJobCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getWorkerJobByJobCode>>>>>", ex);
        }
        return res;

    }

    @Override
    public String getBasicWorkerJobByJobCode(String jobCode) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            Jobs jobres = jobsRepository.getJobsByJobsCode(jobCode);
            if (jobres != null && jobres.getId() > 0) {

                String dtFormatDate = GigflexConstants.YYYY_MM_DD;
                String datefoemat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                if (datefoemat != null && datefoemat.trim().length() > 0) {
                    dtFormatDate = datefoemat.trim();
                }

                JobsRes jres = new JobsRes();
                jres.setEndDT(GigflexDateUtil.convertDateToString(jobres.getEndDT(), dtFormatDate));
                jres.setEndDTStamp(jobres.getEndDT());
                jres.setId(jobres.getId());
                jres.setJobName(jobres.getJobName());
                jres.setJobsCode(jobres.getJobsCode());
                jres.setNotes(jobres.getNotes());
                jres.setOrganizationCode(jobres.getOrganizationCode());
                jres.setPatientCode(jobres.getPatientCode());
                jres.setProcedureCode(jobres.getProcedureCode());
                jres.setStartDT(GigflexDateUtil.convertDateToString(jobres.getStartDT(), dtFormatDate));
                jres.setStartDTStamp(jobres.getStartDT());
                jres.setDateFormat(dtFormatDate);
                jres.setTimeFormat(timeformat);
                jres.setDaysList(jobres.getDaysList());
                
                String jobDurationHours = "";
                if(jobres.getDurationHours() < 10)
                {
                    StringBuilder durationBuilder = new StringBuilder();
                    durationBuilder.append("0");
                    durationBuilder.append(jobres.getDurationHours().toString()) ;
                    jobDurationHours = durationBuilder.toString();
                }
                else
                {
                    jobDurationHours = jobres.getDurationHours().toString();
                }
                jres.setDurationHours(jobDurationHours);
                
                String jobDurationMinute = "";
                if(jobres.getDurationMinute() < 10)
                {
                    StringBuilder minuteBuilder = new StringBuilder();
                    minuteBuilder.append("0");
                    minuteBuilder.append(jobres.getDurationMinute().toString()) ;
                    jobDurationMinute = minuteBuilder.toString();
                }
                else
                {
                    jobDurationMinute = jobres.getDurationMinute().toString();
                }
                jres.setDurationMinute(jobDurationMinute);
                jres.setIsDateOfMonth(jobres.getIsDateOfMonth());
                jres.setRepeatType(jobres.getRepeatType());
                jres.setRepeatValue(jobres.getRepeatValue());
                jres.setStartTime(jobres.getStartTime());
                PatientDetails pDetail = patientDao.getPatientDetailsBypatientCode(jobres.getPatientCode().trim());
                if(pDetail!=null)
                {
                  jres.setPatientDetail(pDetail);
                }

                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Success.");
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(jres);
                jsonobj.put("data", new JSONObject(Detail));

            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Jobs not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getBasicWorkerJobByJobCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getBasicWorkerJobByJobCode>>>>>", ex);
        }
        return res;

    }

    @Override
    public String getWorkerJobDurationByJobDurationCode(String jobDurationCode) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsDuration jdurRes = jobsDurationRepository.getJobsDurationByJobsDurationCode(jobDurationCode);
            if (jdurRes != null && jdurRes.getId() > 0) {
                Jobs jobres = jobsRepository.getJobsByJobsCode(jdurRes.getJobsCode());
                if (jobres != null && jobres.getId() > 0) {
                    JobsAssignToWorker jas = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsDurationCode(jobDurationCode);
                    PatientDetails pd = patientDao.getPatientDetailBypatientCode(jobres.getPatientCode());
                    ProcedureMaster pcm = procedureMasterDao.getProcedureMasterByProcedureCode(jobres.getProcedureCode());
                    String timezone = null;
                    String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                    String dtFormatView = dtFormat;
                    String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.TimeZone);
                    String datefoemat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                    String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                    if (datefoemat != null && datefoemat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                        dtFormatView = datefoemat.trim() + " " + timeformat.trim();
                    }

                    if (timezoneCode != null && timezoneCode.length() > 0) {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                        if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                            timezone = tzd.getTimeZoneName();
                        }
                    }

                    JobsDurationRes jobsdurRes = new JobsDurationRes();
                    jobsdurRes.setId(jdurRes.getId());
                    jobsdurRes.setJobsCode(jdurRes.getJobsCode());
                    jobsdurRes.setJobsDurationCode(jdurRes.getJobsDurationCode());
                    Date stDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getStartTime(), timezone, dtFormatView);
                    String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                    Date endDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getEndTime(), timezone, dtFormatView);
                    String endDatestr = GigflexDateUtil.convertDateToString(endDate, dtFormatView);
                    jobsdurRes.setEndTime(endDatestr);
                    jobsdurRes.setStartTime(stDatestr);
                    String dur = "";
                    String jobDurationHours = "";
                    if (jdurRes.getDurationHours() != null && jdurRes.getDurationHours() > 0) {
                        
                         if(jobres.getDurationHours() < 10)
                        {
                            StringBuilder durationBuilder = new StringBuilder();
                            durationBuilder.append("0");
                            durationBuilder.append(jobres.getDurationHours().toString()) ;
                            jobDurationHours = durationBuilder.toString();
                        }
                        else
                        {
                            jobDurationHours = jobres.getDurationHours().toString();
                        }
                        
                        dur = jobDurationHours + " Hours ";
                    }
                    jobsdurRes.setDurationHours(jobDurationHours);
                    
                    String jobDurationMinute = "";
                    if (jdurRes.getDurationMinute() != null && jdurRes.getDurationMinute() > 0) {
                       
                        if(jobres.getDurationMinute() < 10)
                        {
                            StringBuilder minuteBuilder = new StringBuilder();
                            minuteBuilder.append("0");
                            minuteBuilder.append(jobres.getDurationMinute().toString()) ;
                            jobDurationMinute = minuteBuilder.toString();
                        }
                        else
                        {
                            jobDurationMinute = jobres.getDurationMinute().toString();
                        }                       
                        
                        dur += jobDurationMinute + " Minutes";
                    }
                    jobsdurRes.setDurationMinute(jobDurationMinute);
                    jobsdurRes.setDuration(dur);

                    if (jas != null && jas.getId() > 0) {
                        jobsdurRes.setJobstatus(jas.getStatus());
                        jobsdurRes.setDistance(jas.getDistance());
                    }

                    if (pd != null && pd.getId() > 0) {
//                                    jobsdurRes.setPatientLatitude(pd.getPatientLatitude());
//                                    jobsdurRes.setPatientLongitude(pd.getPatientLongitude());
                        jobsdurRes.setPatientDetails(pd);
                    }
                    if (pcm != null && pcm.getId() > 0) {
                        jobsdurRes.setProcedureMaster(pcm);
                    }

                    jobsdurRes.setDateFormat(datefoemat);
                    jobsdurRes.setTimeFormat(timeformat); 
                    jobsdurRes.setJobName(jdurRes.getJobName()); 
                    jobsdurRes.setNotes(jdurRes.getNotes());                    
                    
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Success.");
                    ObjectMapper mapperObj = new ObjectMapper();
                    String Detail = mapperObj.writeValueAsString(jobsdurRes);
                    jsonobj.put("data", new JSONObject(Detail));
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Jobs not found.");
                }
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Jobs Duration not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getWorkerJobDurationByJobDurationCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getWorkerJobDurationByJobDurationCode>>>>>", ex);
        }
        return res;
    }

    @Override
    public String getJobsAssignToWorkerByJobAssignToWorkerCode(String jobAssignToWorkerCode) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsAassignWorkerCode(jobAssignToWorkerCode);
            if (jaw != null && jaw.getId() > 0) {
                JobsAssignToWorkerResponse jawres = new JobsAssignToWorkerResponse();
                jawres.setComment(jaw.getComment());
                jawres.setDistance(jaw.getDistance());
                jawres.setId(jaw.getId());
                jawres.setJobsAassignWorkerCode(jaw.getJobsAassignWorkerCode());
                jawres.setJobsCode(jaw.getJobsCode());
                jawres.setJobsDurationCode(jaw.getJobsDurationCode());
                jawres.setStatus(jaw.getStatus());
                if (jaw.getWorkerCode() != null && jaw.getWorkerCode().length() > 0) {
                    Worker wr = workerRepository.findByWorkerCode(jaw.getWorkerCode());
                    if (wr != null && wr.getId() > 0) {
                        jawres.setWorker(wr);
                    }
                }

                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Success.");
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(jawres);
                jsonobj.put("data", new JSONObject(Detail));
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobsAssignToWorker not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getJobsAssignToWorkerByJobAssignToWorkerCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getJobsAssignToWorkerByJobAssignToWorkerCode>>>>>", ex);
        }
        return res;
    }

    @Override
    public String getJobsAssignToWorkerByJobsCode(String jobCode) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            List<JobsAssignToWorker> jawList = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsCode(jobCode);
            if (jawList != null && jawList.size() > 0) {
                List<JobsAssignToWorkerResponse> jawresList = new ArrayList<JobsAssignToWorkerResponse>();
                for (JobsAssignToWorker jaw : jawList) {
                    JobsAssignToWorkerResponse jawres = new JobsAssignToWorkerResponse();
                    jawres.setComment(jaw.getComment());
                    jawres.setDistance(jaw.getDistance());
                    jawres.setId(jaw.getId());
                    jawres.setJobsAassignWorkerCode(jaw.getJobsAassignWorkerCode());
                    jawres.setJobsCode(jaw.getJobsCode());
                    jawres.setJobsDurationCode(jaw.getJobsDurationCode());
                    jawres.setStatus(jaw.getStatus());
                    if (jaw.getWorkerCode() != null && jaw.getWorkerCode().length() > 0) {
                        Worker wr = workerRepository.findByWorkerCode(jaw.getWorkerCode());
                        if (wr != null && wr.getId() > 0) {
                            jawres.setWorker(wr);
                        }
                    }
                    jawresList.add(jawres);
                }

                if (jawresList.size() > 0) {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Success.");
                    ObjectMapper mapperObj = new ObjectMapper();
                    String Detail = mapperObj.writeValueAsString(jawresList);
                    jsonobj.put("data", new JSONArray(Detail));
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "JobsAssignToWorker not found.");
                }
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobsAssignToWorker not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getJobsAssignToWorkerByJobsCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getJobsAssignToWorkerByJobsCode>>>>>", ex);
        }
        return res;

    }
    
    @Override
    public String getJobsAssignToWorkerByJobsCodeSpecialRes(String jobCode) {
       
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            List<JobsAssignToWorker> jawList = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsCode(jobCode);
            Jobs jobRes  = jobsRepository.getJobsByJobsCode(jobCode);
            
            String timezone = null;
            String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
            String dtFormatView = dtFormat;
            if(jobRes != null )
            {                
                String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobRes.getOrganizationCode(), GigflexConstants.TimeZone);
                String datefoemat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobRes.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobRes.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                if (datefoemat != null && datefoemat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                    dtFormatView = datefoemat.trim() + " " + timeformat.trim();
                }

                if (timezoneCode != null && timezoneCode.length() > 0) {
                    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                        timezone = tzd.getTimeZoneName();
                    }
                }
            }
            else
            {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Jobs not found.");
                return jsonobj.toString();
            }
            
            if (jawList != null && jawList.size() > 0) {                
                List<EligibleWorkerRes> eligibleWorkerResList = new ArrayList<EligibleWorkerRes>();
                for (JobsAssignToWorker jaw : jawList) {
                    EligibleWorkerRes elegibleRes = new EligibleWorkerRes();
                    elegibleRes.setJobsCode(jobCode); 
                    elegibleRes.setJobsDurationCode(jaw.getJobsDurationCode());  
                    List<WorkerWithDistance> workerWithDistanceList = new ArrayList<WorkerWithDistance>(); 
                    if (jaw.getWorkerCode() != null && jaw.getWorkerCode().length() > 0) {
                        Worker wr = workerRepository.findByWorkerCode(jaw.getWorkerCode());
                        if (wr != null && wr.getId() > 0) {
                            WorkerWithDistance workerWithDistance = new WorkerWithDistance();
                            workerWithDistance.setWorker(wr); 
                            workerWithDistance.setDistance(jaw.getDistance()); 
                            workerWithDistanceList.add(workerWithDistance); 
                        }
                    }
                    
                    JobsDuration jobDurationRes = jobsDurationRepository.getJobsDurationByJobsDurationCode(jaw.getJobsDurationCode());
                    if(jobDurationRes != null && timezone != null)
                    {
                       Date startDate = jobDurationRes.getStartTime();                        
                       Date stDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormatView);
                       String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                       
                       elegibleRes.setJobDurationStartTime(stDatestr); 
                    }
                    elegibleRes.setWorkerWithDistanceList(workerWithDistanceList); 
                    
                    eligibleWorkerResList.add(elegibleRes);
                }
                
                if (eligibleWorkerResList.size() > 0) {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Success.");
                    ObjectMapper mapperObj = new ObjectMapper();
                    String Detail = mapperObj.writeValueAsString(eligibleWorkerResList);
                    jsonobj.put("data", new JSONArray(Detail));
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "JobsAssignToWorker not found.");
                }
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobsAssignToWorker not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getJobsAssignToWorkerByJobsCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getJobsAssignToWorkerByJobsCode>>>>>", ex);
        }
        return res;

    }

    @Override
    public String getJobsAssignToWorkerByJobsCodeAndJobDurationCode(String jobCode, String jobDurationCode) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsCodeAndJobsDurationCode(jobCode, jobDurationCode);
            if (jaw != null && jaw.getId() > 0) {
                JobsAssignToWorkerResponse jawres = new JobsAssignToWorkerResponse();
                jawres.setComment(jaw.getComment());
                jawres.setDistance(jaw.getDistance());
                jawres.setId(jaw.getId());
                jawres.setJobsAassignWorkerCode(jaw.getJobsAassignWorkerCode());
                jawres.setJobsCode(jaw.getJobsCode());
                jawres.setJobsDurationCode(jaw.getJobsDurationCode());
                jawres.setStatus(jaw.getStatus());
                if (jaw.getWorkerCode() != null && jaw.getWorkerCode().length() > 0) {
                    Worker wr = workerRepository.findByWorkerCode(jaw.getWorkerCode());
                    if (wr != null && wr.getId() > 0) {
                        jawres.setWorker(wr);
                    }
                }

                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Success.");
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(jawres);
                jsonobj.put("data", new JSONObject(Detail));
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobsAssignToWorker not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getJobsAssignToWorkerByJobsCodeAndJobDurationCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in getJobsAssignToWorkerByJobsCodeAndJobDurationCode>>>>>", ex);
        }
        return res;
    }

    
    
    @Override
    public String assignToWorkerByJobCodeAndJobDurationCode(AssignToWorkerReq req, String jobCode, String jobDurationCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsCodeAndJobsDurationCode(jobCode, jobDurationCode);
            if (jaw != null && jaw.getId() > 0) {
                jaw.setIpAddress(ip);
                jaw.setDistance(req.getDistance());
                jaw.setWorkerCode(req.getWorkerCode());
                jaw.setStatus(GigflexConstants.JOBSTATUS_ASSIGNED);
                JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                if (jawres != null && jawres.getId() > 0) {

                    HealthcareNotification notification = new HealthcareNotification();
                    String appointmentId = jawres.getAppointmentId();

                    Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                    String organizationCode = "";
                    if (job != null) {
                        organizationCode = job.getOrganizationCode();
                    }

                    Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                    String organizationName = "";
                    if (org != null) {
                        organizationName = org.getOrganizationName();
                    }
                    String workerCode = jawres.getWorkerCode();
                    Worker worker = workerRepository.findByWorkerCode(workerCode);

                    String workerName = "";
                    if (worker != null) {
                        workerName = worker.getName();
                    }

                    JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                    Date startTime = null;
                    Date endTime = null;
                    if (jd != null) {
                        startTime = jd.getStartTime();
                        endTime = jd.getEndTime();
                    }

                    Date stDate = null;
                    Date endDate = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatView = dtFormat;
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                        String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                        if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                            dtFormatView = dateformat.trim() + " " + timeformat.trim();
                        }

                        if (timezoneCode != null && timezoneCode.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                        }
                    }

                    String message = "Job has been assigned";
                    String bodyContentShortMessage = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;

                    String shortMessage = "" + message + "";

                    notification.setUserCode(workerCode);
                    notification.setMessage(bodyContentShortMessage);
                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                    notification.setShortMessage(shortMessage);
                    notification.setAppointmentCode(appointmentId);
                    notification.setIsRead(Boolean.FALSE);
                    notification.setIpAddress(ip);

                    notificationService.saveHealthcareNotification(notification);

                    String email = "";
                    if (worker != null) {
                        email = worker.getEmail();
                    }
                    SendNotification sn = new SendNotification();

                    String bodyContent = message + " Details are given below-<br>"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;

                    if (email != null && email.length() > 0) {
                        String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                    }
                    
                    
                    List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(worker.getWorkerCode().trim());
                    if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                     {
                       //for push notification 
                         for(DeviceDetail deviceDetail : deviceDetailResList)
                         {
                             PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Job Alert", bodyContentShortMessage);
                         }                                                        
                     }

                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job has been assigned.");
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job Assignment has been failed.");
                }
            } else {
                JobsDuration jdur = jobsDurationRepository.getJobsDurationByJobsDurationCode(jobDurationCode);
                if (jdur != null && jdur.getId() > 0 && jdur.getJobsCode() != null && jdur.getJobsCode().equals(jobCode)) {
                    JobsAssignToWorker jtw = new JobsAssignToWorker();
                    jtw.setIpAddress(ip);
                    jtw.setDistance(req.getDistance());
                    jtw.setWorkerCode(req.getWorkerCode());
                    jtw.setJobsCode(jobCode);
                    jtw.setJobsDurationCode(jobDurationCode);
                    jtw.setStatus(GigflexConstants.JOBSTATUS_ASSIGNED);
                    JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jtw);
                    if (jawres != null && jawres.getId() > 0) {

                        //
                        HealthcareNotification notification = new HealthcareNotification();
                        String appointmentId = jawres.getAppointmentId();

                        Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                        String organizationCode = "";
                        if (job != null) {
                            organizationCode = job.getOrganizationCode();
                        }

                        Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                        String organizationName = "";
                        if (org != null) {
                            organizationName = org.getOrganizationName();
                        }
                        String workerCode = jawres.getWorkerCode();
                        Worker worker = workerRepository.findByWorkerCode(workerCode);

                        String workerName = "";
                        if (worker != null) {
                            workerName = worker.getName();
                        }

                        JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                        Date startTime = null;
                        Date endTime = null;
                        if (jd != null) {
                            startTime = jd.getStartTime();
                            endTime = jd.getEndTime();
                        }

                        Date stDate = null;
                        Date endDate = null;
                        if (startTime != null && endTime != null) {
                            String timezone = null;
                            String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                            String dtFormatView = dtFormat;
                            String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                            String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                            if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                                dtFormatView = dateformat.trim() + " " + timeformat.trim();
                            }

                            if (timezoneCode != null && timezoneCode.length() > 0) {
                                TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                    timezone = tzd.getTimeZoneName();
                                }
                            }

                            if (timezone != null) {
                                stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                                endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                            }
                        }

                        String message = "Job has been assigned";
                        String bodyContentShortMessage = message + ". Details are given below-"
                                + "Worker Name : " + workerName
                                + "Organization Name : " + organizationName
                                + " Start Time : " + stDate
                                + " End Time : " + endDate
                                + " Appointment ID : " + appointmentId;

                        String shortMessage = "" + message + "";

                        notification.setUserCode(workerCode);
                        notification.setMessage(bodyContentShortMessage);
                        notification.setUserType("All");
                        notification.setShortMessage(shortMessage);
                        notification.setAppointmentCode(appointmentId);
                        notification.setIsRead(Boolean.FALSE);
                        notification.setIpAddress(ip);

                        notificationService.saveHealthcareNotification(notification);

                        String email = "";
                        if (worker != null) {
                            email = worker.getEmail();
                        }
                        SendNotification sn = new SendNotification();

                        String bodyContent = message + " Details are given below-<br>"
                                + "Worker Name : " + workerName
                                + "Organization Name : " + organizationName
                                + " Start Time : " + stDate
                                + " End Time : " + endDate
                                + " Appointment ID : " + appointmentId;

                        if (email != null && email.length() > 0) {
                            String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                            LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                        }

                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Job has been assigned.");
                    } else {
                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Job Assignment has been failed.");
                    }
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Jobs Code and Jobs Duration not found.");
                }
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerByJobCodeAndJobDurationCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerByJobCodeAndJobDurationCode>>>>>", ex);
        }
        return res;
    }

     @Override
    public String assignToWorkerByJobDurationCode(AssignToWorkerReqNew req, String jobDurationCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsDurationCode(jobDurationCode);
            if (jaw != null && jaw.getId() > 0) {
                Jobs j = jobsRepository.getJobsByJobsCode(jaw.getJobsCode());
                if (j != null && j.getId() > 0) {
                    JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jobDurationCode);
                    if(jd != null && jd.getId() > 0)
                    {
                   String orgTimeZone=null;
                   String timezoneCodeOrg = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, j.getOrganizationCode(), GigflexConstants.TimeZone);
                   if (timezoneCodeOrg != null && timezoneCodeOrg.length() > 0) {
                                    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCodeOrg);
                                    if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                        orgTimeZone = tzd.getTimeZoneName();
                                    }
                                }  
                    Worker oldwkr=null;
                    Worker wkr = workerRepository.getWorkerdetailByworkerCode(req.getWorkerCode());
                    if (wkr != null && wkr.getId() > 0) {
                        if(jaw.getWorkerCode()!=null)
                        {
                            if(!jaw.getWorkerCode().equalsIgnoreCase(req.getWorkerCode()))
                            {
                               oldwkr = workerRepository.getWorkerdetailByworkerCode(jaw.getWorkerCode());
                            }
                        }
                       
                        PatientDetails pDetail = patientDao.getPatientDetailsBypatientCode(j.getPatientCode());
                        String manualassign = GigflexConstants.JOBSTATUS_ASSIGNED;
                        String autoass = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, j.getOrganizationCode(), GigflexConstants.FULLTIME_STAFF_AUTO_ASSIGN);
                        if (autoass != null && autoass.trim().length() > 0 && autoass.equalsIgnoreCase("true")) {
                            manualassign = GigflexConstants.JOBSTATUS_ACCEPTED;
                        }
                        jaw.setIpAddress(ip);
//                        if (pDetail != null && pDetail.getPatientLatitude() != null && pDetail.getPatientLatitude().trim().length() > 0 && pDetail.getPatientLongitude() != null && pDetail.getPatientLongitude().trim().length() > 0 && wkr.getLatitude() != null && wkr.getLatitude().trim().length() > 0 && wkr.getLongitude() != null && wkr.getLongitude().trim().length() > 0) {
//                            
//                            Double distance = distance(pDetail.getPatientLatitude().trim(), pDetail.getPatientLongitude().trim(), wkr.getLatitude().trim(), wkr.getLongitude().trim());
//                            jaw.setDistance(distance);
//                        }

                        jaw.setWorkerCode(req.getWorkerCode());
                        jaw.setStatus(manualassign);
                        JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                        if (jawres != null && jawres.getId() > 0) {
                            try{
                                startAssignJobToWorkerDynamicDistanceThread(wkr,j.getOrganizationCode(),jd.getStartTime(),orgTimeZone);
                                
                            }
                            catch(Exception ex)
                            {
                                ex.printStackTrace();
                            }
                             try{
                                 if(oldwkr!=null && oldwkr.getId()>0)
                                 {
                                startAssignJobToWorkerDynamicDistanceThread(oldwkr,j.getOrganizationCode(),jd.getStartTime(),orgTimeZone);
                                 }
                                
                            }
                            catch(Exception ex)
                            {
                                ex.printStackTrace();
                            }
                            String message = "";
                            jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                            jsonobj.put("timestamp", new Date());
                            if (jawres.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED)) {
                                jsonobj.put("message", "Job has been assigned and auto accepted.");
                                message = "Job has been assigned and auto accepted.";
                            } else {
                                jsonobj.put("message", "Job has been assigned.");
                                message = "Job has been assigned.";
                            }

                            HealthcareNotification notification = new HealthcareNotification();
                            String appointmentId = jaw.getAppointmentId();

                            //Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                            String organizationCode = "";
                            if (j != null) {
                                organizationCode = j.getOrganizationCode();
                            }

                            Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                            String organizationName = "";
                            if (org != null) {
                                organizationName = org.getOrganizationName();
                            }
                            String workerCode = jawres.getWorkerCode();
                            Worker worker = workerRepository.findByWorkerCode(workerCode);

                            String workerName = "";
                            if (worker != null) {
                                workerName = worker.getName();
                            }

                            
                            Date startTime = null;
                            Date endTime = null;
                            if (jd != null) {
                                startTime = jd.getStartTime();
                                endTime = jd.getEndTime();
                            }

                            Date stDate = null;
                            Date endDate = null;
                            if (startTime != null && endTime != null) {
                                String timezone = null;
                                String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                String dtFormatView = dtFormat;
                                String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, req.getWorkerCode(), GigflexConstants.TimeZone);
                                String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, req.getWorkerCode(), GigflexConstants.DATEFORMAT);
                                String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, req.getWorkerCode(), GigflexConstants.TIMEFORMAT);
                                if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                                    dtFormatView = dateformat.trim() + " " + timeformat.trim();
                                }

                                if (timezoneCode != null && timezoneCode.length() > 0) {
                                    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                    if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                        timezone = tzd.getTimeZoneName();
                                    }
                                }

                                if (timezone != null) {
                                    stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                                    endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                                }
                            }

                            String bodyContentShortMessage = message + ". Details are given below-"
                                    + "Worker Name : " + workerName
                                    + "Organization Name : " + organizationName
                                    + " Start Time : " + stDate
                                    + " End Time : " + endDate
                                    + " Appointment ID : " + appointmentId;

                            String shortMessage = "" + message + "";

                            notification.setUserCode(workerCode);
                            notification.setMessage(bodyContentShortMessage);
                            notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                            notification.setShortMessage(shortMessage);
                            notification.setAppointmentCode(appointmentId);
                            notification.setIsRead(Boolean.FALSE);
                            notification.setIpAddress(ip);

                            notificationService.saveHealthcareNotification(notification);

                            String email = "";
                            if (worker != null) {
                                email = worker.getEmail();
                            }
                            String bodyContent = message + ". Details are given below-<br>"
                                    + "Worker Name : " + workerName
                                    + "Organization Name : " + organizationName
                                    + " Start Time : " + stDate
                                    + " End Time : " + endDate
                                    + " Appointment ID : " + appointmentId;
                            SendNotification sn = new SendNotification();

                            if (email != null && email.length() > 0) {
                                String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                                LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                            }
                            
                            List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(worker.getWorkerCode().trim());
                            if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                             {
                               //for push notification 
                                 for(DeviceDetail deviceDetail : deviceDetailResList)
                                 {
                                     PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Job Alert", bodyContentShortMessage);
                                 }                                                        
                             }
                            
                        } else {
                            jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Job Assignment has been failed.");
                        }
                    } else {

                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Worker not found.");

                    }
                    } else {

                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job duration not found.");

                }
                } else {

                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Jobs not found.");

                }
            } else {

                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Jobs Duration not found.");

            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerByJobCodeAndJobDurationCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerByJobCodeAndJobDurationCode>>>>>", ex);
        }
        return res;
    }
        
   
    @Override
    public String assignToWorkerByJobAssignToWorkerCode(AssignToWorkerReq req, String jobAssignToWorkerCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsAassignWorkerCode(jobAssignToWorkerCode);
            if (jaw != null && jaw.getId() > 0) {
                jaw.setIpAddress(ip);
                jaw.setDistance(req.getDistance());
                jaw.setWorkerCode(req.getWorkerCode());
                jaw.setStatus(GigflexConstants.JOBSTATUS_ASSIGNED);
                JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                if (jawres != null && jawres.getId() > 0) {

                    HealthcareNotification notification = new HealthcareNotification();
                    String appointmentId = jaw.getAppointmentId();

                    Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                    String organizationCode = "";
                    if (job != null) {
                        organizationCode = job.getOrganizationCode();
                    }

                    Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                    String organizationName = "";
                    if (org != null) {
                        organizationName = org.getOrganizationName();
                    }
                    String workerCode = jawres.getWorkerCode();
                    Worker worker = workerRepository.findByWorkerCode(workerCode);

                    String workerName = "";
                    if (worker != null) {
                        workerName = worker.getName();
                    }

                    JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                    Date startTime = null;
                    Date endTime = null;
                    if (jd != null) {
                        startTime = jd.getStartTime();
                        endTime = jd.getEndTime();
                    }

                    Date stDate = null;
                    Date endDate = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatView = dtFormat;
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, req.getWorkerCode(), GigflexConstants.TimeZone);
                        String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, req.getWorkerCode(), GigflexConstants.DATEFORMAT);
                        String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, req.getWorkerCode(), GigflexConstants.TIMEFORMAT);
                        if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                            dtFormatView = dateformat.trim() + " " + timeformat.trim();
                        }

                        if (timezoneCode != null && timezoneCode.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                        }
                    }

                    String message = "Job has been assigned";
                    String bodyContentShortMessage = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;

                    String shortMessage = "" + message + "";

                    notification.setUserCode(workerCode);
                    notification.setMessage(bodyContentShortMessage);
                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                    notification.setShortMessage(shortMessage);
                    notification.setAppointmentCode(appointmentId);
                    notification.setIsRead(Boolean.FALSE);
                    notification.setIpAddress(ip);

                    notificationService.saveHealthcareNotification(notification);

                    String email = "";
                    if (worker != null) {
                        email = worker.getEmail();
                    }
                    String bodyContent = message + ". Details are given below-<br>"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;
                    SendNotification sn = new SendNotification();

                    if (email != null && email.length() > 0) {
                        String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                    }

                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job has been assigned.");
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job Assignment has been failed.");
                }
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobsAssignToWorker not found.");
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerByJobAssignToWorkerCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerByJobAssignToWorkerCode>>>>>", ex);
        }
        return res;
    }

    @Override
    public String assignToWorkerAccepted(AssignToWorkerStatusReq req, String jobAssignToWorkerCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsAassignWorkerCode(jobAssignToWorkerCode);
            if (jaw != null && jaw.getId() > 0) {
                if (jaw.getWorkerCode() != null && jaw.getWorkerCode().equalsIgnoreCase(req.getWorkerCode())) {
                    jaw.setIpAddress(ip);
                    jaw.setStatus(GigflexConstants.JOBSTATUS_ACCEPTED);
                    JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                    if (jawres != null && jawres.getId() > 0) {

                        HealthcareNotification notification = new HealthcareNotification();
                        String appointmentId = jaw.getAppointmentId();

                        Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                        String organizationCode = "";
                        if (job != null) {
                            organizationCode = job.getOrganizationCode();
                        }

                        Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                        String organizationName = "";
                        if (org != null) {
                            organizationName = org.getOrganizationName();
                        }
                        String workerCode = jawres.getWorkerCode();
                        Worker worker = workerRepository.findByWorkerCode(workerCode);
                        Users user = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);

                        String workerName = "";
                        if (worker != null) {
                            workerName = worker.getName();
                        }

                        JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                        Date startTime = null;
                        Date endTime = null;
                        if (jd != null) {
                            startTime = jd.getStartTime();
                            endTime = jd.getEndTime();
                        }

                        Date stDate = null;
                        Date endDate = null;
                        if (startTime != null && endTime != null) {
                            String timezone = null;
                            String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                            String dtFormatView = dtFormat;
                            String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                            String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                            if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                                dtFormatView = dateformat.trim() + " " + timeformat.trim();
                            }

                            if (timezoneCode != null && timezoneCode.length() > 0) {
                                TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                    timezone = tzd.getTimeZoneName();
                                }
                            }

                            if (timezone != null) {
                                stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                                endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                            }
                        }

                        String message = "Job has been Accepted";
                        String bodyContentShortMessage = message + ". Details are given below-"
                                + "Worker Name : " + workerName
                                + "Organization Name : " + organizationName
                                + " Start Time : " + stDate
                                + " End Time : " + endDate
                                + " Appointment ID : " + appointmentId;

                        String shortMessage = "" + message + "";

                        String email = "";
                        String userCode ="";
                        if (user != null) {
                            email = user.getEmail();
                            userCode = user.getUserCode();
                            
                        }
                        
                        
                        notification.setUserCode(userCode);
                        notification.setMessage(bodyContentShortMessage);
                        notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                        notification.setShortMessage(shortMessage);
                        notification.setAppointmentCode(appointmentId);
                        notification.setIsRead(Boolean.FALSE);
                        notification.setIpAddress(ip);

                        notificationService.saveHealthcareNotification(notification);

                        
                        String bodyContent = message + ". Details are given below-<br>"
                                + "Worker Name : " + workerName
                                + "Organization Name : " + organizationName
                                + " Start Time : " + stDate
                                + " End Time : " + endDate
                                + " Appointment ID : " + appointmentId;
                        SendNotification sn = new SendNotification();

                        if (email != null && email.length() > 0) {
                            String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                            LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                        }

                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Job has been Accepted.");
                    } else {
                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Job acceptance has been failed.");
                    }
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Worker code is not matched.");
                }
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobsAssignToWorker not found.");
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerAccepted>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerAccepted>>>>>", ex);
        }
        return res;
    }

    @Override
    public String assignToWorkerRejected(AssignToWorkerStatusReq req, String jobAssignToWorkerCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsAassignWorkerCode(jobAssignToWorkerCode);
            if (jaw != null && jaw.getId() > 0) {
                if (jaw.getWorkerCode().equalsIgnoreCase(req.getWorkerCode())) {
                    jaw.setIpAddress(ip);
                    jaw.setComment(req.getComment());
                    jaw.setStatus(GigflexConstants.JOBSTATUS_REJECTED);
                    JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                    if (jawres != null && jawres.getId() > 0) {

                        HealthcareNotification notification = new HealthcareNotification();
                        String appointmentId = jaw.getAppointmentId();

                        Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                        String organizationCode = "";
                        if (job != null) {
                            organizationCode = job.getOrganizationCode();
                        }

                        Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                        String organizationName = "";
                        if (org != null) {
                            organizationName = org.getOrganizationName();
                        }
                        String workerCode = jawres.getWorkerCode();
                        Worker worker = workerRepository.findByWorkerCode(workerCode);
                        Users user = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);

                        String workerName = "";
                        if (worker != null) {
                            workerName = worker.getName();
                        }

                        JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                        Date startTime = null;
                        Date endTime = null;
                        if (jd != null) {
                            startTime = jd.getStartTime();
                            endTime = jd.getEndTime();
                        }

                        Date stDate = null;
                        Date endDate = null;
                        if (startTime != null && endTime != null) {
                            String timezone = null;
                            String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                            String dtFormatView = dtFormat;
                            String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                            String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                            String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                            if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                                dtFormatView = dateformat.trim() + " " + timeformat.trim();
                            }

                            if (timezoneCode != null && timezoneCode.length() > 0) {
                                TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                    timezone = tzd.getTimeZoneName();
                                }
                            }

                            if (timezone != null) {
                                stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                                endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                            }
                        }

                        String email = "";
                        String userCode ="";
                        if (user != null) {
                            email = user.getEmail();
                            userCode = user.getUserCode();
                        }
                        
                        String message = "Job has been rejected";
                        String bodyContentShortMessage = message + ". Details are given below-"
                                + "Worker Name : " + workerName
                                + "Organization Name : " + organizationName
                                + " Start Time : " + stDate
                                + " End Time : " + endDate
                                + " Appointment ID : " + appointmentId;

                        String shortMessage = "" + message + "";

                        notification.setUserCode(userCode);
                        notification.setMessage(bodyContentShortMessage);
                        notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                        notification.setShortMessage(shortMessage);
                        notification.setAppointmentCode(appointmentId);
                        notification.setIsRead(Boolean.FALSE);
                        notification.setIpAddress(ip);

                        notificationService.saveHealthcareNotification(notification);

                       
                        
                        String bodyContent = message + ". Details are given below-<br>"
                                + "Worker Name : " + workerName
                                + "Organization Name : " + organizationName
                                + " Start Time : " + stDate
                                + " End Time : " + endDate
                                + " Appointment ID : " + appointmentId;
                        SendNotification sn = new SendNotification();

                        if (email != null && email.length() > 0) {
                            String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                            LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                        }

                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Job has been rejected.");
                    } else {
                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Job rejection has been failed.");
                    }
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Worker code is not matched.");
                }
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobsAssignToWorker not found.");
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerAccepted>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerAccepted>>>>>", ex);
        }
        return res;
    }

    private Double distance(String lat1, String lon1, String lat2, String lon2) {
        try {
            if(lat1!=null &&lat1.trim().length()>0 && lon1!=null && lon1.trim().length()>0 && lat2!=null && lat2.trim().length()>0 && lon2!=null && lon2.trim().length()>0 )
            {
                GoogleDistanceDurationResponse res=GoogleDistanceDuration.getGoogleDistanceDuration(googleKey, lat1.trim(), lon1.trim(), lat2.trim(), lon2.trim());
                if(res!=null && res.getStatus())
                {
                    if(res.getDistanceValue()!=null )
                    {
                        double mileCon=1609.344;
                        Double dis=res.getDistanceValue()/mileCon;
                        return dis;
                    }
                }
            }
        } catch (Exception e) {
            LOG.error("Error in distance>>>", e);
        }
        return null;
    }

    private Integer duration(String lat1, String lon1, String lat2, String lon2) {
        try {
            if(lat1!=null &&lat1.trim().length()>0 && lon1!=null && lon1.trim().length()>0 && lat2!=null && lat2.trim().length()>0 && lon2!=null && lon2.trim().length()>0 )
            {
                GoogleDistanceDurationResponse res=GoogleDistanceDuration.getGoogleDistanceDuration(googleKey, lat1.trim(), lon1.trim(), lat2.trim(), lon2.trim());
                if(res!=null && res.getStatus())
                {
                    if(res.getDurationValue()!=null )
                    {
                        return res.getDurationValue();
                    }
                }
            }
        } catch (Exception e) {
            LOG.error("Error in duration>>>", e);
        }
        return null;
    }
    
    private GoogleDistanceDurationResponse getGoogleDistanceDurationResponse(String lat1, String lon1, String lat2, String lon2) {
        try {
            if(lat1!=null &&lat1.trim().length()>0 && lon1!=null && lon1.trim().length()>0 && lat2!=null && lat2.trim().length()>0 && lon2!=null && lon2.trim().length()>0 )
            {
                GoogleDistanceDurationResponse res=GoogleDistanceDuration.getGoogleDistanceDuration(googleKey, lat1.trim(), lon1.trim(), lat2.trim(), lon2.trim());
                if(res!=null && res.getStatus())
                {
                    
                        return res;
                    
                }
            }
        } catch (Exception e) {
            LOG.error("Error in getGoogleDistanceDurationResponse>>>", e);
        }
        return null;
    }

    @Override
    public String getAllJobsByWorkerCodeWithFilterByPage(String workerCode, List<String> status, String stratDT, String endDT, int page, int limit) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            if (limit > 0) {
                Worker worker = workerRepository.findByWorkerCode(workerCode);
                if(worker!=null && worker.getId()>0)
                {
                List<String> orderLst = new ArrayList<String>();
                orderLst.add(GigflexConstants.JOBSTATUS_ASSIGNED);           
                orderLst.add(GigflexConstants.JOBSTATUS_REJECTED);
                orderLst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                orderLst.add(GigflexConstants.JOBSTATUS_PENDING);
                orderLst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                orderLst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                orderLst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                orderLst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                Pageable pageableRequest = PageRequest.of(page, limit);
                Date sDT = null;
                Date eDT = null;
                 String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician,workerCode , GigflexConstants.TimeZone);
                            String timezone = null;
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getId() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                            String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                            String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.DATEFORMAT);
                            String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.TIMEFORMAT);
                            if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                                dtFormat = dateformat.trim() + " " + timeformat.trim();
                            }
                if (stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                    stratDT = stratDT + " 00:00:00";
                    endDT = endDT + " 00:00:00";

                    //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                    //sDT = GigflexDateUtil.convertStringToDate(stratDT.trim(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    //eDT = GigflexDateUtil.convertStringToDate(endDT.trim(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    sDT = GigflexDateUtil.convertStringDateToGMT(stratDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    if (sDT == null || eDT == null) {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                        return derr.toString();
                    }
                    Calendar cal = Calendar.getInstance();
                    cal.setTime(eDT);
                    cal.add(Calendar.DATE, 1);
                    eDT = cal.getTime();
                }
                List<Object> objlstCheck = null;
                int count = 0;
                if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                    List<String> stlst = new ArrayList<String>();
                    stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                    stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                    stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                    stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                    stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                    stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                    stlst.add(GigflexConstants.JOBSTATUS_PENDING);
                    stlst.add(GigflexConstants.JOBSTATUS_REJECTED);
                    status = stlst;
                }

                List<Object> objlst = null;
                List<Object> objlstfordist = null;
                if (sDT != null && eDT != null) {
                    objlstCheck = jobsAssignToWorkerRepository.getAllJobsByWorkerCodeWithFilter(workerCode, status, sDT, eDT);
                    objlst = jobsAssignToWorkerRepository.getAllJobsByWorkerCodeWithFilter(workerCode, status, sDT, eDT,orderLst, pageableRequest);
                    objlstfordist = jobsAssignToWorkerRepository.getAllJobsByWorkerCodeWithFilterForDist(workerCode, status, sDT, eDT, pageableRequest);
                    if (objlstCheck != null && objlstCheck.size() > 0) {
                        count = objlstCheck.size();
                    }
                } else {
                    objlstCheck = jobsAssignToWorkerRepository.getAllJobsByWorkerCodeWithFilter(workerCode, status);
                    objlst = jobsAssignToWorkerRepository.getAllJobsByWorkerCodeWithFilter(workerCode, status,orderLst, pageableRequest);
                    objlstfordist = jobsAssignToWorkerRepository.getAllJobsByWorkerCodeWithFilterForDist(workerCode, status, pageableRequest);
                    if (objlstCheck != null && objlstCheck.size() > 0) {
                        count = objlstCheck.size();
                    }
                }
                HashMap <String,PatientDetails> patientMap=new HashMap<>();
                HashMap <String,Double> jobDurationDistanceMap=new HashMap<>();
                HashMap <String,String> startDatePatientCodeMap=new HashMap<>();
                if(objlstfordist!=null && objlstfordist.size()>0)
                {
                    for (Object object : objlstfordist) {
                        Object[] obj = (Object[]) object;
                        if (obj.length >= 3) {
                            Jobs j = (Jobs) obj[0];
                            JobsDuration jd = (JobsDuration) obj[1];
                            JobsAssignToWorker aws=(JobsAssignToWorker) obj[2];
                            if(!patientMap.containsKey(j.getPatientCode()))
                            {
                            PatientDetails pd = patientDao.getPatientDetailsBypatientCode(j.getPatientCode());
                            if(pd!=null && pd.getId()>0)
                            {
                                patientMap.put(j.getPatientCode(), pd);
                            }
                            }
                            if (timezone != null && timezone.length() > 0) {
                                Date startDate = jd.getStartTime();
                                startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                String startDt = GigflexDateUtil.convertDateToString(startDate, GigflexConstants.YYYY_MM_DD);
                                if (!startDatePatientCodeMap.containsKey(startDt)) {
                                    PatientDetails pdSource =  patientMap.get(j.getPatientCode());
                                     if(pdSource!=null && pdSource.getId()>0)
                                   {
                                        Double distance = distance(worker.getLatitude(), worker.getLongitude(),pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
                                        jobDurationDistanceMap.put(jd.getJobsDurationCode(), distance);
                                   }
                                    startDatePatientCodeMap.put(startDt, j.getPatientCode());
                                } else {
                                   String pcode=startDatePatientCodeMap.get(startDt);
                                   if(pcode!=null)
                                   {
                                   PatientDetails pd =patientMap.get(pcode);
                                   if(pd!=null && pd.getId()>0)
                                   {
                                     PatientDetails pdSource =  patientMap.get(j.getPatientCode());
                                     if(pdSource!=null && pdSource.getId()>0)
                                   {
                                       Double distance = distance(pd.getPatientLatitude(), pd.getPatientLongitude(),pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
                                        jobDurationDistanceMap.put(jd.getJobsDurationCode(), distance);
                                   }
                                   }
                                   }
                                    startDatePatientCodeMap.put(startDt, j.getPatientCode());
                                }
                            }
                            
                        }
                    }
                   
                }

                List<JobAssigntoWorkerWithFilterforWorkerResponse> awslst = new ArrayList<JobAssigntoWorkerWithFilterforWorkerResponse>();
                if (objlst != null && objlst.size() > 0) {
                    for (Object object : objlst) {
                        JobAssigntoWorkerWithFilterforWorkerResponse aws = new JobAssigntoWorkerWithFilterforWorkerResponse();
                        Object[] obj = (Object[]) object;
                        if (obj.length >= 3) {
                            Jobs j = (Jobs) obj[0];
                            JobsDuration jd = (JobsDuration) obj[1];
                            aws.setJobsAssignToWorker((JobsAssignToWorker) obj[2]);
//                            
                           aws.setDateFormat(dateformat);
                           aws.setTimeFormat(timeformat);

                            String startDt = "";
                            String endDt = "";
                            Date sdt = null;
                            Date edt = null;
                            if (timezone != null && timezone.length() > 0) {
                                Date startDate = jd.getStartTime();
                                startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                sdt = startDate;
                                startDt = GigflexDateUtil.convertDateToString(startDate, dtFormat);
                                Date endDate = jd.getEndTime();
                                endDate = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                edt = endDate;
                                endDt = GigflexDateUtil.convertDateToString(endDate, dtFormat);
                            }
                            aws.setEndTime(endDt);
                            aws.setEndTimeStamp(edt);
                            aws.setJobName(jd.getJobName());
                            aws.setJobsCode(j.getJobsCode());
                            aws.setJobsDurationCode(jd.getJobsDurationCode());
                            aws.setNotes(jd.getNotes());
                            aws.setStartTime(startDt);
                            aws.setStartTimeStamp(sdt);
                            aws.setProcedureCode(j.getProcedureCode());
                            if (j.getProcedureCode() != null && j.getProcedureCode().length() > 0) {
                                ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(j.getProcedureCode());
                                aws.setProcedureMaster(pm);
                            }
                            aws.setOrganizationCode(j.getOrganizationCode());
                            if (j.getOrganizationCode() != null && j.getOrganizationCode().length() > 0) {

                                Organization o = organizationRepository.findByOrganizationCode(j.getOrganizationCode());
                                if (o != null && o.getId() > 0) {
                                    aws.setOrganizationName(o.getOrganizationName());
                                }
                            }

                            aws.setPatientCode(j.getPatientCode());
                            PatientDetails pd =  patientMap.get(j.getPatientCode());
                            aws.setPatientDetails(pd);
                            Double distance=jobDurationDistanceMap.get(jd.getJobsDurationCode());
                            if(distance!=null && distance>0)
                            {
                                aws.setDistance(distance.toString());
                            }
//                            if (j.getPatientCode() != null && j.getPatientCode().length() > 0) {
//                                PatientDetails pd = patientDao.getPatientDetailsBypatientCode(j.getPatientCode());
//                                aws.setPatientDetails(pd);
//                            }
                            
                            awslst.add(aws);
                        }
                    }
                    if (awslst != null && awslst.size() > 0) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Success");
                        jsonobj.put("count", count);
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(awslst);
                        jsonobj.put("data", new JSONArray(Detail));
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Records not found.");
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Records not found.");
                }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Worker not found.");
                }
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;

    }

    @Override
    public String gettodaysAppoinmentsforMobileByworkerCode(String workerCode) {
        String res = "";
        try {
             List<String> orderLst = new ArrayList<String>();
                orderLst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                orderLst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
            
            List<TodaysAssignedPatientListResForMobile> assignedPationentList = new ArrayList<>();
            List<TodaysAssignedPatientListResForMobile> assignedPationentList2 = new ArrayList<>();

            JSONObject jsonobj = new JSONObject();
             String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.TimeZone);
             String timezone = null;
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                        if (tzd != null && tzd.getId() > 0) {
                            timezone = tzd.getTimeZoneName();
                        }
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dFormat = GigflexConstants.YYYY_MM_DD;
                        String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.DATEFORMAT);
                        String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.TIMEFORMAT);
                        if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                            dtFormat = dateformat.trim() + " " + timeformat.trim();
                        }
                        if (dateformat != null && dateformat.trim().length() > 0) {
                            dFormat = dateformat.trim() ;
                        }
            Date d = new Date();
            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            String date1 = dateFormat.format(d);
            //DateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String date2 = date1 + " 00:00:00";
            Date startTime = GigflexDateUtil.convertStringDateToGMT(date2, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);

            String date3 = date1 + " 23:59:59";
            Date endTime =GigflexDateUtil.convertStringDateToGMT(date3, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
            List<Object> objlist = jobsAssignToWorkerRepository.getTodaysCurruntAppointmentByworkerCode(workerCode, GigflexConstants.JOBSTATUS_ACCEPTED, GigflexConstants.JOBSTATUS_INPROGRESS, startTime, endTime,orderLst);
            if (objlist != null && objlist.size() > 0) {
                for (Object o : objlist) {
                    TodaysAssignedPatientListResForMobile ap = new TodaysAssignedPatientListResForMobile();
                    Object[] arr = (Object[]) o;
                    if (arr.length >= 3) {
                        JobsAssignToWorker js = (JobsAssignToWorker) arr[0];
                        JobsDuration jd = (JobsDuration) arr[1];
                        Jobs j = (Jobs) arr[2];
                        ap.setStatus(js.getStatus());
                        PatientDetails pd = patientDao.getPatientDetailsBypatientCode(j.getPatientCode());
                        ap.setDistance(js.getDistance());
                        ap.setJobDurationCode(js.getJobsDurationCode());
                        ap.setName(pd.getPatientName());
                        ap.setAddress(pd.getPatientAddress()+" "+pd.getPatientCity()+" "+pd.getPatientState()+" "+pd.getPatientCountry()+" "+pd.getZipCode());
                        ap.setPatientLatitude(pd.getPatientLatitude());
                        ap.setPatientLongitude(pd.getPatientLongitude());
                        ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(j.getProcedureCode());
                        ap.setProcedureIcon(pm.getProcedureIcon());
                       

                        String startDt = "";
                        String endDt = "";
                        Date sdt = null;
                        Date edt = null;
                        if (timezone != null && timezone.length() > 0) {
                            Date startDate = jd.getStartTime();
                            startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                            sdt = startDate;
                            startDt = GigflexDateUtil.convertDateToString(startDate, dtFormat);
                            Date endDate = jd.getEndTime();
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                            edt = endDate;
                            endDt = GigflexDateUtil.convertDateToString(endDate, dtFormat);
                        }
                        long time = 0;
                        long diffMs = edt.getTime() - sdt.getTime();
                        long diffSec = diffMs / 1000;
                        long min = diffSec / 60;
                        time = min;
                        if (time < 59) {
                            ap.setTime(time + " minute");
                        } else if (time >= 60) {
                            long hr = time / 60;
                            if (hr > 24) {
                                ap.setTime(hr + "day");
                            } else {
                                ap.setTime(hr + " Hours");
                            }

                        }

//                   if(time>60)
//                   {
//                    long hr=min/60;
//                   ap.setTime(hr+" hours");
//                   }else
//                   {
//                       
//                    ap.setTime(time+" min");
//                   }
                        ap.setStartTime(startDt);
                        ap.setEndTime(endDt);
                        String sdtstr=GigflexDateUtil.convertDateToString(sdt, dFormat);
                        ap.setDate(sdtstr);
                        assignedPationentList.add(ap);
                    }
                }
            }

            List<Object> objlist2 = jobsAssignToWorkerRepository.getCurruntAppointmentByworkerCode(workerCode, GigflexConstants.JOBSTATUS_ASSIGNED);
            if (objlist2 != null && objlist2.size() > 0) {
                int count = 0;
                for (Object o : objlist2) {
                    TodaysAssignedPatientListResForMobile ap = new TodaysAssignedPatientListResForMobile();
                    Object[] arr = (Object[]) o;
                    if (arr.length >= 3) {
                        count++;
                        JobsAssignToWorker js = (JobsAssignToWorker) arr[0];
                        JobsDuration jd = (JobsDuration) arr[1];
                        Jobs j = (Jobs) arr[2];
                        ap.setStatus(js.getStatus());
                        PatientDetails pd = patientDao.getPatientDetailsBypatientCode(j.getPatientCode());
                        ap.setName(pd.getPatientName());
                        ap.setAddress(pd.getPatientAddress()+" "+pd.getPatientCity()+" "+pd.getPatientState()+" "+pd.getPatientCountry()+" "+pd.getZipCode());

                        ap.setDistance(js.getDistance());
                        ap.setJobDurationCode(js.getJobsDurationCode());
                        ap.setPatientLatitude(pd.getPatientLatitude());
                        ap.setPatientLongitude(pd.getPatientLongitude());
                        ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(j.getProcedureCode());
                        ap.setProcedureIcon(pm.getProcedureIcon());
                        
                        String startDt = "";
                        String endDt = "";
                        Date sdt = null;
                        Date edt = null;
                        if (timezone != null && timezone.length() > 0) {
                            Date startDate = jd.getStartTime();
                            startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                            sdt = startDate;
                            startDt = GigflexDateUtil.convertDateToString(startDate, dtFormat);
                            Date endDate = jd.getEndTime();
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                            edt = endDate;
                            endDt = GigflexDateUtil.convertDateToString(endDate, dtFormat);
                        }
                        long time = 0;
                        long diffMs = edt.getTime() - sdt.getTime();
                        long diffSec = diffMs / 1000;
                        long min = diffSec / 60;
                        time = min;
                        if (time < 59) {
                            ap.setTime(time + " minute");
                        } else if (time >= 60) {
                            long hr = time / 60;
                            if (hr > 24) {
                                ap.setTime(hr + "day");
                            } else {
                                ap.setTime(hr + " Hours");
                            }

                        }

                        ap.setStartTime(startDt);
                        ap.setEndTime(endDt);
                        DateFormat date = new SimpleDateFormat(dFormat);
                        String sdtstr=GigflexDateUtil.convertDateToString(sdt, dFormat);
                        ap.setDate(sdtstr);
                        assignedPationentList2.add(ap);
                        if (count >= 2) {
                            break;
                        }
                    }
                }
            }

            if ((assignedPationentList != null && assignedPationentList.size() > 0) || (assignedPationentList2 != null && assignedPationentList2.size() > 0)) {
                JSONObject obj2 = new JSONObject();
                ObjectMapper mapper = new ObjectMapper();
                String Detail = mapper.writeValueAsString(assignedPationentList);
                obj2.put("TodaysAppointments", new JSONArray(Detail));

                ObjectMapper mapper2 = new ObjectMapper();
                String Detail2 = mapper2.writeValueAsString(assignedPationentList2);
                obj2.put("NewAppointments", new JSONArray(Detail2));

                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("data", obj2);

            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobsAssignToWorker not found");
            }
            res = jsonobj.toString();

        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerAccepted>>>>>", ex);

        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in assignToWorkerAccepted>>>>>", ex);
        }
        return res;
    }

    @Override
    public String getEligibleWorkerForJobsByJobDurationCode(String jobDurationCode) {

        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            Object o = jobsDurationRepository.getJobsDurationAndJobsByJobsDurationCode(jobDurationCode);
            if (o != null) {
                Object[] arr = (Object[]) o;
                if (arr.length >= 2) {
                    Jobs j = (Jobs) arr[0];
                    JobsDuration jd = (JobsDuration) arr[1];
                    if (j != null && jd != null) {
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, j.getOrganizationCode().trim(), GigflexConstants.TimeZone);
                    String orgtimezone=null;
                    if (timezoneCode != null && timezoneCode.length() > 0) {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                        if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                            orgtimezone = tzd.getTimeZoneName();
                        }
                    }
                        PatientDetails pDetail = patientDao.getPatientDetailsBypatientCode(j.getPatientCode());
                        EligibleWorkerRes ewres = null;
                        
                        List<String> skills = procedureSkillMappingDao.getProcedureSkillCodesByProcedureCode(j.getProcedureCode());

                        List<String> workerCodeList = workerApprovalStatusRepository.getAllApprovedWorkerCodesByOrgCode(j.getOrganizationCode());
                        if (workerCodeList.size() > 0 && skills.size() > 0) {

                            ewres = new EligibleWorkerRes();
                            ewres.setJobsCode(jd.getJobsCode());
                            ewres.setJobsDurationCode(jd.getJobsDurationCode());
                            List<String> workerList = new ArrayList<String>();
                            workerList.addAll(workerCodeList);
                            List<WorkerWithDistance> eligWorkerLst = new ArrayList<WorkerWithDistance>();
                            Date jdStartime = jd.getStartTime();
                            Date jdEndTime = jd.getEndTime();
                            Calendar cal = Calendar.getInstance();

                            cal.setTime(jdStartime);
                            cal.add(Calendar.HOUR_OF_DAY, -1);
                            Date decrementedjdStartime = cal.getTime();

                            cal.setTime(jdEndTime);
                            cal.add(Calendar.HOUR_OF_DAY, 1);
                            Date incrementedjdEndTime = cal.getTime();
                            List<String> busyWorkerList = jobsAssignToWorkerRepository.getBusyWorkerList(decrementedjdStartime, incrementedjdEndTime, workerList, GigflexConstants.JOBSTATUS_CANCELLED, GigflexConstants.JOBSTATUS_REJECTED);
                            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getAssignedWorkerList(GigflexConstants.JOBSTATUS_ASSIGNED,GigflexConstants.JOBSTATUS_ACCEPTED,jobDurationCode);
                            workerList.removeAll(busyWorkerList);
                                                       
                             if(jaw != null && jaw.getWorkerCode()!=null) {
                                String assignedAcceptedWorker=jaw.getWorkerCode();
                                WorkerWithDistance eligWorker = new WorkerWithDistance();
                                List<String> matchedskills = orgWorkerSkillDao.getSkillCodeListByworkerCodeAndSkills(assignedAcceptedWorker, skills);
                                if ( !(matchedskills.size() < skills.size())) {
                                                                        
                                    List<WorkerTimeOff> workerTimeOffList = workerTimeOffDao.getTimeOffByWorkerCodeAndBetweenDateTimeStamp(assignedAcceptedWorker, jdStartime, jdEndTime);
                                    if (  !(workerTimeOffList != null && workerTimeOffList.size() > 0)) {
                                       
                                        Worker wkr = workerRepository.getWorkerdetailByworkerCode(assignedAcceptedWorker);
                                        if (wkr != null && wkr.getId() > 0) {

                                            eligWorker.setWorker(wkr);
                                            eligWorker.setDistance(jaw.getDistance());
                                            eligWorker.setIsAssigned(true); 
                                            eligWorkerLst.add(eligWorker);
                                        }
                                    }                                    
                                }

                             }
                            
                            for (String workerCode : workerList) {
                                WorkerWithDistance eligWorker = new WorkerWithDistance();
                                List<String> matchedskills = orgWorkerSkillDao.getSkillCodeListByworkerCodeAndSkills(workerCode, skills);
                                if (matchedskills.size() < skills.size()) {
                                    continue;
                                }

                                List<WorkerTimeOff> workerTimeOffList = workerTimeOffDao.getTimeOffByWorkerCodeAndBetweenDateTimeStamp(workerCode, jdStartime, jdEndTime);
                                if (workerTimeOffList != null && workerTimeOffList.size() > 0) {
                                    continue;
                                }
                                
                                 String timezone=null;
                    String timezoneCodeW = GigflexUtility.findSettingValueByNameFromLocal(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician,workerCode, GigflexConstants.TimeZone);
                    if (timezoneCodeW != null && timezoneCodeW.length() > 0) {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCodeW);
                        if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                            timezone = tzd.getTimeZoneName();
                        }
                    }
                    if(timezone==null || timezone.isEmpty())
                    {
                        timezone=orgtimezone;
                    }
                    
                    
                    
                    Boolean hopNot=false;
                Date timestampStartTime =null;
               try{
               timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(jd.getStartTime(), orgtimezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
               
                   if (timestampStartTime != null) {
                       String stDate=GigflexDateUtil.convertDateToString(timestampStartTime, GigflexConstants.YYYY_MM_DD);
                       if(stDate!=null)
                       {
                       Calendar call = Calendar.getInstance();
                       call.setTime(timestampStartTime);
                       int day = call.get(Calendar.DAY_OF_WEEK);
                     
                          
                             WorkerHoursOfOperation whop= workerHoursofOperationDao.getHoursByWorkerCodeAndDayCode(workerCode, day);
                              if(whop!=null && whop.getFromTime()!=null && whop.getFromTime().length()>0 && whop.getToTime()!=null && whop.getToTime().length()>0)
                              {
                              String startDT = stDate + " "+whop.getFromTime();
                              String endDT = stDate + " "+whop.getToTime();
                            
                              Date  sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                              Date  eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS); 
                              if(sDT!=null && eDT!=null)
                              {
                                  if(sDT.after(jd.getStartTime()))
                                  {
                                      hopNot=true;
                                  }
                                  if(eDT.before(jd.getEndTime()))
                                  {
                                     hopNot=true; 
                                  }
                              }
                              }
                      
                       }
                   }
               }catch(Exception e)
               {
                   e.printStackTrace();
                   LOG.error("Error in geteligible API date conversion>>>", e);
               }
               
               if(hopNot)
               {
                   continue;
               }
                                
                                Worker wkr = workerRepository.getWorkerdetailByworkerCode(workerCode);
                                if (wkr != null && wkr.getId() > 0) {
                                    eligWorker.setWorker(wkr);
                                    PatientDetails pd=findLastPatientDeatil(wkr,jd.getStartTime(),orgtimezone);
                                    if(pd!=null)
                                    {
                                        if (pDetail != null && pDetail.getPatientLatitude() != null && pDetail.getPatientLatitude().trim().length() > 0 && pDetail.getPatientLongitude() != null && pDetail.getPatientLongitude().trim().length() > 0 && pd.getPatientLatitude() != null && pd.getPatientLatitude().trim().length() > 0 && pd.getPatientLongitude()!= null && pd.getPatientLongitude().trim().length() > 0) {
                                        Double distance = distance(pd.getPatientLatitude().trim(),pd.getPatientLongitude().trim(),pDetail.getPatientLatitude().trim(), pDetail.getPatientLongitude().trim());
                                        eligWorker.setDistance(distance);
                                    }
                                    }
                                    else
                                    {
                                    if (pDetail != null && pDetail.getPatientLatitude() != null && pDetail.getPatientLatitude().trim().length() > 0 && pDetail.getPatientLongitude() != null && pDetail.getPatientLongitude().trim().length() > 0 && wkr.getLatitude() != null && wkr.getLatitude().trim().length() > 0 && wkr.getLongitude() != null && wkr.getLongitude().trim().length() > 0) {
                                        Double distance = distance(pDetail.getPatientLatitude().trim(), pDetail.getPatientLongitude().trim(), wkr.getLatitude().trim(), wkr.getLongitude().trim());
                                        eligWorker.setDistance(distance);
                                    }
                                    }
                                    eligWorker.setIsAssigned(false); 
                                    eligWorkerLst.add(eligWorker);
                                }

                            }
                            ewres.setWorkerWithDistanceList(eligWorkerLst);

                        }

                        if (ewres != null) {
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Success");
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(ewres);
                            jsonobj.put("data", new JSONObject(Detail));
                        } else {
                            jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Worker not found");
                        }

                    } else {
                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Jobs not found");
                    }
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Jobs not found");
                }
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Jobs not found");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;
    }

    public String assignToWorkerAcceptedByJobDurationCode(AssignToWorkerReqNew req, String jobDurationCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsDurationCode(jobDurationCode);
            if (jaw != null && jaw.getId() > 0) {

                jaw.setIpAddress(ip);
                //jaw.setDistance(req.getDistance());
                jaw.setWorkerCode(req.getWorkerCode());
                jaw.setStatus(GigflexConstants.JOBSTATUS_ACCEPTED);
                JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                if (jawres != null && jawres.getId() > 0) {

                    HealthcareNotification notification = new HealthcareNotification();
                    String appointmentId = jaw.getAppointmentId();

                    Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                    String organizationCode = "";
                    if (job != null) {
                        organizationCode = job.getOrganizationCode();
                    }

                    Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                    String organizationName = "";
                    if (org != null) {
                        organizationName = org.getOrganizationName();
                    }
                    String workerCode = jawres.getWorkerCode();
                    Worker worker = workerRepository.findByWorkerCode(workerCode);
                    Users user = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);

                    String workerName = "";
                    if (worker != null) {
                        workerName = worker.getName();
                    }

                    JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                    Date startTime = null;
                    Date endTime = null;
                    if (jd != null) {
                        startTime = jd.getStartTime();
                        endTime = jd.getEndTime();
                    }

                    Date stDate = null;
                    Date endDate = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatView = dtFormat;
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                        String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                        if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                            dtFormatView = dateformat.trim() + " " + timeformat.trim();
                        }

                        if (timezoneCode != null && timezoneCode.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                        }
                    }

                    String message = "Job has been Accepted";
                    String bodyContentShortMessage = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;

                    String shortMessage = "" + message + "";

                    String email = "";
                    String userCode ="";
                    if (user != null) {
                        email = user.getEmail();
                        userCode = user.getUserCode();
                    }
                    notification.setUserCode(userCode);
                    notification.setMessage(bodyContentShortMessage);
                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                    notification.setShortMessage(shortMessage);
                    notification.setAppointmentCode(appointmentId);
                    notification.setIsRead(Boolean.FALSE);
                    notification.setIpAddress(ip);

                    notificationService.saveHealthcareNotification(notification);

                    
                    String bodyContent = message + ". Details are given below-<br>"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;
                    SendNotification sn = new SendNotification();

                    if (email != null && email.length() > 0) {
                        String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                    }

                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job has been accepted.");
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job Accepted has been failed.");
                }
                res = jsonobj.toString();
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobDurationCode not found");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
    public String assignToWorkerrejectedByJobDurationCode(RejectToworkerreq Req, String jobdurationCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsDurationCode(jobdurationCode);
            if (jaw != null && jaw.getId() > 0) {

                jaw.setIpAddress(ip);
                //jaw.setDistance(req.getDistance());
                jaw.setWorkerCode(Req.getWorkerCode());
                jaw.setStatus(GigflexConstants.JOBSTATUS_REJECTED);
                jaw.setComment(Req.getComment());
                JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                if (jawres != null && jawres.getId() > 0) {

                    HealthcareNotification notification = new HealthcareNotification();
                    String appointmentId = jaw.getAppointmentId();

                    Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                    String organizationCode = "";
                    if (job != null) {
                        organizationCode = job.getOrganizationCode();
                    }

                    Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                    String organizationName = "";
                    if (org != null) {
                        organizationName = org.getOrganizationName();
                    }
                    String workerCode = jawres.getWorkerCode();
                    Worker worker = workerRepository.findByWorkerCode(workerCode);
                    Users user = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);

                    String workerName = "";
                    if (worker != null) {
                        workerName = worker.getName();
                    }

                    JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                    Date startTime = null;
                    Date endTime = null;
                    if (jd != null) {
                        startTime = jd.getStartTime();
                        endTime = jd.getEndTime();
                    }

                    Date stDate = null;
                    Date endDate = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatView = dtFormat;
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                        String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                        if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                            dtFormatView = dateformat.trim() + " " + timeformat.trim();
                        }

                        if (timezoneCode != null && timezoneCode.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                        }
                    }

                    String message = "Job has been rejected";
                    String bodyContentShortMessage = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;

                    String shortMessage = "" + message + "";

                     String email = "";
                     String userCode ="";
                    if (user != null) {
                        email = user.getEmail();
                        userCode = user.getUserCode();
                    }
                    notification.setUserCode(userCode);
                    notification.setMessage(bodyContentShortMessage);
                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                    notification.setShortMessage(shortMessage);
                    notification.setAppointmentCode(appointmentId);
                    notification.setIsRead(Boolean.FALSE);
                    notification.setIpAddress(ip);

                    notificationService.saveHealthcareNotification(notification);

                   
                    String bodyContent = message + ". Details are given below-<br>"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;
                    SendNotification sn = new SendNotification();

                    if (email != null && email.length() > 0) {
                        String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                    }

                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job has been rejected.");
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job Rejection has been failed.");
                }
                res = jsonobj.toString();
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobDurationCode not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
    public String assignToWorkercancelByJobDurationCode(CancelToworkerReq Req, String jobDurationCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsDurationCode(jobDurationCode);
            if (jaw != null && jaw.getId() > 0) {

                jaw.setIpAddress(ip);
                //jaw.setDistance(req.getDistance());
//                jaw.setWorkerCode(Req.getWorkerCode());
                jaw.setStatus(GigflexConstants.JOBSTATUS_CANCELLED);
                jaw.setComment(Req.getComment());
                JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                if (jawres != null && jawres.getId() > 0) {

                    HealthcareNotification notification = new HealthcareNotification();
                    String appointmentId = jaw.getAppointmentId();

                    Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                    String organizationCode = "";
                    if (job != null) {
                        organizationCode = job.getOrganizationCode();
                    }

                    Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                    String organizationName = "";
                    if (org != null) {
                        organizationName = org.getOrganizationName();
                    }
                    String workerCode = jawres.getWorkerCode();
                    Worker worker = workerRepository.findByWorkerCode(workerCode);

                    String workerName = "";
                    if (worker != null) {
                        workerName = worker.getName();
                    }

                    JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                    Date startTime = null;
                    Date endTime = null;
                    if (jd != null) {
                        startTime = jd.getStartTime();
                        endTime = jd.getEndTime();
                    }

                    Date stDate = null;
                    Date endDate = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatView = dtFormat;
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.TimeZone);
                        String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.DATEFORMAT);
                        String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.TIMEFORMAT);
                        if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                            dtFormatView = dateformat.trim() + " " + timeformat.trim();
                        }

                        if (timezoneCode != null && timezoneCode.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                        }
                    }

                    String message = "Job has been Cancelled";
                    String bodyContentShortMessage = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;

                    String shortMessage = "" + message + "";

                    notification.setUserCode(workerCode);
                    notification.setMessage(bodyContentShortMessage);
                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                    notification.setShortMessage(shortMessage);
                    notification.setAppointmentCode(appointmentId);
                    notification.setIsRead(Boolean.FALSE);
                    notification.setIpAddress(ip);

                    notificationService.saveHealthcareNotification(notification);

                    String email = "";
                    if (worker != null) {
                        email = worker.getEmail();
                    }
                    String bodyContent = message + ". Details are given below-<br>"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;
                    SendNotification sn = new SendNotification();

                    if (email != null && email.length() > 0) {
                        String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                    }
                    
                    List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(worker.getWorkerCode().trim());
                    if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                     {
                       //for push notification 
                         for(DeviceDetail deviceDetail : deviceDetailResList)
                         {
                             PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Job Alert", bodyContentShortMessage);
                         }                                                        
                     }

                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job has been Cancelled.");
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job Cancelation has been failed.");
                }
                res = jsonobj.toString();
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobDurationCode not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
    public String assignToWorkerInProgressByJobDurationCode(AssignWorkerInProgerssStatusReq Req, String jobDurationCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsDurationCode(jobDurationCode);
            if (jaw != null && jaw.getId() > 0) {

           PatientDetails pds= patientDao.getPatientDetailByjobCode(jaw.getJobsCode());
              if(pds!=null && pds.getId()>0)
              {
              Double miles=distance(Req.getCurruntLatitude().trim(), Req.getCurruntLongitude().trim(),  pds.getPatientLatitude(),  pds.getPatientLongitude());
             
                if(miles==null || miles > 1)
                {GigflexResponse derr = new GigflexResponse(500, new Date(), "You are not present in Currunt Location");
		      return derr.toString();
                    
                }
                jaw.setStartLat(Req.getCurruntLatitude());
                jaw.setStartLong(Req.getCurruntLongitude());
                jaw.setIpAddress(ip);
                //jaw.setDistance(req.getDistance());
                jaw.setWorkerCode(Req.getWorkerCode());
                jaw.setStatus(GigflexConstants.JOBSTATUS_INPROGRESS);
                jaw.setComment(Req.getComment());
                JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                if (jawres != null && jawres.getId() > 0) {

                    HealthcareNotification notification = new HealthcareNotification();
                    String appointmentId = jaw.getAppointmentId();

                    Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                    String organizationCode = "";
                    if (job != null) {
                        organizationCode = job.getOrganizationCode();
                    }

                    Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                    String organizationName = "";
                    if (org != null) {
                        organizationName = org.getOrganizationName();
                    }
                    String workerCode = jawres.getWorkerCode();
                    Worker worker = workerRepository.findByWorkerCode(workerCode);
                    Users user = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);

                    String workerName = "";
                    if (worker != null) {
                        workerName = worker.getName();
                    }

                    JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                    Date startTime = null;
                    Date endTime = null;
                    if (jd != null) {
                        startTime = jd.getStartTime();
                        endTime = jd.getEndTime();
                    }

                    Date stDate = null;
                    Date endDate = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatView = dtFormat;
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                        String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                        if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                            dtFormatView = dateformat.trim() + " " + timeformat.trim();
                        }

                        if (timezoneCode != null && timezoneCode.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                            
                        }
                    }

                    String message = "Job has been inProgress";
                     String email = "";
                     String userCode ="";
                    if (user != null) {
                        email = user.getEmail();
                        userCode = user.getUserCode();
                    }
                    
                    String bodyContentShortMessage = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;

                    String shortMessage = "" + message + "";

                    notification.setUserCode(userCode);
                    notification.setMessage(bodyContentShortMessage);
                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                    notification.setShortMessage(shortMessage);
                    notification.setAppointmentCode(appointmentId);
                    notification.setIsRead(Boolean.FALSE);
                    notification.setIpAddress(ip);

                    notificationService.saveHealthcareNotification(notification);

                   
                    String bodyContent = message + ". Details are given below-<br>"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;
                    SendNotification sn = new SendNotification();

                    if (email != null && email.length() > 0) {
                        String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                    }

                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job is inProgress");
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job Progration has been failed.");
                }
//                       res=jsonobj.toString();
//                  
//                 res=jsonobj.toString();
              }else{
                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "PateintDetails is not found.");
                  }
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobDurationCode  is not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
        }
        return res;
    }

    public String assignToWorkercompleteByJobDurationCode(AssignWorkerInProgerssStatusReq Req, String jobDurationCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsDurationCode(jobDurationCode);
            if (jaw != null && jaw.getId() > 0) {

                PatientDetails pds = patientDao.getPatientDetailByjobCode(jaw.getJobsCode());
                if (pds != null && pds.getId() > 0) {
                    
                    Double miles = distance(Req.getCurruntLatitude().trim(), Req.getCurruntLongitude().trim(), pds.getPatientLatitude(), pds.getPatientLongitude());
                    if (miles!=null && miles < 1) {
                        jaw.setIpAddress(ip);
                        //jaw.setDistance(req.getDistance());
                        jaw.setEndLat(Req.getCurruntLatitude());
                        jaw.setEndLong(Req.getCurruntLongitude());
                        jaw.setWorkerCode(Req.getWorkerCode());
                        jaw.setStatus(GigflexConstants.JOBSTATUS_COMPLETED);
                        jaw.setComment(Req.getComment());
                        JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                        if (jawres != null && jawres.getId() > 0) {
                            HealthcareNotification notification = new HealthcareNotification();
                            String appointmentId = jaw.getAppointmentId();

                            Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                            String organizationCode = "";
                            if (job != null) {
                                organizationCode = job.getOrganizationCode();
                            }

                            Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                            String organizationName = "";
                            if (org != null) {
                                organizationName = org.getOrganizationName();
                            }
                            String workerCode = jawres.getWorkerCode();
                            Worker worker = workerRepository.findByWorkerCode(workerCode);
                            Users user = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);

                            String workerName = "";
                            if (worker != null) {
                                workerName = worker.getName();
                            }

                            JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                            Date startTime = null;
                            Date endTime = null;
                            if (jd != null) {
                                startTime = jd.getStartTime();
                                endTime = jd.getEndTime();
                            }

                            Date stDate = null;
                            Date endDate = null;
                            if (startTime != null && endTime != null) {
                                String timezone = null;
                                String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                                String dtFormatView = dtFormat;
                                String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                                String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                                String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                                if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                                    dtFormatView = dateformat.trim() + " " + timeformat.trim();
                                }

                                if (timezoneCode != null && timezoneCode.length() > 0) {
                                    TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                    if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                        timezone = tzd.getTimeZoneName();
                                    }
                                }

                                if (timezone != null) {
                                    stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                                    endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                                }
                            }

                            String message = "Job has been Completed";
                            String bodyContentShortMessage = message + ". Details are given below-"
                                    + "Worker Name : " + workerName
                                    + "Organization Name : " + organizationName
                                    + " Start Time : " + stDate
                                    + " End Time : " + endDate
                                    + " Appointment ID : " + appointmentId;

                            String shortMessage = "" + message + "";

                            String email = "";
                            String userCode ="";
                            if (user != null) {
                                email = user.getEmail();
                                userCode = user.getUserCode();
                            }
                            
                            notification.setUserCode(userCode);
                            notification.setMessage(bodyContentShortMessage);
                            notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                            notification.setShortMessage(shortMessage);
                            notification.setAppointmentCode(appointmentId);
                            notification.setIsRead(Boolean.FALSE);
                            notification.setIpAddress(ip);

                            notificationService.saveHealthcareNotification(notification);

                           
                            String bodyContent = message + ". Details are given below-<br>"
                                    + "Worker Name : " + workerName
                                    + "Organization Name : " + organizationName
                                    + " Start Time : " + stDate
                                    + " End Time : " + endDate
                                    + " Appointment ID : " + appointmentId;
                            SendNotification sn = new SendNotification();

                            if (email != null && email.length() > 0) {
                                String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                                LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                            }
                            
                            List<DeviceDetail> deviceDetailResList = deviceDetailDao.getDeviceDetailByUserCode(worker.getWorkerCode().trim());
                            if(deviceDetailResList != null && deviceDetailResList.size() > 0)
                             {
                               //for push notification 
                                 for(DeviceDetail deviceDetail : deviceDetailResList)
                                 {
                                     PushNotification.pushFCMNotification(FMCurl,authKey,deviceDetail.getDeviceId(), "Job Alert", bodyContentShortMessage);
                                 }                                                        
                             }

                            jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Job is Completed");
                        } else {
                            jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Job Completion has been failed.");
                        }
                        res = jsonobj.toString();
                    } else {
                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "You are not present in Currunt Location");
                    }
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "PatientDetails  is not found.");
                }
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobDurationCode  is not found.");
            }

            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
        }
        return res;
    }

    public String assignToWorkerPendingByJobDurationCode(RejectToworkerreq Req, String jobDurationCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsDurationCode(jobDurationCode);
            if (jaw != null && jaw.getId() > 0) {

                jaw.setIpAddress(ip);
                //jaw.setDistance(req.getDistance());
                jaw.setWorkerCode(Req.getWorkerCode());
                jaw.setStatus(GigflexConstants.JOBSTATUS_PENDING);
                jaw.setComment(Req.getComment());
                JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                if (jawres != null && jawres.getId() > 0) {

                    HealthcareNotification notification = new HealthcareNotification();
                    String appointmentId = jaw.getAppointmentId();

                    Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                    String organizationCode = "";
                    if (job != null) {
                        organizationCode = job.getOrganizationCode();
                    }

                    Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                    String organizationName = "";
                    if (org != null) {
                        organizationName = org.getOrganizationName();
                    }
                    String workerCode = jawres.getWorkerCode();
                    Worker worker = workerRepository.findByWorkerCode(workerCode);
                    Users user = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);

                    String workerName = "";
                    if (worker != null) {
                        workerName = worker.getName();
                    }

                    JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                    Date startTime = null;
                    Date endTime = null;
                    if (jd != null) {
                        startTime = jd.getStartTime();
                        endTime = jd.getEndTime();
                    }

                    Date stDate = null;
                    Date endDate = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatView = dtFormat;
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                        String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                        if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                            dtFormatView = dateformat.trim() + " " + timeformat.trim();
                        }

                        if (timezoneCode != null && timezoneCode.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDate = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatView);
                            endDate = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatView);
                        }
                    }

                    String message = "Job has been pending";
                    String bodyContentShortMessage = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;

                    String shortMessage = "" + message + "";

                    String email = "";
                    String userCode ="";
                    if (user != null) {
                        email = user.getEmail();
                        userCode = user.getUserCode();
                    }
                    
                    notification.setUserCode(userCode);
                    notification.setMessage(bodyContentShortMessage);
                    notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                    notification.setShortMessage(shortMessage);
                    notification.setAppointmentCode(appointmentId);
                    notification.setIsRead(Boolean.FALSE);
                    notification.setIpAddress(ip);

                    notificationService.saveHealthcareNotification(notification);

                   
                    String bodyContent = message + ". Details are given below-<br>"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDate
                            + " End Time : " + endDate
                            + " Appointment ID : " + appointmentId;
                    SendNotification sn = new SendNotification();

                    if (email != null && email.length() > 0) {
                        String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                        LOG.info("Cron scheduler mail response in DriverTimeOffServiceImpl >>>>>>", response);
                    }

                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job is pending");
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job pending has been failed.");
                }
                res = jsonobj.toString();
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobDurationCode  is not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
    public String assignToWorkerexpiredByJobDurationCode(CancelToworkerReq Req, String jobDurationCode, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsAssignToWorker jaw = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsDurationCode(jobDurationCode);
            if (jaw != null && jaw.getId() > 0) {

                jaw.setIpAddress(ip);
                //jaw.setDistance(req.getDistance());
//                jaw.setWorkerCode(Req.getWorkerCode());
                jaw.setStatus(GigflexConstants.JOBSTATUS_EXPIRED);
                jaw.setComment(Req.getComment()); 

                JobsAssignToWorker jawres = jobsAssignToWorkerRepository.save(jaw);
                if (jawres != null && jawres.getId() > 0) {

                    HealthcareNotification notification = new HealthcareNotification();
                    HealthcareNotification notificationWorker = new HealthcareNotification();
                    String appointmentId = jaw.getAppointmentId();

                    Jobs job = jobsRepository.getJobsByJobsCode(jawres.getJobsCode());
                    String organizationCode = "";
                    if (job != null) {
                        organizationCode = job.getOrganizationCode();
                    }

                    Organization org = organizationRepository.findByOrganizationCode(organizationCode);

                    String organizationName = "";
                    if (org != null) {
                        organizationName = org.getOrganizationName();
                    }
                    String workerCode = jawres.getWorkerCode();
                    Worker worker = workerRepository.findByWorkerCode(workerCode);
                    Users user = workerTimeOffDao.getAdminByOrganizationCode(organizationCode);

                    String workerName = "";
                    if (worker != null) {
                        workerName = worker.getName();
                    }

                    JobsDuration jd = jobsDurationRepository.getJobsDurationByJobsDurationCode(jawres.getJobsDurationCode());
                    Date startTime = null;
                    Date endTime = null;
                    if (jd != null) {
                        startTime = jd.getStartTime();
                        endTime = jd.getEndTime();
                    }

                    Date stDateAdmin = null;
                    Date endDateAdmin = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatViewAdmin = dtFormat;
                        String timezoneCodeAdmin = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                        String dateformatAdmin = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformatAdmin = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                        if (dateformatAdmin != null && dateformatAdmin.trim().length() > 0 && timeformatAdmin != null && timeformatAdmin.trim().length() > 0) {
                            dtFormatViewAdmin = dateformatAdmin.trim() + " " + timeformatAdmin.trim();
                        }

                        if (timezoneCodeAdmin != null && timezoneCodeAdmin.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCodeAdmin);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDateAdmin = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatViewAdmin);
                            endDateAdmin = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatViewAdmin);
                        }
                    }

                    Date stDateWorker = null;
                    Date endDateWorker = null;
                    if (startTime != null && endTime != null) {
                        String timezone = null;
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dtFormatViewWorker = dtFormat;
                        String timezoneCodeWorker = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.TimeZone);
                        String dateformatWorker = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.DATEFORMAT);
                        String timeformatWorker = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.TIMEFORMAT);
                        if (dateformatWorker != null && dateformatWorker.trim().length() > 0 && timeformatWorker != null && timeformatWorker.trim().length() > 0) {
                            dtFormatViewWorker = dateformatWorker.trim() + " " + timeformatWorker.trim();
                        }

                        if (timezoneCodeWorker != null && timezoneCodeWorker.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCodeWorker);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }

                        if (timezone != null) {
                            stDateWorker = GigflexDateUtil.getGMTtoLocationDate(startTime, timezone, dtFormatViewWorker);
                            endDateWorker = GigflexDateUtil.getGMTtoLocationDate(endTime, timezone, dtFormatViewWorker);
                        }
                    }
                    
                    
                    String message = "Job has been Expired";
                    String bodyContentShortMessageAdmin = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDateAdmin
                            + " End Time : " + endDateAdmin
                            + " Appointment ID : " + appointmentId;
                    
                    String bodyContentShortMessageWorker = message + ". Details are given below-"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDateWorker
                            + " End Time : " + endDateWorker
                            + " Appointment ID : " + appointmentId;

                    String shortMessage = "" + message + "";

                    String emailAdmin = "";
                    String userCode = "";
                    if (user != null) {
                        emailAdmin = user.getEmail();
                        userCode = user.getUserCode();
                        
                        notification.setUserCode(userCode);
                        notification.setMessage(bodyContentShortMessageAdmin);
                        notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_ADMIN);
                        notification.setShortMessage(shortMessage);
                        notification.setAppointmentCode(appointmentId);
                        notification.setIsRead(Boolean.FALSE);
                        notification.setIpAddress(ip);

                        notificationService.saveHealthcareNotification(notification);
                    }
                    
                    String emailWorker = "";
                    if (worker != null) {
                        emailWorker =  worker.getEmail();
                        
                        notificationWorker.setUserCode(workerCode);
                        notificationWorker.setMessage(bodyContentShortMessageWorker);
                        notificationWorker.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                        notificationWorker.setShortMessage(shortMessage);
                        notificationWorker.setAppointmentCode(appointmentId);
                        notificationWorker.setIsRead(Boolean.FALSE);
                        notificationWorker.setIpAddress(ip);

                        notificationService.saveHealthcareNotification(notificationWorker);
                    }

                    String bodyContentAdmin = message + ". Details are given below-<br>"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDateAdmin
                            + " End Time : " + endDateAdmin
                            + " Appointment ID : " + appointmentId;
                    
                    SendNotification snAdmin = new SendNotification();

                    if (emailAdmin != null && emailAdmin.length() > 0) {
                        String response = snAdmin.sendMail(emailAdmin, subject, bodyContentAdmin, mailServiceURL);

                        LOG.info("Cron scheduler mail response in JobsServiceImpl >>>>>>", response);
                    }
                    
                    
                     String bodyContentWorker = message + ". Details are given below-<br>"
                            + "Worker Name : " + workerName
                            + "Organization Name : " + organizationName
                            + " Start Time : " + stDateWorker
                            + " End Time : " + endDateWorker
                            + " Appointment ID : " + appointmentId;
                     
                     SendNotification snWorker = new SendNotification();

                    if (emailWorker != null && emailWorker.length() > 0) {
                        String response = snWorker.sendMail(emailWorker, subject, bodyContentWorker, mailServiceURL);

                        LOG.info("Cron scheduler mail response in JobsServiceImpl >>>>>>", response);
                    }

                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job is Expired");
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Job Expiration has been failed.");
                }
                res = jsonobj.toString();
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "JobDurationCode  is not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
        }
        return res;
    }

    @Override
    public String updateJobDurationByJobDurationCode(String jobDurationCode,JobDurationUpdate jobDurationUpdate, String ip) {
       
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            JobsDuration jdurRes = jobsDurationRepository.getJobsDurationByJobsDurationCode(jobDurationCode);
            if (jdurRes != null && jdurRes.getId() > 0) {
                Jobs jobres = jobsRepository.getJobsByJobsCode(jdurRes.getJobsCode());
                if (jobres != null && jobres.getId() > 0) {
                    PatientDetails pDetail = patientDao.getPatientDetailsBypatientCode(jobres.getPatientCode());

                    if (pDetail != null && pDetail.getId() > 0) {
                        String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.TimeZone);
                        String timezone = null;
                        if (timezoneCode != null && timezoneCode.length() > 0) {
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                        }
                        String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        Date sdtm = GigflexDateUtil.convertStringDateToGMT(jobDurationUpdate.getStartTime(), timezone, dtFormat);
                        Date edtm = null;
                        Calendar call = Calendar.getInstance();
                        call.setTime(sdtm);
                        if (jobDurationUpdate.getDurationHours() != null && jobDurationUpdate.getDurationHours() > 0) {
                            call.add(Calendar.HOUR_OF_DAY, jobDurationUpdate.getDurationHours());
                        }
                        if (jobDurationUpdate.getDurationMinute() != null && jobDurationUpdate.getDurationMinute() > 0) {
                            call.add(Calendar.MINUTE, jobDurationUpdate.getDurationMinute());
                        }
                        edtm = call.getTime();
                        if (sdtm == null || edtm == null) {
                            jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_EXCEPTION);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Date parsing exception is occured.");
                            return jsonobj.toString();
                        }
                        if (sdtm.after(edtm)) {
                            jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_EXCEPTION);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Start Date should not be after that End Date.");
                            return jsonobj.toString();
                        }
                        Date curDt=new Date();
                        if (curDt.after(sdtm)) {
                            jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_EXCEPTION);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Start Date should not be before that Current Date.");
                            return jsonobj.toString();
                        }
                        JobsAssignToWorker jas = jobsAssignToWorkerRepository.getJobsAssignToWorkerByJobsDurationCode(jobDurationCode);
                        if (jas == null) {
                            JobsAssignToWorker jtw = new JobsAssignToWorker();
                            jtw.setIpAddress(ip);
                            jtw.setJobsCode(jobres.getJobsCode());
                            jtw.setJobsDurationCode(jdurRes.getJobsDurationCode());
                            jtw.setStatus(GigflexConstants.JOBSTATUS_PENDING);
                            jtw.setAppointmentId(genAppointmentID());
                            jas = jobsAssignToWorkerRepository.save(jtw);
                        }
                        if (jas != null && jas.getId() > 0) {
                            if (jas.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_INPROGRESS)) {
                                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Job Duration can not updated due to Job Duration is in Inprogress state.");
                                return jsonobj.toString();
                            }
                            if (jas.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_COMPLETED)) {
                                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Job Duration can not updated due to Job Duration is in Completed state.");
                                return jsonobj.toString();
                            }
                            Timestamp sd=new Timestamp(sdtm.getTime());  
                            Timestamp ed=new Timestamp(edtm.getTime());  
                            if (jdurRes.getStartTime().equals(sd) && jdurRes.getEndTime().equals(ed)) {
                                if(jobDurationUpdate.getJobName()!=null && jobDurationUpdate.getJobName().trim().length()>0)
                                {
                                jdurRes.setJobName(jobDurationUpdate.getJobName());
                                }
                                if(jobDurationUpdate.getNotes()!=null && jobDurationUpdate.getNotes().trim().length()>0)
                                {
                                    jdurRes.setNotes(jobDurationUpdate.getNotes());
                                }
                                JobsDuration jdurResponse = jobsDurationRepository.save(jdurRes);
                                if (jdurResponse != null && jdurResponse.getId() > 0) {
                                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Job Duration has been updated.");
                                return jsonobj.toString();
                                }
                                else
                                {
                                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                                jsonobj.put("timestamp", new Date());
                                jsonobj.put("message", "Job Duration updation has been failed.");
                                return jsonobj.toString(); 
                                }
                            } else {
                                Date oldStarttime = jdurRes.getStartTime();
                                Date oldEndtime = jdurRes.getEndTime();
                                jdurRes.setStartTime(sdtm);
                                jdurRes.setEndTime(edtm);
                                if(jobDurationUpdate.getJobName()!=null && jobDurationUpdate.getJobName().trim().length()>0)
                                {
                                jdurRes.setJobName(jobDurationUpdate.getJobName());
                                }
                                if(jobDurationUpdate.getNotes()!=null && jobDurationUpdate.getNotes().trim().length()>0)
                                {
                                    jdurRes.setNotes(jobDurationUpdate.getNotes());
                                }
                                jdurRes.setDurationHours(jobDurationUpdate.getDurationHours());
                                jdurRes.setDurationMinute(jobDurationUpdate.getDurationMinute());
                                JobsDuration jdurResponse = jobsDurationRepository.save(jdurRes);
                                if (jdurResponse != null && jdurResponse.getId() > 0) {
                                    HashMap<String, String> mapJobDurationTime = new HashMap<>();
                                    String dtFormatView = dtFormat;
                String datefoemat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                if (datefoemat != null && datefoemat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                    dtFormatView = datefoemat.trim() + " " + timeformat.trim();
                }
                                    Date stDate = GigflexDateUtil.getGMTtoLocationDate(jdurResponse.getStartTime(), timezone, dtFormatView);
                                                String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                                                mapJobDurationTime.put(jdurResponse.getJobsDurationCode(), stDatestr);
                                    
                                    
                                    boolean manualassign = true;
                                    String autoass = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.FULLTIME_STAFF_AUTO_ASSIGN);
                                    if (autoass != null && autoass.trim().length() > 0 && autoass.equalsIgnoreCase("true")) {
                                        manualassign = false;
                                    }

                                    String oldWorker = jas.getWorkerCode();
                                    String oldStatus = jas.getStatus();
                                    jas.setStatus(GigflexConstants.JOBSTATUS_PENDING);
                                    jas.setWorkerCode(null);
                                    JobsAssignToWorker jasRes = jobsAssignToWorkerRepository.save(jas);
                                    if (jasRes != null && jasRes.getId() > 0) {
                                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_SUCCESS);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Job Duration has been updated.");
                                        List<JobsDuration> jdurLst = new ArrayList<JobsDuration>();
                                        jdurLst.add(jdurResponse);
                                        try
                                        {
                                            if (oldWorker != null && oldWorker.length() > 0 && (oldStatus.equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED) || oldStatus.equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED))) {
                                            Worker wkr = workerRepository.getWorkerdetailByworkerCode(oldWorker);
                                            if (wkr != null && wkr.getId() > 0) {
                                                try
                                            {
                                               startAssignJobToWorkerDynamicDistanceThread(wkr,jobres.getOrganizationCode(),oldStarttime,timezone);
                                            }
                                            catch(Exception ee)
                                            {
                                                LOG.error("Error in job update>>>>", ee);
                                            }
                                                String bodyContentShortMessage = "Dear technician, You are relieved form job."
                                                        + " Appointment ID : " + jasRes.getAppointmentId();

                                                String shortMessage = "Job release notification";
                                                HealthcareNotification notification = new HealthcareNotification();
                                                notification.setUserCode(wkr.getWorkerCode());
                                                notification.setMessage(bodyContentShortMessage);
                                                notification.setUserType(GigflexConstants.NOTIFICATION_USER_TYPE_WORKER);
                                                notification.setShortMessage(shortMessage);
                                                notification.setAppointmentCode(jasRes.getAppointmentId());
                                                notification.setIsRead(Boolean.FALSE);
                                                notification.setIpAddress(ip);

                                                notificationService.saveHealthcareNotification(notification);

                                                String email = "";
                                                email = wkr.getEmail();

                                                String bodyContent = "Dear technician,<br><br>You are relieved form job."
                                                        + " Appointment ID : " + jasRes.getAppointmentId();
                                                SendNotification sn = new SendNotification();

                                                if (email != null && email.length() > 0) {
                                                    String response = sn.sendMail(email, subject, bodyContent, mailServiceURL);

                                                    LOG.info("mail response in job duration update >>>>>>", response);
                                                }
                                            }

                                        }
                                        }
                                        catch(Exception ee)
                                        {
                                            LOG.error("job duration update notification >>>>>>", ee);
                                        }

                                        //for manual assignment
                                        if (manualassign) {
                                            List<EligibleWorkerRes> ewresLst = getEligibleWorkerForManualAssignment(jobres, jdurLst, pDetail,mapJobDurationTime);
                                            if (ewresLst != null && ewresLst.size() > 0) {
                                                EligibleWorkerRes resp = ewresLst.get(0);
                                                if (resp != null && resp.getWorkerWithDistanceList() != null && resp.getWorkerWithDistanceList().size() > 0) {
                                                    jsonobj.put("message", "Job Duration has been updated and please assingin to technician.");
                                                    ObjectMapper mapperObj = new ObjectMapper();
                                                    String Detail = mapperObj.writeValueAsString(resp);
                                                    jsonobj.put("data", new JSONObject(Detail));
                                                }
                                            }
                                            //for auto assignment
                                        } else {
                                            List<EligibleWorkerRes> ewresLst = autoJobAssignmentToWorker(jobres, jdurLst, pDetail,mapJobDurationTime,timezone);
                                            if (ewresLst != null && ewresLst.size() > 0) {
                                                EligibleWorkerRes resp = ewresLst.get(0);
                                                if (resp != null && resp.getWorkerWithDistanceList() != null && resp.getWorkerWithDistanceList().size() > 0) {
                                                    jsonobj.put("message", "Job Duration has been updated and auto assingin to technician.");
                                                    ObjectMapper mapperObj = new ObjectMapper();
                                                    String Detail = mapperObj.writeValueAsString(resp);
                                                    jsonobj.put("data", new JSONObject(Detail));
                                                }
                                            }
                                        }

                                        
                                    } else {
                                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                                        jsonobj.put("timestamp", new Date());
                                        jsonobj.put("message", "Job Duration updation has been failed.");
                                        jdurResponse.setStartTime(oldStarttime);
                                        jdurResponse.setEndTime(oldEndtime);
                                        jobsDurationRepository.save(jdurResponse);
                                    }

                                } else {
                                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("message", "Job Duration updation has been failed.");
                                    return jsonobj.toString();
                                }
                            }

                        } else {
                            jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Jobs Assign to worker not found.");
                        }
                    } else {
                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Patient Details not found.");
                    }
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Jobs not found.");
                }
            } else {
                jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                jsonobj.put("timestamp", new Date());
                jsonobj.put("message", "Jobs Duration not found.");
            }
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in updateJobDurationByJobDurationCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in updateJobDurationByJobDurationCode>>>>>", ex);
        }
        return res;
    
    }

   @Override
    public String updateWorkerJobSeriesByJobsCode(String jobCode, JobsUpdateRequest jobr, String ip) {
         String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
                Jobs jobs = jobsRepository.getJobsByJobsCode(jobCode);
                if (jobs != null && jobs.getId() > 0) {
                    PatientDetails pDetail = patientDao.getPatientDetailsBypatientCode(jobs.getPatientCode());
                    if (pDetail != null && pDetail.getId() > 0) {
                        Date sdt = null;
                Date edt = null;
                try {
                    sdt = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(jobr.getStartDate().trim());
                    edt = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).parse(jobr.getEndDate().trim());
                } catch (Exception ee) {
                    LOG.error("Error in createWorkerJob>>>>>", ee);
                }
                if (sdt == null || edt == null) {
                    GigflexResponse derr = new GigflexResponse(400, new Date(),
                            "Plz send start date and end date in correct format(" + GigflexConstants.YYYY_MM_DD + ")");
                    return derr.toString();
                } else {
                    if (sdt.after(edt)) {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Start date can not be after End date");
                        return derr.toString();
                    }
                }
                                         String orgst =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobs.getOrganizationCode().trim(), GigflexConstants.ORG_WORKING_TIME_START);
                            String orgend =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobs.getOrganizationCode().trim(), GigflexConstants.ORG_WORKING_TIME_END);
                            if(orgst==null || orgend==null || orgst.trim().length()==0 ||  orgend.trim().length()==0 )
                            {
                                 GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Please set working time from setting.");
                                return derr.toString();
                            }
                            orgst=orgst.trim().length()==5?orgst.trim()+":00":orgst.trim();
                            orgend=orgend.trim().length()==5?orgend.trim()+":00":orgend.trim();
                            String startDTPeriodStr = jobr.getStartDate().trim() + " "+orgst;
                            Date startDTPeriod=GigflexDateUtil.convertStringToDate(startDTPeriodStr, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            String endDTPeriodStr = jobr.getStartDate().trim() + " "+orgend;
                            Date endDTPeriod=GigflexDateUtil.convertStringToDate(endDTPeriodStr, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            String checkSdtStr=jobr.getStartDate().trim() + " "+jobr.getStartTime().trim();
                            Date checkSdt=GigflexDateUtil.convertStringToDate(checkSdtStr, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            if(startDTPeriod==null || endDTPeriod==null || checkSdt==null)
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Exception is occurred in date parsing at validation.");
                                return derr.toString();
                            }
                            if(checkSdt.before(startDTPeriod))
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Job start time should be in Organization's working time.");
                                return derr.toString();
                            }
                            Calendar callck = Calendar.getInstance();
                callck.setTime(checkSdt);
                if (jobr.getDurationHours() != null && jobr.getDurationHours() > 0) {
                    callck.add(Calendar.HOUR_OF_DAY, jobr.getDurationHours());
                }
                if (jobr.getDurationMinute() != null && jobr.getDurationMinute() > 0) {
                    callck.add(Calendar.MINUTE, jobr.getDurationMinute());
                }
                Date checkEdt = callck.getTime();
                if(checkEdt.after(endDTPeriod))
                    {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Job duration time should be in Organization's working time.");
                                return derr.toString();
                    }
                
HashMap <Integer,String> dayCodeSettingMap=new HashMap<>();
                for(int i=1;i<=7;i++)
                {
                    String lookingForValue = "ORG_WORKING_DAY_";
                    lookingForValue += i;
                    String dayVal = null;
                    try {
                        Object clazz = new GigflexConstants();
                        Field field = clazz.getClass().getField(lookingForValue);
                        dayVal = (String) field.get(clazz);
                        if (dayVal != null) {
                            String dayValSt = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobs.getOrganizationCode().trim(), dayVal);
                            if (dayValSt != null) {
                                dayCodeSettingMap.put(i, dayValSt);
                            }
                        }
                    } catch (Exception e1) {
                        e1.printStackTrace();
                    }

                }
                
                if(jobr.getRepeatType().equalsIgnoreCase("Week"))
                {
                    for(Integer dl:jobr.getDaysList())
                    {
                        if(!dayCodeSettingMap.containsKey(dl))
                        {
                            GigflexResponse derr = new GigflexResponse(400, new Date(), GigflexDateUtil.getNameFromDayCode(dl)+" is not working day.");
                            return derr.toString();
                        }
                        else
                        {
                            if(!(dayCodeSettingMap.get(dl)!=null &&  dayCodeSettingMap.get(dl).equalsIgnoreCase("true")))
                            {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),GigflexDateUtil.getNameFromDayCode(dl)+" is off day.");
                                return derr.toString();
                            }
                        }
                    }
                }
                
       HashMap <Date,Boolean> holidayOrgMap=new HashMap<>(); 
       try{
         
       String orgHoliday =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobs.getOrganizationCode().trim(), GigflexConstants.ORG_SPEC_NON_WORKING_DAYS);
       if(orgHoliday!=null && orgHoliday.trim().length()>0)
       {
           String holiarr[]=orgHoliday.split(",");
           for(int j=0;j<holiarr.length;j++)
           {
               String str=holiarr[j];
               if(str!=null)
               {
                   Date hdt=GigflexDateUtil.convertStringToDate(str.trim(), GigflexConstants.DD_MMMM_YYYY);
                   if(hdt!=null)
                   {
                       holidayOrgMap.put(hdt, Boolean.TRUE);
                   }
               }
           }
       }
             
       }
       catch(Exception eee)
       {
           eee.printStackTrace();
       }
            if(holidayOrgMap.containsKey(sdt)) 
            {
                 GigflexResponse derr = new GigflexResponse(400, new Date(),
                                jobr.getStartDate()+" is non working date.");
                                return derr.toString();
            }
                   String timezone = null;
                    String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                    String dtFormatDate = GigflexConstants.YYYY_MM_DD;
                    String dtFormatView = dtFormat;
                    String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobs.getOrganizationCode(), GigflexConstants.TimeZone);
                    String datefoemat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobs.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                    String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobs.getOrganizationCode(), GigflexConstants.TIMEFORMAT);
                    if (datefoemat != null && datefoemat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                        dtFormatView = datefoemat.trim() + " " + timeformat.trim();
                    }
                    if (datefoemat != null && datefoemat.trim().length() > 0) {
                        dtFormatDate = datefoemat.trim();
                    }
                    if (timezoneCode != null && timezoneCode.length() > 0) {
                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                        if (tzd != null && tzd.getTimeZoneName() != null && tzd.getTimeZoneName().length() > 0) {
                            timezone = tzd.getTimeZoneName();
                        }
                    }
                    jobs.setEndDT(edt);
                    jobs.setIpAddress(ip);
                    jobs.setJobName(jobr.getJobName());
                    jobs.setNotes(jobr.getNotes());
                    jobs.setPatientCode(jobr.getPatientCode());
                    jobs.setProcedureCode(jobr.getProcedureCode());
                    jobs.setStartDT(sdt);
                    if(jobr.getDaysList()!=null && jobr.getDaysList().size()>0)
                {
                    String dlst="";
                    int i=0;
                    for(Integer dl:jobr.getDaysList())
                    {
                        if(i==0)
                        {
                            dlst=""+dl;
                        }else
                        {
                            dlst+=","+dl;
                        }
                        i++;
                    }
                jobs.setDaysList(dlst);
                }
                if(jobr.getDurationHours()!=null)
                {
                jobs.setDurationHours(jobr.getDurationHours());
                }
                else
                {
                  jobs.setDurationHours(0);  
                }
                if(jobr.getDurationMinute()!=null)
                {
                jobs.setDurationMinute(jobr.getDurationMinute());
                }
                else
                {
                  jobs.setDurationMinute(0);
                }
                
                jobs.setIsDateOfMonth(jobr.getIsDateOfMonth());
                jobs.setRepeatType(jobr.getRepeatType());
                jobs.setRepeatValue(jobr.getRepeatValue());
                jobs.setStartTime(jobr.getStartTime().trim());
                Jobs jobres = jobsRepository.save(jobs);
                    if(jobres!=null && jobres.getId()>0)
                    {
                        
                    List<String> statusList=new ArrayList<String>();
                    statusList.add(GigflexConstants.JOBSTATUS_PENDING);
                    statusList.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                    statusList.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                    List<JobsAssignToWorker> jatowList = jobsAssignToWorkerRepository.getJobsAssignToWorkerListByJobCodeWithFilterForUpdate(jobCode,statusList);
                    if(jatowList!=null && jatowList.size()>0)
                    {
                        for(JobsAssignToWorker jaw:jatowList)
                        {
                            JobsAssignToWorker notijaw=new JobsAssignToWorker();
                            notijaw.setId(jaw.getId());
                            notijaw.setAppointmentId(jaw.getAppointmentId());
                            notijaw.setJobsAassignWorkerCode(jaw.getJobsAassignWorkerCode());
                            notijaw.setJobsCode(jaw.getJobsCode());
                            notijaw.setJobsDurationCode(jaw.getJobsDurationCode());
                            notijaw.setStatus(jaw.getStatus());
                            notijaw.setWorkerCode(jaw.getWorkerCode());
                                    
                            
                            JobsDuration jd=jobsDurationRepository.getJobsDurationByJobsDurationCode(jaw.getJobsDurationCode());
                            jobsAssignToWorkerRepository.deleteById(jaw.getId());
                            if (notijaw.getWorkerCode() != null && notijaw.getWorkerCode().length() > 0 && (notijaw.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED) || notijaw.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED))) {
                                Worker wkr = workerRepository.getWorkerdetailByworkerCode(notijaw.getWorkerCode());
                                            if (wkr != null && wkr.getId() > 0 && jd!=null) {
                                                try
                                            {
                                               startAssignJobToWorkerDynamicDistanceThread(wkr,jobres.getOrganizationCode(),jd.getStartTime(),timezone);
                                            }
                                            catch(Exception ee)
                                            {
                                                LOG.error("Error in job update>>>>", ee);
                                            } 
                                }
                                String bodyContentShortMessage = "Dear technician, <br><br>You are relieved form job."
                                                        + " Appointment ID : " + notijaw.getAppointmentId();
                                startJobMailNotificationThread(true,notijaw,subject,bodyContentShortMessage);         
                               
                            }
                            
                            if(jd!=null && jd.getId()>0)
                            {
                                jobsDurationRepository.deleteById(jd.getId());
                            }
                            
                        }
                    }
                    

                    List<JobsDuration> jdurLst = new ArrayList<JobsDuration>();
                    List<JobsDurationRes> jdurResLst = new ArrayList<JobsDurationRes>();
                    HashMap<String, String> mapJobDurationTime = new HashMap<>();
                    Boolean st = false;
                    
                    JobsRes jres = new JobsRes();
                    jres.setEndDT(GigflexDateUtil.convertDateToString(jobres.getEndDT(), dtFormatDate));
                    jres.setEndDTStamp(jobres.getEndDT());
                    jres.setId(jobres.getId());
                    jres.setJobName(jobres.getJobName());
                    jres.setJobsCode(jobres.getJobsCode());
                    jres.setNotes(jobres.getNotes());
                    jres.setOrganizationCode(jobres.getOrganizationCode());
                    jres.setPatientCode(jobres.getPatientCode());
                    jres.setProcedureCode(jobres.getProcedureCode());
                    jres.setStartDT(GigflexDateUtil.convertDateToString(jobres.getStartDT(), dtFormatDate));
                    jres.setStartDTStamp(jobres.getStartDT());
                    jres.setDaysList(jobres.getDaysList());
                    String jobDurationHours = "";
                    if(jobres.getDurationHours() < 10)
                    {
                        StringBuilder durationBuilder = new StringBuilder();
                        durationBuilder.append("0");
                        durationBuilder.append(jobres.getDurationHours().toString()) ;
                        jobDurationHours = durationBuilder.toString();
                    }
                    else
                    {
                        jobDurationHours = jobres.getDurationHours().toString();
                    }
                    jres.setDurationHours(jobDurationHours);

                    String jobDurationMinute = "";
                    if(jobres.getDurationMinute() < 10)
                    {
                        StringBuilder minuteBuilder = new StringBuilder();
                        minuteBuilder.append("0");
                        minuteBuilder.append(jobres.getDurationMinute().toString()) ;
                        jobDurationMinute = minuteBuilder.toString();
                    }
                    else
                    {
                        jobDurationMinute = jobres.getDurationMinute().toString();
                    }
                    jres.setDurationMinute(jobDurationMinute);
                    jres.setIsDateOfMonth(jobres.getIsDateOfMonth());
                    jres.setRepeatType(jobres.getRepeatType());
                    jres.setRepeatValue(jobres.getRepeatValue());
                    jres.setStartTime(jobres.getStartTime());

                    if (timezone != null && timezone.length() > 0) {

                        if (jobr.getRepeatType().equalsIgnoreCase("Day")) {
                            do {
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(sdt);
                                System.out.println(">>>" + sdt);

                                try {

                                    String dtStr = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).format(sdt);
                                    String sdtStr = dtStr + " " + jobr.getStartTime().trim();
                                    //String edtStr=dtStr+" "+jobr.getEndTime().trim(); 
                                    boolean boolstm = GigflexDateUtil.validateDateFormat(sdtStr, dtFormat);
                                    //boolean booletm=   GigflexDateUtil.validateDateFormat(edtStr,dtFormat);
                                    if (boolstm == true) //&& booletm==true)
                                    {
                                        if(!(holidayOrgMap.containsKey(sdt)) )
                                        {
                                        Date chkdt=GigflexDateUtil.convertStringToDate(sdtStr, dtFormat);
                                        Calendar calint = Calendar.getInstance();
                                        calint.setTime(chkdt);
                                        Integer day=calint.get(Calendar.DAY_OF_WEEK);
                                        Boolean stck=true;
                                        if(!dayCodeSettingMap.containsKey(day))
                                        {
                                            stck=false;
                                        }
                                        else
                                        {
                                            if(!(dayCodeSettingMap.get(day)!=null && dayCodeSettingMap.get(day).equalsIgnoreCase("true")))
                                            {
                                                stck=false;
                                            }
                                        }
                                        if(stck)
                                        {
                                        Date sdtm = null;// new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getStartTime().trim());
                                        Date edtm = null;//new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getEndTime().trim());

                                        sdtm = GigflexDateUtil.convertStringDateToGMT(sdtStr, timezone, dtFormat);
                                        Calendar call = Calendar.getInstance();
                                        call.setTime(sdtm);
                                        if (jobr.getDurationHours() != null && jobr.getDurationHours() > 0) {
                                            call.add(Calendar.HOUR_OF_DAY, jobr.getDurationHours());
                                        }
                                        if (jobr.getDurationMinute() != null && jobr.getDurationMinute() > 0) {
                                            call.add(Calendar.MINUTE, jobr.getDurationMinute());
                                        }
                                        edtm = call.getTime(); //GigflexDateUtil.convertStringDateToGMT(edtStr, timezone,dtFormat);
                                        Date curDt=new Date();
                                        if (sdtm != null && edtm != null && edtm.after(sdtm) && sdtm.after(curDt)) {
                                            JobsDuration jdur = new JobsDuration();
                                            jdur.setEndTime(edtm);
                                            jdur.setIpAddress(ip);
                                            jdur.setJobsCode(jobres.getJobsCode());
                                            jdur.setStartTime(sdtm);
                                            jdur.setDurationHours(jobr.getDurationHours());
                                            jdur.setDurationMinute(jobr.getDurationMinute());
                                            jdur.setJobName(jobr.getJobName());
                                            jdur.setNotes(jobr.getNotes());
                                            JobsDuration jdurRes = jobsDurationRepository.save(jdur);
                                            if (jdurRes != null && jdurRes.getId() > 0) {
                                                jdurLst.add(jdurRes);
                                                JobsDurationRes jobsdurRes = new JobsDurationRes();
                                                jobsdurRes.setId(jdurRes.getId());
                                                jobsdurRes.setJobsCode(jdurRes.getJobsCode());
                                                jobsdurRes.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                Date stDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getStartTime(), timezone, dtFormatView);
                                                String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                                                Date endDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getEndTime(), timezone, dtFormatView);
                                                String endDatestr = GigflexDateUtil.convertDateToString(endDate, dtFormatView);
                                                jobsdurRes.setEndTime(endDatestr);
                                                jobsdurRes.setStartTime(stDatestr);
                                                mapJobDurationTime.put(jdurRes.getJobsDurationCode(), stDatestr);
                                                jobsdurRes.setJobName(jdurRes.getJobName());
                                                jobsdurRes.setNotes(jdurRes.getNotes());
                                                jdurResLst.add(jobsdurRes);
                                                JobsAssignToWorker jtw = new JobsAssignToWorker();
                                                jtw.setIpAddress(ip);
                                                jtw.setJobsCode(jobres.getJobsCode());
                                                jtw.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                jtw.setStatus(GigflexConstants.JOBSTATUS_PENDING);
                                                jtw.setAppointmentId( genAppointmentID());
                                                JobsAssignToWorker jtwRes = jobsAssignToWorkerRepository.save(jtw);
                                                if (jtwRes != null && jtwRes.getId() > 0) {
                                                    st = Boolean.TRUE;
                                                }

                                            }
                                        }
                                    }
                                    }
                                    }
                                } catch (Exception ee) {
                                    LOG.error("Error in createWorkerJob>>>>>", ee);
                                }

                                cal.add(Calendar.DAY_OF_MONTH, jobr.getRepeatValue());
                                sdt = cal.getTime();

                            } while (!(sdt.after(edt)));
                        } else if (jobr.getRepeatType().equalsIgnoreCase("Week")) {
                            do {
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(sdt);
                                int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
                                try {
                                    
                                    if (jobr.getDaysList().contains(dayOfWeek)) {
                                        String dtStr = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).format(sdt);
                                        String sdtStr = dtStr + " " + jobr.getStartTime().trim();
                                        //String edtStr=dtStr+" "+jobr.getEndTime().trim(); 
                                        boolean boolstm = GigflexDateUtil.validateDateFormat(sdtStr, dtFormat);
                                        //boolean booletm=   GigflexDateUtil.validateDateFormat(edtStr,dtFormat);
                                        if (boolstm == true) //&& booletm==true)
                                        {
                                        if(!(holidayOrgMap.containsKey(sdt)) )
                                        {
                                        Date chkdt=GigflexDateUtil.convertStringToDate(sdtStr, dtFormat);
                                        Calendar calint = Calendar.getInstance();
                                        calint.setTime(chkdt);
                                        Integer day=calint.get(Calendar.DAY_OF_WEEK);
                                        Boolean stck=true;
                                        if(!dayCodeSettingMap.containsKey(day))
                                        {
                                            stck=false;
                                        }
                                        else
                                        {
                                            if(!(dayCodeSettingMap.get(day)!=null && dayCodeSettingMap.get(day).equalsIgnoreCase("true")))
                                            {
                                                stck=false;
                                            }
                                        }
                                        if(stck)
                                        {
                                            Date sdtm = null;// new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getStartTime().trim());
                                            Date edtm = null;//new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getEndTime().trim());

                                            sdtm = GigflexDateUtil.convertStringDateToGMT(sdtStr, timezone, dtFormat);
                                            Calendar call = Calendar.getInstance();
                                            call.setTime(sdtm);
                                            if (jobr.getDurationHours() != null && jobr.getDurationHours() > 0) {
                                                call.add(Calendar.HOUR_OF_DAY, jobr.getDurationHours());
                                            }
                                            if (jobr.getDurationMinute() != null && jobr.getDurationMinute() > 0) {
                                                call.add(Calendar.MINUTE, jobr.getDurationMinute());
                                            }
                                            edtm = call.getTime(); //GigflexDateUtil.convertStringDateToGMT(edtStr, timezone,dtFormat);
                                            Date curDt=new Date();
                                        if (sdtm != null && edtm != null && edtm.after(sdtm) && sdtm.after(curDt)) {
                                                JobsDuration jdur = new JobsDuration();
                                                jdur.setEndTime(edtm);
                                                jdur.setIpAddress(ip);
                                                jdur.setJobsCode(jobres.getJobsCode());
                                                jdur.setStartTime(sdtm);
                                                jdur.setDurationHours(jobr.getDurationHours());
                                                jdur.setDurationMinute(jobr.getDurationMinute());
                                                jdur.setJobName(jobr.getJobName());
                                                jdur.setNotes(jobr.getNotes());
                                                JobsDuration jdurRes = jobsDurationRepository.save(jdur);
                                                if (jdurRes != null && jdurRes.getId() > 0) {
                                                    jdurLst.add(jdurRes);
                                                    JobsDurationRes jobsdurRes = new JobsDurationRes();
                                                    jobsdurRes.setId(jdurRes.getId());
                                                    jobsdurRes.setJobsCode(jdurRes.getJobsCode());
                                                    jobsdurRes.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                    Date stDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getStartTime(), timezone, dtFormatView);
                                                    String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                                                    Date endDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getEndTime(), timezone, dtFormatView);
                                                    String endDatestr = GigflexDateUtil.convertDateToString(endDate, dtFormatView);
                                                    jobsdurRes.setEndTime(endDatestr);
                                                    jobsdurRes.setStartTime(stDatestr);
                                                    mapJobDurationTime.put(jdurRes.getJobsDurationCode(), stDatestr);
                                                    jobsdurRes.setJobName(jdurRes.getJobName());
                                                    jobsdurRes.setNotes(jdurRes.getNotes());
                                                    jdurResLst.add(jobsdurRes);
                                                    JobsAssignToWorker jtw = new JobsAssignToWorker();
                                                    jtw.setIpAddress(ip);
                                                    jtw.setJobsCode(jobres.getJobsCode());
                                                    jtw.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                    jtw.setStatus(GigflexConstants.JOBSTATUS_PENDING);
                                                    jtw.setAppointmentId( genAppointmentID());
                                                    JobsAssignToWorker jtwRes = jobsAssignToWorkerRepository.save(jtw);
                                                    if (jtwRes != null && jtwRes.getId() > 0) {
                                                        st = Boolean.TRUE;
                                                    }

                                                }
                                            }
                                        }
                                        }
                                        }
                                    }
                                } catch (Exception ee) {
                                    LOG.error("Error in createWorkerJob>>>>>", ee);
                                }

                                int incr = 1;
                                if (dayOfWeek == 7) {
                                    incr = ((jobr.getRepeatValue() - 1) * dayOfWeek) + incr;
                                    cal.add(Calendar.DAY_OF_MONTH, incr);
                                } else {
                                    cal.add(Calendar.DAY_OF_MONTH, incr);
                                }
                                sdt = cal.getTime();

                            } while (!(sdt.after(edt)));
                        } else if (jobr.getRepeatType().equalsIgnoreCase("Month")) {
                            do {
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(sdt);
                                int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
                                int weekOfMonth = cal.get(Calendar.WEEK_OF_MONTH);

                                try {
                                    String dtStr = new SimpleDateFormat(GigflexConstants.YYYY_MM_DD).format(sdt);
                                    String sdtStr = dtStr + " " + jobr.getStartTime().trim();
                                    //String edtStr=dtStr+" "+jobr.getEndTime().trim(); 
                                    boolean boolstm = GigflexDateUtil.validateDateFormat(sdtStr, dtFormat);
                                    //boolean booletm=   GigflexDateUtil.validateDateFormat(edtStr,dtFormat);
                                    if (boolstm == true) //&& booletm==true)
                                    {
                                        if(!(holidayOrgMap.containsKey(sdt)) )
                                        {
                                        Date chkdt=GigflexDateUtil.convertStringToDate(sdtStr, dtFormat);
                                        Calendar calint = Calendar.getInstance();
                                        calint.setTime(chkdt);
                                        Integer day=calint.get(Calendar.DAY_OF_WEEK);
                                        Boolean stck=true;
                                        if(!dayCodeSettingMap.containsKey(day))
                                        {
                                            stck=false;
                                        }
                                        else
                                        {
                                            if(!(dayCodeSettingMap.get(day)!=null && dayCodeSettingMap.get(day).equalsIgnoreCase("true")))
                                            {
                                                stck=false;
                                            }
                                        }
                                        if(stck)
                                        {
                                        Date sdtm = null;// new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getStartTime().trim());
                                        Date edtm = null;//new SimpleDateFormat(GigflexConstants.DD_MM_YYYY_HH_MM_SS).parse(dtStr+" "+jobr.getEndTime().trim());

                                        sdtm = GigflexDateUtil.convertStringDateToGMT(sdtStr, timezone, dtFormat);
                                        Calendar call = Calendar.getInstance();
                                        call.setTime(sdtm);
                                        if (jobr.getDurationHours() != null && jobr.getDurationHours() > 0) {
                                            call.add(Calendar.HOUR_OF_DAY, jobr.getDurationHours());
                                        }
                                        if (jobr.getDurationMinute() != null && jobr.getDurationMinute() > 0) {
                                            call.add(Calendar.MINUTE, jobr.getDurationMinute());
                                        }
                                        edtm = call.getTime(); //GigflexDateUtil.convertStringDateToGMT(edtStr, timezone,dtFormat);
                                        Date curDt=new Date();
                                        if (sdtm != null && edtm != null && edtm.after(sdtm) && sdtm.after(curDt)) {
                                            JobsDuration jdur = new JobsDuration();
                                            jdur.setEndTime(edtm);
                                            jdur.setIpAddress(ip);
                                            jdur.setJobsCode(jobres.getJobsCode());
                                            jdur.setStartTime(sdtm);
                                            jdur.setDurationHours(jobr.getDurationHours());
                                            jdur.setDurationMinute(jobr.getDurationMinute());
                                            jdur.setJobName(jobr.getJobName());
                                            jdur.setNotes(jobr.getNotes());
                                            JobsDuration jdurRes = jobsDurationRepository.save(jdur);
                                            if (jdurRes != null && jdurRes.getId() > 0) {
                                                jdurLst.add(jdurRes);
                                                JobsDurationRes jobsdurRes = new JobsDurationRes();
                                                jobsdurRes.setId(jdurRes.getId());
                                                jobsdurRes.setJobsCode(jdurRes.getJobsCode());
                                                jobsdurRes.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                Date stDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getStartTime(), timezone, dtFormatView);
                                                String stDatestr = GigflexDateUtil.convertDateToString(stDate, dtFormatView);
                                                Date endDate = GigflexDateUtil.getGMTtoLocationDate(jdurRes.getEndTime(), timezone, dtFormatView);
                                                String endDatestr = GigflexDateUtil.convertDateToString(endDate, dtFormatView);
                                                jobsdurRes.setEndTime(endDatestr);
                                                jobsdurRes.setStartTime(stDatestr);
                                                mapJobDurationTime.put(jdurRes.getJobsDurationCode(), stDatestr);
                                                jobsdurRes.setJobName(jdurRes.getJobName());
                                                jobsdurRes.setNotes(jdurRes.getNotes());
                                                jdurResLst.add(jobsdurRes);
                                                JobsAssignToWorker jtw = new JobsAssignToWorker();
                                                jtw.setIpAddress(ip);
                                                jtw.setJobsCode(jobres.getJobsCode());
                                                jtw.setJobsDurationCode(jdurRes.getJobsDurationCode());
                                                jtw.setStatus(GigflexConstants.JOBSTATUS_PENDING);
                                                jtw.setAppointmentId( genAppointmentID());
                                                JobsAssignToWorker jtwRes = jobsAssignToWorkerRepository.save(jtw);
                                                if (jtwRes != null && jtwRes.getId() > 0) {
                                                    st = Boolean.TRUE;
                                                }

                                            }
                                        }
                                        }
                                        }
                                    }

                                } catch (Exception ee) {
                                    LOG.error("Error in createWorkerJob>>>>>", ee);
                                }

                                cal.add(Calendar.MONTH, jobr.getRepeatValue());
                                if (!(jobr.getIsDateOfMonth())) {
                                    cal.set(Calendar.DAY_OF_MONTH, cal.getActualMinimum(Calendar.DAY_OF_MONTH));
                                    cal.set(Calendar.WEEK_OF_MONTH, weekOfMonth);
                                    cal.set(Calendar.DAY_OF_WEEK, dayOfWeek);
                                }

                                sdt = cal.getTime();

                            } while (!(sdt.after(edt)));
                        }

                    }
                    if (st && (jdurLst != null && jdurLst.size() > 0)) {
                        boolean manualassign = true;
                        String autoass = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobres.getOrganizationCode(), GigflexConstants.FULLTIME_STAFF_AUTO_ASSIGN);
                        if (autoass != null && autoass.trim().length() > 0 && autoass.equalsIgnoreCase("true")) {
                            manualassign = false;
                        }
                        //for manual assignment
                        if (manualassign) {
                            List<EligibleWorkerRes> ewresLst = getEligibleWorkerForManualAssignment(jobres, jdurLst, pDetail,mapJobDurationTime);
                            JobManualResponse jmres = new JobManualResponse();
                            jmres.setJobsDurationResList(jdurResLst);
                            jmres.setJobsRes(jres);
                            jmres.setEligibleWorkerResList(ewresLst);
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("manualAssignment", true);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Job updation has been done.");
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(jmres);
                            jsonobj.put("data", new JSONObject(Detail));
                        } else {//for automatic assignment

                            List<EligibleWorkerRes> ewresLst = autoJobAssignmentToWorker(jobres, jdurLst, pDetail,mapJobDurationTime,timezone);
                            JobManualResponse jmres = new JobManualResponse();
                            jmres.setJobsDurationResList(jdurResLst);
                            jmres.setJobsRes(jres);
                            jmres.setEligibleWorkerResList(ewresLst);
                            jsonobj.put("responsecode", 200);
                            jsonobj.put("manualAssignment", false);
                            jsonobj.put("timestamp", new Date());
                            jsonobj.put("message", "Job updation has been done.");
                            ObjectMapper mapperObj = new ObjectMapper();
                            String Detail = mapperObj.writeValueAsString(jmres);
                            jsonobj.put("data", new JSONObject(Detail));
                        }

                    } else {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Job updation has been done without job duration.");
                    }
                
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                        
                    }
                    else
                    {
                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_FAILED);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Job updation has been failed.");
                    }
                        
                        } else {
                        jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Patient Details not found.");
                    }
                } else {
                    jsonobj.put("responsecode", GigflexConstants.REAPONSECODE_NOTFOUND);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Jobs not found.");
                }
           
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in updateWorkerJobSeriesByJobsCode>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
            LOG.error("Error in updateWorkerJobSeriesByJobsCode>>>>>", ex);
        }
        return res;
    }
    
    @Override
    public String getJobForDashboardByOrganizationCode(String organizationCode, String startDT, String endDT) {
        
        String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

                        Organization org = orgDao.findByOrganizationCode(organizationCode);
                        if (org != null && org.getId() > 0 ) {
                                                        
                                String timezone = null;
                                Date sDT = null;
                                Date eDT = null;

                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                                TimeZoneDetail tz = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                                if (tz != null && tz.getTimeZoneName() != null) {
                                    timezone = tz.getTimeZoneName();
                                    if (startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                                        startDT = startDT + " 00:00:00";
                                        endDT = endDT + " 23:59:59";

                                        sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                                        eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                                        if (sDT == null || eDT == null) {
                                            GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                    "Date conversion has been failed.");
                                            return derr.toString();
                                        }
                                    }
                                }
                                
                                List<JobsAssignToWorker> objlst = null;
                                if (sDT != null && eDT != null) {
                                    
                                     objlst = jobsRepository.getAllDashboardJobByOrganizationCode(organizationCode,sDT,eDT);
                                }
                                else
                                {
                                     objlst = jobsRepository.getAllDashboardJobByOrganizationCode(organizationCode);
                                }
                            	
                                int count = 0;
                                if(objlst != null && objlst.size() > 0)
                                {
                                    count = objlst.size();
                                }

                                List<JobsAssignToWorker> assigned =  null;
                                if (sDT != null && eDT != null) {
                                   
                                    assigned = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_ASSIGNED,sDT,eDT);
                                }
                                else
                                {
                                     assigned = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_ASSIGNED);
                                }
                                 
                                int assignedCount = 0;
                                if(assigned != null && assigned.size() > 0)
                                {
                                    assignedCount = assigned.size();
                                }


                                List<JobsAssignToWorker> pending = null;
                                if (sDT != null && eDT != null) {
                                    pending = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_PENDING,sDT,eDT);
                                }
                                else
                                {
                                    pending = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_PENDING);
                                }
                                
                                int pendingCount = 0;
                                if(pending != null && pending.size() > 0)
                                {
                                    pendingCount = pending.size();
                                }


                                List<JobsAssignToWorker> inProgress = null;
                                if (sDT != null && eDT != null) {
                                    inProgress = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_INPROGRESS,sDT,eDT);
                                }
                                else
                                {
                                    inProgress = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_INPROGRESS);
                                }
                                
                                int inProgressCount = 0;
                                if(inProgress != null && inProgress.size() >0)
                                {
                                    inProgressCount = inProgress.size();
                                }


                                List<JobsAssignToWorker> accepted = null;
                                if (sDT != null && eDT != null) {
                                    accepted = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_ACCEPTED,sDT,eDT);
                                }
                                else
                                {
                                    accepted = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_ACCEPTED);
                                }
                                
                                int acceptedCount = 0;
                                if(accepted != null && accepted.size() > 0)
                                {
                                    acceptedCount = accepted.size();
                                }


                                List<JobsAssignToWorker> cancelled = null;
                                if (sDT != null && eDT != null) {
                                    cancelled = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_CANCELLED,sDT,eDT);
                                }
                                else
                                {
                                    cancelled = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_CANCELLED);
                                }
                                
                                int cancelledCount = 0;
                                if(cancelled != null && cancelled.size() > 0)
                                {
                                    cancelledCount = cancelled.size();
                                }

                                List<JobsAssignToWorker> expired = null;
                                if (sDT != null && eDT != null) {
                                    expired = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_EXPIRED,sDT,eDT);
                                }
                                else
                                {
                                    expired = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_EXPIRED);
                                }
                                
                                int expiredCount = 0;
                                if(expired != null && expired.size() > 0)
                                {
                                    expiredCount = expired.size();
                                }

                                List<JobsAssignToWorker> rejected = null;
                                if (sDT != null && eDT != null) {
                                    rejected = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_REJECTED,sDT,eDT);
                                }
                                else
                                {
                                    rejected = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_REJECTED);
                                }
                                
                                int rejectedCount = 0;
                                if(rejected != null && rejected.size() > 0)
                                {
                                    rejectedCount = rejected.size();
                                }

                                List<JobsAssignToWorker> completed = null;
                                if (sDT != null && eDT != null) {
                                    completed = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_COMPLETED,sDT,eDT);
                                }
                                else
                                {
                                    completed = jobsRepository.getAllDashboardJobByOrganizationCodeByStatus(organizationCode,
                                                GigflexConstants.JOBSTATUS_COMPLETED);
                                }
                                
                                int completedCount = 0;    
                                if(completed != null && completed.size() > 0)
                                {
                                    completedCount = completed.size();
                                }

//                                if (objlst != null && objlst.size() > 0) {
                                    JSONArray jarr = new JSONArray();

                                    JSONObject j1 = new JSONObject();
                                    j1.put("status", GigflexConstants.JOBSTATUS_ASSIGNED);
                                    j1.put("count", assignedCount);			
                                    jarr.add(j1);


                                    JSONObject j2 = new JSONObject();
                                    j2.put("status", GigflexConstants.JOBSTATUS_PENDING);
                                    j2.put("count", pendingCount);				
                                    jarr.add(j2);


                                    JSONObject j3 = new JSONObject();
                                    j3.put("status", GigflexConstants.JOBSTATUS_INPROGRESS);
                                    j3.put("count", inProgressCount);				
                                    jarr.add(j3);


                                    JSONObject j4 = new JSONObject();
                                    j4.put("status", GigflexConstants.JOBSTATUS_ACCEPTED);
                                    j4.put("count", acceptedCount);				
                                    jarr.add(j4);

                                    JSONObject j5 = new JSONObject();
                                    j5.put("status", GigflexConstants.JOBSTATUS_CANCELLED);
                                    j5.put("count", cancelledCount);				
                                    jarr.add(j5);

                                    JSONObject j6 = new JSONObject();
                                    j6.put("status", GigflexConstants.JOBSTATUS_EXPIRED);
                                    j6.put("count", expiredCount);				
                                    jarr.add(j6);

                                    JSONObject j7 = new JSONObject();
                                    j7.put("status", GigflexConstants.JOBSTATUS_REJECTED);
                                    j7.put("count", rejectedCount);				
                                    jarr.add(j7);

                                    JSONObject j8 = new JSONObject();
                                    j8.put("status", GigflexConstants.JOBSTATUS_COMPLETED);
                                    j8.put("count", completedCount);				
                                    jarr.add(j8);		
                                        
//                                  JSONObject j9 = new JSONObject();
//                                  j9.put("startTime", sDT);
//                                  jarr.add(j9);
//                                  JSONObject j10 = new JSONObject();
//                                  j10.put("endTime", eDT);
//                                  jarr.add(j10);

                                    jsonobj.put("responsecode", 200);
                                    jsonobj.put("message", "Success");
                                    jsonobj.put("timestamp", new Date());
                                    jsonobj.put("allcount", count);
                                    jsonobj.put("data", jarr);

//                                } else {
//                                        jsonobj.put("responsecode", 404);
//                                        jsonobj.put("message", "Record Not Found");
//                                        jsonobj.put("timestamp", new Date());
//                                }
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Organization does not exist.");
                            jsonobj.put("timestamp", new Date());
                        }                                               
		

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
    }
  

    @Override
    public String getAllJobsByOrganizationCodeWithFilterByPage(String organizationCode, List<String> status, String startDT, String endDT, int page, int limit) {
        
         String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            if (limit > 0) {
                
                List<String> orderLst = new ArrayList<String>();
                orderLst.add(GigflexConstants.JOBSTATUS_ASSIGNED);           
                orderLst.add(GigflexConstants.JOBSTATUS_REJECTED);
                orderLst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                orderLst.add(GigflexConstants.JOBSTATUS_PENDING);
                orderLst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                orderLst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                orderLst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                orderLst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                
                
                
                Pageable pageableRequest = PageRequest.of(page, limit);

                Organization org = orgDao.findByOrganizationCode(organizationCode);
                if (org != null && org.getId() > 0 ) {
                   
                    String timezone = null;
                    Date sDT = null;
                    Date eDT = null;

                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                        if (startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                            startDT = startDT + " 00:00:00";
                            endDT = endDT + " 23:59:59";

                            sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            if (sDT == null || eDT == null) {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Date conversion has been failed.");
                                return derr.toString();
                            }
                          
                        }
                    }
                    List<Object> objlstCheck = null;

                    int count = 0;
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_REJECTED);
                        stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                        stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                        stlst.add(GigflexConstants.JOBSTATUS_PENDING);
                        status = stlst;
                    }

                    List<Object> objlst = null;

                    if (sDT != null && eDT != null) {
                        objlst = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPage(organizationCode, status, sDT, eDT,orderLst,pageableRequest);
                        objlstCheck = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPage(organizationCode, status, sDT, eDT,orderLst);
                        if (objlstCheck != null && objlstCheck.size() > 0) {
                            count = objlstCheck.size();
                        }
                    } else {
                        objlst = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPage(organizationCode, status,orderLst, pageableRequest);
                        objlstCheck = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPage(organizationCode, status,orderLst);
                        if (objlstCheck != null && objlstCheck.size() > 0) {
                            count = objlstCheck.size();
                        }
                    }

                    List<JobsAllResponse> maplst = new ArrayList<JobsAllResponse>();
                    if (objlst != null && objlst.size() > 0) {
                        
                        String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                       
                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                        {
                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                        }                

                        String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);

                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timeznCode);
                        
                        for (int i = 0; i < objlst.size(); i++) {
                            Object[] arr = (Object[]) objlst.get(i);
                            if (arr.length >= 3) {

                                JobsAllResponse jaRes = new JobsAllResponse();
                                String conStartDt = "";
                                String conEndTime="";
                                Jobs jobData = (Jobs) arr[0];
                                JobsDuration jdData= (JobsDuration) arr[1];
                                JobsAssignToWorker jawData = (JobsAssignToWorker) arr[2];
                                Date timestampStartTime =null;
                                Date timestampEndTime = null;
                                if (tzd != null && tzd.getId() > 0) {

                                    timezone = tzd.getTimeZoneName();
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(jdData.getStartTime()!=null){
                                         Date startDate = jdData.getStartTime();
                                         timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                         conStartDt=GigflexDateUtil.convertDateToString(timestampStartTime, dtFormat);
                                        }
                                        if(jdData.getEndTime()!=null){
                                            Date endDate = jdData.getEndTime();
                                            timestampEndTime = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                            conEndTime=GigflexDateUtil.convertDateToString(timestampEndTime, dtFormat);
                                         }
                                    }
                                }    
                                jaRes.setJobsCode(jdData.getJobsCode());
                                jaRes.setJobsDurationCode(jdData.getJobsDurationCode());
                                jaRes.setDateFormat(dateformat);
                                jaRes.setTimeFormat(timeformat); 
                                
                                String duration ="";
                                
                                Integer hours = jdData.getDurationHours();
                                Integer minute = jdData.getDurationMinute();
                                
                                String strHours = "";
                                if(hours != null && hours > 0 )
                                {
                                    strHours = hours.toString();
                                }
                                
                                String strMinute = "";
                                if(minute != null && minute > 0 )
                                {
                                    strMinute = minute.toString();
                                }
                                
                                if(strHours.length() > 0 )
                                {
                                    duration = strHours +" Hours ";
                                }
                                
                                if(strMinute.length() > 0 )
                                {
                                    duration =duration+strMinute+" Minutes";
                                }
                                
                                jaRes.setDuration(duration);
                                jaRes.setEndTime(conEndTime);
                                jaRes.setStartTime(conStartDt);
                                jaRes.setTimestampStartTime(timestampStartTime);
                                jaRes.setTimestampEndTime(timestampEndTime); 
                                
                                String patientLat ="";
                                String patientLong ="";
                                if(jobData.getPatientCode() != null)
                                {
                                    jaRes.setPatientCode(jobData.getPatientCode());
                                    PatientDetails patientDetails = patientDao.getPatientDetailBypatientCode(jobData.getPatientCode());
                                    
                                    if(patientDetails != null)
                                    {
                                        
                                        jaRes.setPatientName(patientDetails.getPatientName());
                                        patientLat = patientDetails.getPatientLatitude();
                                        patientLong = patientDetails.getPatientLongitude();
                                        jaRes.setPatientDetails(patientDetails); 
                                    }
                                    else
                                    {
                                        jaRes.setPatientName("");
                                    }
                                }
                                else
                                {
                                    jaRes.setPatientCode("");
                                    jaRes.setPatientName("");
                                    
                                }
                                
                                if(jobData.getProcedureCode() != null)
                                {
                                    jaRes.setProcedureCode(jobData.getProcedureCode());
                                    
                                    ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(jaRes.getProcedureCode());
                                    
                                    if( pm != null )
                                    {
                                        jaRes.setProcedureIcon(pm.getProcedureIcon()); 
                                    }
                                }
                                else
                                {
                                    jaRes.setProcedureCode("");
                                    jaRes.setProcedureIcon("");
                                }
                                
                                jaRes.setStatus(jawData.getStatus());
                                String workerLat = "";
                                String workerLang = ""; 
                                if(jawData.getWorkerCode() != null)
                                {
                                     jaRes.setWorkerCode(jawData.getWorkerCode());
                                     
                                     Worker worker = workerRepository.findByWorkerCode(jawData.getWorkerCode());
                                     
                                     if(worker != null)
                                     {
                                         jaRes.setWorkerName(worker.getName());
                                         workerLat = worker.getLatitude();
                                         workerLang = worker.getLongitude();
                                     }
                                     else
                                     {
                                         jaRes.setWorkerName("");
                                     }                                     
                                }
                                else
                                {
                                    jaRes.setWorkerCode("");
                                    jaRes.setWorkerName("");
                                }                                                              
                                
                                String strDistance = "";
                                
                                
                                if(workerLat.trim().length() >0 && workerLang.trim().length() >0 && patientLat.trim().length() >0 && patientLong.trim().length() >0 )
                                {
                                    try
                                    {
                                        Double distance  = distance(workerLat.trim(), workerLang.trim(), patientLat.trim(), patientLong.trim());
                                        if(distance!=null)
                                        {
                                        strDistance = String.valueOf(distance);
                                        }
                                    }
                                    catch(Exception e)
                                    {
                                        e.printStackTrace();
                                    }
                                    
                                }
                                jaRes.setDistance(strDistance);  
                                
//                                if(jobData.getPatientCode() != null)
//                                {
//                                    PatientDetails pDetails = patientDao.getPatientDetailBypatientCode(jobData.getPatientCode());
//                                    
//                                    if(pDetails != null)
//                                    {
//                                       jaRes.setPatientDetails(pDetails); 
//                                    }
//                                    
//                                }
                                
                                
                                maplst.add(jaRes);

                            }
                        }
                    }
                    if (maplst != null && maplst.size() > 0) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("count", count);
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("data", new JSONArray(Detail));                       
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Organization does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;

    }

    
    @Override
    public String getAllJobsByOrganizationCodeWithFilter(String organizationCode, List<String> status, String startDT, String endDT) {
        
         String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
       
                
                List<String> orderLst = new ArrayList<String>();
                orderLst.add(GigflexConstants.JOBSTATUS_ASSIGNED);           
                orderLst.add(GigflexConstants.JOBSTATUS_REJECTED);
                orderLst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                orderLst.add(GigflexConstants.JOBSTATUS_PENDING);
                orderLst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                orderLst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                orderLst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                orderLst.add(GigflexConstants.JOBSTATUS_EXPIRED);                

                Organization org = orgDao.findByOrganizationCode(organizationCode);
                if (org != null && org.getId() > 0 ) {
                   
                    String timezone = null;
                    Date sDT = null;
                    Date eDT = null;
                    Date sDTForPersentage = null;
                    String startDTForPersentage ="";
                    
                    
                    String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);

                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    String startDateForPersentage = new String(startDT);
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                        if (startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                            startDTForPersentage = startDT + " 23:59:59";
                            startDT = startDT + " 00:00:00";
                            endDT = endDT + " 23:59:59";
                            

                            sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            sDTForPersentage = GigflexDateUtil.convertStringDateToGMT(startDTForPersentage, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            if (sDT == null || eDT == null) {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Date conversion has been failed.");
                                return derr.toString();
                            }
                          
                        }
                    }
                    
                    boolean isPercentageCalculate = false; 
                    String statusForPercentageCalculation ="";
                    if ( status.size() == 1 ) {

                        if(status.get(0).equalsIgnoreCase("all"))
                        {
                            isPercentageCalculate = true;
                        }
                        else if(status.get(0).equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED) || 
                                status.get(0).equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED) ||
                                status.get(0).equalsIgnoreCase(GigflexConstants.JOBSTATUS_PENDING) )
                        {
                            statusForPercentageCalculation = status.get(0);
                        }
                       
                    }                    
                    else if( status.size() > 0 && (status.contains(GigflexConstants.JOBSTATUS_ASSIGNED) 
                            && status.contains(GigflexConstants.JOBSTATUS_ACCEPTED ) 
                            && status.contains(GigflexConstants.JOBSTATUS_PENDING)) ) 
                    {
                        isPercentageCalculate = true;
                    }
                    
                    
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_REJECTED);
                        stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                        stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                        stlst.add(GigflexConstants.JOBSTATUS_PENDING);
                        status = stlst;                        
                    }

                    List<Object> objlst = null;
                    List<Object> objlstfordist = null;
                    if (sDT != null && eDT != null) {
                        objlst = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPage(organizationCode, status, sDT, eDT,orderLst);
                        objlstfordist = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPageForDist(organizationCode, status, sDT, eDT);
                        
                    } else {
                        objlst = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPage(organizationCode, status,orderLst);
                        objlstfordist = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPageForDist(organizationCode, status);
                    }

                HashMap <String,Worker> workerMap=new HashMap<>();
                HashMap <String,PatientDetails> patientMap=new HashMap<>();
                HashMap <String,Double> jobDurationDistanceMap=new HashMap<>();
                HashMap <String,String> startDatePatientCodeMap=new HashMap<>();
                if(objlstfordist!=null && objlstfordist.size()>0)
                {
                    for (Object object : objlstfordist) {
                        Object[] obj = (Object[]) object;
                        if (obj.length >= 3) {
                            Jobs j = (Jobs) obj[0];
                            JobsDuration jd = (JobsDuration) obj[1];
                            JobsAssignToWorker aws=(JobsAssignToWorker) obj[2];
                            if(aws!=null && aws.getWorkerCode()!=null)
                            {
                                if(!workerMap.containsKey(aws.getWorkerCode()))
                                {
                                    Worker wkr=workerRepository.getWorkerdetailByworkerCode(aws.getWorkerCode());
                                    if(wkr!=null && wkr.getId()>0)
                                    {
                                        workerMap.put(aws.getWorkerCode(), wkr);
                                    }
                                }
                            }
                            if(!patientMap.containsKey(j.getPatientCode()))
                            {
                            PatientDetails pd = patientDao.getPatientDetailsBypatientCode(j.getPatientCode());
                            if(pd!=null && pd.getId()>0)
                            {
                                patientMap.put(j.getPatientCode(), pd);
                            }
                            }
                            if (timezone != null && timezone.length() > 0) {
                                Date startDate = jd.getStartTime();
                                startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                String startDt = GigflexDateUtil.convertDateToString(startDate, GigflexConstants.YYYY_MM_DD);
                                startDt+="$"+aws.getWorkerCode();
                                if (!startDatePatientCodeMap.containsKey(startDt)) {
                                    Worker worker=workerMap.get(aws.getWorkerCode());
                                    if(worker!=null && worker.getId()>0)
                                    {
                                    PatientDetails pdSource =  patientMap.get(j.getPatientCode());
                                     if(pdSource!=null && pdSource.getId()>0)
                                   {
                                        Double distance = distance(worker.getLatitude(), worker.getLongitude(),pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
                                        jobDurationDistanceMap.put(jd.getJobsDurationCode(), distance);
                                   }
                                    }
                                    startDatePatientCodeMap.put(startDt, j.getPatientCode());
                                } else {
                                    String pcode = startDatePatientCodeMap.get(startDt);
                                    if (pcode != null) {
                                        PatientDetails pd = patientMap.get(pcode);
                                        if (pd != null && pd.getId() > 0) {
                                            PatientDetails pdSource = patientMap.get(j.getPatientCode());
                                            if (pdSource != null && pdSource.getId() > 0) {
                                                Double distance = distance(pd.getPatientLatitude(), pd.getPatientLongitude(), pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
                                                jobDurationDistanceMap.put(jd.getJobsDurationCode(), distance);
                                            }
                                        }
                                    }
                                    startDatePatientCodeMap.put(startDt, j.getPatientCode());
                                }
                            }
                            
                        }
                    }
                   
                }
                    
                    List<JobsAllResponse> maplst = new ArrayList<JobsAllResponse>();
                    if (objlst != null && objlst.size() > 0) {
                        
                        
                       
                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                        {
                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                        }                

                        String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);

                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timeznCode);
                        
                        for (int i = 0; i < objlst.size(); i++) {
                            Object[] arr = (Object[]) objlst.get(i);
                            if (arr.length >= 3) {

                                JobsAllResponse jaRes = new JobsAllResponse();
                                String conStartDt = "";
                                String conEndTime="";
                                Jobs jobData = (Jobs) arr[0];
                                JobsDuration jdData= (JobsDuration) arr[1];
                                JobsAssignToWorker jawData = (JobsAssignToWorker) arr[2];
                                Date timestampStartTime =null;
                                Date timestampEndTime = null;
                                if (tzd != null && tzd.getId() > 0) {
                                    timezone = tzd.getTimeZoneName();
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(jdData.getStartTime()!=null){
                                         Date startDate = jdData.getStartTime();
                                         timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                         conStartDt=GigflexDateUtil.convertDateToString(timestampStartTime, dtFormat);
                                        }
                                        if(jdData.getEndTime()!=null){
                                            Date endDate = jdData.getEndTime();
                                            timestampEndTime = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                            conEndTime=GigflexDateUtil.convertDateToString(timestampEndTime, dtFormat);
                                         }
                                    }
                                }    
                                jaRes.setDateFormat(dateformat);
                                jaRes.setTimeFormat(timeformat); 
                                
                                String duration ="";
                                
                                Integer hours = jdData.getDurationHours();
                                Integer minute = jdData.getDurationMinute();
                                
                                String strHours = "";
                                if(hours != null && hours > 0 )
                                {
                                    strHours = hours.toString();
                                }
                                
                                String strMinute = "";
                                if(minute != null && minute > 0 )
                                {
                                    strMinute = minute.toString();
                                }
                                
                                if(strHours.length() > 0 )
                                {
                                    duration = strHours +" Hours ";
                                }
                                
                                if(strMinute.length() > 0 )
                                {
                                    duration =duration+strMinute+" Minutes";
                                }
                                
                                jaRes.setDuration(duration);
                                jaRes.setEndTime(conEndTime);
                                jaRes.setStartTime(conStartDt);
                                jaRes.setTimestampStartTime(timestampStartTime);
                                jaRes.setTimestampEndTime(timestampEndTime); 
                                jaRes.setJobsCode(jdData.getJobsCode());
                                jaRes.setJobsDurationCode(jdData.getJobsDurationCode());
                                if(jobData.getPatientCode() != null)
                                {
                                    jaRes.setPatientCode(jobData.getPatientCode());
                                    if (patientMap.containsKey(jobData.getPatientCode())) {
                                        PatientDetails patientDetails = patientMap.get(jobData.getPatientCode());

                                        if (patientDetails != null) {

                                            jaRes.setPatientName(patientDetails.getPatientName());
                                            jaRes.setPatientDetails(patientDetails);
                                        } else {
                                            jaRes.setPatientName("");
                                        }
                                    }
                                }
                                else
                                {
                                    jaRes.setPatientCode("");
                                    jaRes.setPatientName("");
                                    
                                }
                                
                                if(jobData.getProcedureCode() != null)
                                {
                                    jaRes.setProcedureCode(jobData.getProcedureCode());
                                    
                                    ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(jaRes.getProcedureCode());
                                    
                                    if( pm != null )
                                    {
                                        jaRes.setProcedureIcon(pm.getProcedureIcon()); 
                                    }
                                }
                                else
                                {
                                    jaRes.setProcedureCode("");
                                    jaRes.setProcedureIcon("");
                                }
                                
                                jaRes.setStatus(jawData.getStatus());
                                if(jawData.getWorkerCode() != null)
                                {
                                    jaRes.setWorkerCode(jawData.getWorkerCode());
                                    if (workerMap.containsKey(jawData.getWorkerCode())) {
                                        Worker worker = workerMap.get(jawData.getWorkerCode());
                                        if (worker != null) {
                                            jaRes.setWorkerName(worker.getName());
                                        } else {
                                            jaRes.setWorkerName("");
                                        }
                                    }
                                }
                                else
                                {
                                    jaRes.setWorkerCode("");
                                    jaRes.setWorkerName("");
                                }                                                              
                                
                                String strDistance = "";
                                if(jobDurationDistanceMap.containsKey(jdData.getJobsDurationCode()))
                                {
                                    Double dis=jobDurationDistanceMap.get(jdData.getJobsDurationCode());
                                    if(dis!=null)
                                    {
                                        strDistance=dis.toString();
                                    }
                                }
                                jaRes.setDistance(strDistance);                                 
                                maplst.add(jaRes);
                            }
                        }
                    }
                    
                    List<PercentageCalculation> pcList = new ArrayList<>();
                    double sumOfPersentage =0.0;
                    int countDays = 0;
                    
                     if (sDT != null && eDT != null) {
                         
                        Date nextDate = sDT;
                        Date nextEndDate = sDTForPersentage;
                        Date responseDate = GigflexDateUtil.convertStringToDate(startDateForPersentage, GigflexConstants.YYYY_MM_DD);
                        List<String> statusList = new ArrayList<>();
                        if(isPercentageCalculate)
                        {            
                            statusList.add(GigflexConstants.JOBSTATUS_ASSIGNED);                                
                            statusList.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                            
                            List<String> pendingStatusList = new ArrayList<>();
                            pendingStatusList.add(GigflexConstants.JOBSTATUS_PENDING);                           
                           
                            while(nextDate.before(eDT) || nextDate.equals(eDT))
                            {
                                String strDate = GigflexDateUtil.convertDateToString(responseDate, dateformat);
                                PercentageCalculation pc =new PercentageCalculation();
                                List<Object> acceptedAndAssignedList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, statusList, nextDate, nextEndDate);
                                
                                int countAcceptedAssigned = 0;
                                int countPending = 0;
                                
                                if(acceptedAndAssignedList != null && acceptedAndAssignedList.size() > 0)
                                {
                                    countAcceptedAssigned = acceptedAndAssignedList.size();
                                }
                                
                                List<Object> pendingList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, pendingStatusList, nextDate, nextEndDate);
                                
                                
                                if(pendingList != null && pendingList.size() > 0 )
                                {
                                    countPending = pendingList.size();
                                }
                                
                                if(countAcceptedAssigned == 0 && countPending == 0)
                                {
                                    
                                }
                                else
                                {
                                    double sum = countAcceptedAssigned+countPending;
                                    double persentage = (countAcceptedAssigned)*100/(sum);
                                    pc.setFullfillmentRatio(persentage); 
                                    pc.setDateTimestamp(responseDate);  
                                    pc.setDate(strDate); 
                                    pc.setDateFormat(dateformat); 
                                    pcList.add(pc);
                                    sumOfPersentage = sumOfPersentage+persentage;
                                    countDays++;
                                }                                                              
                               
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(nextDate);
                                cal.add(Calendar.DAY_OF_MONTH, 1);                           
                                nextDate = cal.getTime();
                                
                                Calendar caleEnd = Calendar.getInstance();
                                caleEnd.setTime(nextEndDate);
                                caleEnd.add(Calendar.DAY_OF_MONTH, 1);                           
                                nextEndDate = caleEnd.getTime();      
                                
                                Calendar calForResponse = Calendar.getInstance();
                                calForResponse.setTime(responseDate);
                                calForResponse.add(Calendar.DAY_OF_MONTH, 1);                           
                                responseDate = calForResponse.getTime();
                            }       
                        }
                        else if(statusForPercentageCalculation.trim().length() > 0)
                        {
                            statusList.add(statusForPercentageCalculation.trim());
                            while(nextDate.before(eDT) || nextDate.equals(eDT))
                            {
                                PercentageCalculation pc =new PercentageCalculation();
                                String strDate = GigflexDateUtil.convertDateToString(responseDate, dateformat);
                                double persentage = 0;
                                
                                List<Object> dataList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, statusList, nextDate, nextEndDate);
                                
                                if(dataList != null && dataList.size() > 0 )
                                {                                          
                                    if(statusForPercentageCalculation.trim().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED) 
                                            || statusForPercentageCalculation.trim().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED) )
                                    {
                                        persentage = 100;

                                    }
                                    else if(statusForPercentageCalculation.trim().equalsIgnoreCase(GigflexConstants.JOBSTATUS_PENDING))
                                    {
                                        persentage = 0;
                                    }
                                    pc.setFullfillmentRatio(persentage); 
                                    pc.setDateTimestamp(responseDate);  
                                    pc.setDate(strDate); 
                                    pc.setDateFormat(dateformat); 
                                    pcList.add(pc);
                                }
                                
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(nextDate);
                                cal.add(Calendar.DAY_OF_MONTH, 1);                           
                                nextDate = cal.getTime();
                                
                                Calendar caleEnd = Calendar.getInstance();
                                caleEnd.setTime(nextEndDate);
                                caleEnd.add(Calendar.DAY_OF_MONTH, 1);                           
                                nextEndDate = caleEnd.getTime();   
                                
                                Calendar calForResponse = Calendar.getInstance();
                                calForResponse.setTime(responseDate);
                                calForResponse.add(Calendar.DAY_OF_MONTH, 1);                           
                                responseDate = calForResponse.getTime();
                            }

                        }
                    
                     }
                    PercentageCalculationRes pcRes = new PercentageCalculationRes(); 
                    pcRes.setJobResponseList(maplst); 
                    pcRes.setPercentageCalculationList(pcList); 
                    double average = 0.0;
                    
                    if(countDays > 0)
                    {
                        average = sumOfPersentage/countDays;
                        pcRes.setFullfillmentAverage(average);  
                    }
                    
                    
                    if ( (maplst != null && maplst.size() > 0) || (pcList.size() > 0) ) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(pcRes);
                        jsonobj.put("data", new JSONObject(Detail));                        
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Organization does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            

            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;

    }
    
    @Override
    public String getAllJobsByOrganizationCodeWithFilterForTest(String organizationCode, List<String> status, String startDT, String endDT) {
        
         String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
       
                
//                List<String> orderLst = new ArrayList<String>();
//                orderLst.add(GigflexConstants.JOBSTATUS_ASSIGNED);           
//                orderLst.add(GigflexConstants.JOBSTATUS_REJECTED);
//                orderLst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
//                orderLst.add(GigflexConstants.JOBSTATUS_PENDING);
//                orderLst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
//                orderLst.add(GigflexConstants.JOBSTATUS_COMPLETED);
//                orderLst.add(GigflexConstants.JOBSTATUS_CANCELLED);
//                orderLst.add(GigflexConstants.JOBSTATUS_EXPIRED);                

                Organization org = orgDao.findByOrganizationCode(organizationCode);
                if (org != null && org.getId() > 0 ) {
                   
                    String timezone = null;
                    Date sDT = null;
                    Date eDT = null;
                    Date sDTForPersentage = null;
                    String startDTForPersentage ="";
                    
                    
                    String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                        {
                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                        } 
                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    String startDateForPersentage = new String(startDT);
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                        if (startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                            startDTForPersentage = startDT + " 23:59:59";
                            startDT = startDT + " 00:00:00";
                            endDT = endDT + " 23:59:59";
                            

                            sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            sDTForPersentage = GigflexDateUtil.convertStringDateToGMT(startDTForPersentage, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            if (sDT == null || eDT == null) {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Date conversion has been failed.");
                                return derr.toString();
                            }
                          
                        }
                    }
                    
                    boolean isPercentageCalculate = false; 
                    String statusForPercentageCalculation ="";
                    if ( status.size() == 1 ) {

                        if(status.get(0).equalsIgnoreCase("all"))
                        {
                            isPercentageCalculate = true;
                        }
                        else if(status.get(0).equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED) || 
                                status.get(0).equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED) ||
                                status.get(0).equalsIgnoreCase(GigflexConstants.JOBSTATUS_PENDING) )
                        {
                            statusForPercentageCalculation = status.get(0);
                        }
                       
                    }                    
                    else if( status.size() > 0 && (status.contains(GigflexConstants.JOBSTATUS_ASSIGNED) 
                            && status.contains(GigflexConstants.JOBSTATUS_ACCEPTED ) 
                            && status.contains(GigflexConstants.JOBSTATUS_PENDING)) ) 
                    {
                        isPercentageCalculate = true;
                    }
                    
                    
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_REJECTED);
                        stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                        stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                        stlst.add(GigflexConstants.JOBSTATUS_PENDING);
                        status = stlst;                        
                    }

                    List<Object> objlst = null;
                   // List<Object> objlstfordist = null;
                    if (sDT != null && eDT != null) {
                        objlst = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPageForTest(organizationCode, status, sDT, eDT);
                        //objlstfordist = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPageForDistForTest(organizationCode, status, sDT, eDT);
                        
                    } else {
                        objlst = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPageForTest(organizationCode, status);
                        //objlstfordist = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPageForDistForTest(organizationCode, status);
                    }

                HashMap <String,Worker> workerMap=new HashMap<>();
               // HashMap <String,PatientDetails> patientMap=new HashMap<>();
                //HashMap <String,Double> jobDurationDistanceMap=new HashMap<>();
               // HashMap <String,String> startDatePatientCodeMap=new HashMap<>();
                HashMap <Date,Integer> acceptedMap=new HashMap<>();
                HashMap <Date,Integer> pendingMap=new HashMap<>();
                
                    
                    List<JobsAllResponse> maplst = new ArrayList<JobsAllResponse>();
                    if (objlst != null && objlst.size() > 0) {
                                              
                        for (int i = 0; i < objlst.size(); i++) {
                            Object[] arr = (Object[]) objlst.get(i);
                            if (arr.length >= 5) {

                                JobsAllResponse jaRes = new JobsAllResponse();
                                String conStartDt = "";
                                String conEndTime="";
                                Jobs jobData = (Jobs) arr[0];
                                JobsDuration jdData= (JobsDuration) arr[1];
                                JobsAssignToWorker jawData = (JobsAssignToWorker) arr[2];
                                PatientDetails patientDetail = (PatientDetails) arr[3];
                                ProcedureMaster pm = (ProcedureMaster) arr[4];
                                       
                                if(jawData!=null && jawData.getWorkerCode()!=null)
                            {
                                if(!workerMap.containsKey(jawData.getWorkerCode()))
                                {
                                    Worker wkr=workerRepository.getWorkerdetailByworkerCode(jawData.getWorkerCode());
                                    if(wkr!=null && wkr.getId()>0)
                                    {
                                        workerMap.put(jawData.getWorkerCode(), wkr);
                                    }
                                }
                            }
//                            if(!patientMap.containsKey(jobData.getPatientCode()))
//                            {
////                                PatientDetails pd = patientDao.getPatientDetailsBypatientCode(j.getPatientCode());
//                                if(patientDetail!=null && patientDetail.getId()>0)
//                                {
//                                    patientMap.put(jobData.getPatientCode(), patientDetail);
//                                }
//                            }
                            
                            
                        
                                
                                Date timestampStartTime =null;
                                Date timestampEndTime = null;
                                
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(jdData.getStartTime()!=null){
                                         Date startDate = jdData.getStartTime();
                                         timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                         conStartDt=GigflexDateUtil.convertDateToString(timestampStartTime, dtFormat);
//                                        if (jawData.getWorkerCode() != null && jawData.getWorkerCode().length() > 0) {
//                                String startDt = GigflexDateUtil.convertDateToString(timestampStartTime, GigflexConstants.YYYY_MM_DD);
//                                startDt+="$"+jawData.getWorkerCode();
//                                if (!startDatePatientCodeMap.containsKey(startDt)) {
//                                    
//                                    Worker worker=workerMap.get(jawData.getWorkerCode());
//                                    if(worker!=null && worker.getId()>0)
//                                    {
//                                        PatientDetails pdSource =  patientMap.get(jobData.getPatientCode());
//                                         if(pdSource!=null && pdSource.getId()>0)
//                                       {
//                                            Double distance = distance(worker.getLatitude(), worker.getLongitude(),pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
//                                             if(distance!=null)
//                                                {
//                                                    jaRes.setDistance(distance.toString());   
//                                                }
//                                       }
//                                    }
//                                    startDatePatientCodeMap.put(startDt, jobData.getPatientCode());
//                                } else {
//                                    String pcode = startDatePatientCodeMap.get(startDt);
//                                    if (pcode != null) {
//                                        PatientDetails pd = patientMap.get(pcode);
//                                        if (pd != null && pd.getId() > 0) {
//                                            PatientDetails pdSource = patientMap.get(jobData.getPatientCode());
//                                            if (pdSource != null && pdSource.getId() > 0) {
//                                                Double distance = distance(pd.getPatientLatitude(), pd.getPatientLongitude(), pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
//                                                if(distance!=null)
//                                                {
//                                                    jaRes.setDistance(distance.toString());   
//                                                }
//                                             }
//                                        }
//                                    }
//                                    startDatePatientCodeMap.put(startDt, jobData.getPatientCode());
//                                }
//                            }
                                        }
                                        if(jdData.getEndTime()!=null){
                                            Date endDate = jdData.getEndTime();
                                            timestampEndTime = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                            conEndTime=GigflexDateUtil.convertDateToString(timestampEndTime, dtFormat);
                                         }
                                    }
                                if(timestampStartTime!=null  && timestampEndTime!=null)
                                {
                                String sStr=GigflexDateUtil.convertDateToString(timestampStartTime, GigflexConstants.YYYY_MM_DD);
                                String eStr=GigflexDateUtil.convertDateToString(timestampEndTime, GigflexConstants.YYYY_MM_DD);
                                if(sStr!=null && eStr!=null)
                                {
                                Date responseSDate = GigflexDateUtil.convertStringToDate(sStr, GigflexConstants.YYYY_MM_DD);
                                Date responseEDate = GigflexDateUtil.convertStringToDate(eStr, GigflexConstants.YYYY_MM_DD);
                                if(jawData.getStatus()!=null && (jawData.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED) || jawData.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED)))
                                {
                                     if (acceptedMap.containsKey(responseSDate)) {
                                         Integer cnt=acceptedMap.get(responseSDate);
                                        cnt=cnt!=null?cnt+=1:1;
                                        acceptedMap.put(responseSDate, cnt);
                                     }
                                     else
                                     {
                                         acceptedMap.put(responseSDate, 1);
                                     }
                                    if(!(responseSDate.equals(responseEDate)))
                                    {
                                        if (acceptedMap.containsKey(responseEDate)) {
                                         Integer cnt=acceptedMap.get(responseEDate);
                                        cnt=cnt!=null?cnt+=1:1;
                                        acceptedMap.put(responseEDate, cnt);
                                     }
                                     else
                                     {
                                         acceptedMap.put(responseEDate, 1);
                                     }
                                    }
                                }else if(jawData.getStatus()!=null && jawData.getStatus().equalsIgnoreCase(GigflexConstants.JOBSTATUS_PENDING) )
                                {
                                    
                                     if (pendingMap.containsKey(responseSDate)) {
                                         Integer cnt=pendingMap.get(responseSDate);
                                        cnt=cnt!=null?cnt+=1:1;
                                        pendingMap.put(responseSDate, cnt);
                                     }
                                     else
                                     {
                                         pendingMap.put(responseSDate, 1);
                                     }
                                    if(!(responseSDate.equals(responseEDate)))
                                    {
                                        if (pendingMap.containsKey(responseEDate)) {
                                         Integer cnt=pendingMap.get(responseEDate);
                                        cnt=cnt!=null?cnt+=1:1;
                                        pendingMap.put(responseEDate, cnt);
                                     }
                                     else
                                     {
                                         pendingMap.put(responseEDate, 1);
                                     }
                                    }
                                
                                }
                                }
                                }
                                jaRes.setDateFormat(dateformat);
                                jaRes.setTimeFormat(timeformat); 
                                
                                String duration ="";
                                
                                Integer hours = jdData.getDurationHours();
                                Integer minute = jdData.getDurationMinute();
                                
                                String strHours = "";
                                if(hours != null && hours > 0 )
                                {
                                    strHours = hours.toString();
                                }
                                
                                String strMinute = "";
                                if(minute != null && minute > 0 )
                                {
                                    strMinute = minute.toString();
                                }
                                
                                if(strHours.length() > 0 )
                                {
                                    duration = strHours +" Hours ";
                                }
                                
                                if(strMinute.length() > 0 )
                                {
                                    duration =duration+strMinute+" Minutes";
                                }
                                
                                jaRes.setDuration(duration);
                                jaRes.setEndTime(conEndTime);
                                jaRes.setStartTime(conStartDt);
                                jaRes.setTimestampStartTime(timestampStartTime);
                                jaRes.setTimestampEndTime(timestampEndTime); 
                                jaRes.setJobsCode(jdData.getJobsCode());
                                jaRes.setJobsDurationCode(jdData.getJobsDurationCode());
                                if(jobData.getPatientCode() != null)
                                {
                                    jaRes.setPatientCode(jobData.getPatientCode());
//                                    if (patientMap.containsKey(jobData.getPatientCode())) {
//                                        PatientDetails patientDetails = patientMap.get(jobData.getPatientCode());

                                        if (patientDetail != null) {

                                            jaRes.setPatientName(patientDetail.getPatientName());
                                            jaRes.setPatientDetails(patientDetail);
                                        } else {
                                            jaRes.setPatientName("");
                                        }
                                    //}
                                }
                                else
                                {
                                    jaRes.setPatientCode("");
                                    jaRes.setPatientName("");
                                    
                                }
                                
                                if(jobData.getProcedureCode() != null)
                                {
                                    jaRes.setProcedureCode(jobData.getProcedureCode());
                                    
//                                    ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(jaRes.getProcedureCode());
                                    
                                    if( pm != null )
                                    {
                                        jaRes.setProcedureIcon(pm.getProcedureIcon()); 
                                    }
                                }
                                else
                                {
                                    jaRes.setProcedureCode("");
                                    jaRes.setProcedureIcon("");
                                }
                                
                                jaRes.setStatus(jawData.getStatus());
                                if(jawData.getWorkerCode() != null)
                                {
                                    jaRes.setWorkerCode(jawData.getWorkerCode());
                                    if (workerMap.containsKey(jawData.getWorkerCode())) {
                                        Worker worker = workerMap.get(jawData.getWorkerCode());
                                        if (worker != null) {
                                            jaRes.setWorkerName(worker.getName());
                                        } else {
                                            jaRes.setWorkerName("");
                                        }
                                    }
                                }
                                else
                                {
                                    jaRes.setWorkerCode("");
                                    jaRes.setWorkerName("");
                                }                                                              
                                
//                                String strDistance = "";
//                                if(jobDurationDistanceMap.containsKey(jdData.getJobsDurationCode()))
//                                {
//                                    Double dis=jobDurationDistanceMap.get(jdData.getJobsDurationCode());
//                                    if(dis!=null)
//                                    {
//                                        strDistance=dis.toString();
//                                    }
//                                }
                                if(jawData!=null && jawData.getDistance()!=null)
                                {
                                jaRes.setDistance(String.format("%.2f", jawData.getDistance()));       
                                }
                                maplst.add(jaRes);
                            }
                        }
                    }
                    
                    List<PercentageCalculation> pcList = new ArrayList<>();
                    double sumOfPersentage =0.0;
                    int countDays = 0;
                    
                     if (sDT != null && eDT != null) {
                         
                        Date nextDate = sDT;
                       // Date nextEndDate = sDTForPersentage;
                        Date responseDate = GigflexDateUtil.convertStringToDate(startDateForPersentage, GigflexConstants.YYYY_MM_DD);
                        List<String> statusList = new ArrayList<>();
                        if(isPercentageCalculate)
                        {            
                            statusList.add(GigflexConstants.JOBSTATUS_ASSIGNED);                                
                            statusList.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                            
                            List<String> pendingStatusList = new ArrayList<>();
                            pendingStatusList.add(GigflexConstants.JOBSTATUS_PENDING);                           
                           
                            while(nextDate.before(eDT) || nextDate.equals(eDT))
                            {
                                String strDate = GigflexDateUtil.convertDateToString(responseDate, dateformat);
                                PercentageCalculation pc =new PercentageCalculation();
                               // List<Object> acceptedAndAssignedList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, statusList, nextDate, nextEndDate);
                                
                                int countAcceptedAssigned = 0;
                                int countPending = 0;
                                
                                if(acceptedMap.containsKey(responseDate))
                                {
                                    if(acceptedMap.get(responseDate)!=null)
                                    {
                                    countAcceptedAssigned = acceptedMap.get(responseDate);
                                    }
                                }
                                
                               // List<Object> pendingList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, pendingStatusList, nextDate, nextEndDate);
                                
                                
                                if(pendingMap.containsKey(responseDate) )
                                {
                                    if(pendingMap.get(responseDate)!=null)
                                    {
                                    countPending =pendingMap.get(responseDate);
                                    }
                                }
                                
                                if(countAcceptedAssigned == 0 && countPending == 0)
                                {
                                    
                                }
                                else
                                {
                                    double sum = countAcceptedAssigned+countPending;
                                    double persentage = (countAcceptedAssigned)*100/(sum);
                                    pc.setFullfillmentRatio(persentage); 
                                    pc.setDateTimestamp(responseDate);  
                                    pc.setDate(strDate); 
                                    pc.setDateFormat(dateformat); 
                                    pcList.add(pc);
                                    sumOfPersentage = sumOfPersentage+persentage;
                                    countDays++;
                                }                                                              
                               
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(nextDate);
                                cal.add(Calendar.DAY_OF_MONTH, 1);                           
                                nextDate = cal.getTime();
                                
//                                Calendar caleEnd = Calendar.getInstance();
//                                caleEnd.setTime(nextEndDate);
//                                caleEnd.add(Calendar.DAY_OF_MONTH, 1);                           
//                                nextEndDate = caleEnd.getTime();      
//                                
                                Calendar calForResponse = Calendar.getInstance();
                                calForResponse.setTime(responseDate);
                                calForResponse.add(Calendar.DAY_OF_MONTH, 1);                           
                                responseDate = calForResponse.getTime();
                            }       
                        }
                        else if(statusForPercentageCalculation.trim().length() > 0)
                        {
                            statusList.add(statusForPercentageCalculation.trim());
                            while(nextDate.before(eDT) || nextDate.equals(eDT))
                            {
                                PercentageCalculation pc =new PercentageCalculation();
                                String strDate = GigflexDateUtil.convertDateToString(responseDate, dateformat);
                                double persentage = 0;
                                
                                //List<Object> dataList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, statusList, nextDate, nextEndDate);
                                
//                                if(dataList != null && dataList.size() > 0 )
//                                {                                          
                                    if(statusForPercentageCalculation.trim().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ASSIGNED) 
                                            || statusForPercentageCalculation.trim().equalsIgnoreCase(GigflexConstants.JOBSTATUS_ACCEPTED) )
                                    {
                                        if(acceptedMap.containsKey(responseDate))
                                {
                                        persentage = 100;
                                         pc.setFullfillmentRatio(persentage); 
                                    pc.setDateTimestamp(responseDate);  
                                    pc.setDate(strDate); 
                                    pc.setDateFormat(dateformat); 
                                    pcList.add(pc);
                                    sumOfPersentage+=persentage;
                                    countDays++;
                                        
                                }
                                        

                                    }
                                    else if(statusForPercentageCalculation.trim().equalsIgnoreCase(GigflexConstants.JOBSTATUS_PENDING))
                                    {
                                        
                                         if(pendingMap.containsKey(responseDate) )
                                        {
                                            persentage = 0;
                                             pc.setFullfillmentRatio(persentage); 
                                    pc.setDateTimestamp(responseDate);  
                                    pc.setDate(strDate); 
                                    pc.setDateFormat(dateformat); 
                                    pcList.add(pc);
                                    sumOfPersentage+=persentage;
                                    countDays++;
                                        }
                                    }
                                   
                                //}
                                
                                Calendar cal = Calendar.getInstance();
                                cal.setTime(nextDate);
                                cal.add(Calendar.DAY_OF_MONTH, 1);                           
                                nextDate = cal.getTime();
                                
//                                Calendar caleEnd = Calendar.getInstance();
//                                caleEnd.setTime(nextEndDate);
//                                caleEnd.add(Calendar.DAY_OF_MONTH, 1);                           
//                                nextEndDate = caleEnd.getTime();   
                                
                                Calendar calForResponse = Calendar.getInstance();
                                calForResponse.setTime(responseDate);
                                calForResponse.add(Calendar.DAY_OF_MONTH, 1);                           
                                responseDate = calForResponse.getTime();
                            }

                        }
                    
                     }
                    PercentageCalculationRes pcRes = new PercentageCalculationRes(); 
                    pcRes.setJobResponseList(maplst); 
                    pcRes.setPercentageCalculationList(pcList); 
                    double average = 0.0;
                    
                    if(countDays > 0)
                    {
                        average = sumOfPersentage/countDays;
                        pcRes.setFullfillmentAverage(average);  
                    }
                    
                    
                    if ( (maplst != null && maplst.size() > 0) || (pcList.size() > 0) ) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(pcRes);
                        jsonobj.put("data", new JSONObject(Detail));                        
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Organization does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            

            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;

    }
    
    
    
    @Override
    public String getAllJobsByOrganizationCodeWithFilter(String organizationCode, List<String> status, String startDT, String endDT, String patientCode) {
        
         String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
       
                
                List<String> orderLst = new ArrayList<String>();
                orderLst.add(GigflexConstants.JOBSTATUS_ASSIGNED);           
                orderLst.add(GigflexConstants.JOBSTATUS_REJECTED);
                orderLst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                orderLst.add(GigflexConstants.JOBSTATUS_PENDING);
                orderLst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                orderLst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                orderLst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                orderLst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                
                
                PatientDetails patientDetails = patientDao.getPatientDetailBypatientCode(patientCode);
                if(patientDetails!=null && patientDetails.getId()>0)
                {
                Organization org = orgDao.findByOrganizationCode(organizationCode);
                if (org != null && org.getId() > 0 ) {
                   
                    String timezone = null;
                    Date sDT = null;
                    Date eDT = null;

                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                        if (startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                            startDT = startDT + " 00:00:00";
                            endDT = endDT + " 23:59:59";

                            sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            if (sDT == null || eDT == null) {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Date conversion has been failed.");
                                return derr.toString();
                            }
                          
                        }
                    }
                    List<Object> objlstCheck = null;

                    
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_REJECTED);
                        stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                        stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                        stlst.add(GigflexConstants.JOBSTATUS_PENDING);
                        status = stlst;
                    }

                    List<Object> objlst = null;

                    if (sDT != null && eDT != null) {
                        objlst = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPage(organizationCode, status, sDT, eDT,patientCode,orderLst);
                        
                    } else {
                        objlst = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPage(organizationCode, status,patientCode,orderLst);
                        
                    }

                    List<JobsAllResponse> maplst = new ArrayList<JobsAllResponse>();
                    if (objlst != null && objlst.size() > 0) {
                        
                        String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                        String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                        String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                       
                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                        {
                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                        }                

                        String timeznCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);

                        TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timeznCode);
                        
                        for (int i = 0; i < objlst.size(); i++) {
                            Object[] arr = (Object[]) objlst.get(i);
                            if (arr.length >= 3) {

                                JobsAllResponse jaRes = new JobsAllResponse();
                                String conStartDt = "";
                                String conEndTime="";
                                Jobs jobData = (Jobs) arr[0];
                                JobsDuration jdData= (JobsDuration) arr[1];
                                JobsAssignToWorker jawData = (JobsAssignToWorker) arr[2];
                                Date timestampStartTime =null;
                                Date timestampEndTime = null;
                                if (tzd != null && tzd.getId() > 0) {

                                    timezone = tzd.getTimeZoneName();
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(jdData.getStartTime()!=null){
                                         Date startDate = jdData.getStartTime();
                                         timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                         conStartDt=GigflexDateUtil.convertDateToString(timestampStartTime, dtFormat);
                                        }
                                        if(jdData.getEndTime()!=null){
                                            Date endDate = jdData.getEndTime();
                                            timestampEndTime = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                            conEndTime=GigflexDateUtil.convertDateToString(timestampEndTime, dtFormat);
                                         }
                                    }
                                }    
                                jaRes.setDateFormat(dateformat);
                                jaRes.setTimeFormat(timeformat); 
                                
                                String duration ="";
                                
                                Integer hours = jdData.getDurationHours();
                                Integer minute = jdData.getDurationMinute();
                                
                                String strHours = "";
                                if(hours != null && hours > 0 )
                                {
                                    strHours = hours.toString();
                                }
                                
                                String strMinute = "";
                                if(minute != null && minute > 0 )
                                {
                                    strMinute = minute.toString();
                                }
                                
                                if(strHours.length() > 0 )
                                {
                                    duration = strHours +" Hours ";
                                }
                                
                                if(strMinute.length() > 0 )
                                {
                                    duration =duration+strMinute+" Minutes";
                                }
                                
                                jaRes.setDuration(duration);
                                jaRes.setEndTime(conEndTime);
                                jaRes.setStartTime(conStartDt);
                                jaRes.setTimestampStartTime(timestampStartTime);
                                jaRes.setTimestampEndTime(timestampEndTime); 
                                jaRes.setJobsCode(jdData.getJobsCode());
                                jaRes.setJobsDurationCode(jdData.getJobsDurationCode());
                                String patientLat ="";
                                String patientLong ="";
                                if(jobData.getPatientCode() != null)
                                {
                                    jaRes.setPatientCode(jobData.getPatientCode());
                                    //PatientDetails patientDetails = patientDao.getPatientDetailBypatientCode(jobData.getPatientCode());
                                    
                                        
                                        jaRes.setPatientName(patientDetails.getPatientName());
                                        patientLat = patientDetails.getPatientLatitude();
                                        patientLong = patientDetails.getPatientLongitude();
                                        jaRes.setPatientDetails(patientDetails); 
                                    
                                }
                                else
                                {
                                    jaRes.setPatientCode("");
                                    jaRes.setPatientName("");
                                    
                                }
                                
                                if(jobData.getProcedureCode() != null)
                                {
                                    jaRes.setProcedureCode(jobData.getProcedureCode());
                                    
                                    ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(jaRes.getProcedureCode());
                                    
                                    if( pm != null )
                                    {
                                        jaRes.setProcedureIcon(pm.getProcedureIcon()); 
                                    }
                                }
                                else
                                {
                                    jaRes.setProcedureCode("");
                                    jaRes.setProcedureIcon("");
                                }
                                
                                jaRes.setStatus(jawData.getStatus());
                                String workerLat = "";
                                String workerLang = ""; 
                                if(jawData.getWorkerCode() != null)
                                {
                                     jaRes.setWorkerCode(jawData.getWorkerCode());
                                     
                                     Worker worker = workerRepository.findByWorkerCode(jawData.getWorkerCode());
                                     
                                     if(worker != null)
                                     {
                                         jaRes.setWorkerName(worker.getName());
                                         workerLat = worker.getLatitude();
                                         workerLang = worker.getLongitude();
                                     }
                                     else
                                     {
                                         jaRes.setWorkerName("");
                                     }                                     
                                }
                                else
                                {
                                    jaRes.setWorkerCode("");
                                    jaRes.setWorkerName("");
                                }                                                              
                                
                                String strDistance = "";
                                
                                
                                if(workerLat.trim().length() >0 && workerLang.trim().length() >0 && patientLat.trim().length() >0 && patientLong.trim().length() >0 )
                                {
                                    try
                                    {
                                        Double distance  = distance(workerLat.trim(), workerLang.trim(), patientLat.trim(), patientLong.trim());
                                        if(distance!=null)
                                        {
                                        strDistance = String.valueOf(distance);
                                        }
                                    }
                                    catch(Exception e)
                                    {
                                        e.printStackTrace();
                                    }
                                    
                                }
                                jaRes.setDistance(strDistance);  
                                
//                                if(jobData.getPatientCode() != null)
//                                {
//                                    PatientDetails pDetails = patientDao.getPatientDetailBypatientCode(jobData.getPatientCode());
//                                    
//                                    if(pDetails != null)
//                                    {
//                                       jaRes.setPatientDetails(pDetails); 
//                                    }
//                                    
//                                }
                                
                                
                                maplst.add(jaRes);

                            }
                        }
                    }
                    if (maplst != null && maplst.size() > 0) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("data", new JSONArray(Detail));                       
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Organization does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
                }
                else
                {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Patient Details does not exist.");
                    jsonobj.put("timestamp", new Date());
                }

            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;

    
    }

    
     public  void startJobMailNotificationThread(Boolean isShort, JobsAssignToWorker jaw,String subject,String sortbody){
        Thread t = new Thread(new JobMailNotificationThread(isShort,jaw, timeZoneDao, jobsRepository,  globalSettingRepository,
             localSettingRepository,  utr,notificationService, mailServiceURL, subject,sortbody,deviceDetailDao,FMCurl,authKey));
        t.start();
    }
     
     public  void startAssignJobToWorkerDynamicDistanceThread(Worker wkr,String organizationCode,Date startDate,String timezone){
        Thread t = new Thread(new AssignJobToWorkerDynamicDistanceThread(wkr,organizationCode,jobsAssignToWorkerRepository,startDate,timezone, googleKey));
        t.start();
    }

    @Override
    public String getAppointmentDetailOfTechnicianByOrganizationCode(String organizationCode, List<String> status, String startDT, String endDT) {
        
          String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
       
                Organization org = orgDao.findByOrganizationCode(organizationCode);
                if (org != null && org.getId() > 0 ) {
                   
                    String timezone = null;
                    Date sDT = null;
                    Date eDT = null;  
                    String sDatestr="";
                    String msg="Success";
                    Boolean appst=false;
                    Date sDTPeriod = null;
                    Date eDTPeriod = null;
                    String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                            {
                                dtFormat=dateformat.trim()+" "+timeformat.trim();
                            } 
                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    int day=0;
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                        if (startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                            try{
                            Date stDate=GigflexDateUtil.convertStringToDate(startDT, GigflexConstants.YYYY_MM_DD);
                            if(stDate!=null)
                            {
                            Calendar cal = Calendar.getInstance();
                            cal.setTime(stDate);
                            String lookingForValue = "ORG_WORKING_DAY_";
                            day=cal.get(Calendar.DAY_OF_WEEK);
                            lookingForValue+=day;
                            String dayVal=null;
                            try
                            {
                                Object clazz = new GigflexConstants();
                                Field field = clazz.getClass().getField(lookingForValue);
                                dayVal=(String) field.get(clazz);
                            }
                            catch(Exception e1)
                            {
                                e1.printStackTrace();
                            }
                            if(dayVal==null || dayVal.isEmpty())
                            {
//                                GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                "Please set working days from setting.");
//                                return derr.toString();
                                msg="Please set working days from setting.";
                            }
                            String dayValSt =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, dayVal);
                            if(dayValSt==null)
                            {
//                                GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                "Please set working days from setting.");
//                                return derr.toString();
                                msg="Please set working days from setting.";
                            }
                            else if(!(dayValSt.equalsIgnoreCase("true")))
                            {
//                                GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                GigflexDateUtil.getNameFromDayCode(day)+" is off day.");
//                                return derr.toString();
                                msg=GigflexDateUtil.getNameFromDayCode(day)+" is off day.";
                            }
                            
                            HashMap <Date,Boolean> holidayOrgMap=new HashMap<>(); 
       try{
         
       String orgHoliday =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider,organizationCode, GigflexConstants.ORG_SPEC_NON_WORKING_DAYS);
       if(orgHoliday!=null && orgHoliday.trim().length()>0)
       {
           String holiarr[]=orgHoliday.split(",");
           for(int j=0;j<holiarr.length;j++)
           {
               String str=holiarr[j];
               if(str!=null)
               {
                   Date hdt=GigflexDateUtil.convertStringToDate(str.trim(), GigflexConstants.DD_MMMM_YYYY);
                   if(hdt!=null)
                   {
                       holidayOrgMap.put(hdt, Boolean.TRUE);
                   }
               }
           }
       }
             
       }
       catch(Exception eee)
       {
           eee.printStackTrace();
       }
            if(holidayOrgMap.containsKey(stDate)) 
            {
//                 GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                startDT+" is non working date.");
//                                return derr.toString();
                msg=startDT+" is non working date.";
            }
                            
                            String orgst =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.ORG_WORKING_TIME_START);
                            String orgend =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.ORG_WORKING_TIME_END);
                            if(orgst==null || orgend==null || orgst.trim().length()==0 ||  orgend.trim().length()==0 )
                            {
//                                 GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                "Please set working time from setting.");
//                                return derr.toString();
                                msg="Please set working time from setting.";
                            }
                            orgst=orgst.trim().length()==5?orgst.trim()+":00":orgst.trim();
                            orgend=orgend.trim().length()==5?orgend.trim()+":00":orgend.trim();
                            sDatestr=startDT.trim();
                            startDT = startDT + " "+orgst;
                            endDT = endDT + " "+orgend;
                            
                            sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);                           
                            if (sDT == null || eDT == null) {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Date conversion has been failed.");
                                return derr.toString();
                            }
                            sDTPeriod=GigflexDateUtil.convertStringToDate(startDT, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDTPeriod=GigflexDateUtil.convertStringToDate(endDT, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            }
                            else
                            {
                                 GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                                return derr.toString();
                            }
                            }
                            catch(Exception ex)
                            {
                                ex.printStackTrace();
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                                return derr.toString();
                            }
                        }
                    }
                    
                    if (sDT == null || eDT == null) {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                        return derr.toString();
                    }                    
                 
                    
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_REJECTED);
                        stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                        stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                        stlst.add(GigflexConstants.JOBSTATUS_PENDING);
                        status = stlst;                        
                    }
                    
                    List<AppointmentDetailByWorkerCode> adWorkerList = new ArrayList<AppointmentDetailByWorkerCode>();
                    List<Worker>  wkList = workerApprovalStatusRepository.getAllApprovedWorkerOnlyByOrgCode(organizationCode);
                    if(wkList != null && wkList.size() > 0)
                    {
                        
                        for(Worker worker : wkList)
                        {
                            AppointmentDetailByWorkerCode adbwc = new AppointmentDetailByWorkerCode();
                            adbwc.setWorkerCode(worker.getWorkerCode());  
                            adbwc.setName(worker.getName());  
                            adbwc.setEmail(worker.getEmail());  
                            adbwc.setWorkerLogo(worker.getWorkerLogo()); 
                            String workerCode =worker.getWorkerCode();
                            
//                            WorkerHoursOfOperationRes hopres=null;
//                            WorkerHoursOfOperation whop=workerHoursofOperationDao.getHoursByWorkerCodeAndDayCode(workerCode, day);
//                            if(whop!=null && whop.getId()>0 && whop.getFromTime()!=null && whop.getFromTime().trim().length()>0 && whop.getToTime()!=null && whop.getToTime().trim().length()>0)
//                            {
//                                try{
//                                    String sdt=sDatestr+" "+whop.getFromTime().trim();
//                                    String edt=sDatestr+" "+whop.getToTime().trim();
//                                    Date sdtinDate=GigflexDateUtil.convertStringToDate(sdt, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
//                                    Date edtinDate=GigflexDateUtil.convertStringToDate(edt, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
//                                    if(sdtinDate.before(sDTPeriod))
//                                    {
//                                        sdtinDate=sDTPeriod;
//                                    }
//                                    if(edtinDate.after(eDTPeriod))
//                                    {
//                                        edtinDate=eDTPeriod;
//                                    }
//                                    sdt=GigflexDateUtil.convertDateToString(sdtinDate, dtFormat);
//                                    edt=GigflexDateUtil.convertDateToString(edtinDate, dtFormat);
//                                    hopres=new WorkerHoursOfOperationRes();
//                                    hopres.setDayCode(whop.getDayCode());
//                                    hopres.setEndDateTime(edt);
//                                    hopres.setFromTime(whop.getFromTime());
//                                    hopres.setStartDateTime(sdt);
//                                    hopres.setToTime(whop.getToTime());
//                                    hopres.setWorkerhoursOfOperationCode(whop.getWorkerhoursOfOperationCode());
//                                    hopres.setDateFormat(dateformat);
//                                    hopres.setTimeFormat(timeformat); 
//                                }
//                                catch(Exception ee)
//                                {
//                                    ee.printStackTrace();
//                                }
//                            }
//                            adbwc.setWorkerHoursOfOperation(hopres);
//                            List<WorkerTimeOff> wtoLst=workerTimeOffDao.getTimeOffByWorkerCodeAndBetweenDateTimeStamp(workerCode, sDT, eDT);
//                            adbwc.setWorkerTimeOffList(wtoLst);
                            List<AppointmentDetail> appointmentDetailList = new ArrayList<>();
//                            if(hopres!=null)
//                            {
                            List<Object>  objlst = jobsRepository.getAppointmentDetailOfTechnicianByOrgCodeAndWorkerCode(organizationCode, status, sDT, eDT,workerCode);

                            if (objlst != null && objlst.size() > 0) {

                                           
                              
                            HashMap <String,PatientDetails> patientMap=new HashMap<>();
                            HashMap <String,String> startDatePatientCodeMap=new HashMap<>();
                            for (int i = 0; i < objlst.size(); i++) {
                                Object[] arr = (Object[]) objlst.get(i);
                                if (arr.length >= 3) {

                                AppointmentDetail adRes = new AppointmentDetail();
                                adRes.setWorkerName( worker.getName());
                                adRes.setWorkerCode(workerCode);
                                Integer drivingTimeInSecond=null;
                                Double distance=null;
                                String drivingStartTime = "";
                                String distanceText = "";
                                String durationText = "";
                                String conStartDt = "";
                                String conEndTime="";
                                Jobs jobData = (Jobs) arr[0];
                                JobsDuration jdData= (JobsDuration) arr[1];
                                JobsAssignToWorker jawData = (JobsAssignToWorker) arr[2];
                                Date timestampStartTime =null;
                                Date timestampEndTime = null;
                                Boolean ispartial=false;
                                if(jobData!=null)
                                {
                                    if(!patientMap.containsKey(jobData.getPatientCode()))
                                    {
                                        PatientDetails pd = patientDao.getPatientDetailsBypatientCode(jobData.getPatientCode());
                                        if(pd!=null && pd.getId()>0)
                                        {
                                            patientMap.put(jobData.getPatientCode(), pd);
                                            adRes.setPatientName(pd.getPatientName());
                                            adRes.setPatientCode(pd.getPatientCode());
                                            adRes.setPatientAddress(pd.getPatientAddress());
                                            adRes.setPhoneNumber(pd.getPhoneNumber());
                                            adRes.setpCountryCode(pd.getpCountryCode());
                                        }
                                    }
                                    else
                                    {
                                        PatientDetails pd = patientMap.get(jobData.getPatientCode());
                                        if(pd!=null && pd.getId()>0)
                                        {
                                            adRes.setPatientName(pd.getPatientName());
                                            adRes.setPatientCode(pd.getPatientCode());
                                        }
                                    }
                                }
                               if(jobData!=null && jobData.getProcedureCode()!=null)
                               {
                                   ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(jobData.getProcedureCode());
                                    
                                    if( pm != null && pm.getProcedureIcon()!=null)
                                    {
                                        adRes.setProcedureIcon(pm.getProcedureIcon()); 
                                    }
                               }
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(jdData.getStartTime()!=null){
                                         Date startDate = jdData.getStartTime();
                                         timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                         if(timestampStartTime.before(sDTPeriod))
                                         {
                                             timestampStartTime=sDTPeriod;
                                             ispartial=true;
                                         }
                                         conStartDt=GigflexDateUtil.convertDateToString(timestampStartTime, dtFormat);
                                        }
                                        if(jdData.getEndTime()!=null){
                                            Date endDate = jdData.getEndTime();
                                            timestampEndTime = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                            if(timestampEndTime.after(eDTPeriod))
                                         {
                                             timestampEndTime=eDTPeriod;
                                             ispartial=true;
                                         }
                                            conEndTime=GigflexDateUtil.convertDateToString(timestampEndTime, dtFormat);
                                         }
                                    }
                                    if(timestampStartTime!=null)
                                    {
                                        String startDt = GigflexDateUtil.convertDateToString(timestampStartTime, GigflexConstants.YYYY_MM_DD);
                                        if (!startDatePatientCodeMap.containsKey(startDt)) {
                                            PatientDetails pdSource =  patientMap.get(jobData.getPatientCode());
                                            if(pdSource!=null && pdSource.getId()>0)
                                          {
                                              GoogleDistanceDurationResponse gddres = getGoogleDistanceDurationResponse(worker.getLatitude(), worker.getLongitude(), pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
                                              if (gddres != null) {
                                                  if (gddres.getDistanceValue() != null) {
                                                      double mileCon = 1609.344;
                                                      distance = gddres.getDistanceValue() / mileCon;

                                                  }
                                                  drivingTimeInSecond=gddres.getDurationValue();
                                                  durationText=gddres.getDurationText();
                                                  distanceText=gddres.getDistanceText();
                                              }
                                          }
                                         startDatePatientCodeMap.put(startDt, jobData.getPatientCode());
                                    } 
                                    else 
                                    {
                                       String pcode=startDatePatientCodeMap.get(startDt);
                                        if(pcode!=null)
                                        {
                                            PatientDetails pd =patientMap.get(pcode);
                                            if(pd!=null && pd.getId()>0)
                                            {
                                                PatientDetails pdSource =  patientMap.get(jobData.getPatientCode());
                                                if(pdSource!=null && pdSource.getId()>0)
                                                {
                                                    GoogleDistanceDurationResponse gddres  = getGoogleDistanceDurationResponse(pd.getPatientLatitude(), pd.getPatientLongitude(),pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
                                                    if (gddres != null) {
                                                        if (gddres.getDistanceValue() != null) {
                                                            double mileCon = 1609.344;
                                                            distance = gddres.getDistanceValue() / mileCon;

                                                        }
                                                        drivingTimeInSecond=gddres.getDurationValue();
                                                        durationText=gddres.getDurationText();
                                                        distanceText=gddres.getDistanceText();
                                                    }
                                                }
                                            }
                                        }
                                        startDatePatientCodeMap.put(startDt, jobData.getPatientCode());
                                    }
                                    }
                                    if(drivingTimeInSecond!=null && ispartial==false)
                                    {
                                        int min=drivingTimeInSecond/60;
                                        Calendar calmin = Calendar.getInstance();
                                        calmin.setTime(timestampStartTime);
                                        calmin.add(Calendar.MINUTE, -min);
                                        Date drvdt=calmin.getTime();
                                        drivingStartTime=GigflexDateUtil.convertDateToString(drvdt, dtFormat);
                                    }
                                adRes.setDistanceText(distanceText);
                                adRes.setDurationText(durationText);
                                adRes.setDistance(distance);
                                adRes.setDrivingTimeInSecond(drivingTimeInSecond);
                                adRes.setDrivingStartTime(drivingStartTime);
                                adRes.setDateFormat(dateformat);
                                adRes.setTimeFormat(timeformat); 
                                adRes.setIsPartial(ispartial);
                                adRes.setJobEndDate(conEndTime);
                                adRes.setJobStartDate(conStartDt);
                                adRes.setTimestampJobsStartTime(timestampStartTime);
                                adRes.setTimestampJobsEndTime(timestampEndTime); 
                                adRes.setJobsCode(jdData.getJobsCode());
                                adRes.setJobsDurationCode(jdData.getJobsDurationCode()); 
                                adRes.setJobName(jdData.getJobName()); 

                                adRes.setStatus(jawData.getStatus());
                           
                                appointmentDetailList.add(adRes);

                                }
                               }                            
                            }
                           // }
                           if(appointmentDetailList!=null && appointmentDetailList.size()>0)
                           {
                               appst=true;
                           }
                             adbwc.setAppointmentDetailList(appointmentDetailList); 
                            
                            adWorkerList.add(adbwc);
                        }

                    
                    
                    }
                    
                    List<StatusCount> statusCountList = new ArrayList<StatusCount>();
                    if (sDT != null && eDT != null) {
                        
                        Date nextStartDate = sDT;
                        Date nextEndDate = nextStartDate;
                        int index = 1;
                        List<String> statusList = new ArrayList<>();
                        statusList.add(GigflexConstants.JOBSTATUS_ASSIGNED);                                
                        statusList.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                            
                        List<String> pendingStatusList = new ArrayList<>();
                        pendingStatusList.add(GigflexConstants.JOBSTATUS_PENDING); 
                        
                        while(nextStartDate.before(eDT))
                        {
//                            String dateTimeFormat = dateformat.trim()+" "+timeformat.trim();
                            String strStartDate = GigflexDateUtil.convertDateToString(nextStartDate, GigflexConstants.YYYY_MM_DD_HH_MM);
                            StatusCount statusCount =new StatusCount();                          

                            Calendar caleEnd = Calendar.getInstance();
                            caleEnd.setTime(nextEndDate);
                            caleEnd.add(Calendar.HOUR_OF_DAY, GigflexConstants.STATUS_COUNT_INTERVAL_IN_HOURS);                           
                            nextEndDate = caleEnd.getTime();    
                            if(nextEndDate.after(eDT))
                            {
                                nextEndDate=eDT;
                            }
                            
                            String strEndDate = GigflexDateUtil.convertDateToString(nextEndDate, GigflexConstants.YYYY_MM_DD_HH_MM);
                            
                            List<Object>  objList = jobsRepository.getAllJobStatusDetailByOrgCode(organizationCode, status, nextStartDate, nextEndDate);
                            int countStatus = 0;

                            if(objList != null && objList.size() > 0)
                            {
                                countStatus = objList.size();
                            }
                            
                            List<Object> acceptedAndAssignedList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, statusList, nextStartDate, nextEndDate);
                                
                            int countAcceptedAssigned = 0;
                            int countPending = 0;
                                
                            if(acceptedAndAssignedList != null && acceptedAndAssignedList.size() > 0)
                            {
                                countAcceptedAssigned = acceptedAndAssignedList.size();
                            }

                            List<Object> pendingList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, pendingStatusList, nextStartDate, nextEndDate);


                            if(pendingList != null && pendingList.size() > 0 )
                            {
                                countPending = pendingList.size();
                            }

                            if( countAcceptedAssigned == 0 && countPending == 0)
                            {
                                statusCount.setFullfillmentRatio(null); 
                            }
                            else
                            {
                                double sum = countAcceptedAssigned+countPending;
                                double persentage = (countAcceptedAssigned)*100/(sum);
                                statusCount.setFullfillmentRatio(persentage); 
                            }
                            
                          
                            statusCount.setDateFormat(GigflexConstants.YYYY_MM_DD); 
                            statusCount.setStatusCount(countStatus);
                            Date startDateTimestamp = GigflexDateUtil.getGMTtoLocationDate(nextStartDate, timezone, GigflexConstants.YYYY_MM_DD_HH_MM);
                            strStartDate = GigflexDateUtil.convertDateToString(startDateTimestamp, GigflexConstants.YYYY_MM_DD_HH_MM);
                            statusCount.setStartDateTimestamp(startDateTimestamp);
                            Date endDateTimestamp = GigflexDateUtil.getGMTtoLocationDate(nextEndDate,timezone,GigflexConstants.YYYY_MM_DD_HH_MM);
                            strEndDate = GigflexDateUtil.convertDateToString(endDateTimestamp, GigflexConstants.YYYY_MM_DD_HH_MM);
                            statusCount.setEndDateTimestamp(endDateTimestamp);
                            statusCount.setStartDate(strStartDate);
                            statusCount.setEndDate(strEndDate); 
                            statusCount.setIndexNumber(index); 

                            Calendar cal = Calendar.getInstance();
                            cal.setTime(nextStartDate);
                            cal.add(Calendar.HOUR_OF_DAY, GigflexConstants.STATUS_COUNT_INTERVAL_IN_HOURS);                           
                            nextStartDate = cal.getTime();
                            statusCountList.add(statusCount);
                            
                            index++;
                      } 
                    }                       
                    
                    AppoaintmentDetailAndStatusCountRes adsRes = new AppoaintmentDetailAndStatusCountRes(); 
                    adsRes.setAppointmentDetailByWorkerCodeList(adWorkerList);  
                    adsRes.setStatusCountList(statusCountList);                     
                    
                    if ( (adWorkerList != null && adWorkerList.size() > 0) || (statusCountList.size() > 0) ) {
                        if(msg.equalsIgnoreCase("Success") && appst!=true)
                        {
                            msg="No appointment is present";
                        }
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", msg);
                        jsonobj.put("timestamp", new Date());
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(adsRes);
                        jsonobj.put("data", new JSONObject(Detail));                        
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Organization does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            

            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;
    }

    
    @Override
    public String getAppointmentDetailOfTechnicianByOrganizationCodeForTest(String organizationCode, List<String> status, String startDT, String endDT) {
        
          String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
       
                Organization org = orgDao.findByOrganizationCode(organizationCode);
                if (org != null && org.getId() > 0 ) {
                   
                    String timezone = null;
                    Date sDT = null;
                    Date eDT = null;  
                    String sDatestr="";
                    String msg="Success";
                    Boolean appst=false;
                    Date sDTPeriod = null;
                    Date eDTPeriod = null;
                    String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                    {
                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                    } 
                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    int day=0;
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                        if (startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                            try{
                            Date stDate=GigflexDateUtil.convertStringToDate(startDT, GigflexConstants.YYYY_MM_DD);
                            if(stDate!=null)
                            {
                            Calendar cal = Calendar.getInstance();
                            cal.setTime(stDate);
                            String lookingForValue = "ORG_WORKING_DAY_";
                            day=cal.get(Calendar.DAY_OF_WEEK);
                            lookingForValue+=day;
                            String dayVal=null;
                            try
                            {
                                Object clazz = new GigflexConstants();
                                Field field = clazz.getClass().getField(lookingForValue);
                                dayVal=(String) field.get(clazz);
                            }
                            catch(Exception e1)
                            {
                                e1.printStackTrace();
                            }
                            if(dayVal==null || dayVal.isEmpty())
                            {
//                                GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                "Please set working days from setting.");
//                                return derr.toString();
                                msg="Please set working days from setting.";
                            }
                            String dayValSt =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, dayVal);
                            if(dayValSt==null)
                            {
//                                GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                "Please set working days from setting.");
//                                return derr.toString();
                                msg="Please set working days from setting.";
                            }
                            else if(!(dayValSt.equalsIgnoreCase("true")))
                            {
//                                GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                GigflexDateUtil.getNameFromDayCode(day)+" is off day.");
//                                return derr.toString();
                                msg=GigflexDateUtil.getNameFromDayCode(day)+" is off day.";
                            }
                            
                            HashMap <Date,Boolean> holidayOrgMap=new HashMap<>(); 
       try{
         
       String orgHoliday =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider,organizationCode, GigflexConstants.ORG_SPEC_NON_WORKING_DAYS);
       if(orgHoliday!=null && orgHoliday.trim().length()>0)
       {
           String holiarr[]=orgHoliday.split(",");
           for(int j=0;j<holiarr.length;j++)
           {
               String str=holiarr[j];
               if(str!=null)
               {
                   Date hdt=GigflexDateUtil.convertStringToDate(str.trim(), GigflexConstants.DD_MMMM_YYYY);
                   if(hdt!=null)
                   {
                       holidayOrgMap.put(hdt, Boolean.TRUE);
                   }
               }
           }
       }
             
       }
       catch(Exception eee)
       {
           eee.printStackTrace();
       }
            if(holidayOrgMap.containsKey(stDate)) 
            {
//                 GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                startDT+" is non working date.");
//                                return derr.toString();
                msg=startDT+" is non working date.";
            }
                            
                            String orgst =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.ORG_WORKING_TIME_START);
                            String orgend =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.ORG_WORKING_TIME_END);
                            if(orgst==null || orgend==null || orgst.trim().length()==0 ||  orgend.trim().length()==0 )
                            {
//                                 GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                "Please set working time from setting.");
//                                return derr.toString();
                                msg="Please set working time from setting.";
                            }
                            orgst=orgst.trim().length()==5?orgst.trim()+":00":orgst.trim();
                            orgend=orgend.trim().length()==5?orgend.trim()+":00":orgend.trim();
                            sDatestr=startDT.trim();
                            startDT = startDT + " "+orgst;
                            endDT = endDT + " "+orgend;
                            
                            sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);                           
                            if (sDT == null || eDT == null) {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Date conversion has been failed.");
                                return derr.toString();
                            }
                            sDTPeriod=GigflexDateUtil.convertStringToDate(startDT, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDTPeriod=GigflexDateUtil.convertStringToDate(endDT, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            }
                            else
                            {
                                 GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                                return derr.toString();
                            }
                            }
                            catch(Exception ex)
                            {
                                ex.printStackTrace();
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                                return derr.toString();
                            }
                        }
                    }
                    
                    if (sDT == null || eDT == null) {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                        return derr.toString();
                    }                    
                 
                    
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_REJECTED);
                        stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                        stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                        stlst.add(GigflexConstants.JOBSTATUS_PENDING);
                        status = stlst;                        
                    }
                    
                    List<AppointmentDetailByWorkerCode> adWorkerList = new ArrayList<AppointmentDetailByWorkerCode>();
                    List<Worker>  wkList = workerApprovalStatusRepository.getAllApprovedWorkerOnlyByOrgCode(organizationCode);
                    if(wkList != null && wkList.size() > 0)
                    {
                        
                        for(Worker worker : wkList)
                        {
                            AppointmentDetailByWorkerCode adbwc = new AppointmentDetailByWorkerCode();
                            adbwc.setWorkerCode(worker.getWorkerCode());  
                            adbwc.setName(worker.getName());  
                            adbwc.setEmail(worker.getEmail());  
                            adbwc.setWorkerLogo(worker.getWorkerLogo()); 
                            String workerCode =worker.getWorkerCode();
                            
//                            WorkerHoursOfOperationRes hopres=null;
//                            WorkerHoursOfOperation whop=workerHoursofOperationDao.getHoursByWorkerCodeAndDayCode(workerCode, day);
//                            if(whop!=null && whop.getId()>0 && whop.getFromTime()!=null && whop.getFromTime().trim().length()>0 && whop.getToTime()!=null && whop.getToTime().trim().length()>0)
//                            {
//                                try{
//                                    String sdt=sDatestr+" "+whop.getFromTime().trim();
//                                    String edt=sDatestr+" "+whop.getToTime().trim();
//                                    Date sdtinDate=GigflexDateUtil.convertStringToDate(sdt, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
//                                    Date edtinDate=GigflexDateUtil.convertStringToDate(edt, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
//                                    if(sdtinDate.before(sDTPeriod))
//                                    {
//                                        sdtinDate=sDTPeriod;
//                                    }
//                                    if(edtinDate.after(eDTPeriod))
//                                    {
//                                        edtinDate=eDTPeriod;
//                                    }
//                                    sdt=GigflexDateUtil.convertDateToString(sdtinDate, dtFormat);
//                                    edt=GigflexDateUtil.convertDateToString(edtinDate, dtFormat);
//                                    hopres=new WorkerHoursOfOperationRes();
//                                    hopres.setDayCode(whop.getDayCode());
//                                    hopres.setEndDateTime(edt);
//                                    hopres.setFromTime(whop.getFromTime());
//                                    hopres.setStartDateTime(sdt);
//                                    hopres.setToTime(whop.getToTime());
//                                    hopres.setWorkerhoursOfOperationCode(whop.getWorkerhoursOfOperationCode());
//                                    hopres.setDateFormat(dateformat);
//                                    hopres.setTimeFormat(timeformat); 
//                                }
//                                catch(Exception ee)
//                                {
//                                    ee.printStackTrace();
//                                }
//                            }
//                            adbwc.setWorkerHoursOfOperation(hopres);
//                            List<WorkerTimeOff> wtoLst=workerTimeOffDao.getTimeOffByWorkerCodeAndBetweenDateTimeStamp(workerCode, sDT, eDT);
//                            adbwc.setWorkerTimeOffList(wtoLst);
                            List<AppointmentDetail> appointmentDetailList = new ArrayList<>();
//                            if(hopres!=null)
//                            {
                            List<Object>  objlst = jobsRepository.getAppointmentDetailOfTechnicianByOrgCodeAndWorkerCodeForTest(organizationCode, status, sDT, eDT,workerCode);

                            if (objlst != null && objlst.size() > 0) {

                                           
                              
//                            HashMap <String,PatientDetails> patientMap=new HashMap<>();
//                            HashMap <String,String> startDatePatientCodeMap=new HashMap<>();
                            for (int i = 0; i < objlst.size(); i++) {
                                Object[] arr = (Object[]) objlst.get(i);
                                if (arr.length >= 5) {

                                AppointmentDetail adRes = new AppointmentDetail();
                                adRes.setWorkerName( worker.getName());
                                adRes.setWorkerCode(workerCode);
                                Integer drivingTimeInSecond=null;
                                Double distance=null;
                                String drivingStartTime = "";
                                String distanceText = "";
                                String durationText = "";
                                String conStartDt = "";
                                String conEndTime="";
                                Jobs jobData = (Jobs) arr[0];
                                JobsDuration jdData= (JobsDuration) arr[1];
                                JobsAssignToWorker jawData = (JobsAssignToWorker) arr[2];
                                PatientDetails pDetail = (PatientDetails) arr[3];
                                ProcedureMaster pm = (ProcedureMaster) arr[4];
                                
                                Date timestampStartTime =null;
                                Date timestampEndTime = null;
                                Boolean ispartial=false;
                                 if(pDetail!=null && pDetail.getId()>0)
                                        {
                                            adRes.setPatientName(pDetail.getPatientName());
                                            adRes.setPatientCode(pDetail.getPatientCode());
                                            adRes.setPatientAddress(pDetail.getPatientAddress());
                                            adRes.setPhoneNumber(pDetail.getPhoneNumber());
                                            adRes.setpCountryCode(pDetail.getpCountryCode());
                                            
                                        }
                                
                               if(jobData!=null && jobData.getProcedureCode()!=null)
                               {
//                                   ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(jobData.getProcedureCode());
                                    
                                    if( pm != null && pm.getProcedureIcon()!=null)
                                    {
                                        adRes.setProcedureIcon(pm.getProcedureIcon()); 
                                    }
                               }
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(jdData.getStartTime()!=null){
                                         Date startDate = jdData.getStartTime();
                                         timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                         if(timestampStartTime.before(sDTPeriod))
                                         {
                                             timestampStartTime=sDTPeriod;
                                             ispartial=true;
                                         }
                                         conStartDt=GigflexDateUtil.convertDateToString(timestampStartTime, dtFormat);
                                        }
                                        if(jdData.getEndTime()!=null){
                                            Date endDate = jdData.getEndTime();
                                            timestampEndTime = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                            if(timestampEndTime.after(eDTPeriod))
                                         {
                                             timestampEndTime=eDTPeriod;
                                             ispartial=true;
                                         }
                                            conEndTime=GigflexDateUtil.convertDateToString(timestampEndTime, dtFormat);
                                         }
                                    }
                                    if(jawData!=null && jawData.getId()>0 && jawData.getDistance()!=null && jawData.getDrivingTimeInSec()!=null)
                                    {
                                         distance =jawData.getDistance();
                                                    
                                                  drivingTimeInSecond= jawData.getDrivingTimeInSec();
                                                  if(drivingTimeInSecond!=null)
                                                  {
                                                      int hr = drivingTimeInSecond / 60;
                                                      int mn = hr % 60;
                                                      hr = hr / 60;
                                                      if (hr > 0) {
                                                          durationText = hr + " hours ";
                                                      }
                                                      if (mn > 0) {
                                                          durationText += mn + " minutes";
                                                      }
                                                  }
                                                  if(jawData.getDistance()!=null)
                                                  {
                                                  distanceText=String.format("%.2f", jawData.getDistance())+" Miles";
                                                  }
                                    }
                                    if(drivingTimeInSecond!=null && ispartial==false)
                                    {
                                        int min=drivingTimeInSecond/60;
                                        Calendar calmin = Calendar.getInstance();
                                        calmin.setTime(timestampStartTime);
                                        calmin.add(Calendar.MINUTE, -min);
                                        Date drvdt=calmin.getTime();
                                        drivingStartTime=GigflexDateUtil.convertDateToString(drvdt, dtFormat);
                                    }
                                adRes.setDistanceText(distanceText);
                                adRes.setDurationText(durationText);
                                adRes.setDistance(distance);
                                adRes.setDrivingTimeInSecond(drivingTimeInSecond);
                                adRes.setDrivingStartTime(drivingStartTime);
                                adRes.setDateFormat(dateformat);
                                adRes.setTimeFormat(timeformat); 
                                adRes.setIsPartial(ispartial);
                                adRes.setJobEndDate(conEndTime);
                                adRes.setJobStartDate(conStartDt);
                                adRes.setTimestampJobsStartTime(timestampStartTime);
                                adRes.setTimestampJobsEndTime(timestampEndTime); 
                                adRes.setJobsCode(jdData.getJobsCode());
                                adRes.setJobsDurationCode(jdData.getJobsDurationCode()); 
                                adRes.setJobName(jdData.getJobName()); 

                                adRes.setStatus(jawData.getStatus());
                           
                                appointmentDetailList.add(adRes);

                                }
                               }                            
                            }
                           // }
                           if(appointmentDetailList!=null && appointmentDetailList.size()>0)
                           {
                               appst=true;
                           }
                             adbwc.setAppointmentDetailList(appointmentDetailList); 
                            
                            adWorkerList.add(adbwc);
                        }

                    
                    
                    }
                    
                    List<StatusCount> statusCountList = new ArrayList<StatusCount>();
                    if (sDT != null && eDT != null) {
                        
                        Date nextStartDate = sDT;
                        Date nextEndDate = nextStartDate;
                        int index = 1;
                        List<String> statusList = new ArrayList<>();
                        statusList.add(GigflexConstants.JOBSTATUS_ASSIGNED);                                
                        statusList.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                            
                        List<String> pendingStatusList = new ArrayList<>();
                        pendingStatusList.add(GigflexConstants.JOBSTATUS_PENDING); 
                        
                        while(nextStartDate.before(eDT))
                        {
//                            String dateTimeFormat = dateformat.trim()+" "+timeformat.trim();
                            String strStartDate = GigflexDateUtil.convertDateToString(nextStartDate, GigflexConstants.YYYY_MM_DD_HH_MM);
                            StatusCount statusCount =new StatusCount();                          

                            Calendar caleEnd = Calendar.getInstance();
                            caleEnd.setTime(nextEndDate);
                            caleEnd.add(Calendar.HOUR_OF_DAY, GigflexConstants.STATUS_COUNT_INTERVAL_IN_HOURS);                           
                            nextEndDate = caleEnd.getTime();    
                            if(nextEndDate.after(eDT))
                            {
                                nextEndDate=eDT;
                            }
                            
                            String strEndDate = GigflexDateUtil.convertDateToString(nextEndDate, GigflexConstants.YYYY_MM_DD_HH_MM);
                            
                            List<Object>  objList = jobsRepository.getAllJobStatusDetailByOrgCode(organizationCode, status, nextStartDate, nextEndDate);
                            int countStatus = 0;

                            if(objList != null && objList.size() > 0)
                            {
                                countStatus = objList.size();
                            }
                            
                            List<Object> acceptedAndAssignedList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, statusList, nextStartDate, nextEndDate);
                                
                            int countAcceptedAssigned = 0;
                            int countPending = 0;
                                
                            if(acceptedAndAssignedList != null && acceptedAndAssignedList.size() > 0)
                            {
                                countAcceptedAssigned = acceptedAndAssignedList.size();
                            }

                            List<Object> pendingList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, pendingStatusList, nextStartDate, nextEndDate);


                            if(pendingList != null && pendingList.size() > 0 )
                            {
                                countPending = pendingList.size();
                            }

                            if( countAcceptedAssigned == 0 && countPending == 0)
                            {
                                statusCount.setFullfillmentRatio(null); 
                            }
                            else
                            {
                                double sum = countAcceptedAssigned+countPending;
                                double persentage = (countAcceptedAssigned)*100/(sum);
                                statusCount.setFullfillmentRatio(persentage); 
                            }
                            
                          
                            statusCount.setDateFormat(GigflexConstants.YYYY_MM_DD); 
                            statusCount.setStatusCount(countStatus);
                            Date startDateTimestamp = GigflexDateUtil.getGMTtoLocationDate(nextStartDate, timezone, GigflexConstants.YYYY_MM_DD_HH_MM);
                            strStartDate = GigflexDateUtil.convertDateToString(startDateTimestamp, GigflexConstants.YYYY_MM_DD_HH_MM);
                            statusCount.setStartDateTimestamp(startDateTimestamp);
                            Date endDateTimestamp = GigflexDateUtil.getGMTtoLocationDate(nextEndDate,timezone,GigflexConstants.YYYY_MM_DD_HH_MM);
                            strEndDate = GigflexDateUtil.convertDateToString(endDateTimestamp, GigflexConstants.YYYY_MM_DD_HH_MM);
                            statusCount.setEndDateTimestamp(endDateTimestamp);
                            statusCount.setStartDate(strStartDate);
                            statusCount.setEndDate(strEndDate); 
                            statusCount.setIndexNumber(index); 

                            Calendar cal = Calendar.getInstance();
                            cal.setTime(nextStartDate);
                            cal.add(Calendar.HOUR_OF_DAY, GigflexConstants.STATUS_COUNT_INTERVAL_IN_HOURS);                           
                            nextStartDate = cal.getTime();
                            statusCountList.add(statusCount);
                            
                            index++;
                      } 
                    }                       
                    
                    AppoaintmentDetailAndStatusCountRes adsRes = new AppoaintmentDetailAndStatusCountRes(); 
                    adsRes.setAppointmentDetailByWorkerCodeList(adWorkerList);  
                    adsRes.setStatusCountList(statusCountList);                     
                    
                    if ( (adWorkerList != null && adWorkerList.size() > 0) || (statusCountList.size() > 0) ) {
                        if(msg.equalsIgnoreCase("Success") && appst!=true)
                        {
                            msg="No appointment is present";
                        }
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", msg);
                        jsonobj.put("timestamp", new Date());
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(adsRes);
                        jsonobj.put("data", new JSONObject(Detail));                        
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Organization does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            

            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;
    }
    
    
    
    @Override
    public String getAllJobsByOrganizationCodeWithFilterDateTime(String organizationCode, List<String> status, String startDT, String endDT) {
        
        
         String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
       
                Organization org = orgDao.findByOrganizationCode(organizationCode);
                if (org != null && org.getId() > 0 ) {
                   
                    String timezone = null;
                    Date sDT = null;
                    Date eDT = null;
                     
                    String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);

                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                        if (startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                            
                            sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            if (sDT == null || eDT == null) {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Date conversion has been failed.");
                                return derr.toString();
                            }
                          
                        }
                    }
                    
                    
                    
                    
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_REJECTED);
                        stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                        stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                        stlst.add(GigflexConstants.JOBSTATUS_PENDING);
                        status = stlst;                        
                    }

                    List<Object> objlst = null;
                   
                     objlst = jobsRepository.getAllJobsByOrganizationCodeWithFilterByPageForDist(organizationCode, status, sDT, eDT);
                        
                    

                HashMap <String,Worker> workerMap=new HashMap<>();
                HashMap <String,PatientDetails> patientMap=new HashMap<>();
                
                    
                    List<AppointmentDetail> maplst = new ArrayList<AppointmentDetail>();
                    if (objlst != null && objlst.size() > 0) {
                        
                        
                       
                        if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                        {
                            dtFormat=dateformat.trim()+" "+timeformat.trim();
                        }                

                        for (int i = 0; i < objlst.size(); i++) {
                            Object[] arr = (Object[]) objlst.get(i);
                            if (arr.length >= 3) {

                                AppointmentDetail jaRes = new AppointmentDetail();
                                String conStartDt = "";
                                String conEndTime="";
                                Jobs jobData = (Jobs) arr[0];
                                JobsDuration jdData= (JobsDuration) arr[1];
                                JobsAssignToWorker jawData = (JobsAssignToWorker) arr[2];
                                Date timestampStartTime =null;
                                Date timestampEndTime = null;
                                if(jawData!=null && jawData.getWorkerCode()!=null)
                            {
                                if(!workerMap.containsKey(jawData.getWorkerCode()))
                                {
                                    Worker wkr=workerRepository.getWorkerdetailByworkerCode(jawData.getWorkerCode());
                                    if(wkr!=null && wkr.getId()>0)
                                    {
                                        workerMap.put(jawData.getWorkerCode(), wkr);
                                    }
                                }
                            }
                            if(!patientMap.containsKey(jobData.getPatientCode()))
                            {
                            PatientDetails pd = patientDao.getPatientDetailsBypatientCode(jobData.getPatientCode());
                            if(pd!=null && pd.getId()>0)
                            {
                                patientMap.put(jobData.getPatientCode(), pd);
                            }
                            }
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(jdData.getStartTime()!=null){
                                         Date startDate = jdData.getStartTime();
                                         timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                         conStartDt=GigflexDateUtil.convertDateToString(timestampStartTime, dtFormat);
                                        }
                                        if(jdData.getEndTime()!=null){
                                            Date endDate = jdData.getEndTime();
                                            timestampEndTime = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                            conEndTime=GigflexDateUtil.convertDateToString(timestampEndTime, dtFormat);
                                         }
                                    }
                                    
                                jaRes.setDateFormat(dateformat);
                                jaRes.setTimeFormat(timeformat); 
                                
                                jaRes.setJobName(jdData.getJobName());
                                jaRes.setJobEndDate(conEndTime);
                                jaRes.setJobStartDate(conStartDt);
                                jaRes.setTimestampJobsStartTime(timestampStartTime);
                                jaRes.setTimestampJobsEndTime(timestampEndTime); 
                                jaRes.setJobsCode(jdData.getJobsCode());
                                jaRes.setJobsDurationCode(jdData.getJobsDurationCode());
                                if(jobData.getPatientCode() != null)
                                {
                                    jaRes.setPatientCode(jobData.getPatientCode());
                                    if (patientMap.containsKey(jobData.getPatientCode())) {
                                        PatientDetails patientDetails = patientMap.get(jobData.getPatientCode());

                                        if (patientDetails != null) {

                                            jaRes.setPatientName(patientDetails.getPatientName());
                                        } 
                                    }
                                }
                                
                                
                                if(jobData.getProcedureCode() != null)
                                {
                                    ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(jobData.getProcedureCode());
                                    
                                    if( pm != null )
                                    {
                                        jaRes.setProcedureIcon(pm.getProcedureIcon()); 
                                    }
                                }
                                
                                if(jawData!=null)
                                {
                                jaRes.setStatus(jawData.getStatus());
                                if(jawData.getWorkerCode() != null)
                                {
                                    jaRes.setWorkerCode(jawData.getWorkerCode());
                                    if (workerMap.containsKey(jawData.getWorkerCode())) {
                                        Worker worker = workerMap.get(jawData.getWorkerCode());
                                        if (worker != null) {
                                            jaRes.setWorkerName(worker.getName());
                                        } 
                                    }
                                }
                                }
                                                                                            
                                
                                                             
                                maplst.add(jaRes);
                            }
                        }
                    }
                    
                    
                    
                    
                    if ( maplst != null && maplst.size() > 0 ) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(maplst);
                        jsonobj.put("data", new JSONArray(Detail));                        
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Organization does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            

            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;

    
    }

    @Override
    public String getDistanceCoveredByTechnician(String workerCode, String stratDT, String endDT) {
        
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
       
                Worker worker = workerRepository.findByWorkerCode(workerCode);
                if(worker!=null && worker.getId()>0)
                {
                
                Date sDT = null;
                Date eDT = null;
                 String timezoneCode = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician,workerCode , GigflexConstants.TimeZone);
                            String timezone = null;
                            TimeZoneDetail tzd = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                            if (tzd != null && tzd.getId() > 0) {
                                timezone = tzd.getTimeZoneName();
                            }
                            String dtFormat = GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                            String dateformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.DATEFORMAT);
                            String timeformat = GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareTechnician, workerCode, GigflexConstants.TIMEFORMAT);
                            if (dateformat != null && dateformat.trim().length() > 0 && timeformat != null && timeformat.trim().length() > 0) {
                                dtFormat = dateformat.trim() + " " + timeformat.trim();
                            }
                if (stratDT != null && stratDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                    stratDT = stratDT + " 00:00:00";
                    endDT = endDT + " 23:59:59";

                    //Date sd = GigflexDateUtil.getGMTtoLocationDate(sDT,timezone, GigflexConstants.dateFormatterForView);
                    //sDT = GigflexDateUtil.convertStringToDate(stratDT.trim(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    //eDT = GigflexDateUtil.convertStringToDate(endDT.trim(), GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    sDT = GigflexDateUtil.convertStringDateToGMT(stratDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    if (sDT == null || eDT == null) {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                        return derr.toString();
                    }
                    
                }
                List<Object> objlstCheck = null;
               
                    List<String> stlst = new ArrayList<String>();
                    stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                    stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                    stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                    stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                    stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                    stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                    stlst.add(GigflexConstants.JOBSTATUS_PENDING);
                    stlst.add(GigflexConstants.JOBSTATUS_REJECTED);
                    
               

                List<Object> objlst = null;
               
             

                objlst = jobsAssignToWorkerRepository.getAllJobsByWorkerCodeWithFilterForDist(workerCode, stlst, sDT, eDT);
                   
                HashMap <String,PatientDetails> patientMap=new HashMap<>();
                HashMap <String,Double> jobDurationDistanceMap=new HashMap<>();
                HashMap <String,String> startDatePatientCodeMap=new HashMap<>();
                
                List<CoveredDistanceRes> awslst = new ArrayList<CoveredDistanceRes>();
                if (objlst != null && objlst.size() > 0) {
                    for (Object object : objlst) {
                        CoveredDistanceRes aws = new CoveredDistanceRes();
                        Object[] obj = (Object[]) object;
                        if (obj.length >= 3) {
                            Jobs j = (Jobs) obj[0];
                            JobsDuration jd = (JobsDuration) obj[1];
                            
//                            

                            if(!patientMap.containsKey(j.getPatientCode()))
                            {
                            PatientDetails pd = patientDao.getPatientDetailsBypatientCode(j.getPatientCode());
                            if(pd!=null && pd.getId()>0)
                            {
                                patientMap.put(j.getPatientCode(), pd);
                            }
                            }
                            if (timezone != null && timezone.length() > 0) {
                                Date startDate = jd.getStartTime();
                                startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                String startDt = GigflexDateUtil.convertDateToString(startDate, GigflexConstants.YYYY_MM_DD);
                                if (!startDatePatientCodeMap.containsKey(startDt)) {
                                    PatientDetails pdSource =  patientMap.get(j.getPatientCode());
                                     if(pdSource!=null && pdSource.getId()>0)
                                   {
                                        Double distance = distance(worker.getLatitude(), worker.getLongitude(),pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
                                        jobDurationDistanceMap.put(jd.getJobsDurationCode(), distance);
                                   }
                                    startDatePatientCodeMap.put(startDt, j.getPatientCode());
                                } else {
                                   String pcode=startDatePatientCodeMap.get(startDt);
                                   if(pcode!=null)
                                   {
                                   PatientDetails pd =patientMap.get(pcode);
                                   if(pd!=null && pd.getId()>0)
                                   {
                                     PatientDetails pdSource =  patientMap.get(j.getPatientCode());
                                     if(pdSource!=null && pdSource.getId()>0)
                                   {
                                       Double distance = distance(pd.getPatientLatitude(), pd.getPatientLongitude(),pdSource.getPatientLatitude(), pdSource.getPatientLongitude());
                                        jobDurationDistanceMap.put(jd.getJobsDurationCode(), distance);
                                   }
                                   }
                                   }
                                    startDatePatientCodeMap.put(startDt, j.getPatientCode());
                                }
                            }

                            String startDt = "";
                            String endDt = "";
                            Date sdt = null;
                            Date edt = null;
                            if (timezone != null && timezone.length() > 0) {
                                Date startDate = jd.getStartTime();
                                startDate = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                sdt = startDate;
                                startDt = GigflexDateUtil.convertDateToString(startDate, dtFormat);
                                Date endDate = jd.getEndTime();
                                endDate = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                edt = endDate;
                                endDt = GigflexDateUtil.convertDateToString(endDate, dtFormat);
                            }
                            aws.setEndTime(endDt);
                            aws.setEndTimeStamp(edt);
                            aws.setJobsDurationCode(jd.getJobsDurationCode());
                            aws.setStartTime(startDt);
                            aws.setStartTimeStamp(sdt);
                            if (j.getProcedureCode() != null && j.getProcedureCode().length() > 0) {
                                ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(j.getProcedureCode());
                              
                            }
                            

                            aws.setPatientCode(j.getPatientCode());
                            PatientDetails pd =  patientMap.get(j.getPatientCode());
                           
//                            if (j.getPatientCode() != null && j.getPatientCode().length() > 0) {
//                                PatientDetails pd = patientDao.getPatientDetailsBypatientCode(j.getPatientCode());
//                                aws.setPatientDetails(pd);
//                            }
                            
                            awslst.add(aws);
                        }
                    }
                    if (awslst != null && awslst.size() > 0) {
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Success");
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(awslst);
                        jsonobj.put("data", new JSONArray(Detail));
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("timestamp", new Date());
                        jsonobj.put("message", "Records not found.");
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Records not found.");
                }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("timestamp", new Date());
                    jsonobj.put("message", "Worker not found.");
                }
            
            res = jsonobj.toString();
        } catch (JSONException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception is occurred.");
            res = derr.toString();
            ex.printStackTrace();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();

        }
        return res;

    }

    @Override
    public String getAppointmentDetailOfTechnicianByOrganizationCodeByPage(String organizationCode, List<String> status, String startDT, String endDT, int page, int limit) {
        
        
          String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
       if (limit > 0) {
            Pageable pageableRequest = PageRequest.of(page, limit);
                Organization org = orgDao.findByOrganizationCode(organizationCode);
                if (org != null && org.getId() > 0 ) {
                   int count=0;
                    String timezone = null;
                    Date sDT = null;
                    Date eDT = null;  
                    String sDatestr="";
                    String msg="Success";
                    Boolean appst=false;
                    Date sDTPeriod = null;
                    Date eDTPeriod = null;
                    String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TIMEFORMAT);
                    if(dateformat!=null && dateformat.trim().length()>0 && timeformat!=null && timeformat.trim().length()>0)
                    {
                        dtFormat=dateformat.trim()+" "+timeformat.trim();
                    } 
                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    int day=0;
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                        if (startDT != null && startDT.trim().length() > 0 && endDT != null && endDT.trim().length() > 0) {
                            try{
                            Date stDate=GigflexDateUtil.convertStringToDate(startDT, GigflexConstants.YYYY_MM_DD);
                            if(stDate!=null)
                            {
                            Calendar cal = Calendar.getInstance();
                            cal.setTime(stDate);
                            String lookingForValue = "ORG_WORKING_DAY_";
                            day=cal.get(Calendar.DAY_OF_WEEK);
                            lookingForValue+=day;
                            String dayVal=null;
                            try
                            {
                                Object clazz = new GigflexConstants();
                                Field field = clazz.getClass().getField(lookingForValue);
                                dayVal=(String) field.get(clazz);
                            }
                            catch(Exception e1)
                            {
                                e1.printStackTrace();
                            }
                            if(dayVal==null || dayVal.isEmpty())
                            {
//                                GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                "Please set working days from setting.");
//                                return derr.toString();
                                msg="Please set working days from setting.";
                            }
                            String dayValSt =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, dayVal);
                            if(dayValSt==null)
                            {
//                                GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                "Please set working days from setting.");
//                                return derr.toString();
                                msg="Please set working days from setting.";
                            }
                            else if(!(dayValSt.equalsIgnoreCase("true")))
                            {
//                                GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                GigflexDateUtil.getNameFromDayCode(day)+" is off day.");
//                                return derr.toString();
                                msg=GigflexDateUtil.getNameFromDayCode(day)+" is off day.";
                            }
                            
                            HashMap <Date,Boolean> holidayOrgMap=new HashMap<>(); 
       try{
         
       String orgHoliday =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider,organizationCode, GigflexConstants.ORG_SPEC_NON_WORKING_DAYS);
       if(orgHoliday!=null && orgHoliday.trim().length()>0)
       {
           String holiarr[]=orgHoliday.split(",");
           for(int j=0;j<holiarr.length;j++)
           {
               String str=holiarr[j];
               if(str!=null)
               {
                   Date hdt=GigflexDateUtil.convertStringToDate(str.trim(), GigflexConstants.DD_MMMM_YYYY);
                   if(hdt!=null)
                   {
                       holidayOrgMap.put(hdt, Boolean.TRUE);
                   }
               }
           }
       }
             
       }
       catch(Exception eee)
       {
           eee.printStackTrace();
       }
            if(holidayOrgMap.containsKey(stDate)) 
            {
//                 GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                startDT+" is non working date.");
//                                return derr.toString();
                msg=startDT+" is non working date.";
            }
                            
                            String orgst =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.ORG_WORKING_TIME_START);
                            String orgend =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, organizationCode, GigflexConstants.ORG_WORKING_TIME_END);
                            if(orgst==null || orgend==null || orgst.trim().length()==0 ||  orgend.trim().length()==0 )
                            {
//                                 GigflexResponse derr = new GigflexResponse(400, new Date(),
//                                "Please set working time from setting.");
//                                return derr.toString();
                                msg="Please set working time from setting.";
                            }
                            orgst=orgst.trim().length()==5?orgst.trim()+":00":orgst.trim();
                            orgend=orgend.trim().length()==5?orgend.trim()+":00":orgend.trim();
                            sDatestr=startDT.trim();
                            startDT = startDT + " "+orgst;
                            endDT = endDT + " "+orgend;
                            
                            sDT = GigflexDateUtil.convertStringDateToGMT(startDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDT = GigflexDateUtil.convertStringDateToGMT(endDT, timezone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);                           
                            if (sDT == null || eDT == null) {
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                        "Date conversion has been failed.");
                                return derr.toString();
                            }
                            sDTPeriod=GigflexDateUtil.convertStringToDate(startDT, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            eDTPeriod=GigflexDateUtil.convertStringToDate(endDT, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                            }
                            else
                            {
                                 GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                                return derr.toString();
                            }
                            }
                            catch(Exception ex)
                            {
                                ex.printStackTrace();
                                GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                                return derr.toString();
                            }
                        }
                    }
                    
                    if (sDT == null || eDT == null) {
                        GigflexResponse derr = new GigflexResponse(400, new Date(),
                                "Date conversion has been failed.");
                        return derr.toString();
                    }                    
                 
                    
                    if (status.size() == 1 && status.get(0).equalsIgnoreCase("all")) {
                        List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_REJECTED);
                        stlst.add(GigflexConstants.JOBSTATUS_EXPIRED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                        stlst.add(GigflexConstants.JOBSTATUS_CANCELLED);
                        stlst.add(GigflexConstants.JOBSTATUS_PENDING);
                        status = stlst;                        
                    }
                    
                    List<AppointmentDetailByWorkerCode> adWorkerList = new ArrayList<AppointmentDetailByWorkerCode>();
                    List<Worker>  wkListcnt = workerApprovalStatusRepository.getAllApprovedWorkerOnlyByOrgCode(organizationCode);
                    if(wkListcnt != null && wkListcnt.size() > 0)
                    {
                        count=wkListcnt.size();
                        List<Worker>  wkList = workerApprovalStatusRepository.getAllApprovedWorkerOnlyByOrgCode(organizationCode,pageableRequest);
                        
                        for(Worker worker : wkList)
                        {
                            AppointmentDetailByWorkerCode adbwc = new AppointmentDetailByWorkerCode();
                            adbwc.setWorkerCode(worker.getWorkerCode());  
                            adbwc.setName(worker.getName());  
                            adbwc.setEmail(worker.getEmail());  
                            adbwc.setWorkerLogo(worker.getWorkerLogo()); 
                            String workerCode =worker.getWorkerCode();
                            
//                            WorkerHoursOfOperationRes hopres=null;
//                            WorkerHoursOfOperation whop=workerHoursofOperationDao.getHoursByWorkerCodeAndDayCode(workerCode, day);
//                            if(whop!=null && whop.getId()>0 && whop.getFromTime()!=null && whop.getFromTime().trim().length()>0 && whop.getToTime()!=null && whop.getToTime().trim().length()>0)
//                            {
//                                try{
//                                    String sdt=sDatestr+" "+whop.getFromTime().trim();
//                                    String edt=sDatestr+" "+whop.getToTime().trim();
//                                    Date sdtinDate=GigflexDateUtil.convertStringToDate(sdt, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
//                                    Date edtinDate=GigflexDateUtil.convertStringToDate(edt, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
//                                    if(sdtinDate.before(sDTPeriod))
//                                    {
//                                        sdtinDate=sDTPeriod;
//                                    }
//                                    if(edtinDate.after(eDTPeriod))
//                                    {
//                                        edtinDate=eDTPeriod;
//                                    }
//                                    sdt=GigflexDateUtil.convertDateToString(sdtinDate, dtFormat);
//                                    edt=GigflexDateUtil.convertDateToString(edtinDate, dtFormat);
//                                    hopres=new WorkerHoursOfOperationRes();
//                                    hopres.setDayCode(whop.getDayCode());
//                                    hopres.setEndDateTime(edt);
//                                    hopres.setFromTime(whop.getFromTime());
//                                    hopres.setStartDateTime(sdt);
//                                    hopres.setToTime(whop.getToTime());
//                                    hopres.setWorkerhoursOfOperationCode(whop.getWorkerhoursOfOperationCode());
//                                    hopres.setDateFormat(dateformat);
//                                    hopres.setTimeFormat(timeformat); 
//                                }
//                                catch(Exception ee)
//                                {
//                                    ee.printStackTrace();
//                                }
//                            }
//                            adbwc.setWorkerHoursOfOperation(hopres);
//                            List<WorkerTimeOff> wtoLst=workerTimeOffDao.getTimeOffByWorkerCodeAndBetweenDateTimeStamp(workerCode, sDT, eDT);
//                            adbwc.setWorkerTimeOffList(wtoLst);
                            List<AppointmentDetail> appointmentDetailList = new ArrayList<>();
//                            if(hopres!=null)
//                            {
                            List<Object>  objlst = jobsRepository.getAppointmentDetailOfTechnicianByOrgCodeAndWorkerCodeForTest(organizationCode, status, sDT, eDT,workerCode);

                            if (objlst != null && objlst.size() > 0) {

                                           
                              
                           // HashMap <String,PatientDetails> patientMap=new HashMap<>();
                           // HashMap <String,String> startDatePatientCodeMap=new HashMap<>();
                            for (int i = 0; i < objlst.size(); i++) {
                                Object[] arr = (Object[]) objlst.get(i);
                                if (arr.length >= 5) {

                                AppointmentDetail adRes = new AppointmentDetail();
                                adRes.setWorkerName( worker.getName());
                                adRes.setWorkerCode(workerCode);
                                Integer drivingTimeInSecond=null;
                                Double distance=null;
                                String drivingStartTime = "";
                                String distanceText = "";
                                String durationText = "";
                                String conStartDt = "";
                                String conEndTime="";
                                
                                Jobs jobData = (Jobs) arr[0];
                                JobsDuration jdData= (JobsDuration) arr[1];
                                JobsAssignToWorker jawData = (JobsAssignToWorker) arr[2];
                                PatientDetails pDetail = (PatientDetails) arr[3];
                                ProcedureMaster pm = (ProcedureMaster) arr[4];
                                if(pDetail!=null && pDetail.getId()>0)
                                        {
                                            adRes.setPatientName(pDetail.getPatientName());
                                            adRes.setPatientCode(pDetail.getPatientCode());
                                            adRes.setPatientAddress(pDetail.getPatientAddress());
                                            adRes.setPhoneNumber(pDetail.getPhoneNumber());
                                            adRes.setpCountryCode(pDetail.getpCountryCode());
                                        }
                                Date timestampStartTime =null;
                                Date timestampEndTime = null;
                                Boolean ispartial=false;
//                                if(jobData!=null)
//                                {
//                                    if(!patientMap.containsKey(jobData.getPatientCode()))
//                                    {
////                                        PatientDetails pd = patientDao.getPatientDetailsBypatientCode(jobData.getPatientCode());
//                                        if(pDetail!=null && pDetail.getId()>0)
//                                        {
//                                            patientMap.put(jobData.getPatientCode(), pDetail);
//                                            adRes.setPatientName(pDetail.getPatientName());
//                                            adRes.setPatientCode(pDetail.getPatientCode());
//                                        }
//                                    }
//                                    else
//                                    {
//                                        PatientDetails pd = patientMap.get(jobData.getPatientCode());
//                                        if(pd!=null && pd.getId()>0)
//                                        {
//                                            adRes.setPatientName(pd.getPatientName());
//                                            adRes.setPatientCode(pd.getPatientCode());
//                                        }
//                                    }
//                                }
                               if(jobData!=null && jobData.getProcedureCode()!=null)
                               {
//                                   ProcedureMaster pm = procedureMasterDao.getProcedureMasterByProcedureCode(jobData.getProcedureCode());
                                    
                                    if( pm != null && pm.getProcedureIcon()!=null)
                                    {
                                        adRes.setProcedureIcon(pm.getProcedureIcon()); 
                                    }
                               }
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(jdData.getStartTime()!=null){
                                         Date startDate = jdData.getStartTime();
                                         timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                         if(timestampStartTime.before(sDTPeriod))
                                         {
                                             timestampStartTime=sDTPeriod;
                                             ispartial=true;
                                         }
                                         conStartDt=GigflexDateUtil.convertDateToString(timestampStartTime, dtFormat);
                                        }
                                        if(jdData.getEndTime()!=null){
                                            Date endDate = jdData.getEndTime();
                                            timestampEndTime = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                            if(timestampEndTime.after(eDTPeriod))
                                         {
                                             timestampEndTime=eDTPeriod;
                                             ispartial=true;
                                         }
                                            conEndTime=GigflexDateUtil.convertDateToString(timestampEndTime, dtFormat);
                                         }
                                    }
                                    if(jawData!=null && jawData.getId()>0 && jawData.getDistance()!=null && jawData.getDrivingTimeInSec()!=null)
                                    {
                                         distance =jawData.getDistance();
                                                    
                                                  drivingTimeInSecond= jawData.getDrivingTimeInSec();
                                                  if(drivingTimeInSecond!=null)
                                                  {
                                                      int hr = drivingTimeInSecond / 60;
                                                      int mn = hr % 60;
                                                      hr = hr / 60;
                                                      if (hr > 0) {
                                                          durationText = hr + " hours ";
                                                      }
                                                      if (mn > 0) {
                                                          durationText += mn + " minutes";
                                                      }
                                                  }
                                                  if(jawData.getDistance()!=null)
                                                  {
                                                  distanceText=String.format("%.2f", jawData.getDistance())+" Miles";
                                                  }
                                    }
                                    if(drivingTimeInSecond!=null && ispartial==false)
                                    {
                                        int min=drivingTimeInSecond/60;
                                        Calendar calmin = Calendar.getInstance();
                                        calmin.setTime(timestampStartTime);
                                        calmin.add(Calendar.MINUTE, -min);
                                        Date drvdt=calmin.getTime();
                                        drivingStartTime=GigflexDateUtil.convertDateToString(drvdt, dtFormat);
                                    }
                                adRes.setDistanceText(distanceText);
                                adRes.setDurationText(durationText);
                                adRes.setDistance(distance);
                                adRes.setDrivingTimeInSecond(drivingTimeInSecond);
                                adRes.setDrivingStartTime(drivingStartTime);
                                adRes.setDateFormat(dateformat);
                                adRes.setTimeFormat(timeformat); 
                                adRes.setIsPartial(ispartial);
                                adRes.setJobEndDate(conEndTime);
                                adRes.setJobStartDate(conStartDt);
                                adRes.setTimestampJobsStartTime(timestampStartTime);
                                adRes.setTimestampJobsEndTime(timestampEndTime); 
                                adRes.setJobsCode(jdData.getJobsCode());
                                adRes.setJobsDurationCode(jdData.getJobsDurationCode()); 
                                adRes.setJobName(jdData.getJobName()); 

                                adRes.setStatus(jawData.getStatus());
                           
                                appointmentDetailList.add(adRes);

                                }
                               }                            
                            }
                           // }
                           if(appointmentDetailList!=null && appointmentDetailList.size()>0)
                           {
                               appst=true;
                           }
                             adbwc.setAppointmentDetailList(appointmentDetailList); 
                            
                            adWorkerList.add(adbwc);
                        }

                    
                    
                    }
                    
                    List<StatusCount> statusCountList = new ArrayList<StatusCount>();
                    if (sDT != null && eDT != null) {
                        
                        Date nextStartDate = sDT;
                        Date nextEndDate = nextStartDate;
                        int index = 1;
                        List<String> statusList = new ArrayList<>();
                        statusList.add(GigflexConstants.JOBSTATUS_ASSIGNED);                                
                        statusList.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                            
                        List<String> pendingStatusList = new ArrayList<>();
                        pendingStatusList.add(GigflexConstants.JOBSTATUS_PENDING); 
                        
                        while(nextStartDate.before(eDT))
                        {
//                            String dateTimeFormat = dateformat.trim()+" "+timeformat.trim();
                            String strStartDate = GigflexDateUtil.convertDateToString(nextStartDate, GigflexConstants.YYYY_MM_DD_HH_MM);
                            StatusCount statusCount =new StatusCount();                          

                            Calendar caleEnd = Calendar.getInstance();
                            caleEnd.setTime(nextEndDate);
                            caleEnd.add(Calendar.HOUR_OF_DAY, GigflexConstants.STATUS_COUNT_INTERVAL_IN_HOURS);                           
                            nextEndDate = caleEnd.getTime();    
                            if(nextEndDate.after(eDT))
                            {
                                nextEndDate=eDT;
                            }
                            
                            String strEndDate = GigflexDateUtil.convertDateToString(nextEndDate, GigflexConstants.YYYY_MM_DD_HH_MM);
                            
                            List<Object>  objList = jobsRepository.getAllJobStatusDetailByOrgCode(organizationCode, status, nextStartDate, nextEndDate);
                            int countStatus = 0;

                            if(objList != null && objList.size() > 0)
                            {
                                countStatus = objList.size();
                            }
                            
                            List<Object> acceptedAndAssignedList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, statusList, nextStartDate, nextEndDate);
                                
                            int countAcceptedAssigned = 0;
                            int countPending = 0;
                                
                            if(acceptedAndAssignedList != null && acceptedAndAssignedList.size() > 0)
                            {
                                countAcceptedAssigned = acceptedAndAssignedList.size();
                            }

                            List<Object> pendingList = jobsRepository.getAllJobsByOrganizationCode(organizationCode, pendingStatusList, nextStartDate, nextEndDate);


                            if(pendingList != null && pendingList.size() > 0 )
                            {
                                countPending = pendingList.size();
                            }

                            if( countAcceptedAssigned == 0 && countPending == 0)
                            {
                                statusCount.setFullfillmentRatio(null); 
                            }
                            else
                            {
                                double sum = countAcceptedAssigned+countPending;
                                double persentage = (countAcceptedAssigned)*100/(sum);
                                statusCount.setFullfillmentRatio(persentage); 
                            }
                            
                          
                            statusCount.setDateFormat(GigflexConstants.YYYY_MM_DD); 
                            statusCount.setStatusCount(countStatus);
                            Date startDateTimestamp = GigflexDateUtil.getGMTtoLocationDate(nextStartDate, timezone, GigflexConstants.YYYY_MM_DD_HH_MM);
                            strStartDate = GigflexDateUtil.convertDateToString(startDateTimestamp, GigflexConstants.YYYY_MM_DD_HH_MM);
                            statusCount.setStartDateTimestamp(startDateTimestamp);
                            Date endDateTimestamp = GigflexDateUtil.getGMTtoLocationDate(nextEndDate,timezone,GigflexConstants.YYYY_MM_DD_HH_MM);
                            strEndDate = GigflexDateUtil.convertDateToString(endDateTimestamp, GigflexConstants.YYYY_MM_DD_HH_MM);
                            statusCount.setEndDateTimestamp(endDateTimestamp);
                            statusCount.setStartDate(strStartDate);
                            statusCount.setEndDate(strEndDate); 
                            statusCount.setIndexNumber(index); 

                            Calendar cal = Calendar.getInstance();
                            cal.setTime(nextStartDate);
                            cal.add(Calendar.HOUR_OF_DAY, GigflexConstants.STATUS_COUNT_INTERVAL_IN_HOURS);                           
                            nextStartDate = cal.getTime();
                            statusCountList.add(statusCount);
                            
                            index++;
                      } 
                    }                       
                    
                    AppoaintmentDetailAndStatusCountRes adsRes = new AppoaintmentDetailAndStatusCountRes(); 
                    adsRes.setAppointmentDetailByWorkerCodeList(adWorkerList);  
                    adsRes.setStatusCountList(statusCountList);                     
                    
                    if ( (adWorkerList != null && adWorkerList.size() > 0) || (statusCountList.size() > 0) ) {
                        if(msg.equalsIgnoreCase("Success") && appst!=true)
                        {
                            msg="No appointment is present";
                        }
                        jsonobj.put("responsecode", 200);
                        jsonobj.put("message", msg);
                        jsonobj.put("count", count);
                        jsonobj.put("timestamp", new Date());
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(adsRes);
                        jsonobj.put("data", new JSONObject(Detail));                        
                    } else {
                        jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date());
                    }
                } else {
                    jsonobj.put("responsecode", 404);
                    jsonobj.put("message", "Organization does not exist.");
                    jsonobj.put("timestamp", new Date());
                }
            
} else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;
    
    }

    @Override
    public String getFullJobDetailsByJobDurationCode(String jobDurationCode) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
             Object  objlst = jobsRepository.getFullJobDetailsByJobDurationCode(jobDurationCode);
             if(objlst!=null)
             {
             AppointmentDetail adRes =null;    
             Object[] arr = (Object[]) objlst;
                if (arr.length >= 5) {
                        
                    String conStartDt = "";
                                String conEndTime="";
                                Date timestampStartTime =null;
                                Date timestampEndTime = null;
                                Integer drivingTimeInSecond=null;
                                Double distance=null;
                                String distanceText = "";
                                String durationText = "";
                                Jobs jobData = (Jobs) arr[0];
                                JobsDuration jdData= (JobsDuration) arr[1];
                                JobsAssignToWorker jawData = (JobsAssignToWorker) arr[2];
                                PatientDetails pDetail = (PatientDetails) arr[3];
                                ProcedureMaster pm = (ProcedureMaster) arr[4];
                                if(jobData!=null && jdData!=null && jawData!=null)
                                {
                                 String timezone = null;
                    
                    String dtFormat=GigflexConstants.DD_MM_YYYY_HH_MM_SS;
                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider, jobData.getOrganizationCode(), GigflexConstants.DATEFORMAT);
                    String timeformat =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider,  jobData.getOrganizationCode(), GigflexConstants.TIMEFORMAT);

                    String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, localSettingRepository, utr, GigflexConstants.HealthcareProvider,  jobData.getOrganizationCode(), GigflexConstants.TimeZone);
                    TimeZoneDetail tz = timeZoneDao.getTimeZoneDetailByTimeZoneCode(timezoneCode);
                    if (tz != null && tz.getTimeZoneName() != null) {
                        timezone = tz.getTimeZoneName();
                    }
                                
                        adRes = new AppointmentDetail();
                                if(pDetail!=null && pDetail.getId()>0)
                                        {
                                            adRes.setPatientName(pDetail.getPatientName());
                                            adRes.setPatientCode(pDetail.getPatientCode());
                                        } 
                               
                                    if(jawData.getWorkerCode()!=null)
                                    {
                                        adRes.setWorkerCode(jawData.getWorkerCode());
                                    Worker wkr=workerRepository.getWorkerdetailByworkerCode(jawData.getWorkerCode());
                                    if(wkr!=null && wkr.getId()>0)
                                    {
                                        adRes.setWorkerName(wkr.getName());
                                    }
                                    }
                                    adRes.setStatus(jawData.getStatus());
                                    if(jawData!=null && jawData.getId()>0 && jawData.getDistance()!=null && jawData.getDrivingTimeInSec()!=null)
                                    {
                                         distance =jawData.getDistance();
                                                    
                                                  drivingTimeInSecond= jawData.getDrivingTimeInSec();
                                                  if(drivingTimeInSecond!=null)
                                                  {
                                                      int hr = drivingTimeInSecond / 60;
                                                      int mn = hr % 60;
                                                      hr = hr / 60;
                                                      if (hr > 0) {
                                                          durationText = hr + " hours ";
                                                      }
                                                      if (mn > 0) {
                                                          durationText += mn + " minutes";
                                                      }
                                                  }
                                                  if(jawData.getDistance()!=null)
                                                  {
                                                  distanceText=String.format("%.2f", jawData.getDistance())+" Miles";
                                                  }
                                    }
                                    adRes.setDistanceText(distanceText);
                                adRes.setDurationText(durationText);
                                adRes.setDistance(distance);
                                adRes.setDrivingTimeInSecond(drivingTimeInSecond);
                                    if(timezone!=null && timezone.length()>0 )
                                    {
                                        if(jdData.getStartTime()!=null){
                                         Date startDate = jdData.getStartTime();
                                         timestampStartTime = GigflexDateUtil.getGMTtoLocationDate(startDate, timezone, dtFormat);
                                         conStartDt=GigflexDateUtil.convertDateToString(timestampStartTime, dtFormat);
                                        }
                                        if(jdData.getEndTime()!=null){
                                            Date endDate = jdData.getEndTime();
                                            timestampEndTime = GigflexDateUtil.getGMTtoLocationDate(endDate, timezone, dtFormat);
                                            conEndTime=GigflexDateUtil.convertDateToString(timestampEndTime, dtFormat);
                                         }
                                    }
                                     if( pm != null )
                                    {
                                        adRes.setProcedureIcon(pm.getProcedureIcon()); 
                                    }
                                     adRes.setDateFormat(dateformat);
                                adRes.setTimeFormat(timeformat); 
                                
                                adRes.setJobName(jdData.getJobName());
                                adRes.setJobEndDate(conEndTime);
                                adRes.setJobStartDate(conStartDt);
                                adRes.setTimestampJobsStartTime(timestampStartTime);
                                adRes.setTimestampJobsEndTime(timestampEndTime); 
                                adRes.setJobsCode(jdData.getJobsCode());
                                adRes.setJobsDurationCode(jdData.getJobsDurationCode());
                                
                }
                                }
                if(adRes!=null)
                {
                    jsonobj.put("responsecode", 200);
                        jsonobj.put("message", "Success");
                        jsonobj.put("timestamp", new Date());
                        ObjectMapper mapperObj = new ObjectMapper();
                        String Detail = mapperObj.writeValueAsString(adRes);
                        jsonobj.put("data", new JSONObject(Detail));        
                }
                else
                {
                    jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date()); 
                }
             }
             else
             {
               jsonobj.put("responsecode", 404);
                        jsonobj.put("message", "Record Not Found");
                        jsonobj.put("timestamp", new Date()); 
             }
            
             res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
        } catch (Exception e) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception occurred.");
            res = derr.toString();
            LOG.error("Exception is occurred.",e);

        }
        return res;
            
    }
    
    
     public PatientDetails findLastPatientDeatil(Worker worker,Date StartDt,String timeZone)
      {
          PatientDetails pdetails=null;
          try{
              
              Date localStartDate = GigflexDateUtil.getGMTtoLocationDate(StartDt, timeZone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
            if(localStartDate!=null )
            {
                String sDate=GigflexDateUtil.convertDateToString(localStartDate, GigflexConstants.YYYY_MM_DD);
                if(sDate!=null && sDate.length()>0)
                {
                    List<String> stlst = new ArrayList<String>();
                        stlst.add(GigflexConstants.JOBSTATUS_ASSIGNED);
                        stlst.add(GigflexConstants.JOBSTATUS_INPROGRESS);
                        stlst.add(GigflexConstants.JOBSTATUS_ACCEPTED);
                        stlst.add(GigflexConstants.JOBSTATUS_COMPLETED);
                    String sdtStr=sDate+" 00:00:00";
                    Date sDT=GigflexDateUtil.convertStringDateToGMT(sdtStr, timeZone, GigflexConstants.DD_MM_YYYY_HH_MM_SS);
                    Date eDT=StartDt;
                    if(sDT!=null && eDT!=null )
                    {
                       List<PatientDetails> pdLsit= jobsAssignToWorkerRepository.getLastPatientDetailsWithFilterInJobAssign(worker.getWorkerCode(), stlst, sDT, eDT);
                       if(pdLsit!=null && pdLsit.size()>0)
                       {
                           pdetails=pdLsit.get(pdLsit.size()-1);
                       }
                    }
                }
            }
              
              
              
              
              }catch(Exception e)
          {
              e.printStackTrace();
          }
          return pdetails;
      }
     
     private Double distanceMath(String lat11, String lon11, String lat22, String lon22) {
         try {
             double lat1 = Double.parseDouble(lat11);
             double lon1 = Double.parseDouble(lon11);
             double lat2 = Double.parseDouble(lat22);
             double lon2 = Double.parseDouble(lon22);
             double theta = lon1 - lon2;
             Double dist = Math.sin(deg2rad(lat1)) * Math.sin(deg2rad(lat2)) + Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.cos(deg2rad(theta));
             dist = Math.acos(dist);
             dist = rad2deg(dist);
             dist = dist * 60 * 1.1515;
             return (dist);
         } catch (Exception e) {
             LOG.error("Error in distance>>>", e);
         }
         return null;
     }
    
     private double deg2rad(double deg) {
        return (deg * Math.PI / 180.0);
    }
     
    private double rad2deg(double rad) {
         return (rad * 180.0 / Math.PI);
    }
}
