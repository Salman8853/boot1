/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.util;

/**
 *
 * @author nirbhay.p
 */
public class GigflexConstants {

    public static final String  DD_MMM = "dd MMM";
    public static final String  YYYY_MM_DD_HH_MM = "yyyy-MM-dd HH:mm";
    public static final String  YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String  HH_MM_SS = "HH:mm:ss";
    public static final String  HH_MM_A="hh:mm a";
    public static final String  HH_MM="HH:mm";
    public static final String  YYYY_MM_DD = "yyyy-MM-dd";
    public static final String DATEFORMAT="DateFormat";
    public static final String TIMEFORMAT="TimeFormat";
    public static final String TIMEZONE="TimeZone";
    public static final String CONFIG_MIN="ConfigureMinutes";
    public static final String START_CHECKIN_MIN="StartCheckInMinutes";
    public static final String ORGANIZATIONS="Organizations";
    public static final String SYSTEM_NOTI="SystemNotification";
    public static final String CAHT="Chat";
    public static final String ALERT="Alert";
    public static final String ADMIN="Admin";
    public static final String MARSHAL="Marshal"; 
    public static final String USER_TYPE_MARSHAL="Marshals"; 
    public static final String dateFormatterForSave ="yyyy-MM-dd HH:mm:ss";
    public static final Integer DEFAULT_SHIFT_INTERVAL_IN_MIN = 60;
    public static final String CONFIGURE_MINUTES_NAME = "ConfigureMinutes";
    public static final String ALERT_MINUTES = "AlertMinutes";
    public static final String MAIL_NOTIFICATIONS = "mail_notifications";
    public static final String SMS_NOTIFICATIONS ="sms_notifications";  
    public static final String NOTIFICATION_USER_TYPE_MARSHAL = "Marshals";
    public static final String GATE_CLOSE = "GC";
    public static final String DEFAULT_GATE_CLOSE_TIME = "23:59";
    
    
    
}
