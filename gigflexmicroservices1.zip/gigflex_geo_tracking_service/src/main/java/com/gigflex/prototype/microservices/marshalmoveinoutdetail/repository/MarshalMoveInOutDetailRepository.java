/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.marshalmoveinoutdetail.repository;

import com.gigflex.prototype.microservices.marshalmoveinoutdetail.dtob.MarshalMoveInOutDetail;
import java.util.Date;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface MarshalMoveInOutDetailRepository extends JpaRepository<MarshalMoveInOutDetail,Long>,JpaSpecificationExecutor<MarshalMoveInOutDetail>{

    @Query("SELECT md,pm,mmd FROM MarshalDetails md,PositionMaster pm ,MarshalMoveInOutDetail mmd  WHERE md.isDeleted != TRUE AND pm.isDeleted != TRUE AND mmd.isDeleted != TRUE AND mmd.positionNumber = pm.positionNumber AND md.marshalCode = mmd.marshalCode AND mmd.marshalCode = :marshalCode AND mmd.moveDate >= :fromDate AND mmd.moveDate <= :toDate ")
    public List<Object> getMarshalMoveInOutDetailBetweenDateByMarshalCode(@Param("fromDate") Date fromDate,@Param("toDate") Date toDate,@Param("marshalCode") String marshalCode);
    
}
