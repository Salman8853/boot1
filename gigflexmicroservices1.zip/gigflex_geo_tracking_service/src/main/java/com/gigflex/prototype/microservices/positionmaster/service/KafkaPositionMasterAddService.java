/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.positionmaster.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.positionmaster.dtob.PositionMaster;
import com.gigflex.prototype.microservices.positionmaster.repository.PositionMasterRepository;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class KafkaPositionMasterAddService {
    
    private PositionMaster positionMasterData;
    
    @Autowired
    PositionMasterRepository positionMasterRepository;
    private static final Logger LOG = LoggerFactory.getLogger(KafkaPositionMasterAddService.class);
    
    @KafkaListener(topics = "AddNewPostionMaster")
    public void listen(@Payload String message) {
        ObjectMapper objectMapper = new ObjectMapper();
        LOG.info("received message='{}'", message);
        try{
            PositionMaster positionMasterDetail = objectMapper.readValue(message, PositionMaster.class);
            LOG.info("received message for AddNewPostionMaster='{}'", positionMasterDetail.getPositionNumber());
            LOG.info("received message for AddNewPostionMaster='{}'", positionMasterDetail.getPositionCode());
            LOG.info("received message for AddNewPostionMaster='{}'", positionMasterDetail.getPositionDescription());
            LOG.info("received message for AddNewPostionMaster='{}'", positionMasterDetail.getPositionSide());
            positionMasterData=new PositionMaster();
            positionMasterData.setIsCritical(positionMasterDetail.isIsCritical());
            positionMasterData.setIsRotating(positionMasterDetail.isIsRotating()); 
            positionMasterData.setIsSun(positionMasterDetail.isIsSun()); 
            positionMasterData.setPositionDescription(positionMasterDetail.getPositionDescription());
            positionMasterData.setPositionLatitude(positionMasterDetail.getPositionLatitude());
            positionMasterData.setPositionLongitude(positionMasterDetail.getPositionLongitude());
            positionMasterData.setPositionNumber(positionMasterDetail.getPositionNumber());
            positionMasterData.setPositionSide(positionMasterDetail.getPositionSide());
            positionMasterData.setRoleDescription(positionMasterDetail.getRoleDescription());
            positionMasterData.setRadius(positionMasterDetail.getRadius());
            positionMasterRepository.save(positionMasterData);
            
        }
       catch (JsonParseException e) {
			LOG.error("In  KafkaPositionMasterAddService for AddNewPostionMaster >>>>", e);
		} catch (JsonMappingException e) {
			LOG.error("In KafkaPositionMasterAddService for AddNewPostionMaster >>>>", e);
		} catch (IOException e) {
			LOG.error("In KafkaPositionMasterAddService for AddNewPostionMaster >>>>", e);
		}catch (Exception e) {
			LOG.error("In KafkaPositionMasterAddService for AddNewPostionMaster >>>>", e);
		}
    }
}
