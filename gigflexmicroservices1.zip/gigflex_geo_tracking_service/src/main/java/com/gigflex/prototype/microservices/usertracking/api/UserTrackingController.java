/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.usertracking.api;

import com.gigflex.prototype.microservices.usertracking.dtob.UserTrackingRequest;
import com.gigflex.prototype.microservices.usertracking.service.UserTrackingService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author nirbhay.p
 */

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/geotrackingservice/")
public class UserTrackingController {
     private static final Logger LOG = LoggerFactory.getLogger(UserTrackingController.class);
    @Autowired
    private UserTrackingService userTrackingService;
    
    @PostMapping("/saveUserTracking")
    public String saveUserTracking(
            @RequestBody UserTrackingRequest req, HttpServletRequest request) {
        try {
            if (req != null && req.getLatitude()!=null && req.getLatitude().trim().length()>0 &&
                 req.getLongitude()!=null &&   req.getLongitude().trim().length()>0 &&
                 req.getUserCode()!=null &&   req.getUserCode().trim().length()>0   )
        {
            req.setLatitude(req.getLatitude().trim());
            req.setLongitude(req.getLongitude().trim());
            req.setUserCode( req.getUserCode().trim());
            String ip = request.getRemoteAddr();
            return userTrackingService.saveUserTracking(req,ip);
        }
        else {
                GigflexResponse derr = new GigflexResponse(400, new Date(), "User Code, Latitude and Longitude should not be blank.");
                return derr.toString();
            }
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            LOG.error("Error in saveUserTracking>>>>>>>", ex);
            return derr.toString();

        }
    }
    
    @GetMapping("/getLastTrackingByUserCode/{userCode}")
    public String getLastTrackingByUserCode(@PathVariable String userCode) {
        if (userCode != null && userCode.trim().length() > 0) {
            return userTrackingService.getLastTrackingByUserCode(userCode.trim());
        } else {
            GigflexResponse derr = new GigflexResponse(400, new Date(), "User Code should not be blank.");
            return derr.toString();
        }
    }
    
    @GetMapping("/getAllUserWithLastTrackingDetail")
    public String getAllUserWithLastTrackingDetail() {
            return userTrackingService.getAllUserWithLastTrackingDetail();
        
    }

}
