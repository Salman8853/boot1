/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.organization.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.gigflex.prototype.microservices.organization.dtob.Organization;




/**
 *
 * @author abhishek
 */
@Repository
public interface OrganizationDao extends JpaRepository<Organization, Long>,JpaSpecificationExecutor<Organization> {
	@Query("SELECT org FROM Organization org WHERE org.isDeleted != TRUE AND org.organizationName = :organizationName")
	public Organization getOrganizationByName(
			@Param("organizationName") String organizationName);
	
	@Query("SELECT d FROM Organization d WHERE d.isDeleted != TRUE AND d.organizationCode = :organizationCode")
	public Organization findByOrganizationCode(@Param("organizationCode") String organizationCode);
	
	
	@Query("SELECT d FROM Organization d WHERE d.isDeleted != TRUE AND d.id = :id")
	public Organization getOrganizationById(@Param("id") Long id);

}
