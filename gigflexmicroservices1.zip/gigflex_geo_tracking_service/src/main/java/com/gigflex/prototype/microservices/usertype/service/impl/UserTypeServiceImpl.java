package com.gigflex.prototype.microservices.usertype.service.impl;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.usertype.dtob.UserType;
import com.gigflex.prototype.microservices.usertype.dtob.UserTypeRequest;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.usertype.service.UserTypeService;
import com.gigflex.prototype.microservices.util.GigflexResponse;

@Service
public class UserTypeServiceImpl implements UserTypeService {

	@Autowired
	UserTypeRepository userTypeDao;

	@Override
	public String getAllUserType() {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			List<UserType> userTypelst = userTypeDao.getAllUserType();

			if (userTypelst != null && userTypelst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(userTypelst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getUserTypeById(Long id) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			UserType userTypelst = userTypeDao.getUserTypeById(id);
			if (userTypelst != null && userTypelst.getId() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(userTypelst);
				jsonobj.put("data", new JSONObject(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found");
				jsonobj.put("timestamp", new Date());

			}
			res = jsonobj.toString();
		} catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getUserTypeByUserTypeCode(String userTypeCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			UserType userTypelst = userTypeDao
					.getUserTypeByUserTypeCode(userTypeCode);
			if (userTypelst != null && userTypelst.getId() > 0) {
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(userTypelst);
				jsonobj.put("responsecode", 200);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Success");
				jsonobj.put("data", new JSONObject(Detail));

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String saveNewUserType(UserTypeRequest userTypeReq, String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();

			if (userTypeReq != null) {

				if (userTypeReq.getUserTypeName() != null
						&& userTypeReq.getUserTypeName().trim().length() > 0) {

					UserType userTypeCheck = userTypeDao
							.getUserTypeByUserTypeName(userTypeReq
									.getUserTypeName());

					if (userTypeCheck != null && userTypeCheck.getId() > 0) {
						jsonobj.put("responsecode", 409);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("message", "userTypeName already exist.");
					} else {

						UserType userTypelst = new UserType();

						userTypelst.setUserTypeName(userTypeReq
								.getUserTypeName());

						userTypelst.setIpAddress(ip);

						UserType userTypeRes = userTypeDao.save(userTypelst);

						jsonobj.put("responsecode", 200);
						jsonobj.put("timestamp", new Date());

						if (userTypeRes != null && userTypeRes.getId() > 0) {

							jsonobj.put("message",
									"UserType has been added successfully.");
							ObjectMapper mapperObj = new ObjectMapper();
							String Detail = mapperObj
									.writeValueAsString(userTypeRes);
							jsonobj.put("data", new JSONObject(Detail));
						} else {
							jsonobj.put("message", "Failed");
						}
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "User Type Name should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Input data is not valid.");

			}
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String updateUserTypeById(Long id, UserTypeRequest userTypeReq,
			String ip) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (id > 0 && userTypeReq != null) {

				if (userTypeReq.getUserTypeName() != null
						&& userTypeReq.getUserTypeName().trim().length() > 0) {

					UserType userTypelst = userTypeDao.getUserTypeById(id);

					if (userTypelst != null && userTypelst.getId() > 0) {

						UserType userTypeCheck = userTypeDao
								.getUserTypeByUserTypeNameNotID(userTypeReq
										.getUserTypeName(),id);

						if (userTypeCheck != null && userTypeCheck.getId() > 0) {
							jsonobj.put("responsecode", 409);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("message",
									"User Type already exist.");
						} else {

							UserType userType = userTypelst;

							userType.setUserTypeName(userTypeReq
									.getUserTypeName());
							userType.setIpAddress(ip);

							UserType userTypeRes = userTypeDao.save(userType);

							if (userTypeRes != null && userTypeRes.getId() > 0) {
								jsonobj.put("responsecode", 200);
								jsonobj.put("message",
										"UserType updation has been done");
								jsonobj.put("timestamp", new Date());
								ObjectMapper mapperObj = new ObjectMapper();
								String Detail = mapperObj
										.writeValueAsString(userTypeRes);
								jsonobj.put("data", new JSONObject(Detail));
							} else {
								jsonobj.put("responsecode", 400);
								jsonobj.put("message",
										"UserType updation has been failed.");
								jsonobj.put("timestamp", new Date());
							}
						}
					} else {
						jsonobj.put("responsecode", 400);
						jsonobj.put("message", "UserType ID is not valid.");
						jsonobj.put("timestamp", new Date());
					}
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "User Type Name should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}

			res = jsonobj.toString();
		} catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception is occurred.");
			res = derr.toString();
			ex.printStackTrace();
		}
		return res;
	}

	@Override
	public String softDeleteByUserTypeCode(String userTypeCode) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			UserType userTypelst = userTypeDao
					.getUserTypeByUserTypeCode(userTypeCode);
			if (userTypelst != null && userTypelst.getId() > 0) {
				userTypelst.setIsDeleted(true);
				UserType userTypeRes = userTypeDao.save(userTypelst);

				if (userTypeRes != null && userTypeRes.getId() > 0) {
					jsonobj.put("responsecode", 200);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "UserType deleted successfully.");
					// kafkaService.sendRoleMasterUpdate(roleRes);
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Failed");
				}

			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("timestamp", new Date());
				jsonobj.put("message", "Record Not Found");
			}
			res = jsonobj.toString();
		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String softMultipleDeleteByUserTypeCode(List<String> userTypeCodeList) {
		String res = "";
		try {
			JSONArray jarr = new JSONArray();
			for (String userTypeCode : userTypeCodeList) {
				if (userTypeCode != null && userTypeCode.trim().length() > 0) {
					JSONObject jsonobj = new JSONObject();

					userTypeCode = userTypeCode.trim();

					UserType userTypelst = userTypeDao
							.getUserTypeByUserTypeCode(userTypeCode);
					if (userTypelst != null && userTypelst.getId() > 0) {

						userTypelst.setIsDeleted(true);
						UserType userTypeRes = userTypeDao.save(userTypelst);
						if (userTypeRes != null && userTypeRes.getId() > 0) {
							jsonobj.put("responsecode", 200);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", userTypeCode);
							jsonobj.put("message",
									"UserType deleted successfully.");
							// kafkaService.se
						} else {
							jsonobj.put("responsecode", 400);
							jsonobj.put("timestamp", new Date());
							jsonobj.put("code", userTypeCode);
							jsonobj.put("message", "Failed");
						}

					} else {
						jsonobj.put("responsecode", 404);
						jsonobj.put("timestamp", new Date());
						jsonobj.put("code", userTypeCode);
						jsonobj.put("message", "Record Not Found");
					}
					jarr.add(jsonobj);
				}
			}
			if (jarr.size() > 0) {
				res = jarr.toString();
			} else {
				GigflexResponse derr = new GigflexResponse(400, new Date(),
						"Multiple delete failed.");
				res = derr.toString();
			}

		} catch (Exception ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	@Override
	public String getAllUserTypeByPgae(int page, int limit) {
		String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
                        if (limit > 0) {
			Pageable pageableRequest = PageRequest.of(page, limit);
			List<UserType> userTypelst = userTypeDao.getAllUserType(pageableRequest);
                         int count=0;
                        List<UserType> cntlst =  userTypeDao.getAllUserType();
                        if(cntlst!=null)
                        {
                        count=cntlst.size();
                        }
			if (userTypelst != null && userTypelst.size() > 0) {
				jsonobj.put("responsecode", 200);
				jsonobj.put("message", "Success");
				jsonobj.put("timestamp", new Date());
                                jsonobj.put("count", count);
				ObjectMapper mapperObj = new ObjectMapper();
				String Detail = mapperObj.writeValueAsString(userTypelst);
				jsonobj.put("data", new JSONArray(Detail));
			} else {
				jsonobj.put("responsecode", 404);
				jsonobj.put("message", "Record Not Found.");
				jsonobj.put("timestamp", new Date());
			}
                        } else {
                jsonobj.put("responsecode", 400);
                jsonobj.put("message", "Limit should not be Zero or Negative.");
                jsonobj.put("timestamp", new Date());
            }
			res = jsonobj.toString();
		} catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
		return res;
	}

	
}
