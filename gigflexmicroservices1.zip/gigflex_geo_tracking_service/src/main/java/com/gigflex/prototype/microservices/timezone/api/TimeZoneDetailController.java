package com.gigflex.prototype.microservices.timezone.api;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gigflex.prototype.microservices.timezone.service.TimeZoneDetailService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/geotrackingservice/")
public class TimeZoneDetailController { 

	@Autowired
	private TimeZoneDetailService timeZoneService;

	@GetMapping("/getAllTimeZoneDetail")
	public String getAllTimeZoneDetail() {
		return timeZoneService.getAllTimeZoneDetail();
	}

//	@PostMapping("/createNewTimeZone")
//	public String createNewTimeZone(
//			@RequestBody TimeZoneDetailMultiRequest timeZonereq,
//			HttpServletRequest request) {
//		String ip = request.getRemoteAddr();
//		return timeZoneService.createNewTimeZone(timeZonereq, ip);
//
//	}

	

	@GetMapping(path = "/getTimeZoneDetailByPage")
	public String getTimeZoneDetailByPage(
			@RequestParam(value = "page", defaultValue = "0") int page,
			@RequestParam(value = "limit", defaultValue = "30") int limit) {

		String TimeZoneDetail = timeZoneService.getAllTimeZoneDetail(page,
				limit);

		return TimeZoneDetail;

	}

	@GetMapping("/getTimeZoneDetail/{id}")
	public String getTimeZoneDetailById(@PathVariable Long id) {
		return timeZoneService.getTimeZoneDetailById(id);
	}

	@GetMapping("/getTimeZoneDetailByTimeZoneCode/{timeZoneCode}")
	public String getTimeZoneDetailByVehicleCode(
			@PathVariable String timeZoneCode) {
		return timeZoneService.getTimeZoneDetailByTimeZoneCode(timeZoneCode);
	}

//	@PutMapping("/updateTimeZoneDetail/{id}")
//	public String updateTimeZoneDetail(@PathVariable Long id,
//			@RequestBody TimeZoneDetailRequest TimeZoneDetailReq,
//			HttpServletRequest request) {
//
//		if (id == null) {
//			return "TimeZoneDetail with Id : (" + id + ") Not found.";
//		} else {
//			String ip = request.getRemoteAddr();
//
//			return timeZoneService.updateTimeZoneDetailById(id,
//					TimeZoneDetailReq, ip);
//
//		}
//
//	}
//
//	@DeleteMapping("/softDeleteTimeZoneDetailByTimeZoneCode/{timeZoneCode}")
//	public String softDeleteTimeZoneDetailByTimeZoneCode(
//			@PathVariable String timeZoneCode) {
//		return timeZoneService
//				.softDeleteTimeZoneDetailByTimeZoneCode(timeZoneCode);
//	}
//
//	@DeleteMapping("/softMultipleDeleteTimeZoneDetailByVehicleCode/{timeZoneCodeList}")
//	public String softMultipleDeleteTimeZoneDetailByVehicleCode(
//			@PathVariable List<String> timeZoneCodeList) {
//		if (timeZoneCodeList != null && timeZoneCodeList.size() > 0) {
//			return timeZoneService
//					.softMultipleDeleteByTimeZoneCode(timeZoneCodeList);
//
//		} else {
//			GigflexResponse derr = new GigflexResponse(400, new Date(),
//					"Input data is not valid");
//			return derr.toString();
//		}
//
//	}

}
