/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.marshalmoveinoutdetail.api;

import com.gigflex.prototype.microservices.marshalmoveinoutdetail.dtob.MarshalMoveInOutDetailRequest;
import com.gigflex.prototype.microservices.marshalmoveinoutdetail.service.MarshalMoveInOutDetailService;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author amit.kumar
 */
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/geotrackingservice/")
public class MarshalMoveInOutDetailController {
    
    @Autowired
    MarshalMoveInOutDetailService marshalMoveInOutDetailService;
    
    @PostMapping("/saveMarshalMoveInOutDetail")
    public String saveMarshalMoveInOutDetail(@RequestBody MarshalMoveInOutDetailRequest marshalMoveInOutDetailRequest,HttpServletRequest request){
                String ip = request.getRemoteAddr();

          return marshalMoveInOutDetailService.saveMarshalMoveInOutDetail(marshalMoveInOutDetailRequest,ip);

    }
    
    @GetMapping("/getAllMarshalMoveInOutDetailByMarshalCodeAndBetweenDate/{marshalCode}/{fromDate}/{toDate}")
    public String getAllMarshalMoveInOutDetailByMarshalCodeAndBetweenDate(@PathVariable String marshalCode,@PathVariable String fromDate,@PathVariable String toDate) {
            return marshalMoveInOutDetailService.findAllMarshalMoveInOutDetailByMarshalCodeAndBetweenDate(marshalCode,fromDate,toDate);
    }
    
}
