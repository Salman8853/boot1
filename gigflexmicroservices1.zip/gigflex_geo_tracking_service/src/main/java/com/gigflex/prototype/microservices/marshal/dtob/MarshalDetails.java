/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.marshal.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "marshal_details")
public class MarshalDetails extends CommonAttributes implements Serializable{
    
        @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
        
        @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "marshal_code", unique = true)
	private String marshalCode;
        
               
        @Column(name = "marshal_first_name", nullable = false)
	private String marshalFirstName;
        
        @Column(name = "marshal_last_name", nullable = false)
	private String marshalLastName;

        @Column(name = "organization_code", nullable = false)
	private String organizationCode;                       
        
	@Column(name = "primary_mobile_number", nullable = false)
	private String primaryMobileNumber;

	@Column(name = "secondary_mobile_number")
	private String secondaryMobileNumber;
	
	@Column(name = "primary_country_code",nullable = false)
        private String primaryCountryCode;
	
	@Column(name = "secondary_country_code")
        private String secondaryCountryCode;
        
        @Column(name = "marshal_email", nullable = true)
	private String marshalEmail;
        
        @Column(name = "is_registered")
        private Boolean isRegistered;
        
        @Column(name = "group_id")
        private Long groupId;

    public Long getGroupId() {
        return groupId;
    }

    public void setGroupId(Long groupId) {
        this.groupId = groupId;
    }        
        @PrePersist
	private void assignUUID() {
		if (this.getMarshalCode() == null || this.getMarshalCode().length() == 0) {
			this.setMarshalCode(UUID.randomUUID().toString());
		}
	}

    public Boolean getIsRegistered() {
        return isRegistered;
    }

    public void setIsRegistered(Boolean isRegistered) {
        this.isRegistered = isRegistered;
    }

   

        
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrganizationCode() {
        return organizationCode;
    }

    public void setOrganizationCode(String organizationCode) {
        this.organizationCode = organizationCode;
    }

    public String getMarshalCode() {
        return marshalCode;
    }

    public void setMarshalCode(String marshalCode) {
        this.marshalCode = marshalCode;
    }

    public String getMarshalFirstName() {
        return marshalFirstName;
    }

    public void setMarshalFirstName(String marshalFirstName) {
        this.marshalFirstName = marshalFirstName;
    }

    public String getMarshalLastName() {
        return marshalLastName;
    }

    public void setMarshalLastName(String marshalLastName) {
        this.marshalLastName = marshalLastName;
    }

    public String getPrimaryMobileNumber() {
        return primaryMobileNumber;
    }

    public void setPrimaryMobileNumber(String primaryMobileNumber) {
        this.primaryMobileNumber = primaryMobileNumber;
    }

    public String getSecondaryMobileNumber() {
        return secondaryMobileNumber;
    }

    public void setSecondaryMobileNumber(String secondaryMobileNumber) {
        this.secondaryMobileNumber = secondaryMobileNumber;
    }   

    public String getPrimaryCountryCode() {
        return primaryCountryCode;
    }

    public void setPrimaryCountryCode(String primaryCountryCode) {
        this.primaryCountryCode = primaryCountryCode;
    }

    public String getSecondaryCountryCode() {
        return secondaryCountryCode;
    }

    public void setSecondaryCountryCode(String secondaryCountryCode) {
        this.secondaryCountryCode = secondaryCountryCode;
    }

    public String getMarshalEmail() {
        return marshalEmail;
    }

    public void setMarshalEmail(String marshalEmail) {
        this.marshalEmail = marshalEmail;
    }
    
}
