package com.gigflex.prototype.microservices.usertype.dtob;

public class UserTypeRequest {
	
	 private String userTypeName;

	public String getUserTypeName() {
		return userTypeName;
	}

	public void setUserTypeName(String userTypeName) {
		this.userTypeName = userTypeName;
	}
	 
	 

}
