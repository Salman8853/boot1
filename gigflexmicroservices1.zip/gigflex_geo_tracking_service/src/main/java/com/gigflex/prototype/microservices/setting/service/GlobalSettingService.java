/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.setting.service;
import com.gigflex.prototype.microservices.setting.dtob.GlobalSettingReq;
import java.util.List;
/**
 *
 * @author nirbhay.p
 */
public interface GlobalSettingService {
    
	public String getAllGlobalSettingByPage(int page, int limit);
	
        public String getGlobalSettingByUserTypeByPage(String userTypeCode,int page, int limit);

	public String saveGlobalSetting(GlobalSettingReq globalSettingReq, String ip);
        
        public String updateGlobalSettingById(GlobalSettingReq globalSettingReq, Long id, String ip);
	
	public String getGlobalSettingByGlobalSettingCode(String globalSettingCode);
        
        public String softDeleteGlobalSettingByGlobalSettingCode(String globalSettingCode);
        
        public String softMultipleDeleteGlobalSettingByGlobalSettingCode(List<String> globalSettingCodeList);
        
        public String getGlobalSettingByUserTypeSettingName(String userTypeCode,String settingName);
        public String getGlobalSettingByUserTypeSettingType(String userTypeCode,String settingType);
}

