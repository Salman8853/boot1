/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.marshalmoveinoutdetail.dtob;

/**
 *
 * @author amit.kumar
 */
public class MarshalMoveInOutDetailRequest {
    
    private String marshalCode;
    private Long positionNumber;
    private Long sid;  
    private String moveToLatitude;
    private String moveToLongitude;
    private String action;

    public String getMarshalCode() {
        return marshalCode;
    }

    public void setMarshalCode(String marshalCode) {
        this.marshalCode = marshalCode;
    }

    public Long getPositionNumber() {
        return positionNumber;
    }

    public void setPositionNumber(Long positionNumber) {
        this.positionNumber = positionNumber;
    }

    public Long getSid() {
        return sid;
    }

    public void setSid(Long sid) {
        this.sid = sid;
    }

    public String getMoveToLatitude() {
        return moveToLatitude;
    }

    public void setMoveToLatitude(String moveToLatitude) {
        this.moveToLatitude = moveToLatitude;
    }

    public String getMoveToLongitude() {
        return moveToLongitude;
    }

    public void setMoveToLongitude(String moveToLongitude) {
        this.moveToLongitude = moveToLongitude;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
    
    
    
    
}
