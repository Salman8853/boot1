/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.usertracking.service;

import com.gigflex.prototype.microservices.usertracking.dtob.UserTrackingRequest;

/**
 *
 * @author nirbhay.p
 */
public interface UserTrackingService {

    public String saveUserTracking(UserTrackingRequest req, String ip);

    public String getLastTrackingByUserCode(String userCode);

    public String getAllUserWithLastTrackingDetail();
    
}
