package com.gigflex.prototype.microservices.config;

import com.gigflex.prototype.microservices.marshalmoveinoutdetail.dtob.MarshalMoveInOutDetail;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

/**
 *
 * @author nirbhay.p
 */


@Service
public class KafkaService {
    
    @Autowired
    private KafkaTemplate<String, MarshalMoveInOutDetail> marshalMoveInOutDetailTemplate;
    
    String kafkaTopicAddMarshalMoveInOut = "AddMarshalMoveInOut";
    
    public void sendAddMarshalMoveInOutDetail(MarshalMoveInOutDetail message){
    	marshalMoveInOutDetailTemplate.send(kafkaTopicAddMarshalMoveInOut, message);
     }
}
