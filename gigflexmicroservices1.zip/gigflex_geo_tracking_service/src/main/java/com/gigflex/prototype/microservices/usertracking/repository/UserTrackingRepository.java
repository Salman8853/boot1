/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.usertracking.repository;

import com.gigflex.prototype.microservices.usertracking.dtob.UserTracking;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author nirbhay.p
 */
@Repository
public interface UserTrackingRepository extends JpaRepository<UserTracking,Long>,JpaSpecificationExecutor<UserTracking>{

    @Query("SELECT u FROM UserTracking u WHERE u.isDeleted != TRUE AND u.userCode = :userCode ORDER BY  u.id")
    public List<UserTracking> getLastTrackingByUserCode(@Param("userCode") String userCode);
    
     @Query("SELECT u FROM UserTracking u WHERE u.isDeleted != TRUE AND u.id IN (SELECT MAX(ut.id) FROM UserTracking ut WHERE ut.isDeleted != TRUE GROUP BY ut.userCode)")
    public List<UserTracking> getAllUserWithLastTrackingDetail();
    
}
