/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.usertracking.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.marshal.dtob.MarshalDetails;
import com.gigflex.prototype.microservices.marshal.repository.MarshalDao;
import com.gigflex.prototype.microservices.usertracking.dtob.UserTracking;
import com.gigflex.prototype.microservices.usertracking.dtob.UserTrackingRequest;
import com.gigflex.prototype.microservices.usertracking.dtob.UserTrackingResponse;
import com.gigflex.prototype.microservices.usertracking.repository.UserTrackingRepository;
import com.gigflex.prototype.microservices.usertracking.service.UserTrackingService;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author nirbhay.p
 */
@Service
public class UserTrackingServiceImpl implements UserTrackingService {

    private static final Logger LOG = LoggerFactory.getLogger(UserTrackingServiceImpl.class);
    @Autowired
    UserTrackingRepository userTrackingRepository;
    @Autowired
    MarshalDao marshalDao;

    @Override
    public String saveUserTracking(UserTrackingRequest req, String ip) {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            UserTracking ut = new UserTracking();
            ut.setLatitude(req.getLatitude());
            ut.setLongitude(req.getLongitude());
            ut.setUserCode(req.getUserCode());
            UserTracking utres = userTrackingRepository.save(ut);
            if (utres != null && utres.getId() > 0) {
                jsonobj.put("message", "User Tracking has been saved.");
                jsonobj.put("responsecode", 200);
                jsonobj.put("timestamp", new Date());
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(utres);
                jsonobj.put("data", new JSONObject(Detail));
                try
                {
                    List<UserTracking> utlst =userTrackingRepository.getLastTrackingByUserCode(req.getUserCode());
                    if(utlst.size()>5)
                    {
                        for(int i=utlst.size()-6;i>=0;i--)
                        {
                            try
                            {
                            UserTracking utt=utlst.get(i);
                            if(utt!=null && utt.getId()>0)
                            {
                                userTrackingRepository.delete(utt);
                            }
                            }
                catch(Exception  e)
                {
                    LOG.error("Error in delete saveUserTracking>>>", e);
                }
                        }
                    }
                }
                catch(Exception  ee)
                {
                    LOG.error("Error in delete saveUserTracking>>>", ee);
                }
            } else {
                jsonobj.put("message", "Failed.");
                jsonobj.put("responsecode", 400);
                jsonobj.put("timestamp", new Date());
            }

            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            LOG.error("Error in saveUserTracking>>>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            LOG.error("Error in saveUserTracking>>>>>>>", ex);
        }
        return res;
    }

    @Override
    public String getLastTrackingByUserCode(String userCode) {
         String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            List<UserTracking> utlst =userTrackingRepository.getLastTrackingByUserCode(userCode);
            if(utlst.size()>0)
            {
                UserTracking ut=utlst.get(utlst.size()-1);
                if (ut != null && ut.getId() > 0) {
                jsonobj.put("message", "Success.");
                jsonobj.put("responsecode", 200);
                jsonobj.put("timestamp", new Date());
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(ut);
                jsonobj.put("data", new JSONObject(Detail));
            } else {
                jsonobj.put("message", "Record not found.");
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
            }

            }
            else
            {
                jsonobj.put("message", "Record not found.");
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            LOG.error("Error in getLastTrackingByUserCode>>>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            LOG.error("Error in getLastTrackingByUserCode>>>>>>>", ex);
        }
        return res;
    }

    @Override
    public String getAllUserWithLastTrackingDetail() {
        String res = "";
        try {
            JSONObject jsonobj = new JSONObject();
            List<UserTracking> utlst =userTrackingRepository.getAllUserWithLastTrackingDetail();
            if(utlst.size()>0)
            {
                List<UserTrackingResponse> utrslst=new ArrayList<>();
                for(UserTracking ut:utlst)
                {
                    UserTrackingResponse utres=new UserTrackingResponse();
                    MarshalDetails md=marshalDao.getRegisteredMarshalDetailsByCode(ut.getUserCode());
                    if(md!=null && md.getId()>0)
                    {
                        utres.setMarshalDetails(md);
                        utres.setLatitude(ut.getLatitude());
                        utres.setLongitude(ut.getLongitude());
                        utres.setTrackingCode(ut.getTrackingCode());
                        utrslst.add(utres);
                        
                    }
                }
                
                if (utrslst.size() > 0) {
                jsonobj.put("message", "Success.");
                jsonobj.put("responsecode", 200);
                jsonobj.put("timestamp", new Date());
                ObjectMapper mapperObj = new ObjectMapper();
                String Detail = mapperObj.writeValueAsString(utrslst);
                jsonobj.put("data", new JSONArray(Detail));
            } else {
                jsonobj.put("message", "Record not found.");
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
            }

            }
            else
            {
                jsonobj.put("message", "Record not found.");
                jsonobj.put("responsecode", 404);
                jsonobj.put("timestamp", new Date());
            }
            res = jsonobj.toString();
        } catch (JSONException | JsonProcessingException ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "JSON parsing exception occurred.");
            res = derr.toString();
            LOG.error("Error in getAllUserWithLastTrackingDetail>>>>>>>", ex);
        } catch (Exception ex) {
            GigflexResponse derr = new GigflexResponse(500, new Date(), "Exception is occurred.");
            res = derr.toString();
            LOG.error("Error in getAllUserWithLastTrackingDetail>>>>>>>", ex);
        }
        return res;
    }

}
