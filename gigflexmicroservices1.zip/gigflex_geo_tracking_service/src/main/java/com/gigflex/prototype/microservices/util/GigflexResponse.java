/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.util;

import java.util.Date;

/**
 *
 * @author nirbhay.p
 */
public class GigflexResponse {
    private int responsecode;
    private String message;
    private Date timestamp ;

    public GigflexResponse() {
    }

    public GigflexResponse(int responsecode, Date timestamp, String message) {
        this.responsecode = responsecode;
        this.message = message;
        this.timestamp = timestamp;
    }

    public int getResponsecode() {
        return responsecode;
    }

    public void setResponsecode(int responsecode) {
        this.responsecode = responsecode;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }
     @Override
    public String toString() {
        return "{\"responsecode\":"+responsecode+", \"message\": \""+message+"\", \"timestamp\": \""+timestamp+"\" }";
    }
}
