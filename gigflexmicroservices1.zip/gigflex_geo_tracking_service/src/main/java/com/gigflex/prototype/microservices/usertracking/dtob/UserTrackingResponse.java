/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gigflex.prototype.microservices.usertracking.dtob;

import com.gigflex.prototype.microservices.marshal.dtob.MarshalDetails;


/**
 *
 * @author nirbhay.p
 */
public class UserTrackingResponse {
    
        private MarshalDetails marshalDetails;
	private String latitude;
	private String longitude;
        private String trackingCode;

    public String getTrackingCode() {
        return trackingCode;
    }

    public void setTrackingCode(String trackingCode) {
        this.trackingCode = trackingCode;
    }
                

    public MarshalDetails getMarshalDetails() {
        return marshalDetails;
    }

    public void setMarshalDetails(MarshalDetails marshalDetails) {
        this.marshalDetails = marshalDetails;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
        
        
}
