/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.marshalmoveinoutdetail.service;

import com.gigflex.prototype.microservices.marshalmoveinoutdetail.dtob.MarshalMoveInOutDetailRequest;

/**
 *
 * @author amit.kumar
 */
public interface MarshalMoveInOutDetailService {

    public String saveMarshalMoveInOutDetail(MarshalMoveInOutDetailRequest marshalMoveInOutDetailRequest, String ip);

    public String findAllMarshalMoveInOutDetailByMarshalCodeAndBetweenDate(String marshalCode, String fromDate, String toDate);
    
}
