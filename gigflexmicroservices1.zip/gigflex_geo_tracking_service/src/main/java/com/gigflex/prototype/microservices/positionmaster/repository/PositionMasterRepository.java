/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.positionmaster.repository;

import com.gigflex.prototype.microservices.positionmaster.dtob.PositionMaster;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface PositionMasterRepository extends JpaRepository<PositionMaster,Long>,JpaSpecificationExecutor<PositionMaster>{
    
    @Query("SELECT pm FROM PositionMaster pm WHERE pm.isDeleted != TRUE")
    public List<PositionMaster> getAllPositionMaster();

    @Query("SELECT pm FROM PositionMaster pm WHERE pm.isDeleted != TRUE AND pm.positionNumber = :positionNumber")
    public PositionMaster getPositionMasterByPositionNumber(@Param("positionNumber") Long positionNumber);
}
