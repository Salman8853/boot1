/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.util;

/**
 *
 * @author amit.kumar
 */
public class GigUtil {
    
    public static String getRootException(Throwable exception) {
        String res = null;
        Throwable rootException = exception;
        while (rootException.getCause() != null) {
            rootException = rootException.getCause();
        }
        res = rootException.getLocalizedMessage();
        return res;
    }
}
