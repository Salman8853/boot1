/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.marshalmoveinoutdetail.service.impl;

import atg.taglib.json.util.JSONArray;
import atg.taglib.json.util.JSONException;
import atg.taglib.json.util.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.config.KafkaService;
import com.gigflex.prototype.microservices.marshal.dtob.MarshalDetails;
import com.gigflex.prototype.microservices.marshal.repository.MarshalDao;
import com.gigflex.prototype.microservices.marshalmoveinoutdetail.dtob.MarshalMoveInOutDetail;
import com.gigflex.prototype.microservices.marshalmoveinoutdetail.dtob.MarshalMoveInOutDetailRequest;
import com.gigflex.prototype.microservices.marshalmoveinoutdetail.dtob.MarshalMoveInOutDetailResponse;
import com.gigflex.prototype.microservices.marshalmoveinoutdetail.repository.MarshalMoveInOutDetailRepository;
import com.gigflex.prototype.microservices.marshalmoveinoutdetail.service.MarshalMoveInOutDetailService;
import com.gigflex.prototype.microservices.positionmaster.dtob.PositionMaster;
import com.gigflex.prototype.microservices.positionmaster.repository.PositionMasterRepository;
import com.gigflex.prototype.microservices.setting.repository.GlobalSettingRepository;
import com.gigflex.prototype.microservices.timezone.dtob.TimeZoneDetail;
import com.gigflex.prototype.microservices.timezone.repository.TimeZoneRepository;
import com.gigflex.prototype.microservices.usertype.repository.UserTypeRepository;
import com.gigflex.prototype.microservices.util.GigflexConstants;
import com.gigflex.prototype.microservices.util.GigflexDateUtil;
import com.gigflex.prototype.microservices.util.GigflexResponse;
import com.gigflex.prototype.microservices.util.GigflexUtility;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class MarshalMoveInOutDetailServiceImpl implements MarshalMoveInOutDetailService{
    
    private static final Logger LOG = LoggerFactory.getLogger(MarshalMoveInOutDetailServiceImpl.class);
    
    @Autowired
    MarshalMoveInOutDetailRepository marshalMoveInOutDetailDao;      
    
    @Autowired
    GlobalSettingRepository globalSettingRepository;
    @Autowired
    UserTypeRepository userTypeDao;
    
    @Autowired
    TimeZoneRepository timeZoneRepository; 
    
    @Autowired
    MarshalDao marshalDao;
    
    @Autowired
    PositionMasterRepository positionMasterDao;
    @Autowired
    KafkaService kafkaService;
    @Override
    public String saveMarshalMoveInOutDetail(MarshalMoveInOutDetailRequest marshalMoveInOutDetailRequest, String ip) {
        
         String res = "";
		try {
			JSONObject jsonobj = new JSONObject();
			if (marshalMoveInOutDetailRequest != null) {
				if (marshalMoveInOutDetailRequest.getAction()!= null && marshalMoveInOutDetailRequest.getAction().trim().length() > 0
                                        && marshalMoveInOutDetailRequest.getMarshalCode()!= null && marshalMoveInOutDetailRequest.getMarshalCode().trim().length() > 0                                       
                                        && marshalMoveInOutDetailRequest.getMoveToLatitude()!= null && marshalMoveInOutDetailRequest.getMoveToLatitude().trim().length() > 0
                                        && marshalMoveInOutDetailRequest.getMoveToLongitude()!= null && marshalMoveInOutDetailRequest.getMoveToLongitude().trim().length() > 0
                                        && marshalMoveInOutDetailRequest.getPositionNumber()!= null && marshalMoveInOutDetailRequest.getPositionNumber().toString().trim().length() > 0
                                        && marshalMoveInOutDetailRequest.getSid()!= null && marshalMoveInOutDetailRequest.getSid().toString().trim().length() > 0
                                        ) {

                                        MarshalDetails marshalCheck = marshalDao.getMarshalDetailsByCode(marshalMoveInOutDetailRequest.getMarshalCode());
                                        
                                        if(marshalCheck != null )
                                        {
                                            
                                            PositionMaster positionCheck = positionMasterDao.getPositionMasterByPositionNumber(marshalMoveInOutDetailRequest.getPositionNumber());
                                            
                                            if(positionCheck != null )
                                            {                                                
                                                String timezoneCode =GigflexUtility.findSettingValueByName(globalSettingRepository, userTypeDao, GigflexConstants.ORGANIZATIONS, GigflexConstants.TIMEZONE);

                                                TimeZoneDetail tz = timeZoneRepository.getTimeZoneDetailByTimeZoneCode(timezoneCode);                                               
                                                String timezone = "";
                                                if (tz != null && tz.getId() > 0 && tz.getTimeZoneName() != null && tz.getTimeZoneName().trim().length() > 0) {

                                                   timezone = tz.getTimeZoneName();

                                                 }
                                                else
                                                {
                                                     GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                                        "Timezone not found.");
                                                        return derr.toString();
                                                }
                                                
                                                Date curDateTime = new Date();
                                                Date localDateTime = GigflexDateUtil.getGMTtoLocationDate(curDateTime, timezone, GigflexConstants.YYYY_MM_DD_HH_MM_SS);
                                                Date moveDate = GigflexDateUtil.getGMTtoLocationDate(curDateTime, timezone, GigflexConstants.YYYY_MM_DD);

                                                String moveInOutTime = GigflexDateUtil.convertDateToString(localDateTime, GigflexConstants.HH_MM_SS);
                                                
                                                MarshalMoveInOutDetail marshalMoveInOutDetail = new MarshalMoveInOutDetail();

                                                marshalMoveInOutDetail.setAction(marshalMoveInOutDetailRequest.getAction());
                                                marshalMoveInOutDetail.setMarshalCode(marshalMoveInOutDetailRequest.getMarshalCode()); 
                                                marshalMoveInOutDetail.setMoveDate(moveDate);
                                                marshalMoveInOutDetail.setMoveDateTime(curDateTime);
                                                marshalMoveInOutDetail.setMoveInOutTime(moveInOutTime);
                                                marshalMoveInOutDetail.setMoveToLatitude(marshalMoveInOutDetailRequest.getMoveToLatitude());
                                                marshalMoveInOutDetail.setMoveToLongitude(marshalMoveInOutDetailRequest.getMoveToLongitude());
                                                marshalMoveInOutDetail.setPositionNumber(marshalMoveInOutDetailRequest.getPositionNumber());
                                                marshalMoveInOutDetail.setSid(marshalMoveInOutDetailRequest.getSid());

                                                marshalMoveInOutDetail.setIpAddress(ip);

                                                MarshalMoveInOutDetail marshalMoveInOutDetailRes = marshalMoveInOutDetailDao.save(marshalMoveInOutDetail);

                                                

                                                if (marshalMoveInOutDetailRes != null && marshalMoveInOutDetailRes.getId() > 0) {
                                                    jsonobj.put("responsecode", 200);
                                                jsonobj.put("timestamp", new Date());    
                                                    jsonobj.put("message",
                                                                        "Marshal Move In Out Detail has been added successfully.");
                                                        ObjectMapper mapperObj = new ObjectMapper();
                                                        String Detail = mapperObj.writeValueAsString(marshalMoveInOutDetailRes);
                                                        jsonobj.put("data", new JSONObject(Detail));
                                                        kafkaService.sendAddMarshalMoveInOutDetail(marshalMoveInOutDetailRes);
                                                } else {
                                                    jsonobj.put("responsecode", 400);
                                                jsonobj.put("timestamp", new Date());    
                                                    jsonobj.put("message", "Failed");
                                                }
                                            }
                                            else
                                            {
                                                jsonobj.put("responsecode", 400);
                                                jsonobj.put("message", "Position Number is not valid.");
                                                jsonobj.put("timestamp", new Date());
                                            }
                                            
                                            
                                        }
                                        else
                                        {
                                            jsonobj.put("responsecode", 400);
                                            jsonobj.put("message", "Marshal Code is not valid.");
                                            jsonobj.put("timestamp", new Date());
                                        }
                                        
					
				} else {
					jsonobj.put("responsecode", 400);
					jsonobj.put("timestamp", new Date());
					jsonobj.put("message", "Action ,Marshal Code ,Move Date,Move In Out Time,Move To Latitude, Move To Longitude ,Position Number & SID should not be blank");
				}
			} else {
				jsonobj.put("responsecode", 400);
				jsonobj.put("message", "Input data is not valid.");
				jsonobj.put("timestamp", new Date());
			}
			res = jsonobj.toString();
		}catch (JSONException | JsonProcessingException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
		}
                catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
                        LOG.error("Error in saveMarshalMoveInOutDetail>>>>>>", e);
		}
		return res;
    }

    @Override
    public String findAllMarshalMoveInOutDetailByMarshalCodeAndBetweenDate(String marshalCode, String fromDate, String toDate) {
        
        String res = "";
		try {
                        JSONObject jsonobj = new JSONObject();
                        if(fromDate != null && fromDate.trim().length() > 0 &&  toDate != null && toDate.trim().length() > 0 
                                && marshalCode != null && marshalCode.trim().length() > 0 )
                        {                          
                            
                            Date fromDt = null;
                            Date toDt = null;
                            
                             try 
                            {
                                  if( !(GigflexDateUtil.isDate(fromDate.trim(), GigflexConstants.YYYY_MM_DD)))
                                  {
                                     GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                         "Plz send from date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
                                         return derr.toString();
                                  }
                                  
                                  if( !(GigflexDateUtil.isDate(toDate.trim(), GigflexConstants.YYYY_MM_DD)))
                                  {
                                     GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                         "Plz send to date in correct format("+GigflexConstants.YYYY_MM_DD+") ");
                                         return derr.toString();
                                  }
                                  
                                  
                                  fromDt=GigflexDateUtil.convertStringToDate(fromDate.trim(), GigflexConstants.YYYY_MM_DD);
                                  toDt=GigflexDateUtil.convertStringToDate(toDate.trim(), GigflexConstants.YYYY_MM_DD);

                                  
                            }
                            catch (Exception ex) {
                                      ex.printStackTrace();
                                      GigflexResponse derr = new GigflexResponse(400, new Date(),
                                                      "Plz send from date/to date   in correct format(yyyy-MM-dd) ");
                                      return derr.toString();
                            } 
                            
                            
                             if(fromDt == null || toDt == null)
                            {
                                 jsonobj.put("message", "Date conversion has been Failed.");
                                        jsonobj.put("responsecode", 500);
                                        jsonobj.put("timestamp", new Date());
                                        return jsonobj.toString();
                            }                                                      
                             
                             
                           MarshalDetails marshalCheck = marshalDao.getMarshalDetailsByCode(marshalCode.trim());
                                        
                            if(marshalCheck != null )
                            {

                                List<Object> objList = marshalMoveInOutDetailDao.getMarshalMoveInOutDetailBetweenDateByMarshalCode(fromDt,toDt,marshalCode);
                                List<MarshalMoveInOutDetailResponse> marshalMoveInOutDetailList = new ArrayList<MarshalMoveInOutDetailResponse>();
                                if(objList != null && objList.size() > 0)
                                {   
                                    String dtFormat=GigflexConstants.YYYY_MM_DD;
                                    String dateformat =GigflexUtility.findSettingValueByName(globalSettingRepository, userTypeDao, GigflexConstants.ORGANIZATIONS, GigflexConstants.DATEFORMAT);

                                    if(dateformat!=null && dateformat.trim().length()>0)
                                    {
                                        dtFormat=dateformat.trim();
                                    }                                   

                                    for (int i = 0; i < objList.size(); i++) {
                                        Object[] arr = (Object[]) objList.get(i);
                                        if (arr.length >= 3) {

                                            MarshalMoveInOutDetailResponse marshalMoveInOutDetailRes = new MarshalMoveInOutDetailResponse();
                                            String moveDt = "";

                                            MarshalDetails  marshalData = (MarshalDetails) arr[0];
                                            PositionMaster positionData = (PositionMaster) arr[1];
                                            MarshalMoveInOutDetail marshalMoveInOutData = (MarshalMoveInOutDetail) arr[2];


                                            if(marshalMoveInOutData.getMoveDate()!=null){                                       

                                             moveDt=GigflexDateUtil.convertDateToString(marshalMoveInOutData.getMoveDate(), dtFormat);
                                            }

                                            marshalMoveInOutDetailRes.setMoveDate(moveDt);      
                                            
                                            marshalMoveInOutDetailRes.setMarshalCode(marshalData.getMarshalCode());
                                            marshalMoveInOutDetailRes.setMarshalName(marshalData.getMarshalFirstName()+" "+marshalData.getMarshalLastName());
                                            marshalMoveInOutDetailRes.setAction(marshalMoveInOutData.getAction());
                                            marshalMoveInOutDetailRes.setMoveInOutTime(marshalMoveInOutData.getMoveInOutTime());
                                            marshalMoveInOutDetailRes.setMoveToLatitude(marshalMoveInOutData.getMoveToLatitude());
                                            marshalMoveInOutDetailRes.setMoveToLongitude(marshalMoveInOutData.getMoveToLongitude());
                                            marshalMoveInOutDetailRes.setPositionDecription(positionData.getPositionDescription());
                                            marshalMoveInOutDetailRes.setPositionNumber(positionData.getPositionNumber());
                                            marshalMoveInOutDetailRes.setSid(marshalMoveInOutData.getSid());
                                            marshalMoveInOutDetailRes.setDateFormat(dtFormat);

                                            marshalMoveInOutDetailList.add(marshalMoveInOutDetailRes);
                                        }

                                   }

                                }

                                if (marshalMoveInOutDetailList != null && marshalMoveInOutDetailList.size() > 0) {
                                        jsonobj.put("responsecode", 200);
                                        jsonobj.put("message", "Success");
                                        jsonobj.put("timestamp", new Date());
                                        ObjectMapper mapperObj = new ObjectMapper();
                                        String Detail = mapperObj.writeValueAsString(marshalMoveInOutDetailList);
                                        jsonobj.put("data", new JSONArray(Detail));
                                } else {
                                        jsonobj.put("responsecode", 404);
                                        jsonobj.put("message", "Record Not Found");
                                        jsonobj.put("timestamp", new Date());
                                }
                                
                            }
                            else
                            {
                                jsonobj.put("responsecode", 400);
                                jsonobj.put("message", "Marshal Code is not valid.");
                                jsonobj.put("timestamp", new Date());
                            }
                        }
                        else
                        {
                            jsonobj.put("responsecode", 404);
                            jsonobj.put("message", "Input is not valid");
                            jsonobj.put("timestamp", new Date());
                        }
			
			res = jsonobj.toString();
		}
                catch (JSONException ex) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"JSON parsing exception occurred.");
			res = derr.toString();
                        
		}
                catch (Exception e) {
			GigflexResponse derr = new GigflexResponse(500, new Date(),
					"Exception occurred.");
			res = derr.toString();
                        LOG.error("Error in getRotationByDateFilter>>>>>>", e);
		}
		return res;
    }

}
