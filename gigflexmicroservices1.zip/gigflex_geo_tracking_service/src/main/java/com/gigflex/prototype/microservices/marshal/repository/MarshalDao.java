/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.marshal.repository;

import com.gigflex.prototype.microservices.marshal.dtob.MarshalDetails;
import java.util.List;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

/**
 *
 * @author amit.kumar
 */
@Repository
public interface MarshalDao extends JpaRepository<MarshalDetails,Long>,JpaSpecificationExecutor<MarshalDetails>{
    
    @Query("SELECT md FROM MarshalDetails md  WHERE md.isDeleted != TRUE AND (md.primaryMobileNumber = :primaryMobileNumber OR md.secondaryMobileNumber = :primaryMobileNumber)")
    public MarshalDetails findByPrimaryMobileNumber(@Param("primaryMobileNumber") String primaryMobileNumber);

    @Query("SELECT md FROM MarshalDetails md  WHERE md.isDeleted != TRUE AND md.marshalEmail = :marshalEmail")
    public MarshalDetails findByEmail(@Param("marshalEmail") String marshalEmail);

    @Query("SELECT md FROM MarshalDetails md  WHERE md.isDeleted != TRUE AND (md.secondaryMobileNumber = :secondaryMobileNumber OR md.primaryMobileNumber = :secondaryMobileNumber)")
    public MarshalDetails findBySecondaryMobileNumber(@Param("secondaryMobileNumber") String secondaryMobileNumber);

    @Query("SELECT md FROM MarshalDetails md  WHERE md.isDeleted != TRUE AND md.marshalEmail = :marshalEmail AND (md.primaryMobileNumber = :mobile OR md.marshalEmail = :mobile)")
    public MarshalDetails findByEmailAndMobile(String marshalEmail, String mobile);

    @Query("SELECT md FROM MarshalDetails md  WHERE md.isDeleted != TRUE AND (md.primaryMobileNumber = :mobile OR md.marshalEmail = :mobile)")
    public MarshalDetails findByMobile(String mobile);

    @Query("SELECT md FROM MarshalDetails md  WHERE md.isDeleted != TRUE AND md.marshalCode = :marshalCode")
    public MarshalDetails getMarshalDetailsByCode(String marshalCode);
    
    @Query("SELECT md FROM MarshalDetails md  WHERE md.isRegistered = TRUE AND md.isDeleted != TRUE AND md.marshalCode = :marshalCode")
    public MarshalDetails getRegisteredMarshalDetailsByCode(String marshalCode);
    
    @Query("SELECT md FROM MarshalDetails md  WHERE md.isRegistered = TRUE AND md.isDeleted != TRUE  ORDER BY md.marshalFirstName")
    public List<MarshalDetails> getAllRegisteredMarshals();
       
    @Query("SELECT md FROM MarshalDetails md  WHERE md.isRegistered = TRUE AND md.isDeleted != TRUE ORDER BY md.marshalFirstName")
    public List<MarshalDetails> getAllRegisteredMarshals(Pageable pageableRequest);
    
    @Query("SELECT md FROM MarshalDetails md  WHERE md.isRegistered = TRUE AND md.isDeleted != TRUE AND md.marshalCode IN (:codeList) ORDER BY md.marshalFirstName")
    public List<MarshalDetails> getAllRegisteredMarshalsByCodes(@Param("codeList") List<String> codeList);
    
    @Query("SELECT md FROM MarshalDetails md  WHERE md.isRegistered = TRUE AND md.isDeleted != TRUE AND md.marshalCode IN (:codeList) ORDER BY md.marshalFirstName")
    public List<MarshalDetails> getAllRegisteredMarshalsByCodes(@Param("codeList") List<String> codeList,Pageable pageableRequest);

    @Query("SELECT md FROM MarshalDetails md  WHERE md.isDeleted != TRUE  ORDER BY md.marshalFirstName")
    public List<MarshalDetails> getAllMarshalsList();
    
}
