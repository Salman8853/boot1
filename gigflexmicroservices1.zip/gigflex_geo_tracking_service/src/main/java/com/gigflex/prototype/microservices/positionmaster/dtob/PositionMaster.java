/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.positionmaster.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "position_master")
public class PositionMaster extends CommonAttributes implements Serializable{
    
     @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
        
        @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "position_code", unique = true)
	private String positionCode;
                       
        @Column(name = "position_number", nullable = false)
	private Long positionNumber;
        
        @Column(name = "radius")
        private Double radius;
        
        @PrePersist
        private void assignUUID() {
            if (this.getPositionCode() == null || this.getPositionCode().length() == 0) {
               this.setPositionCode(UUID.randomUUID().toString());
            }
        }
        
        @Column(name = "position_description", nullable = false)
	private String positionDescription;
        
        
        @Column(name = "role_description",columnDefinition = "TEXT", nullable = false)
	private String roleDescription;
        
        @Column(name = "position_side", nullable = false)
	private String positionSide;
        
        @Column(name = "is_critical", nullable = false)
	private Boolean isCritical;
        
        @Column(name = "is_sun", nullable = false)
	private Boolean isSun;
        
        @Column(name = "is_rotating", nullable = false)
	private Boolean isRotating;
        
        @Column(name = "position_latitude")
	private String positionLatitude;
        
        @Column(name = "position_longitude")
	private String positionLongitude;

        public Long getId() {
            return id;
        }

        public void setId(Long id) {
            this.id = id;
        }

        public String getPositionCode() {
            return positionCode;
        }

        public void setPositionCode(String positionCode) {
            this.positionCode = positionCode;
        }

        public Long getPositionNumber() {
            return positionNumber;
        }

        public void setPositionNumber(Long positionNumber) {
            this.positionNumber = positionNumber;
        }

        public String getPositionDescription() {
            return positionDescription;
        }

        public void setPositionDescription(String positionDescription) {
            this.positionDescription = positionDescription;
        }

        public String getRoleDescription() {
            return roleDescription;
        }

        public void setRoleDescription(String roleDescription) {
            this.roleDescription = roleDescription;
        }

        public String getPositionSide() {
            return positionSide;
        }

        public void setPositionSide(String positionSide) {
            this.positionSide = positionSide;
        }

        public Boolean isIsCritical() {
            return isCritical;
        }

        public void setIsCritical(Boolean isCritical) {
            this.isCritical = isCritical;
        }

        public Boolean isIsSun() {
            return isSun;
        }

        public void setIsSun(Boolean isSun) {
            this.isSun = isSun;
        }

        public Boolean isIsRotating() {
            return isRotating;
        }

        public void setIsRotating(Boolean isRotating) {
            this.isRotating = isRotating;
        }

        public String getPositionLatitude() {
            return positionLatitude;
        }

        public void setPositionLatitude(String positionLatitude) {
            this.positionLatitude = positionLatitude;
        }

        public String getPositionLongitude() {
            return positionLongitude;
        }

        public void setPositionLongitude(String positionLongitude) {
            this.positionLongitude = positionLongitude;
        }

    public Double getRadius() {
        return radius;
    }

    public void setRadius(Double radius) {
        this.radius = radius;
    }

              
}
