/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.marshal.service;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gigflex.prototype.microservices.marshal.dtob.MarshalDetails;
import com.gigflex.prototype.microservices.marshal.repository.MarshalDao;
import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

/**
 *
 * @author amit.kumar
 */
@Service
public class KafkaMarshalDetailConsumeFromUserRegistration {
    	 
       	    
        @Autowired
        MarshalDao marshalDao;
        private static final Logger LOG = LoggerFactory.getLogger(KafkaMarshalDetailConsumeFromUserRegistration.class);
        
        
         @KafkaListener(topics = "AddMarshalDetails")
	     public void listen(@Payload String message) {
	           ObjectMapper objectMapper = new ObjectMapper();
	        LOG.info("received message='{}'", message);
	        try{
                    
                    MarshalDetails notify = objectMapper.readValue(message, MarshalDetails.class);
	            LOG.info("received message for AddMarshalDetails='{}'", notify.getMarshalFirstName());
	            LOG.info("received message for AddMarshalDetails='{}'", notify.getMarshalEmail());	            
                     MarshalDetails md =new MarshalDetails();
                     md.setIpAddress(notify.getIpAddress());
                     md.setIsDeleted(notify.getIsDeleted());
                     md.setIsRegistered(notify.getIsRegistered());
                     md.setMarshalCode(notify.getMarshalCode());
                     md.setMarshalEmail(notify.getMarshalEmail());
                     md.setMarshalFirstName(notify.getMarshalFirstName());
                     md.setMarshalLastName(notify.getMarshalLastName());
                     md.setOrganizationCode(notify.getOrganizationCode());
                     md.setPrimaryCountryCode(notify.getPrimaryCountryCode());
                     md.setPrimaryMobileNumber(notify.getPrimaryMobileNumber());
                     md.setSecondaryCountryCode(notify.getSecondaryCountryCode());
                     md.setSecondaryMobileNumber(notify.getSecondaryMobileNumber());
                     md.setGroupId(notify.getGroupId());
	            marshalDao.save(md);
	            
	        }
	         catch (JsonParseException e) {
				LOG.error("In  KafkaMarshalDetailConsumeFromUserRegistration for AddMarshalDetails >>>>", e);
			} catch (JsonMappingException e) {
				LOG.error("In KafkaMarshalDetailConsumeFromUserRegistration for AddMarshalDetails >>>>", e);
			} catch (IOException e) {
				LOG.error("In KafkaMarshalDetailConsumeFromUserRegistration for AddMarshalDetails >>>>", e);
			}catch (Exception e) {
				LOG.error("In KafkaMarshalDetailConsumeFromUserRegistration for AddMarshalDetails >>>>", e);
			}
	         
	     }
}
