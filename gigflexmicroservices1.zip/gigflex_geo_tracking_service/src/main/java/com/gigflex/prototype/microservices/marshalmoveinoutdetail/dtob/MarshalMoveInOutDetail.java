/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.gigflex.prototype.microservices.marshalmoveinoutdetail.dtob;

import com.gigflex.prototype.microservices.util.CommonAttributes;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;

/**
 *
 * @author amit.kumar
 */
@Entity
@Table(name = "marshal_move_in_out_detail")
public class MarshalMoveInOutDetail extends CommonAttributes implements Serializable{
    
        @Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long id;
        
        @GeneratedValue(generator = "uuid", strategy = GenerationType.AUTO)
	@GenericGenerator(name = "uuid", strategy = "uuid2")
	@Column(name = "marshal_move_in_out_detail_code", unique = true)
	private String marshalMoveInOutDetailCode;
                       
        @Column(name = "marshal_code",  nullable = false)
	private String marshalCode;
        
        @Column(name = "position_number", nullable = false)
	private Long positionNumber;
        
        @Column(name = "sid", nullable = false)
	private Long sid;
        
        @Column(name = "move_in_out_time")
        private String moveInOutTime;
        
        @Column(name = "move_date", columnDefinition = "DATE")
	private Date moveDate;
        
        @Column(name = "move_date_time", columnDefinition = "DATETIME")
	private Date moveDateTime;
	
        @Column(name = "move_to_latitude")
	private String moveToLatitude;
        
        @Column(name = "move_to_longitude")
	private String moveToLongitude;
        
        
        @Column(name = "move_action")
	private String action;
        
        @PrePersist
        private void assignUUID() {
            if (this.getMarshalMoveInOutDetailCode() == null || this.getMarshalMoveInOutDetailCode().length() == 0) {
               this.setMarshalMoveInOutDetailCode(UUID.randomUUID().toString());
            }
        }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMarshalMoveInOutDetailCode() {
        return marshalMoveInOutDetailCode;
    }

    public void setMarshalMoveInOutDetailCode(String marshalMoveInOutDetailCode) {
        this.marshalMoveInOutDetailCode = marshalMoveInOutDetailCode;
    }

    public String getMarshalCode() {
        return marshalCode;
    }

    public void setMarshalCode(String marshalCode) {
        this.marshalCode = marshalCode;
    }

    public Long getPositionNumber() {
        return positionNumber;
    }

    public void setPositionNumber(Long positionNumber) {
        this.positionNumber = positionNumber;
    }

    public Long getSid() {
        return sid;
    }

    public void setSid(Long sid) {
        this.sid = sid;
    }

    public String getMoveInOutTime() {
        return moveInOutTime;
    }

    public void setMoveInOutTime(String moveInOutTime) {
        this.moveInOutTime = moveInOutTime;
    }

    public Date getMoveDate() {
        return moveDate;
    }

    public void setMoveDate(Date moveDate) {
        this.moveDate = moveDate;
    }

    public Date getMoveDateTime() {
        return moveDateTime;
    }

    public void setMoveDateTime(Date moveDateTime) {
        this.moveDateTime = moveDateTime;
    }

    public String getMoveToLatitude() {
        return moveToLatitude;
    }

    public void setMoveToLatitude(String moveToLatitude) {
        this.moveToLatitude = moveToLatitude;
    }

    public String getMoveToLongitude() {
        return moveToLongitude;
    }

    public void setMoveToLongitude(String moveToLongitude) {
        this.moveToLongitude = moveToLongitude;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }
        
        
        
}
